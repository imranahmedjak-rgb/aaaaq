#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$HERE/payload/dist/public"
BACKUP="/var/backups/devglobaljobs-v62-click-only-$(date +%Y%m%d-%H%M%S)"

fail(){
  echo
  echo '============================================================'
  echo "SAFE STOP: $*"
  if [ -d "$BACKUP" ] && [ -f "$BACKUP/index.html" ]; then
    echo 'ROLLBACK: restoring the two pre-V62 frontend files...'
    cp -af "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -af "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    echo 'ROLLBACK COMPLETE.'
  fi
  echo 'NO PM2, BACKEND, DATABASE, CSS, RECRUITMENT, PAYMENT, SEO OR PWA CHANGE WAS REQUESTED.'
  echo '============================================================'
  exit 1
}

echo '============================================================'
echo 'DEV GLOBAL JOBS V62'
echo 'EMPLOYER SIDEBAR CLICK FUNCTION ONLY'
echo 'ZERO DESIGN / ZERO CSS / ZERO BACKEND CHANGE'
echo '============================================================'

cd "$HERE"
echo '1/7 CURRENT V60 BASELINE + HEALTH'
[ -f "$APP/dist/public/index.html" ] || fail 'live index missing'
[ -f "$APP/dist/public/assets/dgj-v51-employer.js" ] || fail 'live employer JS missing'
LIVE_IDX="$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')"
LIVE_EMP="$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')"
LIVE_RECJS="$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')"
LIVE_RECCSS="$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')"
[ "$LIVE_IDX" = "0bbad414a3193318bab69b1b83e4db8679d11297d386af2a34afcfe54062cf9c" ] || fail "index baseline is not exact restored V60 ($LIVE_IDX)"
[ "$LIVE_EMP" = "92bb0ad3f4c82ca993cb0c8c5e457c1ef71b40830b8cd9d2b24d7b791aefed70" ] || fail "employer JS baseline is not exact restored V60 ($LIVE_EMP)"
[ "$LIVE_RECJS" = "25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304" ] || fail 'recruitment JS differs; refusing unrelated overwrite'
[ "$LIVE_RECCSS" = "4fd6bc549aa36c3c674404d13c9e0ef0e65de46f23988daf759cce421b021042" ] || fail 'recruitment CSS differs; refusing unrelated overwrite'
CODE="$(curl -sS -o /tmp/dgj-v62-before.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "API health is $CODE"
echo 'PASS: exact restored V60 frontend and backend health verified.'

echo '2/7 PACKAGE PREFLIGHT'
bash "$HERE/preflight-v62.sh" || fail 'V62 preflight failed'

echo '3/7 PRIVATE TWO-FILE BACKUP'
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
echo "Backup: $BACKUP"

echo '4/7 ATOMIC TWO-FILE INSTALL'
install -m 0644 "$PAYLOAD/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v62.tmp"
install -m 0644 "$PAYLOAD/index.html" "$APP/dist/public/index.html.v62.tmp"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v62.tmp" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/index.html.v62.tmp" "$APP/dist/public/index.html"
echo 'PASS: only employer JS + index cache reference installed.'

echo '5/7 EXACT BYTE VERIFICATION'
[ "$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')" = "57a29871212ca558702f3af42e9380891e893a6449a1ae8b6f4849f58ce8b385" ] || fail 'installed index hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')" = "c4afaf399214c8a1f4aedacf6d4b66e5e80526ffc6571613f36c9873de8883e0" ] || fail 'installed employer JS hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')" = "25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304" ] || fail 'protected recruitment JS changed unexpectedly'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')" = "4fd6bc549aa36c3c674404d13c9e0ef0e65de46f23988daf759cce421b021042" ] || fail 'protected recruitment CSS changed unexpectedly'
echo 'PASS: exact bytes and protected assets verified.'

echo '6/7 ORIGIN CONTRACT — NO PM2 RELOAD'
IDX="$(curl -fsS --max-time 15 http://127.0.0.1:8080/)" || fail 'origin homepage fetch failed'
printf '%s' "$IDX" | grep -F 'dgj-v51-employer.js?v=62.0.0' >/dev/null || fail 'origin index does not expose V62 employer cache version'
JS="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v51-employer.js)" || fail 'origin employer JS fetch failed'
printf '%s' "$JS" | grep -F 'window.__DGJ_V62_CLICK_FUNCTION_ONLY__' >/dev/null || fail 'origin employer JS does not expose V62 marker'
echo 'PASS: origin serves V62 function-only repair without restarting backend.'

echo '7/7 FINAL HEALTH + SCOPE'
CODE="$(curl -sS -o /tmp/dgj-v62-after.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "post-install API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "post-install homepage health is $HOME"

echo '============================================================'
echo 'SUCCESS: V62 EMPLOYER CLICK FUNCTION ONLY IS LIVE'
echo '============================================================'
echo '✓ Existing V60 dashboard/post-job/sidebar design unchanged'
echo '✓ Existing switchPostToEmployerTab() used'
echo '✓ Existing activateEmployerTab() used'
echo '✓ Pointer target blocker bypassed by coordinate hit testing'
echo '✓ No CSS changed'
echo '✓ No recruitment/Easy Apply file changed'
echo '✓ No Admin file changed'
echo '✓ No backend/database/payment/SEO/PWA file changed'
echo '✓ No PM2 reload/restart performed'
echo "Rollback backup: $BACKUP"
echo '============================================================'
