Dev Global Jobs V62 — Employer Click Function Only

Purpose:
Repair mouse/touch activation of the EXISTING Employer Workspace sidebar without redesigning or replacing the sidebar.

Root interaction handled:
If another same-document layer receives the pointer target, V60's closest() click resolver cannot see the sidebar element. V62 keeps the exact V60 visual DOM and determines whether the pointer coordinates fell inside an existing sidebar control. It then calls the existing Employer Workspace tab functions.

No navigation architecture is replaced. No structural sidebar detach. No route redesign. No CSS changes.
