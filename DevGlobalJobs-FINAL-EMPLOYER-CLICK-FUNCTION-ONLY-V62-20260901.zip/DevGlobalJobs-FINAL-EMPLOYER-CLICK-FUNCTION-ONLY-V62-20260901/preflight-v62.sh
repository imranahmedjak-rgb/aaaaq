#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
sha256sum -c PAYLOAD-SHA256SUMS.txt
node --check payload/dist/public/assets/dgj-v51-employer.js >/dev/null
grep -Fq 'window.__DGJ_V62_CLICK_FUNCTION_ONLY__' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'switchPostToEmployerTab(t)' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "activateEmployerTab(t,true)" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'dgj-v51-employer.js?v=62.0.0' payload/dist/public/index.html
! grep -Fq 'dgj-v51-recruitment.js?v=62' payload/dist/public/index.html
! grep -Fq 'dgj-v51-recruitment.css?v=62' payload/dist/public/index.html
echo 'PASS: V62 function-only click repair verified.'
