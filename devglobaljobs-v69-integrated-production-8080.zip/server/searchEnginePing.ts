import { log } from "./index";

const BASE_URL = "https://devglobaljobs.com";
const INDEXNOW_KEY = "d8f4e2a1b7c3d9e5f6a0b4c8d2e7f1a3";

let lastPingTime = 0;
const PING_INTERVAL = 30 * 60 * 1000;

const CATEGORIES = ["all", "un", "ngo", "remote", "international", "technology", "healthcare", "business", "education", "engineering", "creative", "sales", "gig"];
const COUNTRY_SLUGS = ["uk", "us", "canada", "australia", "germany", "france", "india", "brazil", "south-africa", "netherlands", "poland", "italy", "belgium", "austria", "switzerland", "new-zealand", "singapore"];
const CITY_SLUGS = ["london","new-york","dubai","toronto","sydney","berlin","paris","amsterdam","singapore","tokyo","zurich","stockholm","geneva","vienna","brussels","melbourne","vancouver","boston","san-francisco","chicago","los-angeles","washington-dc","ottawa","dublin","edinburgh","madrid","barcelona","rome","oslo","copenhagen","helsinki","seoul","hong-kong","kuala-lumpur","bangkok","montreal","lisbon","abu-dhabi","warsaw","prague","budapest","cape-town","nairobi","istanbul","shanghai","munich","frankfurt","milan","auckland","denver"];

export async function pingSearchEngines(): Promise<void> {
  const now = Date.now();
  if (now - lastPingTime < PING_INTERVAL) return;
  lastPingTime = now;

  const sitemapUrl = encodeURIComponent(`${BASE_URL}/sitemap-index.xml`);

  const pingUrls = [
    `https://www.google.com/ping?sitemap=${sitemapUrl}`,
    `https://www.bing.com/ping?sitemap=${sitemapUrl}`,
  ];

  for (const url of pingUrls) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
      log(`Sitemap ping ${url.split("?")[0].split("//")[1].split("/")[0]}: ${res.status}`, "seo");
    } catch (e) {
      log(`Sitemap ping failed: ${url.split("//")[1]?.split("/")[0]}`, "seo");
    }
  }
}

export async function submitUrlsToIndexNow(urls: string[]): Promise<void> {
  if (urls.length === 0) return;

  const batch = urls.slice(0, 10000);

  try {
    const payload = {
      host: "devglobaljobs.com",
      key: INDEXNOW_KEY,
      keyLocation: `${BASE_URL}/${INDEXNOW_KEY}.txt`,
      urlList: batch,
    };

    const res = await fetch("https://api.indexnow.org/IndexNow", {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(15000),
    });

    log(`IndexNow submitted ${batch.length} URLs, status: ${res.status}`, "seo");
  } catch (e) {
    log(`IndexNow submission failed for ${batch.length} URLs`, "seo");
  }
}

let pendingUrls: string[] = [];
let submitTimeout: ReturnType<typeof setTimeout> | null = null;

export function queueUrlForIndexing(url: string): void {
  pendingUrls.push(url);

  if (submitTimeout) return;

  submitTimeout = setTimeout(async () => {
    const urls = [...pendingUrls];
    pendingUrls = [];
    submitTimeout = null;

    if (urls.length > 0) {
      await submitUrlsToIndexNow(urls);
      await pingSearchEngines();
    }
  }, 60000);
}

export function queueNewJobUrls(jobIds: number[]): void {
  for (const id of jobIds) {
    queueUrlForIndexing(`${BASE_URL}/jobs/detail/${id}`);
  }
}

export function submitAllPagesToIndexNow(): void {
  const urls: string[] = [BASE_URL];

  for (const cat of CATEGORIES) {
    urls.push(`${BASE_URL}/jobs/${cat}`);
  }

  for (const slug of COUNTRY_SLUGS) {
    urls.push(`${BASE_URL}/jobs/country/${slug}`);
  }

  for (const city of CITY_SLUGS) {
    urls.push(`${BASE_URL}/jobs/city/${city}`);
  }

  urls.push(`${BASE_URL}/post-job`);
  urls.push(`${BASE_URL}/about`);
  urls.push(`${BASE_URL}/privacy`);
  urls.push(`${BASE_URL}/terms`);

  for (const url of urls) {
    queueUrlForIndexing(url);
  }

  log(`Queued ${urls.length} page URLs for IndexNow submission`, "seo");
}

export function getIndexNowKey(): string {
  return INDEXNOW_KEY;
}
