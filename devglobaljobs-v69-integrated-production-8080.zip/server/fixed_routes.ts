import { Router } from "express";
import { db } from "./db";
import { sql } from "drizzle-orm";

const router = Router();

// Yeh function har country code ko sahi name aur slug mein badlega
const getCountryInfo = (code: string) => {
  const mapping: Record<string, {name: string, slug: string}> = {
    "US": { name: "United States", slug: "united-states" },
    "GB": { name: "United Kingdom", slug: "united-kingdom" },
    "PK": { name: "Pakistan", slug: "pakistan" },
    "IN": { name: "India", slug: "india" },
    "AE": { name: "United Arab Emirates", slug: "uae" },
    "ID": { name: "Indonesia", slug: "indonesia" },
    "KE": { name: "Kenya", slug: "kenya" },
    "NG": { name: "Nigeria", slug: "nigeria" },
    "PH": { name: "Philippines", slug: "philippines" }
  };
  return mapping[code] || { name: code, slug: code.toLowerCase() };
};

// API Endpoint Fix
router.get("/api/jobs/country/stats", async (_req, res) => {
  try {
    const result = await db.execute(sql`SELECT country, count(*) as count FROM jobs WHERE country IS NOT NULL GROUP BY country ORDER BY count DESC`);
    const stats = (result.rows as any[]).map(row => {
      const info = getCountryInfo(row.country);
      return { code: row.country, name: info.name, slug: info.slug, count: parseInt(row.count) };
    });
    res.json(stats);
  } catch (e) {
    res.status(500).json({ message: "Failed to fetch stats" });
  }
});
