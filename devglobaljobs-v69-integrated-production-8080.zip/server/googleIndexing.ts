import { GoogleAuth } from "google-auth-library";
import { log } from "./index";

const INDEXING_API_URL = "https://indexing.googleapis.com/v3/urlNotifications:publish";
const SCOPES = ["https://www.googleapis.com/auth/indexing"];
const BASE_URL = "https://devglobaljobs.com";

let authClient: any = null;

function getAuthClient() {
  if (authClient) return authClient;

  const saJson = process.env.GOOGLE_INDEXING_SA_JSON;
  if (!saJson) {
    log("Google Indexing API: GOOGLE_INDEXING_SA_JSON not set — skipping", "seo");
    return null;
  }

  try {
    const credentials = JSON.parse(saJson);
    authClient = new GoogleAuth({
      credentials,
      scopes: SCOPES,
    });
    return authClient;
  } catch (e) {
    log("Google Indexing API: Failed to parse service account JSON", "seo");
    return null;
  }
}

async function getAccessToken(): Promise<string | null> {
  try {
    const auth = getAuthClient();
    if (!auth) return null;
    const client = await auth.getClient();
    const tokenResponse = await client.getAccessToken();
    return tokenResponse.token || null;
  } catch (e: any) {
    log(`Google Indexing API: Auth error — ${e.message}`, "seo");
    return null;
  }
}

export async function notifyGoogleJobUrl(url: string, type: "URL_UPDATED" | "URL_DELETED" = "URL_UPDATED"): Promise<boolean> {
  const token = await getAccessToken();
  if (!token) return false;

  try {
    const res = await fetch(INDEXING_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({ url, type }),
      signal: AbortSignal.timeout(15000),
    });

    if (res.ok) {
      log(`Google Indexing API: ${type} submitted for ${url}`, "seo");
      return true;
    } else {
      const body = await res.text();
      log(`Google Indexing API: ${type} failed (${res.status}) for ${url} — ${body.slice(0, 200)}`, "seo");
      return false;
    }
  } catch (e: any) {
    log(`Google Indexing API: Request failed for ${url} — ${e.message}`, "seo");
    return false;
  }
}

let googlePendingUpdates: string[] = [];
let googlePendingDeletes: string[] = [];
let googleSubmitTimeout: ReturnType<typeof setTimeout> | null = null;
const DAILY_LIMIT = 190;
let dailyCount = 0;
let dailyResetAt = Date.now() + 24 * 60 * 60 * 1000;

function resetDailyCountIfNeeded() {
  if (Date.now() >= dailyResetAt) {
    dailyCount = 0;
    dailyResetAt = Date.now() + 24 * 60 * 60 * 1000;
  }
}

async function flushGoogleQueue() {
  resetDailyCountIfNeeded();
  const remaining = DAILY_LIMIT - dailyCount;
  if (remaining <= 0) {
    log(`Google Indexing API: Daily limit reached (${DAILY_LIMIT}/day), skipping`, "seo");
    googlePendingUpdates = [];
    googlePendingDeletes = [];
    return;
  }

  const updates = googlePendingUpdates.splice(0, Math.min(remaining, googlePendingUpdates.length));
  const deletes = googlePendingDeletes.splice(0, Math.min(remaining - updates.length, googlePendingDeletes.length));
  googleSubmitTimeout = null;

  for (const url of updates) {
    if (dailyCount >= DAILY_LIMIT) break;
    const ok = await notifyGoogleJobUrl(url, "URL_UPDATED");
    if (ok) dailyCount++;
    await new Promise(r => setTimeout(r, 200));
  }

  for (const url of deletes) {
    if (dailyCount >= DAILY_LIMIT) break;
    const ok = await notifyGoogleJobUrl(url, "URL_DELETED");
    if (ok) dailyCount++;
    await new Promise(r => setTimeout(r, 200));
  }
}

export function queueGoogleIndexingUpdate(jobId: number): void {
  const url = `${BASE_URL}/jobs/detail/${jobId}`;
  if (!googlePendingUpdates.includes(url)) {
    googlePendingUpdates.push(url);
  }
  scheduleFlush();
}

export function queueGoogleIndexingDelete(jobId: number): void {
  const url = `${BASE_URL}/jobs/detail/${jobId}`;
  if (!googlePendingDeletes.includes(url)) {
    googlePendingDeletes.push(url);
  }
  scheduleFlush();
}

export function queueGoogleBlogUpdate(slug: string): void {
  const url = `${BASE_URL}/blog/${slug}`;
  if (!googlePendingUpdates.includes(url)) {
    googlePendingUpdates.push(url);
  }
  scheduleFlush();
}

export function queueGoogleBlogDelete(slug: string): void {
  const url = `${BASE_URL}/blog/${slug}`;
  if (!googlePendingDeletes.includes(url)) {
    googlePendingDeletes.push(url);
  }
  scheduleFlush();
}

function scheduleFlush() {
  if (googleSubmitTimeout) return;
  googleSubmitTimeout = setTimeout(flushGoogleQueue, 60 * 1000);
}

export function queueGoogleIndexingBatch(jobIds: number[]): void {
  for (const id of jobIds) {
    const url = `${BASE_URL}/jobs/detail/${id}`;
    if (!googlePendingUpdates.includes(url)) {
      googlePendingUpdates.push(url);
    }
  }
  scheduleFlush();
}

export function getGoogleIndexingStatus(): { dailyCount: number; limit: number; pendingUpdates: number; pendingDeletes: number; resetsAt: string } {
  return {
    dailyCount,
    limit: DAILY_LIMIT,
    pendingUpdates: googlePendingUpdates.length,
    pendingDeletes: googlePendingDeletes.length,
    resetsAt: new Date(dailyResetAt).toISOString(),
  };
}
