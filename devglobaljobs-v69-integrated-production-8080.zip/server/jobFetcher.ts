import { storage } from "./storage";
import type { InsertJob } from "@shared/schema";
import { log } from "./index";
import sanitizeHtml from "sanitize-html";
import { classifyJobSkillCategory } from "./jobClassifier";
import { queueNewJobUrls, pingSearchEngines } from "./searchEnginePing";
import RSSParser from "rss-parser";

async function fetchWithRetry(url: string, options: RequestInit & { signal?: AbortSignal } = {}, maxRetries = 3): Promise<Response> {
  let lastError: Error = new Error("Unknown error");
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const res = await fetch(url, options);
      if (res.ok || res.status === 404) return res;
      if (res.status === 429 || res.status >= 500) {
        const delay = Math.min(1000 * Math.pow(2, attempt), 10000);
        await new Promise(r => setTimeout(r, delay));
        continue;
      }
      return res;
    } catch (err: any) {
      lastError = err;
      if (attempt < maxRetries - 1) {
        const delay = Math.min(1000 * Math.pow(2, attempt), 10000);
        await new Promise(r => setTimeout(r, delay));
      }
    }
  }
  throw lastError;
}

const COUNTRY_NAME_TO_CODE: Record<string, string> = {
  "united states": "US", "united states of america": "US", "usa": "US",
  "united kingdom": "GB", "uk": "GB", "great britain": "GB", "england": "GB", "scotland": "GB", "wales": "GB",
  "canada": "CA", "australia": "AU", "germany": "DE", "deutschland": "DE",
  "france": "FR", "india": "IN", "brazil": "BR", "brasil": "BR",
  "south africa": "ZA", "netherlands": "NL", "holland": "NL",
  "poland": "PL", "italy": "IT", "italia": "IT",
  "belgium": "BE", "austria": "AT", "switzerland": "CH",
  "new zealand": "NZ", "singapore": "SG",
  "spain": "ES", "portugal": "PT", "japan": "JP", "china": "CN",
  "south korea": "KR", "korea": "KR", "mexico": "MX",
  "sweden": "SE", "norway": "NO", "denmark": "DK", "finland": "FI",
  "ireland": "IE", "czech republic": "CZ", "czechia": "CZ",
  "romania": "RO", "hungary": "HU", "greece": "GR",
  "turkey": "TR", "russia": "RU", "ukraine": "UA",
  "argentina": "AR", "chile": "CL", "colombia": "CO",
  "philippines": "PH", "indonesia": "ID", "malaysia": "MY",
  "thailand": "TH", "vietnam": "VN", "pakistan": "PK",
  "bangladesh": "BD", "sri lanka": "LK", "nepal": "NP",
  "kenya": "KE", "nigeria": "NG", "ghana": "GH", "egypt": "EG",
  "morocco": "MA", "ethiopia": "ET", "tanzania": "TZ", "uganda": "UG",
  "united arab emirates": "AE", "uae": "AE", "saudi arabia": "SA",
  "israel": "IL", "qatar": "QA", "kuwait": "KW",
  "luxembourg": "LU", "malta": "MT", "cyprus": "CY",
  "iceland": "IS", "estonia": "EE", "latvia": "LV", "lithuania": "LT",
  "croatia": "HR", "serbia": "RS", "bulgaria": "BG", "slovakia": "SK", "slovenia": "SI",
};

function normalizeCountryCode(location: string | null | undefined, existingCode: string | null | undefined): string | null {
  if (existingCode && existingCode.length === 2) return existingCode.toUpperCase();
  if (!location) return null;
  const lower = location.toLowerCase().trim();
  for (const [name, code] of Object.entries(COUNTRY_NAME_TO_CODE)) {
    if (lower.includes(name)) return code;
  }
  if (lower.includes("remote") || lower === "global" || lower === "worldwide" || lower === "anywhere") return null;
  return null;
}

const UN_FULL_NAMES = [
  "United Nations", "UN Development Programme", "UN Children's Fund",
  "UN High Commissioner for Refugees", "UN Office for Project Services",
  "UN Educational, Scientific and Cultural Organization",
  "International Organization for Migration",
  "World Health Organization", "World Food Programme",
  "Food and Agriculture Organization", "International Labour Organization",
  "International Monetary Fund", "International Court of Justice",
  "International Criminal Court", "World Trade Organization",
  "World Bank Group", "UN Women", "UN Secretariat",
  "UN Peacekeeping", "UN Global Compact", "UN Volunteers",
  "UN-Habitat", "UN-SPIDER",
];

const UN_ACRONYMS = [
  "UNDP", "UNICEF", "UNHCR", "UNOPS", "UNESCO", "WFP", "FAO",
  "UNFPA", "UNEP", "UNODC", "UNCTAD", "UNIDO", "UNWTO",
  "IAEA", "OPCW", "CTBTO", "UNAIDS", "UNRWA", "UNITAR",
  "UNCDF", "UNCITRAL", "UNDSS", "UNDRR", "UNFCCC",
  "UNRISD", "UNSSC", "UNECE", "UNECA", "UNESCAP", "UNESCWA",
  "ECLAC", "ESCAP", "ESCWA", "OHCHR", "DPPA",
  "UNMISS", "MINUSMA", "MONUSCO", "UNIFIL", "UNDOF", "UNFICYP",
  "MINURSO", "MINUSCA", "UNISFA", "UNMIK", "UNSOM", "BINUH",
  "UNMAS", "IFAD",
];

const UN_EXACT_MATCH = [
  "WHO", "ILO", "ITU", "UPU", "WMO", "WIPO", "IOM", "IMF",
  "ICJ", "ICC", "WTO", "UNV", "UNU", "DPKO", "DPO",
  "ECA", "ECE", "OCHA", "DESA",
];

const NGO_FULL_NAMES = [
  "Save the Children", "Red Cross", "Red Crescent", "Oxfam",
  "CARE International", "Médecins Sans Frontières", "Doctors Without Borders",
  "World Vision", "International Rescue Committee", "Mercy Corps",
  "Catholic Relief Services", "Plan International", "ActionAid",
  "Amnesty International", "Human Rights Watch", "Greenpeace",
  "World Wildlife Fund", "Danish Refugee Council", "Norwegian Refugee Council",
  "Islamic Relief", "Action Against Hunger", "Action contre la Faim",
  "Handicap International", "Humanity & Inclusion",
  "Médecins du Monde", "Solidarités International",
  "Terre des hommes", "War Child", "SOS Children",
  "GOAL Global", "Concern Worldwide", "Welthungerhilfe",
  "Chemonics", "DAI Global", "DT Global", "Palladium",
  "FHI 360", "Jhpiego", "Population Services International",
  "Global Alliance for Improved Nutrition", "Clinton Health Access",
  "International Medical Corps", "One Acre Fund", "Heifer International",
  "Aga Khan Foundation", "Near East Foundation",
  "Lutheran World Federation", "Tearfund", "Relief International",
  "International Alert", "Samaritan's Purse", "INTERSOS",
  "Première Urgence Internationale", "Cooperazione Internazionale",
  "Danish Church Aid", "Diakonia", "Mines Advisory Group", "HALO Trust",
  "Geneva Call", "MedGlobal", "UK-Med", "Peace Winds",
  "Committed To Good", "People in Need", "Malteser International",
  "Cordaid", "Médecins d'Afrique", "Search for Common Ground",
  "Internews", "Creative Associates", "Winrock International",
  "Management Sciences for Health", "International Center for Transitional Justice",
  "Transparency International", "Global Witness",
  "Doctors of the World", "Partners in Health",
  "WaterAid", "charity: water", "Habitat for Humanity", "Build Change",
  "Seeds of Peace", "Pathfinder International",
  "EngenderHealth", "Marie Stopes", "IMPACT Initiatives", "REACH Initiative",
  "Polish Humanitarian Action", "Finnish Red Cross",
  "Danish Red Cross", "British Red Cross", "American Red Cross",
  "Fédération internationale pour les droits humains",
  "International Crisis Group", "Aga Khan Development Network",
  "SEED Madagascar", "African Wildlife Foundation",
  "Conservation International", "The Nature Conservancy",
  "Global Fund", "GAVI Alliance", "Pathfinder",
  "Water.org",
];

const NGO_ACRONYMS = [
  "ACTED", "COOPI", "ICRC", "IFRC", "FIDH", "AKDN", "ICTJ",
  "WWF",
];

const NGO_EXACT_MATCH = [
  "MSF", "IRC", "CRS", "DRC", "NRC", "PSI", "GAIN", "CHAI",
  "IMC", "MDM", "BRAC", "PUI", "MAG", "CTG", "PIN", "ZOA",
  "MSH", "ICG", "JSI", "PATH", "Pact", "Gavi", "Ipas", "Caritas",
];

function matchesWordBoundary(text: string, term: string): boolean {
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(`(?:^|[\\s,;:()/\\-])${escaped}(?:$|[\\s,;:()/\\-])`, "i");
  return regex.test(text);
}

function isUNOrganization(orgName: string): boolean {
  const lower = orgName.toLowerCase();
  if (UN_FULL_NAMES.some((name) => lower.includes(name.toLowerCase()))) return true;
  if (UN_ACRONYMS.some((acr) => lower.includes(acr.toLowerCase()))) return true;
  if (UN_EXACT_MATCH.some((exact) => matchesWordBoundary(orgName, exact))) return true;
  return false;
}

function isNGOOrganization(orgName: string): boolean {
  const lower = orgName.toLowerCase();
  if (NGO_FULL_NAMES.some((name) => lower.includes(name.toLowerCase()))) return true;
  if (NGO_ACRONYMS.some((acr) => lower.includes(acr.toLowerCase()))) return true;
  if (NGO_EXACT_MATCH.some((exact) => matchesWordBoundary(orgName, exact))) return true;
  return false;
}

function detectCategory(orgName: string, defaultCategory: string): string {
  if (isUNOrganization(orgName)) return "un";
  if (isNGOOrganization(orgName)) return "ngo";
  return defaultCategory;
}

function sanitizeDescription(html: string | undefined | null): string {
  if (!html) return "";
  return sanitizeHtml(html, {
    allowedTags: ["b", "i", "em", "strong", "p", "br", "ul", "ol", "li", "h2", "h3", "h4", "a", "span"],
    allowedAttributes: {
      a: ["href", "target", "rel"],
    },
  });
}

function assignSkillCategory(title: string, description: string, sourceCategory: string): string {
  const skill = classifyJobSkillCategory(title, description);
  if (skill) return skill;
  if (sourceCategory === "remote") return "technology";
  if (sourceCategory === "international") return "business";
  if (sourceCategory === "ngo") return "business";
  if (sourceCategory === "un") return "business";
  return "business";
}

const FRESHNESS_DAYS = 30;
const MIN_DESCRIPTION_LENGTH = 300;

function isWithinDays(dateStr: string | null | undefined, days: number): boolean {
  if (!dateStr) return false;
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return false;
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  return date >= cutoff;
}

async function fetchReliefWebJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    let page = 0;
    while (true) {
      const reliefUrl = "https://api.reliefweb.int/v2/jobs?appname=TrendNova-v5ofdaDo&limit=1000&offset=" + (page * 1000);
      const fromDate = new Date(Date.now() - FRESHNESS_DAYS * 24 * 60 * 60 * 1000);
      const fromDateStr = fromDate.toISOString().replace("Z", "+00:00").replace(/\.\d{3}/, "");
      const reliefBody = {
        fields: {
          include: ["title", "body", "url", "source.name", "country.name", "date.created", "date.closing", "type.name"]
        },
        sort: ["date.created:desc"],
        filter: {
          field: "date.created",
          value: {
            from: fromDateStr,
          }
        }
      };
      const res = await fetchWithRetry(reliefUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reliefBody),
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) {
        log(`ReliefWeb: API returned ${res.status} ${res.statusText}`, "jobFetcher");
        break;
      }
      const data = await res.json();
      const items = data.data || [];
      log(`ReliefWeb page ${page}: totalCount=${data.totalCount || 0}, items=${items.length}`, "jobFetcher");
      if (items.length === 0) break;

      for (const item of items) {
        const fields = item.fields;
        if (!isWithinDays(fields.date?.created, FRESHNESS_DAYS)) continue;
        const orgName = fields.source?.[0]?.name || "Unknown";
        const isUN = isUNOrganization(orgName);
        const country = fields.country?.map((c: any) => c.name).join(", ") || "";
        const title = fields.title || "Untitled";
        const desc = sanitizeDescription(fields.body);
        const sourceCategory = isUN ? "un" : "ngo";

        allJobs.push({
          title,
          organization: orgName,
          location: country,
          category: sourceCategory,
          description: desc,
          url: fields.url,
          source: "ReliefWeb",
          sourceId: `reliefweb-${item.id}`,
          jobType: fields.type?.[0]?.name || null,
          salary: null,
          country: normalizeCountryCode(country, null),
          closingDate: fields.date?.closing ? new Date(fields.date.closing) : null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, sourceCategory),
        });
      }
      if (items.length < 1000) break;
      page++;
    }
    log(`ReliefWeb: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`ReliefWeb error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchRemoteOKJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    const res = await fetchWithRetry("https://remoteok.com/api", {
      headers: { "User-Agent": "DevGlobalJobs/1.0" },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return [];
    const data = await res.json();

    for (const item of data.slice(1)) {
      if (!item.position) continue;
      if (!isWithinDays(item.date, FRESHNESS_DAYS)) continue;
      const title = item.position;
      const desc = sanitizeDescription(item.description);
      const loc = item.location || "Remote";
      allJobs.push({
        title,
        organization: item.company || "Unknown",
        location: loc,
        category: "remote",
        description: desc,
        url: item.url || item.apply_url,
        source: "RemoteOK",
        sourceId: `remoteok-${item.id}`,
        jobType: "Full-time",
        salary: item.salary || null,
        country: normalizeCountryCode(loc, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc, "remote"),
      });
    }
    log(`RemoteOK: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`RemoteOK error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchRemotiveJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    const res = await fetchWithRetry("https://remotive.com/api/remote-jobs?limit=0", {
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) return [];
    const data = await res.json();

    for (const item of data.jobs || []) {
      if (!isWithinDays(item.publication_date, FRESHNESS_DAYS)) continue;
      const title = item.title;
      const desc = sanitizeDescription(item.description);
      const remotiveLoc = item.candidate_required_location || "Remote";
      allJobs.push({
        title,
        organization: item.company_name || "Unknown",
        location: remotiveLoc,
        category: "remote",
        description: desc,
        url: item.url,
        source: "Remotive",
        sourceId: `remotive-${item.id}`,
        jobType: item.job_type?.replace(/_/g, " ") || "Full-time",
        salary: item.salary || null,
        country: normalizeCountryCode(remotiveLoc, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc, "remote"),
      });
    }
    log(`Remotive: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`Remotive error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchJobicyJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    const res = await fetchWithRetry("https://jobicy.com/api/v2/remote-jobs?count=500", {
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return [];
    const data = await res.json();

    for (const item of data.jobs || []) {
      if (!isWithinDays(item.pubDate, FRESHNESS_DAYS)) continue;
      const title = item.jobTitle;
      const desc = sanitizeDescription(item.jobDescription);
      const jobicyLoc = item.jobGeo || "Remote";
      allJobs.push({
        title,
        organization: item.companyName || "Unknown",
        location: jobicyLoc,
        category: "remote",
        description: desc,
        url: item.url,
        source: "Jobicy",
        sourceId: `jobicy-${item.id}`,
        jobType: item.jobType || "Full-time",
        salary: item.annualSalaryMin && item.annualSalaryMax
          ? `$${item.annualSalaryMin} - $${item.annualSalaryMax}`
          : null,
        country: normalizeCountryCode(jobicyLoc, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc, "remote"),
      });
    }
    log(`Jobicy: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`Jobicy error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchArbeitnowJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    let page = 1;
    while (true) {
      const res = await fetchWithRetry(`https://www.arbeitnow.com/api/job-board-api?page=${page}`, {
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.data || [];
      if (items.length === 0) break;

      let pageHasFresh = false;
      for (const item of items) {
        const arbeitnowCreatedRaw = item.created_at;
        const arbeitnowCreatedAt =
          typeof arbeitnowCreatedRaw === "number"
            ? new Date(
                arbeitnowCreatedRaw < 1000000000000
                  ? arbeitnowCreatedRaw * 1000
                  : arbeitnowCreatedRaw
              )
            : arbeitnowCreatedRaw;

        if (!isWithinDays(arbeitnowCreatedAt, FRESHNESS_DAYS)) continue;
        pageHasFresh = true;
        const title = item.title;
        const desc = sanitizeDescription(item.description);
        const isRemote = item.remote;
        const arbLoc = item.location || (isRemote ? "Remote" : "International");
        allJobs.push({
          title,
          organization: item.company_name || "Unknown",
          location: arbLoc,
          category: isRemote ? "remote" : detectCategory(item.company_name || "Unknown", "international"),
          description: desc,
          url: item.url,
          source: "Arbeitnow",
          sourceId: `arbeitnow-${item.slug}`,
          jobType: "Full-time",
          salary: null,
          country: normalizeCountryCode(arbLoc, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, isRemote ? "remote" : "international"),
        });
      }
      if (!pageHasFresh) break;
      page++;
    }
    log(`Arbeitnow: fetched ${allJobs.length} jobs (${page - 1} pages)`, "jobFetcher");
  } catch (err: any) {
    log(`Arbeitnow error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchTheMuseJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    let page = 1;
    while (true) {
      const res = await fetchWithRetry(`https://www.themuse.com/api/public/jobs?page=${page}&descending=true`, {
        signal: AbortSignal.timeout(20000),
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.results || [];
      if (items.length === 0) break;

      let pageHasFresh = false;
      for (const item of items) {
        if (!isWithinDays(item.publication_date, FRESHNESS_DAYS)) continue;
        pageHasFresh = true;
        const location = item.locations?.map((l: any) => l.name).join(", ") || "Global";
        const title = item.name;
        const desc = sanitizeDescription(item.contents);
        allJobs.push({
          title,
          organization: item.company?.name || "Unknown",
          location: location,
          category: detectCategory(item.company?.name || "Unknown", "international"),
          description: desc,
          url: item.refs?.landing_page,
          source: "The Muse",
          sourceId: `themuse-${item.id}`,
          jobType: item.type || "Full-time",
          salary: null,
          country: normalizeCountryCode(location, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, "international"),
        });
      }
      if (!pageHasFresh) break;
      page++;
    }
    log(`TheMuse: fetched ${allJobs.length} jobs (${page - 1} pages)`, "jobFetcher");
  } catch (err: any) {
    log(`TheMuse error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchHimalayasJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    let offset = 0;
    const batchSize = 20;
    while (true) {
      const res = await fetchWithRetry(`https://himalayas.app/jobs/api?limit=${batchSize}&offset=${offset}`, {
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.jobs || [];
      if (items.length === 0) break;

      let pageHasFresh = false;
      for (const item of items) {
        const himalayasDateRaw =
          item.pubDate || item.updated || item.createdAt;

        const himalayasDate =
          typeof himalayasDateRaw === "number"
            ? new Date(
                himalayasDateRaw < 1000000000000
                  ? himalayasDateRaw * 1000
                  : himalayasDateRaw
              )
            : himalayasDateRaw;

        if (!isWithinDays(himalayasDate, FRESHNESS_DAYS)) continue;
        pageHasFresh = true;
        const title = item.title;
        const desc = sanitizeDescription(item.description || item.excerpt);
        const location = item.locationRestrictions?.join(", ") || "Remote";
        const salary = item.minSalary && item.maxSalary
          ? `${item.currency || "$"}${item.minSalary.toLocaleString()} - ${item.currency || "$"}${item.maxSalary.toLocaleString()}`
          : null;
        allJobs.push({
          title,
          organization: item.companyName || "Unknown",
          location,
          category: "remote",
          description: desc,
          url: item.applicationLink || `https://himalayas.app/jobs/${item.guid}`,
          source: "Himalayas",
          sourceId: `himalayas-${item.guid}`,
          jobType: item.employmentType || "Full-time",
          salary,
          country: normalizeCountryCode(location, null),
          closingDate: item.expiryDate ? new Date(item.expiryDate) : null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, "remote"),
        });
      }
      const actualLimit = Number(data.limit) || batchSize;

      if (!pageHasFresh || items.length < actualLimit) break;

      offset += actualLimit;
    }
    log(`Himalayas: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`Himalayas error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchWorkingNomadsJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    const res = await fetchWithRetry("https://www.workingnomads.com/api/exposed_jobs/", {
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return [];
    const data = await res.json();

    for (const item of data || []) {
      if (!item.title) continue;
      if (!isWithinDays(item.pub_date, FRESHNESS_DAYS)) continue;
      const title = item.title;
      const desc = sanitizeDescription(item.description);
      const location = item.location || "Remote";
      allJobs.push({
        title,
        organization: item.company_name || "Unknown",
        location,
        category: "remote",
        description: desc,
        url: item.url,
        source: "WorkingNomads",
        sourceId: `workingnomads-${item.id || item.url}`,
        jobType: "Full-time",
        salary: null,
        country: normalizeCountryCode(location, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc, "remote"),
      });
    }
    log(`WorkingNomads: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`WorkingNomads error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

// Adzuna free plan: 250 calls/day
// Fetch interval: every 4 hours (6 fetches/day)
// Budget per fetch: 250 / 4hr = ~62 calls → 10 countries × 4 pages = 40 calls (safe margin)
const ADZUNA_COUNTRIES = ["us", "gb", "ca", "au", "in", "de", "fr", "nz", "za", "nl"];
const ADZUNA_MAX_PAGES_PER_COUNTRY = 4; // 4 pages × 50 results = 200 jobs/country
const ADZUNA_DAILY_CALL_LIMIT = 200; // stay well under 250/day hard limit

let lastAdzunaFetch = 0;
const ADZUNA_FETCH_INTERVAL = 4 * 60 * 60 * 1000; // fetch every 4 hours

// Daily call counter — resets at midnight
let adzunaDayCallCount = 0;
let adzunaLastResetDay = -1;

function checkAndResetAdzunaDaily() {
  const today = new Date().getUTCDay();
  if (today !== adzunaLastResetDay) {
    adzunaDayCallCount = 0;
    adzunaLastResetDay = today;
  }
}

async function fetchAdzunaJobs(): Promise<InsertJob[]> {
  const now = Date.now();
  if (lastAdzunaFetch > 0 && now - lastAdzunaFetch < ADZUNA_FETCH_INTERVAL) {
    return [];
  }

  checkAndResetAdzunaDaily();
  if (adzunaDayCallCount >= ADZUNA_DAILY_CALL_LIMIT) {
    log(`Adzuna: daily call limit reached (${adzunaDayCallCount}/${ADZUNA_DAILY_CALL_LIMIT}), skipping`, "jobFetcher");
    return [];
  }

  const allJobs: InsertJob[] = [];
  const appId = process.env.ADZUNA_APP_ID;
  const appKey = process.env.ADZUNA_APP_KEY;
  if (!appId || !appKey) {
    log("Adzuna: skipping (no API keys configured)", "jobFetcher");
    return [];
  }

  try {
    for (const country of ADZUNA_COUNTRIES) {
      if (adzunaDayCallCount >= ADZUNA_DAILY_CALL_LIMIT) {
        log(`Adzuna: daily limit hit mid-fetch, stopping at country ${country}`, "jobFetcher");
        break;
      }
      try {
        let page = 1;
        while (page <= ADZUNA_MAX_PAGES_PER_COUNTRY) {
          if (adzunaDayCallCount >= ADZUNA_DAILY_CALL_LIMIT) break;

          const url = `https://api.adzuna.com/v1/api/jobs/${country}/search/${page}?app_id=${appId}&app_key=${appKey}&results_per_page=50&max_days_old=${FRESHNESS_DAYS}&content-type=application/json`;
          const res = await fetchWithRetry(url, { signal: AbortSignal.timeout(20000) });
          adzunaDayCallCount++;

          if (res.status === 429) {
            log(`Adzuna ${country}: rate limited (429), stopping`, "jobFetcher");
            break;
          }
          if (!res.ok) break;

          const data = await res.json();
          const items = data.results || [];
          if (items.length === 0) break;

          for (const item of items) {
            const title = item.title?.replace(/<[^>]*>/g, "") || "Untitled";
            const desc = sanitizeDescription(item.description);
            const location = item.location?.display_name || country.toUpperCase();
            const org = item.company?.display_name || "Unknown";
            const salary = item.salary_min && item.salary_max
              ? `${item.salary_min.toLocaleString()} - ${item.salary_max.toLocaleString()}`
              : null;

            const PREMIUM_COUNTRIES = ["us", "gb", "ca", "au", "nz", "de", "nl", "fr"];
            const isSponsored = PREMIUM_COUNTRIES.includes(country) && !!salary;
            allJobs.push({
              title,
              organization: org,
              location,
              category: isSponsored ? "sponsored" : detectCategory(org, "international"),
              description: desc,
              url: item.redirect_url,
              source: "Adzuna",
              sourceId: `adzuna-${item.id}`,
              jobType: item.contract_type || "Full-time",
              salary,
              country: country.toUpperCase(),
              closingDate: null,
              isEmployerPosted: false,
              applyEmail: null,
              stripePaymentId: null,
              featured: false,
              skillCategory: assignSkillCategory(title, desc, "international"),
            });
          }
          if (items.length < 50) break;
          page++;
        }
      } catch (err: any) {
        log(`Adzuna ${country}: ${err.message}`, "jobFetcher");
      }
    }
    lastAdzunaFetch = Date.now();
    log(`Adzuna: fetched ${allJobs.length} jobs (${adzunaDayCallCount} API calls used today)`, "jobFetcher");
  } catch (err: any) {
    log(`Adzuna error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchUSAJobsJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  const apiKey = process.env.USAJOBS_API_KEY;
  const email = process.env.USAJOBS_EMAIL || "info@devglobaljobs.com";
  if (!apiKey) {
    log("USAJobs: skipping (no API key configured)", "jobFetcher");
    return [];
  }
  try {
    let page = 1;
    const maxPages = 20;
    while (page <= maxPages) {
      const url = `https://data.usajobs.gov/api/Search?DatePosted=${FRESHNESS_DAYS}&ResultsPerPage=500&Page=${page}`;
      const res = await fetchWithRetry(url, {
        headers: {
          "Authorization-Key": apiKey,
          "User-Agent": email,
        },
        signal: AbortSignal.timeout(30000),
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.SearchResult?.SearchResultItems || [];
      if (items.length === 0) break;

      for (const item of items) {
        const desc_obj = item.MatchedObjectDescriptor;
        if (!desc_obj) continue;
        const title = desc_obj.PositionTitle || "Untitled";
        const org = desc_obj.OrganizationName || desc_obj.DepartmentName || "US Government";
        const location = desc_obj.PositionLocationDisplay || "United States";
        const jobUrl = desc_obj.PositionURI || desc_obj.ApplyURI?.[0] || "";
        const salary = desc_obj.PositionRemuneration?.[0]?.Description || null;
        const schedule = desc_obj.PositionSchedule?.[0]?.Name || "Full-time";
        const qualifications = desc_obj.QualificationSummary || "";
        const duties = desc_obj.UserArea?.Details?.MajorDuties || "";
        const desc = sanitizeDescription(`<p>${qualifications}</p><p>${duties}</p>`);

        allJobs.push({
          title,
          organization: org,
          location,
          category: detectCategory(org, "international"),
          description: desc,
          url: jobUrl,
          source: "USAJobs",
          sourceId: `usajobs-${desc_obj.PositionID || item.MatchedObjectId}`,
          jobType: schedule,
          salary,
          country: "US",
          closingDate: desc_obj.ApplicationCloseDate ? new Date(desc_obj.ApplicationCloseDate) : null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, "international"),
        });
      }

      const totalResults = data.SearchResult?.SearchResultCountAll || 0;
      if (page * 500 >= totalResults) break;
      page++;
    }
    log(`USAJobs: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`USAJobs error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function fetchFindWorkJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    const findWorkToken =
      process.env.FINDWORK_API_KEY ||
      process.env.FINDWORK_TOKEN;

    if (!findWorkToken) {
      log(
        "FindWork skipped: FINDWORK_API_KEY is not configured",
        "jobFetcher"
      );
      return allJobs;
    }

    let page = 1;
    const maxPages = 10;
    while (page <= maxPages) {
      const res = await fetchWithRetry(`https://findwork.dev/api/jobs/?page=${page}&sort_by=date`, {
        signal: AbortSignal.timeout(15000),
        headers: {
          Authorization: `Token ${findWorkToken}`,
          Accept: "application/json",
        },
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.results || [];
      if (items.length === 0) break;

      for (const item of items) {
        if (!isWithinDays(item.date_posted, FRESHNESS_DAYS)) continue;
        const title = item.role || "Untitled";
        const desc = sanitizeDescription(item.text);
        const location = item.location || (item.remote ? "Remote" : "Global");
        allJobs.push({
          title,
          organization: item.company_name || "Unknown",
          location,
          category: item.remote ? "remote" : detectCategory(item.company_name || "Unknown", "international"),
          description: desc,
          url: item.url,
          source: "FindWork",
          sourceId: `findwork-${item.id}`,
          jobType: item.employment_type || "Full-time",
          salary: null,
          country: normalizeCountryCode(location, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, item.remote ? "remote" : "international"),
        });
      }
      if (!data.next) break;
      page++;
    }
    log(`FindWork: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`FindWork error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

const rssParser = new RSSParser();

async function fetchYouthOpportunitiesRSS(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  const feeds = [
    { url: "https://opportunitiesforyouth.org/feed/", source: "OpportunitiesForYouth" },
    { url: "https://opportunitiesforyouth.org/category/scholarships/feed/", source: "OpportunitiesForYouth" },
    { url: "https://opportunitiesforyouth.org/category/jobs/fellowship/feed/", source: "OpportunitiesForYouth" },
    { url: "https://scholarshipscorner.website/feed/", source: "ScholarshipsCorner" },
    { url: "https://scholarshipscorner.website/fellowships/feed/", source: "ScholarshipsCorner" },
    { url: "https://www2.fundsforngos.org/category/fellowships/feed/", source: "FundsForNGOs" },
    { url: "https://www2.fundsforngos.org/category/scholarships-2/feed/", source: "FundsForNGOs" },
  ];

  for (const feed of feeds) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      for (const item of (parsed.items || [])) {
        if (!item.title) continue;
        const title = item.title.trim();
        const link = item.link || "";
        const pubDate = item.pubDate || item.isoDate;
        const desc = sanitizeDescription(item["content:encoded"] || item.contentSnippet || item.content || "");
        const sourceId = `${feed.source.toLowerCase()}-${link || title}`;

        if (pubDate && !isWithinDays(pubDate, FRESHNESS_DAYS)) continue;

        allJobs.push({
          title,
          organization: feed.source === "OpportunitiesForYouth" ? "Opportunities For Youth" :
                         feed.source === "ScholarshipsCorner" ? "Scholarships Corner" :
                         "Funds For NGOs",
          location: "Global",
          category: "international",
          description: desc,
          url: link,
          source: feed.source,
          sourceId,
          jobType: "Fellowship",
          salary: null,
          country: null,
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: "youth",
        });
      }
      log(`${feed.source}: fetched ${parsed.items?.length || 0} items from RSS`, "jobFetcher");
    } catch (err: any) {
      log(`${feed.source} RSS error: ${err.message}`, "jobFetcher");
    }
  }

  log(`Youth RSS total: fetched ${allJobs.length} opportunities`, "jobFetcher");
  return allJobs;
}

async function fetchGulfJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  const gulfFeeds = [
    { url: "https://www.naukrigulf.com/jobs.rss", source: "NaukriGulf" },
    { url: "https://www.naukrigulf.com/jobs/rss?industry=IT+Software", source: "NaukriGulf" },
    { url: "https://www.naukrigulf.com/jobs/rss?industry=Finance+Accounts", source: "NaukriGulf" },
    { url: "https://www.naukrigulf.com/jobs/rss?industry=Healthcare+Medical", source: "NaukriGulf" },
  ];
  const GULF_COUNTRY_CODES: Record<string, string> = {
    "UAE": "AE", "United Arab Emirates": "AE", "Dubai": "AE", "Abu Dhabi": "AE",
    "Qatar": "QA", "Doha": "QA",
    "Saudi Arabia": "SA", "KSA": "SA", "Riyadh": "SA", "Jeddah": "SA",
    "Kuwait": "KW", "Oman": "OM", "Muscat": "OM", "Bahrain": "BH",
  };
  for (const feed of gulfFeeds) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      for (const item of (parsed.items || [])) {
        if (!item.title) continue;
        const title = item.title.replace(/<[^>]*>/g, "").trim();
        const link = item.link || "";
        const pubDate = item.pubDate || item.isoDate;
        if (pubDate && !isWithinDays(pubDate, FRESHNESS_DAYS)) continue;
        const desc = sanitizeDescription(item["content:encoded"] || item.contentSnippet || item.content || item.summary || "");
        const locationRaw = (item as any).location || "";
        const countryCode = Object.entries(GULF_COUNTRY_CODES).find(([k]) => locationRaw.includes(k) || title.includes(k))?.[1] || null;
        const sourceId = `gulf-${feed.source.toLowerCase()}-${link || title}`;
        allJobs.push({
          title,
          organization: item.author || "Gulf Employer",
          location: locationRaw || "Gulf Region",
          category: "sponsored",
          description: desc,
          url: link,
          source: feed.source,
          sourceId,
          jobType: "Full-time",
          salary: null,
          country: countryCode,
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, "international"),
        });
      }
      log(`${feed.source}: fetched ${parsed.items?.length || 0} Gulf jobs`, "jobFetcher");
    } catch (err: any) {
      log(`${feed.source} RSS error: ${err.message}`, "jobFetcher");
    }
  }
  return allJobs;
}

async function fetchWeWorkRemotelyJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  const feeds = [
    { url: "https://weworkremotely.com/remote-jobs.rss", cat: "remote" },
    { url: "https://weworkremotely.com/categories/remote-programming-jobs.rss", cat: "technology" },
    { url: "https://weworkremotely.com/categories/remote-design-jobs.rss", cat: "design" },
    { url: "https://weworkremotely.com/categories/remote-management-and-finance-jobs.rss", cat: "business" },
    { url: "https://weworkremotely.com/categories/remote-customer-support-jobs.rss", cat: "customer-support" },
    { url: "https://weworkremotely.com/categories/remote-devops-sysadmin-jobs.rss", cat: "technology" },
  ];
  for (const feed of feeds) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      for (const item of (parsed.items || [])) {
        if (!item.title) continue;
        const title = item.title.replace(/<[^>]*>/g, "").trim();
        const link = item.link || "";
        const pubDate = item.pubDate || item.isoDate;
        if (pubDate && !isWithinDays(pubDate, FRESHNESS_DAYS)) continue;
        const desc = sanitizeDescription(item["content:encoded"] || item.contentSnippet || item.content || item.summary || "");
        const org = item.author || (item["company"] as string) || "Remote Company";
        const sourceId = `weworkremotely-${link || title}`;
        allJobs.push({
          title,
          organization: org,
          location: "Remote / Worldwide",
          category: feed.cat,
          description: desc,
          url: link,
          source: "WeWorkRemotely",
          sourceId,
          jobType: "Remote",
          salary: null,
          country: null,
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: feed.cat === "technology" ? "technology" : feed.cat === "design" ? "design" : "business",
        });
      }
      log(`WeWorkRemotely (${feed.cat}): fetched ${parsed.items?.length || 0} items`, "jobFetcher");
    } catch (err: any) {
      log(`WeWorkRemotely RSS error (${feed.cat}): ${err.message}`, "jobFetcher");
    }
  }
  return allJobs;
}

async function fetchRemoteCoJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  const feeds = [
    { url: "https://remote.co/remote-jobs/feed/", cat: "remote" },
    { url: "https://remote.co/remote-jobs/developer/feed/", cat: "technology" },
    { url: "https://remote.co/remote-jobs/designer/feed/", cat: "design" },
    { url: "https://remote.co/remote-jobs/recruiter/feed/", cat: "hr" },
    { url: "https://remote.co/remote-jobs/manager/feed/", cat: "business" },
    { url: "https://remote.co/remote-jobs/customer-service/feed/", cat: "customer-support" },
    { url: "https://remote.co/remote-jobs/writer/feed/", cat: "content" },
    { url: "https://remote.co/remote-jobs/marketing/feed/", cat: "marketing" },
  ];
  for (const feed of feeds) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      for (const item of (parsed.items || [])) {
        if (!item.title) continue;
        const title = item.title.replace(/<[^>]*>/g, "").trim();
        const link = item.link || "";
        const pubDate = item.pubDate || item.isoDate;
        if (pubDate && !isWithinDays(pubDate, FRESHNESS_DAYS)) continue;
        const desc = sanitizeDescription(item["content:encoded"] || item.contentSnippet || item.content || item.summary || "");
        const org = item.author || "Remote Company";
        const sourceId = `remoteco-${link || title}`;
        allJobs.push({
          title,
          organization: org,
          location: "Remote / Worldwide",
          category: feed.cat,
          description: desc,
          url: link,
          source: "RemoteCo",
          sourceId,
          jobType: "Remote",
          salary: null,
          country: null,
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: feed.cat === "technology" ? "technology" : feed.cat === "design" ? "design" : "business",
        });
      }
      log(`Remote.co (${feed.cat}): fetched ${parsed.items?.length || 0} items`, "jobFetcher");
    } catch (err: any) {
      log(`Remote.co RSS error (${feed.cat}): ${err.message}`, "jobFetcher");
    }
  }
  return allJobs;
}

// Query open Greenhouse job boards for top companies — no API key required
const GREENHOUSE_COMPANIES = [
  "stripe", "airbnb", "coinbase", "doordash", "reddit", "pinterest", "lyft",
  "figma", "notion", "discord", "linear", "vercel", "shopify", "mongodb",
  "elastic", "cloudflare", "hashicorp", "confluent", "cockroachdb", "sentry",
  "postman", "brex", "ramp", "gusto", "rippling", "lattice", "intercom",
  "zendesk", "hubspot", "freshworks", "datadog", "crowdstrike", "okta",
  "twilio", "amplitude", "mixpanel", "segment", "fivetran", "dbt-labs",
  "airtable", "webflow", "retool", "supabase", "browserstack", "duolingo",
  "grammarly", "carta", "plaid", "robinhood", "chime", "openai",
];

/* DGJ_ASHBY_EMIRATES_FETCHERS_START */

async function fetchAshbyJobs() {
  const allJobs = [];

  const boards = [
    { slug: "openai", organization: "OpenAI" },
    { slug: "ramp", organization: "Ramp" },
    { slug: "notion", organization: "Notion" },
  ];

  for (const board of boards) {
    try {
      const response = await fetchWithRetry(
        `https://api.ashbyhq.com/posting-api/job-board/${board.slug}`,
        {
          signal: AbortSignal.timeout(45000),
          headers: {
            Accept: "application/json",
            "User-Agent": "DevGlobalJobsBot/1.0 (+https://devglobaljobs.com)",
          },
        }
      );

      if (!response.ok) {
        log(
          `Ashby ${board.organization}: HTTP ${response.status}`,
          "jobFetcher"
        );
        continue;
      }

      const data = await response.json();
      const jobs = Array.isArray(data.jobs) ? data.jobs : [];

      for (const item of jobs) {
        if (!item || !item.id || !item.title || item.isListed === false) {
          continue;
        }

        const description = sanitizeDescription(
          item.descriptionPlain ||
          item.descriptionHtml ||
          ""
        );

        const postalAddress =
          item.address &&
          item.address.postalAddress
            ? item.address.postalAddress
            : {};

        const primaryLocation =
          item.location ||
          postalAddress.addressLocality ||
          (item.isRemote ? "Remote" : "International");

        const secondaryLocations = Array.isArray(item.secondaryLocations)
          ? item.secondaryLocations
              .map((location: any) => {
                if (typeof location === "string") return location;

                return (
                  location.location ||
                  location.addressLocality ||
                  location.name ||
                  ""
                );
              })
              .filter(Boolean)
          : [];

        const location = [
          primaryLocation,
          ...secondaryLocations,
        ]
          .filter(Boolean)
          .filter((value, index, array) => array.indexOf(value) === index)
          .join(", ");

        const countryName =
          postalAddress.addressCountry ||
          location ||
          null;

        allJobs.push({
          title: item.title,
          organization: board.organization,
          location: location || "International",
          category: item.isRemote
            ? "remote"
            : detectCategory(
                item.department ||
                item.team ||
                board.organization,
                "international"
              ),
          description,
          url: item.applyUrl || item.jobUrl,
          source: "Ashby",
          sourceId: `ashby-${board.slug}-${item.id}`,
          jobType: item.employmentType || "Full-time",
          salary: null,
          country: normalizeCountryCode(countryName, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(
            item.title,
            description,
            item.isRemote ? "remote" : "international"
          ),
        });
      }

      log(
        `Ashby ${board.organization}: fetched ${jobs.length} jobs`,
        "jobFetcher"
      );
    } catch (error) {
      log(
        `Ashby ${board.organization} error: ${error instanceof Error ? error.message : String(error)}`,
        "jobFetcher"
      );
    }
  }

  log(
    `Ashby total: fetched ${allJobs.length} jobs`,
    "jobFetcher"
  );

  return allJobs;
}

async function fetchEmiratesGroupJobs() {
  const allJobs: InsertJob[] = [];

  try {
    const response = await fetchWithRetry(
      "https://www.emiratesgroupcareers.com/api/v1/jobs/",
      {
        signal: AbortSignal.timeout(45000),
        headers: {
          Accept: "application/json",
          "User-Agent": "Mozilla/5.0",
        },
      }
    );

    if (!response.ok) {
      log(
        `Emirates Group Careers: HTTP ${response.status}`,
        "jobFetcher"
      );
      return allJobs;
    }

    const data = await response.json();
    const jobs = Array.isArray(data.data) ? data.data : [];

    for (const item of jobs) {
      if (!item || !item.title || !item.redirectionurl) {
        continue;
      }

      const description = sanitizeDescription(
        item.jobdescription || ""
      );

      const location = [
        item.location,
        item.city,
        item.state,
        item.country,
      ]
        .filter(Boolean)
        .filter((value, index, array) => array.indexOf(value) === index)
        .join(", ");

      let closingDate = null;

      if (item.closingdate) {
        const closingValue = Number(item.closingdate);

        closingDate = Number.isFinite(closingValue)
          ? new Date(
              closingValue < 1000000000000
                ? closingValue * 1000
                : closingValue
            )
          : new Date(item.closingdate);

        if (
          closingDate instanceof Date &&
          Number.isNaN(closingDate.getTime())
        ) {
          closingDate = null;
        }
      }

      allJobs.push({
        title: item.title,
        organization:
          item.brand ||
          "Emirates Group",
        location: location || "Dubai, United Arab Emirates",
        category: detectCategory(
          item.category ||
          item.subcategory ||
          item.brand ||
          "Emirates Group",
          "international"
        ),
        description,
        url: item.redirectionurl,
        source: "EmiratesGroupCareers",
        sourceId: `emirates-${item.id || item.reqid || item.reqno}`,
        jobType: "Full-time",
        salary: null,
        country: normalizeCountryCode(
          item.country || location,
          null
        ),
        closingDate,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(
          item.title,
          description,
          "international"
        ),
      });
    }

    log(
      `Emirates Group Careers: fetched ${allJobs.length} jobs`,
      "jobFetcher"
    );
  } catch (error) {
    log(
      `Emirates Group Careers error: ${error instanceof Error ? error.message : String(error)}`,
      "jobFetcher"
    );
  }

  return allJobs;
}

/* DGJ_ASHBY_EMIRATES_FETCHERS_END */

async function fetchGreenhouseJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  const results = await Promise.allSettled(
    GREENHOUSE_COMPANIES.map(async (company) => {
      const url = `https://boards-api.greenhouse.io/v1/boards/${company}/jobs?content=true`;
      const res = await fetchWithRetry(url, { signal: AbortSignal.timeout(15000) }, 2);
      if (!res.ok) return [];
      const data = await res.json();
      const jobs: InsertJob[] = [];
      for (const job of (data.jobs || [])) {
        const title = job.title || "Untitled";
        const desc = sanitizeDescription(job.content || job.description || "");
        const locationName = job.location?.name || "Remote / Worldwide";
        const deptName = job.departments?.[0]?.name || "General";
        const updatedAt = job.updated_at;
        if (updatedAt && !isWithinDays(updatedAt, FRESHNESS_DAYS)) continue;
        jobs.push({
          title,
          organization: company.charAt(0).toUpperCase() + company.slice(1).replace(/-/g, " "),
          location: locationName,
          category: detectCategory(company, "technology"),
          description: desc,
          url: job.absolute_url || `https://boards.greenhouse.io/${company}/jobs/${job.id}`,
          source: "Greenhouse",
          sourceId: `greenhouse-${job.id}`,
          jobType: "Full-time",
          salary: null,
          country: normalizeCountryCode(locationName, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, "technology"),
        });
      }
      return jobs;
    })
  );
  let total = 0;
  for (const r of results) {
    if (r.status === "fulfilled") { allJobs.push(...r.value); total += r.value.length; }
  }
  log(`Greenhouse: fetched ${total} jobs from ${GREENHOUSE_COMPANIES.length} companies`, "jobFetcher");
  return allJobs;
}

// Query open Lever job boards for top companies — no API key required
const LEVER_COMPANIES = [
  "netflix", "khan-academy", "carta", "remote", "deel", "gofundme",
  "duolingo", "canva", "loom", "pitch", "doist", "basecamp",
  "automattic", "close", "zapier", "invision", "mattermost",
  "aha", "superside", "toptal", "crossover", "X-team",
  "convertkit", "calendly", "bevy", "hotjar", "netlify",
];

async function fetchLeverJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  const results = await Promise.allSettled(
    LEVER_COMPANIES.map(async (company) => {
      const url = `https://api.lever.co/v0/postings/${company}?mode=json`;
      const res = await fetchWithRetry(url, { signal: AbortSignal.timeout(15000) }, 2);
      if (!res.ok) return [];
      const data = await res.json();
      const jobs: InsertJob[] = [];
      for (const job of (Array.isArray(data) ? data : [])) {
        const title = job.text || "Untitled";
        const desc = sanitizeDescription(job.descriptionBody || job.description || "");
        const locationName = job.categories?.location || job.workplaceType || "Remote / Worldwide";
        const team = job.categories?.team || "General";
        const createdAt = job.createdAt ? new Date(job.createdAt).toISOString() : null;
        if (createdAt && !isWithinDays(createdAt, FRESHNESS_DAYS)) continue;
        jobs.push({
          title,
          organization: company.charAt(0).toUpperCase() + company.slice(1).replace(/-/g, " "),
          location: locationName,
          category: detectCategory(company, "technology"),
          description: desc,
          url: job.hostedUrl || job.applyUrl || "",
          source: "Lever",
          sourceId: `lever-${job.id}`,
          jobType: job.categories?.commitment || "Full-time",
          salary: null,
          country: normalizeCountryCode(locationName, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc, "technology"),
        });
      }
      return jobs;
    })
  );
  let total = 0;
  for (const r of results) {
    if (r.status === "fulfilled") { allJobs.push(...r.value); total += r.value.length; }
  }
  log(`Lever: fetched ${total} jobs from ${LEVER_COMPANIES.length} companies`, "jobFetcher");
  return allJobs;
}

async function fetchNoFluffJobs(): Promise<InsertJob[]> {
  const allJobs: InsertJob[] = [];
  try {
    const res = await fetchWithRetry("https://nofluffjobs.com/api/posting?salaryCurrency=USD&salaryPeriod=month", { signal: AbortSignal.timeout(15000) }, 2);
    if (!res.ok) { log(`NoFluffJobs: HTTP ${res.status}`, "jobFetcher"); return []; }
    const data = await res.json();
    const postings = data.postings || [];
    for (const item of postings) {
      const title = item.title || "Untitled";
      const org = item.name || item.company?.name || "Unknown Company";
      const cityRaw = item.location?.places?.[0]?.city;
      const locationName = (typeof cityRaw === "string" ? cityRaw : null) || (typeof item.location?.place === "string" ? item.location.place : null) || "Remote";
      const countryRaw = item.location?.places?.[0]?.country;
      const countryStr = typeof countryRaw === "string" ? countryRaw : (countryRaw && typeof countryRaw === "object" ? (countryRaw as any).name || null : null);
      const desc = sanitizeDescription((Array.isArray(item.requirements) ? item.requirements.join("\n") : "") || (typeof item.description === "string" ? item.description : "") || "");
      const salary = item.salary ? `${item.salary.from || ""} - ${item.salary.to || ""} ${item.salary.currency || ""}`.trim() : null;
      allJobs.push({
        title,
        organization: org,
        location: locationName,
        category: detectCategory(org, "technology"),
        description: desc,
        url: `https://nofluffjobs.com/job/${item.id}`,
        source: "NoFluffJobs",
        sourceId: `nofluff-${item.id}`,
        jobType: item.seniority?.[0] || "Full-time",
        salary,
        country: normalizeCountryCode(countryStr || locationName, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc, "technology"),
      });
    }
    log(`NoFluffJobs: fetched ${postings.length} jobs`, "jobFetcher");
  } catch (err: any) {
    log(`NoFluffJobs error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}

async function deduplicateAndStore(newJobs: InsertJob[]): Promise<number> {
  const uniqueJobs: InsertJob[] = [];
  const seenKeys = new Set<string>();
  let shortDescFiltered = 0;

  for (const job of newJobs) {
    const plainDesc = (job.description || "").replace(/<[^>]*>/g, "").trim();
    if (plainDesc.length < MIN_DESCRIPTION_LENGTH) { shortDescFiltered++; continue; }
    const key = job.sourceId || `${job.source}-${job.title}-${job.organization}`;
    if (seenKeys.has(key)) continue;
    seenKeys.add(key);
    uniqueJobs.push(job);
  }
  if (shortDescFiltered > 0) {
    log(`Filtered ${shortDescFiltered} jobs with descriptions < ${MIN_DESCRIPTION_LENGTH} chars`, "jobFetcher");
  }

  if (uniqueJobs.length > 0) {
    const insertedIds = await storage.insertJobsReturningIds(uniqueJobs);
    if (insertedIds.length > 0) {
      queueNewJobUrls(insertedIds);
    }
    return insertedIds.length;
  }

  return 0;
}

export async function fetchAllJobs(): Promise<void> {
  log("Starting job fetch cycle...", "jobFetcher");

  try {
    const results = await Promise.allSettled([
      fetchReliefWebJobs(),
      fetchRemoteOKJobs(),
      fetchRemotiveJobs(),
      fetchJobicyJobs(),
      fetchArbeitnowJobs(),
      fetchTheMuseJobs(),
      fetchHimalayasJobs(),
      fetchWorkingNomadsJobs(),
      fetchAdzunaJobs(),
      fetchUSAJobsJobs(),
      fetchYouthOpportunitiesRSS(),
      fetchWeWorkRemotelyJobs(),
      fetchGulfJobs(),
      fetchAshbyJobs(),
      fetchEmiratesGroupJobs(),
      fetchGreenhouseJobs(),
      fetchLeverJobs(),
      fetchNoFluffJobs(),
    ]);

    const allJobs: InsertJob[] = [];
    const sourceNames = [
      "ReliefWeb",
      "RemoteOK",
      "Remotive",
      "Jobicy",
      "Arbeitnow",
      "TheMuse",
      "Himalayas",
      "WorkingNomads",
      "Adzuna",
      "USAJobs",
      "YouthRSS",
      "WeWorkRemotely",
      "GulfJobs",
      "Ashby",
      "EmiratesGroupCareers",
      "Greenhouse",
      "Lever",
      "NoFluffJobs"
    ];
    let successCount = 0;
    let failCount = 0;
    for (let i = 0; i < results.length; i++) {
      const result = results[i];
      if (result.status === "fulfilled") {
        allJobs.push(...result.value);
        successCount++;
        if (result.value.length === 0) {
          log(`${sourceNames[i]}: returned 0 jobs`, "jobFetcher");
        }
      } else {
        log(`${sourceNames[i]}: failed - ${result.reason}`, "jobFetcher");
        failCount++;
      }
    }

    const insertedCount = await deduplicateAndStore(allJobs);
    log(`Job fetch complete: ${allJobs.length} fetched from ${successCount} sources, ${insertedCount} new jobs stored, ${failCount} sources failed`, "jobFetcher");

    const totalSources = results.length;
    const successRate = successCount / totalSources;
    const currentTotal = (await storage.getJobStats()).total || 0;
    const MIN_JOBS_FOR_CLEANUP = 5000;
    const MIN_SUCCESS_RATE = 0.5;

    if (successRate >= MIN_SUCCESS_RATE && currentTotal > MIN_JOBS_FOR_CLEANUP) {
      const cleanupStats = await storage.runFullCleanup();
      const totalCleaned = cleanupStats.expiredByClosingDate + cleanupStats.staleJobs + cleanupStats.employerRegular + cleanupStats.employerFeatured + cleanupStats.duplicates;
      log(`Auto-cleanup complete: ${totalCleaned} jobs removed [expired closing dates: ${cleanupStats.expiredByClosingDate}, stale 30d+: ${cleanupStats.staleJobs}, employer regular 30d+: ${cleanupStats.employerRegular}, employer featured 60d+: ${cleanupStats.employerFeatured}, duplicates: ${cleanupStats.duplicates}]`, "jobFetcher");
    } else {
      log(`Skipping cleanup: ${Math.round(successRate * 100)}% sources succeeded (need ${Math.round(MIN_SUCCESS_RATE * 100)}%), ${currentTotal} total jobs (need ${MIN_JOBS_FOR_CLEANUP}+)`, "jobFetcher");
    }

    if (insertedCount > 0) {
      pingSearchEngines().catch(() => {});
    }
  } catch (err: any) {
    log(`Job fetch cycle error: ${err.message}`, "jobFetcher");
  }
}

let isFetching = false;

export async function fetchAllJobsSafe(): Promise<void> {
  if (isFetching) {
    log("Fetch already in progress, skipping...", "jobFetcher");
    return;
  }
  isFetching = true;
  try {
    await fetchAllJobs();
  } finally {
    isFetching = false;
  }
}

const FETCH_INTERVAL = 30 * 60 * 1000;
const CLEANUP_INTERVAL = 6 * 60 * 60 * 1000;

async function runStartupCleanup(): Promise<void> {
  try {
    log("Running startup cleanup (removing duplicates + expired jobs)...", "jobFetcher");
    const stats = await storage.runFullCleanup();
    const total = stats.expiredByClosingDate + stats.staleJobs + stats.employerRegular + stats.employerFeatured + stats.duplicates;
    log(`Startup cleanup done: ${total} jobs removed [expired closing dates: ${stats.expiredByClosingDate}, stale 30d+: ${stats.staleJobs}, employer regular 30d+: ${stats.employerRegular}, employer featured 60d+: ${stats.employerFeatured}, duplicates: ${stats.duplicates}]`, "jobFetcher");
    const jobStats = await storage.getJobStats();
    log(`Database status after cleanup: ${jobStats.total} total jobs`, "jobFetcher");
  } catch (err: any) {
    log(`Startup cleanup error: ${err.message}`, "jobFetcher");
  }
}

async function runScheduledCleanup(): Promise<void> {
  try {
    log("Running scheduled cleanup...", "jobFetcher");
    const stats = await storage.runFullCleanup();
    const total = stats.expiredByClosingDate + stats.staleJobs + stats.employerRegular + stats.employerFeatured + stats.duplicates;
    if (total > 0) {
      log(`Scheduled cleanup: ${total} jobs removed [expired: ${stats.expiredByClosingDate}, stale: ${stats.staleJobs}, emp-regular: ${stats.employerRegular}, emp-featured: ${stats.employerFeatured}, duplicates: ${stats.duplicates}]`, "jobFetcher");
    } else {
      log("Scheduled cleanup: no stale jobs found, database is clean", "jobFetcher");
    }
  } catch (err: any) {
    log(`Scheduled cleanup error: ${err.message}`, "jobFetcher");
  }
}

const EXPIRED_CLEANUP_INTERVAL = 60 * 60 * 1000; // every 1 hour

async function runExpiredJobsCleanup(): Promise<void> {
  try {
    const removed = await storage.removeExpiredClosingDateJobs();
    if (removed > 0) {
      log(`Hourly expired cleanup: removed ${removed} jobs with passed closing dates`, "jobFetcher");
    }
  } catch (err: any) {
    log(`Hourly expired cleanup error: ${err.message}`, "jobFetcher");
  }
}

export function startJobFetchScheduler(): void {
  runStartupCleanup().then(() => {
    fetchAllJobsSafe();
  });

  setInterval(() => {
    fetchAllJobsSafe();
  }, FETCH_INTERVAL);

  setInterval(() => {
    runScheduledCleanup();
  }, CLEANUP_INTERVAL);

  setInterval(() => {
    runExpiredJobsCleanup();
  }, EXPIRED_CLEANUP_INTERVAL);

  log(`Job fetch scheduler started (fetch every ${FETCH_INTERVAL / 120000} min, cleanup every ${CLEANUP_INTERVAL / 31200000} hrs)`, "jobFetcher");
}
