import { storage } from "./storage";

const BASE_URL = "https://devglobaljobs.com";

const CATEGORIES = [
  { slug: "all", name: "All International Jobs", desc: "Browse every verified international job opportunity from Fortune 500 corporations, global tech leaders, financial institutions, government bodies, and top employers worldwide." },
  { slug: "un", name: "UN Jobs", desc: "Career opportunities with United Nations agencies and affiliated organizations worldwide." },
  { slug: "ngo", name: "NGO Jobs", desc: "Humanitarian and non-profit career opportunities from leading NGOs and development organizations." },
  { slug: "remote", name: "Remote Jobs", desc: "Work from anywhere positions at top remote-first companies and distributed teams worldwide." },
  { slug: "international", name: "International Jobs", desc: "Global career positions across 190+ countries from verified international employers." },
  { slug: "technology", name: "Technology Jobs", desc: "Software development, IT, data science, cybersecurity, and tech career opportunities." },
  { slug: "healthcare", name: "Healthcare Jobs", desc: "Medical, nursing, pharmaceutical, and public health career opportunities worldwide." },
  { slug: "business", name: "Business & Finance Jobs", desc: "Business, finance, accounting, management, and corporate career opportunities." },
  { slug: "education", name: "Education Jobs", desc: "Teaching, academic, training, and educational administration positions." },
  { slug: "engineering", name: "Engineering Jobs", desc: "Civil, mechanical, electrical, and technical engineering career opportunities." },
  { slug: "creative", name: "Creative & Media Jobs", desc: "Design, writing, video production, and digital marketing positions." },
  { slug: "sales", name: "Sales & Marketing Jobs", desc: "Sales, marketing, business development, and revenue growth positions." },
  { slug: "gig", name: "Gig Economy Jobs", desc: "Freelance, contract, part-time, and flexible work opportunities." },
];

const COUNTRIES: Record<string, string> = {
  uk: "United Kingdom", us: "United States", canada: "Canada", australia: "Australia",
  germany: "Germany", france: "France", india: "India", brazil: "Brazil",
  "south-africa": "South Africa", netherlands: "Netherlands", poland: "Poland",
  italy: "Italy", belgium: "Belgium", austria: "Austria", switzerland: "Switzerland",
  "new-zealand": "New Zealand", singapore: "Singapore",
};

const SLUG_TO_CODE: Record<string, string> = {
  uk: "GB", us: "US", canada: "CA", australia: "AU", germany: "DE",
  france: "FR", india: "IN", brazil: "BR", "south-africa": "ZA",
  netherlands: "NL", poland: "PL", italy: "IT", belgium: "BE",
  austria: "AT", switzerland: "CH", "new-zealand": "NZ", singapore: "SG",
};

const safe = (str: string) => str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

interface CachedSSR {
  data: { title: string; org: string; location: string; id: number }[];
  expires: number;
}

const ssrCache = new Map<string, CachedSSR>();
const SSR_CACHE_TTL = 10 * 60 * 1000;

async function getSSRJobs(category: string, limit: number = 20): Promise<{ title: string; org: string; location: string; id: number }[]> {
  const cacheKey = `cat:${category}`;
  const cached = ssrCache.get(cacheKey);
  if (cached && Date.now() < cached.expires) return cached.data;

  try {
    const result = await storage.getJobsPaginated(category === "all" ? undefined : category, limit, 0);
    const data = result.jobs.map(j => ({
      title: j.title,
      org: j.organization,
      location: j.location || "Worldwide",
      id: j.id,
    }));
    ssrCache.set(cacheKey, { data, expires: Date.now() + SSR_CACHE_TTL });
    return data;
  } catch {
    return [];
  }
}

async function getSSRCountryJobs(countryCode: string, limit: number = 20): Promise<{ title: string; org: string; location: string; id: number }[]> {
  const cacheKey = `country:${countryCode}`;
  const cached = ssrCache.get(cacheKey);
  if (cached && Date.now() < cached.expires) return cached.data;

  try {
    const result = await storage.getJobsByCountryPaginated(countryCode, limit, 0);
    const data = result.jobs.map(j => ({
      title: j.title,
      org: j.organization,
      location: j.location || "Worldwide",
      id: j.id,
    }));
    ssrCache.set(cacheKey, { data, expires: Date.now() + SSR_CACHE_TTL });
    return data;
  } catch {
    return [];
  }
}

function renderJobList(ssrJobs: { title: string; org: string; location: string; id: number }[]): string {
  if (ssrJobs.length === 0) return "<p>Loading job listings...</p>";
  return `<ul style="list-style:none;padding:0;margin:0">${ssrJobs.map(j =>
    `<li style="padding:12px 0;border-bottom:1px solid #e5e7eb"><a href="/jobs/detail/${j.id}" style="color:#1a56db;text-decoration:none;font-size:16px;font-weight:600;display:block">${safe(j.title)}</a><span style="color:#6b7280;font-size:14px">${safe(j.org)} &bull; ${safe(j.location)}</span></li>`
  ).join("")}</ul>`;
}

function renderCategoryNav(): string {
  return `<nav style="margin:32px 0" aria-label="Job Categories"><h2 style="font-size:20px;font-weight:700;margin-bottom:16px">Browse Jobs by Category</h2><ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px">${CATEGORIES.map(c =>
    `<li><a href="/jobs/${c.slug}" style="color:#1a56db;text-decoration:none;padding:6px 16px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:14px">${c.name}</a></li>`
  ).join("")}</ul></nav>`;
}

function renderCountryNav(): string {
  return `<nav style="margin:32px 0" aria-label="Jobs by Country"><h2 style="font-size:20px;font-weight:700;margin-bottom:16px">Browse Jobs by Country</h2><ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px">${Object.entries(COUNTRIES).map(([slug, name]) =>
    `<li><a href="/jobs/country/${slug}" style="color:#1a56db;text-decoration:none;padding:6px 16px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:14px">${name} Jobs</a></li>`
  ).join("")}</ul></nav>`;
}

function generateItemListSchema(ssrJobs: { title: string; org: string; id: number }[], pageName: string, pageUrl: string): string {
  if (ssrJobs.length === 0) return "";
  const schema = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    "name": pageName,
    "url": pageUrl,
    "numberOfItems": ssrJobs.length,
    "itemListElement": ssrJobs.map((j, i) => ({
      "@type": "ListItem",
      "position": i + 1,
      "url": `${BASE_URL}/jobs/detail/${j.id}`,
      "name": `${j.title} at ${j.org}`,
    })),
  };
  return `<script type="application/ld+json">${JSON.stringify(schema)}</script>`;
}

function generateCollectionPageSchema(pageName: string, pageDesc: string, pageUrl: string, totalJobs: number): string {
  return `<script type="application/ld+json">${JSON.stringify({
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": pageName,
    "description": pageDesc,
    "url": pageUrl,
    "isPartOf": { "@type": "WebSite", "name": "Dev Global Jobs", "url": BASE_URL },
    "provider": { "@type": "Organization", "name": "Trend Nova World Limited", "url": BASE_URL },
    "about": { "@type": "Thing", "name": `${pageName} on Dev Global Jobs` },
    ...(totalJobs > 0 ? { "mainEntity": { "@type": "ItemList", "numberOfItems": totalJobs } } : {}),
  })}</script>`;
}

function wrapSSR(content: string): string {
  return `<div id="ssr-content" style="max-width:1200px;margin:0 auto;padding:24px 16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#1f2937">${content}<footer style="margin-top:40px;padding-top:20px;border-top:1px solid #e5e7eb;color:#6b7280;font-size:13px"><p>Dev Global Jobs is operated by <strong>Trend Nova World Limited</strong>, a UK-registered company (No. 16709289).</p><p>27 Old Gloucester Street, London, WC1N 3AX, United Kingdom</p><p style="margin-top:8px"><a href="mailto:info@devglobaljobs.com" style="color:#1a56db">info@devglobaljobs.com</a> | <a href="tel:+447473863903" style="color:#1a56db">+44 7473 863903</a> | <a href="/about" style="color:#1a56db">About Us</a> | <a href="/privacy" style="color:#1a56db">Privacy Policy</a> | <a href="/terms" style="color:#1a56db">Terms of Service</a></p></footer></div>`;
}

export async function generateSSRContent(urlPath: string): Promise<{ body: string; headExtra: string }> {
  const path = urlPath.split("?")[0];

  const categoryMatch = path.match(/^\/jobs\/(all|un|ngo|remote|international|technology|healthcare|business|education|engineering|creative|sales|gig)$/);
  if (categoryMatch) {
    const cat = categoryMatch[1];
    const catInfo = CATEGORIES.find(c => c.slug === cat);
    const catName = catInfo?.name || cat;
    const catDesc = catInfo?.desc || "";
    const ssrJobs = await getSSRJobs(cat);
    const jobList = renderJobList(ssrJobs);
    const pageUrl = `${BASE_URL}/jobs/${cat}`;
    const itemListSchema = generateItemListSchema(ssrJobs, `${catName} - Dev Global Jobs`, pageUrl);
    const collectionSchema = generateCollectionPageSchema(catName, catDesc, pageUrl, ssrJobs.length);

    const relatedCategories = CATEGORIES.filter(c => c.slug !== cat).slice(0, 6);

    const body = wrapSSR(`
      <header style="margin-bottom:24px">
        <nav style="font-size:13px;color:#6b7280;margin-bottom:12px"><a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo; <a href="/jobs/all" style="color:#1a56db;text-decoration:none">Jobs</a> &rsaquo; <span>${safe(catName)}</span></nav>
        <h1 style="font-size:28px;font-weight:800;margin:0 0 12px;line-height:1.2">${safe(catName)} - Find Verified ${safe(catName)} Worldwide</h1>
        <p style="font-size:16px;color:#4b5563;line-height:1.6;margin:0">${safe(catDesc)} Updated every 30 minutes from 11 verified sources including ReliefWeb, RemoteOK, Adzuna, USAJobs, and more.</p>
      </header>
      <section>
        <h2 style="font-size:20px;font-weight:700;margin:0 0 16px">Latest ${safe(catName)} Opportunities</h2>
        ${jobList}
        <p style="margin-top:16px"><a href="/jobs/${cat}" style="color:#1a56db;font-weight:600">View all ${safe(catName.toLowerCase())} &rarr;</a></p>
      </section>
      <section style="margin-top:32px">
        <h2 style="font-size:18px;font-weight:700;margin-bottom:12px">Related Categories</h2>
        <ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px">${relatedCategories.map(c =>
          `<li><a href="/jobs/${c.slug}" style="color:#1a56db;text-decoration:none;padding:6px 16px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:14px">${c.name}</a></li>`
        ).join("")}</ul>
      </section>
      ${renderCountryNav()}
    `);

    return { body, headExtra: itemListSchema + collectionSchema };
  }

  const countryMatch = path.match(/^\/jobs\/country\/([a-z-]+)$/);
  if (countryMatch) {
    const slug = countryMatch[1];
    const countryName = COUNTRIES[slug];
    if (countryName) {
      const countryCode = SLUG_TO_CODE[slug] || slug.toUpperCase();
      const ssrJobs = await getSSRCountryJobs(countryCode);
      const jobList = renderJobList(ssrJobs);
      const pageUrl = `${BASE_URL}/jobs/country/${slug}`;
      const pageTitle = `${countryName} Jobs - International Careers in ${countryName}`;
      const pageDesc = `Browse verified international job opportunities in ${countryName}. Find careers at top employers, Fortune 500 companies, global tech leaders, financial institutions, and governments hiring in ${countryName}.`;
      const itemListSchema = generateItemListSchema(ssrJobs, pageTitle, pageUrl);
      const collectionSchema = generateCollectionPageSchema(pageTitle, pageDesc, pageUrl, ssrJobs.length);

      const otherCountries = Object.entries(COUNTRIES).filter(([s]) => s !== slug).slice(0, 8);

      const body = wrapSSR(`
        <header style="margin-bottom:24px">
          <nav style="font-size:13px;color:#6b7280;margin-bottom:12px"><a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo; <a href="/jobs/all" style="color:#1a56db;text-decoration:none">Jobs</a> &rsaquo; <span>${safe(countryName)} Jobs</span></nav>
          <h1 style="font-size:28px;font-weight:800;margin:0 0 12px;line-height:1.2">${safe(countryName)} Jobs - Find International Careers in ${safe(countryName)}</h1>
          <p style="font-size:16px;color:#4b5563;line-height:1.6;margin:0">${safe(pageDesc)} Updated continuously from 11 verified sources including ReliefWeb, RemoteOK, Adzuna, and more.</p>
        </header>
        <section>
          <h2 style="font-size:20px;font-weight:700;margin:0 0 16px">Latest Jobs in ${safe(countryName)}</h2>
          ${jobList}
        </section>
        <section style="margin-top:32px">
          <h2 style="font-size:18px;font-weight:700;margin-bottom:12px">Jobs in Other Countries</h2>
          <ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px">${otherCountries.map(([s, n]) =>
            `<li><a href="/jobs/country/${s}" style="color:#1a56db;text-decoration:none;padding:6px 16px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:14px">${n} Jobs</a></li>`
          ).join("")}</ul>
        </section>
        ${renderCategoryNav()}
      `);

      return { body, headExtra: itemListSchema + collectionSchema };
    }
  }

  const cityMatch = path.match(/^\/jobs\/city\/([a-z0-9-]+)$/);
  if (cityMatch) {
    const citySlug = cityMatch[1];
    const cityName = citySlug.replace(/-/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase());
    try {
      const cityJobs = await storage.getJobsByCityPaginated(citySlug.replace(/-/g, " "), 20, 0);
      const jobList = renderJobList(cityJobs.jobs.map(j => ({ title: j.title, org: j.organization, location: j.location || cityName, id: j.id })));
      const pageTitle = `Jobs in ${cityName} - International Careers | Dev Global Jobs`;
      const pageDesc = `Browse ${cityJobs.total > 0 ? cityJobs.total.toLocaleString() + "+" : "verified"} international job opportunities in ${cityName}. Find tech, finance, engineering, healthcare, and business roles from top employers. Updated daily.`;
      const pageUrl = `${BASE_URL}/jobs/city/${citySlug}`;
      const breadcrumbSchema = JSON.stringify({
        "@context": "https://schema.org", "@type": "BreadcrumbList",
        "itemListElement": [
          { "@type": "ListItem", "position": 1, "name": "Home", "item": BASE_URL },
          { "@type": "ListItem", "position": 2, "name": "All Jobs", "item": `${BASE_URL}/jobs/all` },
          { "@type": "ListItem", "position": 3, "name": `Jobs in ${cityName}`, "item": pageUrl },
        ],
      });
      const topCities = ["london","new-york","dubai","toronto","sydney","berlin","paris","amsterdam","singapore","tokyo","zurich","stockholm","geneva","vienna","brussels","melbourne","vancouver","dublin","madrid","barcelona"];
      const body = wrapSSR(`
        <header style="margin-bottom:24px">
          <nav style="font-size:13px;color:#6b7280;margin-bottom:12px">
            <a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo;
            <a href="/jobs/all" style="color:#1a56db;text-decoration:none"> All Jobs</a> &rsaquo;
            <span> Jobs in ${safe(cityName)}</span>
          </nav>
          <h1 style="font-size:28px;font-weight:800;margin:0 0 8px">Jobs in ${safe(cityName)} - International Careers</h1>
          <p style="font-size:16px;color:#4b5563;margin:0">${pageDesc}</p>
        </header>
        <section>
          <h2 style="font-size:20px;font-weight:700;margin:0 0 16px">Latest Jobs in ${safe(cityName)}</h2>
          ${jobList}
          <p style="margin-top:16px"><a href="/jobs/all" style="color:#1a56db;font-weight:600">Browse all international jobs &rarr;</a></p>
        </section>
        <section style="margin-top:32px">
          <h2 style="font-size:18px;font-weight:700;margin-bottom:12px">Other Major Cities</h2>
          <ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px">
            ${topCities.filter(c => c !== citySlug).map(c => {
              const cn = c.replace(/-/g, " ").replace(/\b\w/g, (l: string) => l.toUpperCase());
              return `<li><a href="/jobs/city/${c}" style="color:#1a56db;text-decoration:none;padding:6px 14px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:13px">${cn}</a></li>`;
            }).join("")}
          </ul>
        </section>
        ${renderCategoryNav()}
      `);
      return { body, headExtra: `<script type="application/ld+json">${breadcrumbSchema}</script>` };
    } catch (e) {
      console.error("[SSR] City page failed:", (e as Error).message);
    }
  }

  if (path === "/" || path === "") {
    const ssrJobs = await getSSRJobs("all", 30);
    const jobList = renderJobList(ssrJobs);

    let totalJobs = 0;
    try {
      const stats = await storage.getJobStats();
      totalJobs = stats.total || 0;
    } catch {}

    const body = wrapSSR(`
      <header style="margin-bottom:32px">
        <h1 style="font-size:32px;font-weight:800;margin:0 0 12px;line-height:1.2">Dev Global Jobs — World's #1 International Job Board</h1>
        <p style="font-size:18px;color:#4b5563;line-height:1.6;margin:0">${totalJobs > 0 ? `${totalJobs.toLocaleString()}+` : "Thousands of"} verified international job opportunities from Fortune 500 corporations, global tech leaders, financial institutions, government bodies, and top employers across 190+ countries. Updated every 30 minutes. Free for job seekers.</p>
      </header>

      <section>
        <h2 style="font-size:22px;font-weight:700;margin:0 0 16px">Featured Job Opportunities</h2>
        ${jobList}
        <p style="margin-top:16px"><a href="/jobs/all" style="color:#1a56db;font-weight:600;font-size:16px">Browse all jobs &rarr;</a></p>
      </section>

      ${renderCategoryNav()}
      ${renderCountryNav()}

      <section style="margin-top:32px">
        <h2 style="font-size:20px;font-weight:700;margin-bottom:12px">About Dev Global Jobs</h2>
        <p style="color:#4b5563;line-height:1.7">Dev Global Jobs aggregates verified job listings from 11 trusted international sources including RemoteOK, Remotive, Jobicy, Arbeitnow, The Muse, Himalayas, WorkingNomads, Adzuna (18 countries), USAJobs, ReliefWeb, and FindWork. Our platform serves international job seekers across 190+ countries with opportunities in technology, finance, healthcare, business, education, engineering, creative, sales, marketing, and the gig economy.</p>
        <p style="color:#4b5563;line-height:1.7;margin-top:8px">Operated by <a href="/about" style="color:#1a56db">Trend Nova World Limited</a>, a UK-registered company (No. 16709289), based at 27 Old Gloucester Street, London, WC1N 3AX.</p>
      </section>

      <section style="margin-top:32px">
        <h2 style="font-size:20px;font-weight:700;margin-bottom:12px">Why Choose Dev Global Jobs?</h2>
        <ul style="padding-left:20px;color:#4b5563;line-height:2">
          <li>11 verified job sources aggregated in real-time, updated every 30 minutes</li>
          <li>17 country-specific job pages for targeted local and international searches</li>
          <li>13 job categories spanning technology, healthcare, business, education, and more</li>
          <li>Jobs from UN agencies, NGOs, remote-first companies, and global employers</li>
          <li>Free for job seekers - browse and apply without registration</li>
          <li>Employers can post jobs for from $29 with global reach</li>
        </ul>
      </section>
    `);

    return { body, headExtra: "" };
  }

  if (path === "/privacy") {
    const body = wrapSSR(`
      <header><nav style="font-size:13px;color:#6b7280;margin-bottom:12px"><a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo; Privacy Policy</nav></header>
      <h1 style="font-size:28px;font-weight:800;margin-bottom:16px">Privacy Policy - Dev Global Jobs</h1>
      <p style="color:#6b7280;margin-bottom:24px">Last updated: ${new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })}</p>
      <section style="line-height:1.8;color:#374151">
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">1. Introduction</h2>
        <p>Dev Global Jobs, operated by Trend Nova World Limited, a company registered in the United Kingdom (Company Number: 16709289), is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website at devglobaljobs.com.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">2. Information We Collect</h2>
        <p>We may collect personal data when you post a job, including your company name, email address, and payment details submitted via Wise bank transfer. We automatically collect usage data including your IP address, browser type, operating system, and pages visited. We use cookies and similar tracking technologies to enhance your browsing experience and analyse website traffic through Google Analytics.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">3. How We Use Your Information</h2>
        <p>We use the information we collect to provide and maintain our job listing service, process job posting payments, send administrative information, improve our website and user experience, and protect against fraudulent activity.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">4. Data Sharing</h2>
        <p>We do not sell your personal information. We may share information with service providers who assist in operating our website (such as Wise for bank transfer processing and Google Analytics for analytics), or when required by law.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">5. Data Security</h2>
        <p>We implement appropriate technical and organisational security measures to protect your personal information. Payments are handled via Wise international bank transfer with full transaction verification.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">6. Your Rights</h2>
        <p>Under GDPR and UK data protection law, you have the right to access, correct, or delete your personal data. Contact us at info@devglobaljobs.com to exercise these rights.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">7. Contact Us</h2>
        <p>For privacy-related inquiries: <a href="mailto:info@devglobaljobs.com" style="color:#1a56db">info@devglobaljobs.com</a></p>
        <p>Trend Nova World Limited, 27 Old Gloucester Street, London, WC1N 3AX, United Kingdom.</p>
      </section>
      ${renderCategoryNav()}
    `);

    return { body, headExtra: "" };
  }

  if (path === "/terms") {
    const body = wrapSSR(`
      <header><nav style="font-size:13px;color:#6b7280;margin-bottom:12px"><a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo; Terms of Service</nav></header>
      <h1 style="font-size:28px;font-weight:800;margin-bottom:16px">Terms of Service - Dev Global Jobs</h1>
      <p style="color:#6b7280;margin-bottom:24px">Last updated: ${new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })}</p>
      <section style="line-height:1.8;color:#374151">
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">1. Agreement to Terms</h2>
        <p>By accessing and using Dev Global Jobs ("the Service"), operated by Trend Nova World Limited (UK Registered Company No. 16709289), you agree to be bound by these Terms of Service. If you do not agree, please do not use the Service.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">2. Description of Service</h2>
        <p>Dev Global Jobs is an international job aggregation and posting platform. We aggregate job listings from 11 verified sources including UN agencies, NGOs, remote job boards, and international employers. Employers can post paid job listings for a fee starting from $29 per posting. Job seekers have free access to browse and apply for positions.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">3. Job Listings</h2>
        <p>We aggregate jobs from multiple trusted sources. While we strive for accuracy, we do not guarantee the accuracy or completeness of any job listing. Job details are provided by employers and third-party sources. We are not responsible for the content of external job postings.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">4. User Responsibilities</h2>
        <p>Users must provide accurate information when posting jobs and comply with all applicable employment laws and regulations in their jurisdiction.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">5. Payment Terms</h2>
        <p>Job posting fees are $29 per listing, paid via secure bank transfer. All payments are non-refundable once the job listing is published.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">6. Intellectual Property</h2>
        <p>The Dev Global Jobs name, logo, and website design are the intellectual property of Trend Nova World Limited. Job listing content belongs to respective employers and sources.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">7. Contact Us</h2>
        <p>For questions about these terms: <a href="mailto:info@devglobaljobs.com" style="color:#1a56db">info@devglobaljobs.com</a></p>
        <p>Trend Nova World Limited, 27 Old Gloucester Street, London, WC1N 3AX, United Kingdom.</p>
      </section>
      ${renderCategoryNav()}
    `);

    return { body, headExtra: "" };
  }

  if (path === "/about") {
    const body = wrapSSR(`
      <header><nav style="font-size:13px;color:#6b7280;margin-bottom:12px"><a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo; About Us</nav></header>
      <h1 style="font-size:28px;font-weight:800;margin-bottom:16px">About Dev Global Jobs - International Job Board</h1>
      <section style="line-height:1.8;color:#374151">
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">Our Mission</h2>
        <p>Dev Global Jobs is the #1 international job aggregation platform, connecting global talent with career opportunities from UN agencies, NGOs, remote companies, and international employers worldwide. We aggregate verified job listings from 11 trusted sources to provide job seekers with access to thousands of international career opportunities across 17 countries and 13 job categories.</p>

        <h2 style="font-size:20px;margin-top:24px;font-weight:700">What We Offer</h2>
        <ul style="padding-left:20px;line-height:2">
          <li><strong>For Job Seekers:</strong> Free access to thousands of verified international job listings, searchable by category, country, and keyword</li>
          <li><strong>For Employers:</strong> Post jobs from $29 with visibility across Google Jobs, Bing, and our international audience</li>
          <li><strong>Real-time Updates:</strong> Jobs refreshed every 30 minutes from 11 verified sources</li>
          <li><strong>Global Reach:</strong> 17 country-specific pages and 13 job categories</li>
        </ul>

        <h2 style="font-size:20px;margin-top:24px;font-weight:700">Our Verified Sources</h2>
        <p>We aggregate jobs from: ReliefWeb (UN/humanitarian), RemoteOK, Remotive, Jobicy, Arbeitnow, The Muse, Himalayas, WorkingNomads, Adzuna (covering 18 countries), USAJobs (U.S. Government), and FindWork.</p>

        <h2 style="font-size:20px;margin-top:24px;font-weight:700">Company Information</h2>
        <ul style="list-style:none;padding:0;line-height:2.2">
          <li><strong>Company:</strong> Trend Nova World Limited</li>
          <li><strong>Company Number:</strong> 16709289 (UK Companies House)</li>
          <li><strong>Registered Address:</strong> 27 Old Gloucester Street, London, WC1N 3AX, United Kingdom</li>
          <li><strong>Email:</strong> <a href="mailto:info@devglobaljobs.com" style="color:#1a56db">info@devglobaljobs.com</a></li>
          <li><strong>Phone:</strong> <a href="tel:+447473863903" style="color:#1a56db">+44 7473 863903</a></li>
          <li><strong>WhatsApp:</strong> <a href="https://wa.me/994518673521" style="color:#1a56db">+994 51 867 35 21</a></li>
        </ul>

        <h2 style="font-size:20px;margin-top:24px;font-weight:700">Follow Us</h2>
        <ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:16px">
          <li><a href="https://www.linkedin.com/company/trendnovaworld/" style="color:#1a56db">LinkedIn</a></li>
          <li><a href="https://www.instagram.com/trendnovaworld/" style="color:#1a56db">Instagram</a></li>
          <li><a href="https://x.com/trendnovaworld" style="color:#1a56db">X (Twitter)</a></li>
          <li><a href="https://www.facebook.com/trendnovaworld" style="color:#1a56db">Facebook</a></li>
        </ul>
      </section>
      ${renderCategoryNav()}
      ${renderCountryNav()}
    `);

    return { body, headExtra: "" };
  }

  if (path === "/post-job") {
    const body = wrapSSR(`
      <header><nav style="font-size:13px;color:#6b7280;margin-bottom:12px"><a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo; Post a Job</nav></header>
      <h1 style="font-size:28px;font-weight:800;margin-bottom:16px">Post a Job on Dev Global Jobs - Reach Global Talent</h1>
      <section style="line-height:1.8;color:#374151">
        <p style="font-size:16px">Post your job listing on Dev Global Jobs and reach thousands of international professionals across 190+ countries. From <strong>$29 per listing</strong>.</p>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">Why Post on Dev Global Jobs?</h2>
        <ul style="padding-left:20px;line-height:2">
          <li>Reach qualified candidates worldwide across 17 countries</li>
          <li>Your job appears in search results, category pages, and country-specific pages</li>
          <li>Automatically indexed by Google Jobs and Bing for maximum visibility</li>
          <li>Trusted platform operated by a UK-registered company</li>
          <li>JobPosting structured data ensures rich results in search engines</li>
          <li>Jobs stay listed for 30 days with full visibility</li>
        </ul>
        <h2 style="font-size:20px;margin-top:24px;font-weight:700">How It Works</h2>
        <ol style="padding-left:20px;line-height:2">
          <li>Fill in your job details (title, company, location, description)</li>
          <li>Pay via Wise bank transfer ($29+)</li>
          <li>Your job goes live immediately across all relevant pages</li>
          <li>Get indexed by Google Jobs within hours</li>
        </ol>
      </section>
      ${renderCategoryNav()}
    `);

    return { body, headExtra: "" };
  }

  const detailMatch = path.match(/^\/jobs\/detail\/(\d+)$/);
  if (detailMatch) {
    try {
      const jobId = parseInt(detailMatch[1]);
      const job = await storage.getJobById(jobId);
      if (job) {
        const descRaw = job.description
          ? job.description.replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/\s+/g, " ").trim()
          : "";
        const descText = descRaw.substring(0, 5000);

        const sentences = descText.split(/(?<=[.!?])\s+/).filter(s => s.length > 10);
        let descParagraphs = "";
        if (sentences.length > 0) {
          const chunkSize = Math.max(3, Math.ceil(sentences.length / 4));
          for (let i = 0; i < sentences.length; i += chunkSize) {
            const chunk = sentences.slice(i, i + chunkSize).join(" ");
            descParagraphs += `<p style="color:#374151;margin-bottom:12px;line-height:1.8">${safe(chunk)}</p>`;
          }
        } else if (descText.length > 0) {
          descParagraphs = `<p style="color:#374151;margin-bottom:12px;line-height:1.8">${safe(descText)}</p>`;
        }

        const postedDate = job.postedAt
          ? new Date(job.postedAt).toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })
          : "Recently";

        const applyUrl = job.url || `${BASE_URL}/jobs/detail/${job.id}`;

        const body = wrapSSR(`
          <header>
            <nav style="font-size:13px;color:#6b7280;margin-bottom:12px"><a href="/" style="color:#1a56db;text-decoration:none">Home</a> &rsaquo; <a href="/jobs/all" style="color:#1a56db;text-decoration:none">Jobs</a> &rsaquo; <span>${safe(job.title)}</span></nav>
          </header>
          <article itemscope itemtype="https://schema.org/JobPosting">
            <h1 style="font-size:26px;font-weight:800;margin:0 0 8px" itemprop="title">${safe(job.title)}</h1>
            <p style="font-size:17px;color:#4b5563;margin-bottom:16px">
              <span itemprop="hiringOrganization" itemscope itemtype="https://schema.org/Organization"><span itemprop="name">${safe(job.organization)}</span></span>
              &bull; <span itemprop="jobLocation" itemscope itemtype="https://schema.org/Place"><span itemprop="address">${safe(job.location || "Worldwide")}</span></span>
            </p>
            <div style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:20px">
              ${job.jobType ? `<span style="background:#eff6ff;color:#1e40af;padding:4px 12px;border-radius:4px;font-size:13px;font-weight:600" itemprop="employmentType">${safe(job.jobType)}</span>` : ""}
              ${job.salary ? `<span style="background:#f0fdf4;color:#166534;padding:4px 12px;border-radius:4px;font-size:13px;font-weight:600">${safe(job.salary)}</span>` : ""}
              ${job.country ? `<span style="background:#fef3c7;color:#92400e;padding:4px 12px;border-radius:4px;font-size:13px;font-weight:600">${safe(job.country)}</span>` : ""}
              <span style="background:#f3f4f6;color:#374151;padding:4px 12px;border-radius:4px;font-size:13px">Posted: <time itemprop="datePosted">${postedDate}</time></span>
            </div>
            <div style="margin:20px 0;padding:20px;background:#eff6ff;border-radius:8px;text-align:center">
              <a href="${safe(applyUrl)}" style="color:#fff;background:#1a56db;padding:14px 40px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:700;font-size:16px" rel="noopener noreferrer">Apply for this position</a>
              <p style="margin-top:8px;font-size:13px;color:#6b7280">Application opens on the employer's website</p>
            </div>

            ${descParagraphs ? `
            <section style="margin:24px 0" itemprop="description">
              <h2 style="font-size:20px;font-weight:700;margin-bottom:16px">Job Description</h2>
              ${descParagraphs}
            </section>
            ` : `
            <section style="margin:24px 0">
              <h2 style="font-size:20px;font-weight:700;margin-bottom:16px">About This Position</h2>
              <p style="color:#374151;line-height:1.8">${safe(job.title)} at ${safe(job.organization)}. This is a ${safe(job.jobType || "full-time")} position${job.location ? ` based in ${safe(job.location)}` : " available worldwide"}. Apply through the link above to submit your application directly to the employer.</p>
            </section>
            `}

            <div style="margin-top:24px;padding:20px;background:#f9fafb;border-radius:8px">
              <h2 style="font-size:18px;font-weight:700;margin-bottom:12px">Job Overview</h2>
              <table style="width:100%;border-collapse:collapse;color:#4b5563;font-size:15px">
                <tr style="border-bottom:1px solid #e5e7eb"><td style="padding:8px 0;font-weight:600;width:140px">Company</td><td style="padding:8px 0">${safe(job.organization)}</td></tr>
                <tr style="border-bottom:1px solid #e5e7eb"><td style="padding:8px 0;font-weight:600">Location</td><td style="padding:8px 0">${safe(job.location || "Worldwide")}</td></tr>
                ${job.jobType ? `<tr style="border-bottom:1px solid #e5e7eb"><td style="padding:8px 0;font-weight:600">Job Type</td><td style="padding:8px 0">${safe(job.jobType)}</td></tr>` : ""}
                ${job.salary ? `<tr style="border-bottom:1px solid #e5e7eb"><td style="padding:8px 0;font-weight:600">Salary</td><td style="padding:8px 0">${safe(job.salary)}</td></tr>` : ""}
                ${job.category ? `<tr style="border-bottom:1px solid #e5e7eb"><td style="padding:8px 0;font-weight:600">Category</td><td style="padding:8px 0"><a href="/jobs/${job.category}" style="color:#1a56db;text-decoration:none">${safe(job.category.charAt(0).toUpperCase() + job.category.slice(1))}</a></td></tr>` : ""}
                <tr style="border-bottom:1px solid #e5e7eb"><td style="padding:8px 0;font-weight:600">Source</td><td style="padding:8px 0">${safe(job.source)}</td></tr>
                <tr><td style="padding:8px 0;font-weight:600">Posted</td><td style="padding:8px 0">${postedDate}</td></tr>
              </table>
            </div>

            <div style="margin-top:24px;padding:20px;background:#f0fdf4;border-radius:8px">
              <h2 style="font-size:18px;font-weight:700;margin-bottom:8px">How to Apply</h2>
              <p style="color:#374151;line-height:1.6">Click the "Apply for this position" button above to be redirected to the employer's application page. This job listing is sourced from ${safe(job.source)} and verified by Dev Global Jobs.</p>
              ${job.applyEmail ? `<p style="color:#374151;margin-top:8px">Or email your application to: <a href="mailto:${safe(job.applyEmail)}" style="color:#1a56db">${safe(job.applyEmail)}</a></p>` : ""}
            </div>
          </article>

          <section style="margin-top:32px">
            <h2 style="font-size:18px;font-weight:700;margin-bottom:12px">Similar Jobs</h2>
            <p style="color:#4b5563">Browse more opportunities:</p>
            <ul style="list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:8px;margin-top:8px">
              <li><a href="/jobs/all" style="color:#1a56db;text-decoration:none;padding:6px 16px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:14px">All Jobs</a></li>
              ${job.category ? `<li><a href="/jobs/${job.category}" style="color:#1a56db;text-decoration:none;padding:6px 16px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:14px">${safe(job.category.charAt(0).toUpperCase() + job.category.slice(1))} Jobs</a></li>` : ""}
              ${job.skillCategory ? `<li><a href="/jobs/${job.skillCategory}" style="color:#1a56db;text-decoration:none;padding:6px 16px;border:1px solid #d1d5db;border-radius:6px;display:inline-block;font-size:14px">${safe(job.skillCategory.charAt(0).toUpperCase() + job.skillCategory.slice(1))} Jobs</a></li>` : ""}
            </ul>
          </section>
          ${renderCategoryNav()}
        `);
        return { body, headExtra: "" };
      }
    } catch (e) {
      console.error("[SSR] Job detail content generation failed for id", detailMatch[1], ":", (e as Error).message);
    }
  }

  return { body: "", headExtra: "" };
}
