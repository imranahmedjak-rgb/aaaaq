import express, { type Express } from "express";
import fs from "fs";
import path from "path";
import { injectMetaTags, injectJobDetailMeta } from "./seoMeta";
import { storage } from "./storage";

export function serveStatic(app: Express) {
  const distPath = path.resolve(__dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`,
    );
  }

  app.use(express.static(distPath));

  app.use("/{*path}", async (_req, res) => {
    const indexPath = path.resolve(distPath, "index.html");
    let html = fs.readFileSync(indexPath, "utf-8");

    try {
      const urlPath = _req.originalUrl.split("?")[0];
      const detailMatch = urlPath.match(/^\/jobs\/detail\/(\d+)/);
      if (detailMatch) {
        const jobId = parseInt(detailMatch[1]);
        try {
          const job = await storage.getJobById(jobId);
          if (job) {
            html = injectJobDetailMeta(html, job);
          }
        } catch (e) {}
      } else {
        html = injectMetaTags(html, _req.originalUrl);
      }
    } catch (e) {}

    res.status(200).set("Content-Type", "text/html").send(html);
  });
}
