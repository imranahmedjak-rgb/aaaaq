const SKILL_CATEGORIES: Record<string, { keywords: string[]; titleKeywords: string[] }> = {
  technology: {
    titleKeywords: [
      "software", "developer", "engineer", "programming", "frontend", "backend",
      "fullstack", "full-stack", "full stack", "devops", "sre", "data scientist",
      "data engineer", "machine learning", "ml engineer", "ai engineer",
      "cloud engineer", "web developer", "mobile developer", "ios developer",
      "android developer", "qa engineer", "test engineer", "security engineer",
      "cybersecurity", "network engineer", "system administrator", "sysadmin",
      "database administrator", "dba", "tech lead", "cto", "vp engineering",
      "platform engineer", "infrastructure", "site reliability",
      "python developer", "java developer", "react developer", "node developer",
      "golang", "rust developer", ".net developer", "php developer",
      "ruby developer", "scala developer", "kotlin developer",
      "solutions architect", "cloud architect", "it manager", "it director",
      "scrum master", "agile coach", "product owner",
    ],
    keywords: [
      "javascript", "typescript", "python", "java", "react", "angular", "vue",
      "node.js", "nodejs", "aws", "azure", "gcp", "docker", "kubernetes",
      "terraform", "ci/cd", "api development", "microservices", "sql",
      "postgresql", "mongodb", "redis", "graphql", "rest api",
      "agile", "scrum", "jira", "github", "gitlab",
    ],
  },
  healthcare: {
    titleKeywords: [
      "nurse", "doctor", "physician", "surgeon", "medical", "clinical",
      "healthcare", "health care", "pharmacist", "pharmacy", "dental",
      "dentist", "therapist", "psychologist", "psychiatrist", "radiologist",
      "pathologist", "laboratory", "lab technician", "biomedical",
      "biotech", "biotechnology", "pharmaceutical", "epidemiologist",
      "public health", "health officer", "health specialist",
      "nutrition", "nutritionist", "dietitian", "veterinary",
      "optometrist", "physiotherapist", "occupational therapist",
      "speech therapist", "midwife", "paramedic", "emt",
      "health coordinator", "wash specialist", "wash officer",
      "medical officer", "health advisor", "clinical officer",
    ],
    keywords: [
      "patient care", "clinical trial", "drug development", "fda",
      "hipaa", "ehr", "electronic health", "telemedicine", "diagnosis",
      "treatment", "hospital", "clinic", "medical device",
      "life sciences", "genomics", "bioinformatics",
    ],
  },
  business: {
    titleKeywords: [
      "accountant", "accounting", "financial analyst", "finance manager",
      "controller", "cfo", "treasurer", "auditor", "tax specialist",
      "investment", "banker", "banking", "actuarial", "actuary",
      "economist", "business analyst", "operations manager",
      "supply chain", "logistics", "procurement", "purchasing",
      "compliance officer", "risk manager", "risk analyst",
      "management consultant", "strategy consultant", "consultant",
      "project manager", "program manager", "portfolio manager",
      "hr manager", "human resources", "recruiter", "talent acquisition",
      "compensation", "payroll", "benefits", "people operations",
      "office manager", "executive assistant", "chief of staff",
      "business development", "general manager", "coo",
      "fund manager", "grants manager", "budget", "fiscal",
    ],
    keywords: [
      "financial reporting", "gaap", "ifrs", "quickbooks", "sap",
      "oracle financials", "erp", "crm", "salesforce",
      "business intelligence", "kpi", "roi", "p&l",
      "strategic planning", "change management", "lean",
      "six sigma", "process improvement",
    ],
  },
  education: {
    titleKeywords: [
      "teacher", "professor", "instructor", "lecturer", "tutor",
      "education", "academic", "faculty", "dean", "principal",
      "curriculum", "training", "trainer", "learning", "e-learning",
      "teaching", "school", "university", "college",
      "research fellow", "research assistant", "postdoctoral",
      "librarian", "library", "admissions", "registrar",
      "education officer", "education specialist", "education coordinator",
      "capacity building", "workshop facilitator",
    ],
    keywords: [
      "pedagogy", "syllabus", "classroom", "student",
      "scholarship", "fellowship", "academic research",
      "distance learning", "online learning", "lms",
      "moodle", "canvas", "blackboard",
    ],
  },
  engineering: {
    titleKeywords: [
      "mechanical engineer", "civil engineer", "electrical engineer",
      "structural engineer", "chemical engineer", "industrial engineer",
      "manufacturing", "production engineer", "process engineer",
      "quality engineer", "quality assurance", "safety engineer",
      "environmental engineer", "mining engineer", "petroleum engineer",
      "aerospace engineer", "marine engineer", "naval architect",
      "construction manager", "site engineer", "project engineer",
      "maintenance engineer", "reliability engineer",
      "architect", "drafter", "cad", "autocad",
      "field engineer", "plant manager", "factory",
      "materials engineer", "metallurgist", "surveyor",
    ],
    keywords: [
      "manufacturing", "production", "assembly", "fabrication",
      "blueprint", "schematic", "iso 9001", "lean manufacturing",
      "cnc", "plc", "hvac", "piping", "welding",
      "structural analysis", "finite element", "solidworks",
      "catia", "revit", "bim",
    ],
  },
  creative: {
    titleKeywords: [
      "designer", "graphic designer", "ui designer", "ux designer",
      "ui/ux", "product designer", "visual designer", "brand designer",
      "creative director", "art director", "illustrator",
      "animator", "motion designer", "video editor", "videographer",
      "photographer", "cinematographer", "content creator",
      "copywriter", "copy editor", "editor", "journalist",
      "writer", "author", "blogger", "content writer",
      "social media manager", "community manager",
      "public relations", "pr specialist", "communications",
      "media specialist", "multimedia",
    ],
    keywords: [
      "photoshop", "illustrator", "figma", "sketch", "indesign",
      "after effects", "premiere", "final cut", "davinci",
      "typography", "branding", "visual identity", "wireframe",
      "prototype", "user research", "usability",
      "content strategy", "editorial", "storytelling",
    ],
  },
  sales: {
    titleKeywords: [
      "sales manager", "sales representative", "sales engineer",
      "account executive", "account manager", "key account",
      "business development", "bdr", "sdr",
      "marketing manager", "digital marketing", "marketing specialist",
      "seo specialist", "sem specialist", "ppc specialist",
      "growth hacker", "growth manager", "growth marketing",
      "customer success", "customer support", "customer service",
      "client relations", "partnership manager",
      "brand manager", "campaign manager", "demand generation",
      "revenue operations", "revops", "marketing director",
      "cmo", "vp sales", "head of sales", "head of marketing",
      "product marketing", "email marketing", "performance marketing",
      "advertising", "media buyer", "affiliate manager",
    ],
    keywords: [
      "lead generation", "pipeline", "quota", "commission",
      "hubspot", "marketo", "mailchimp", "google analytics",
      "a/b testing", "conversion", "funnel", "retention",
      "churn", "nps", "customer satisfaction", "upsell",
      "cross-sell", "cold calling", "outbound",
    ],
  },
  gig: {
    titleKeywords: [
      "freelance", "contractor", "contract", "temporary",
      "part-time", "part time", "intern", "internship",
      "consultant", "gig", "project-based",
      "flexible", "casual", "seasonal",
      "volunteer", "per diem",
    ],
    keywords: [
      "freelancing", "short-term", "contract work",
      "independent contractor", "1099", "self-employed",
      "remote work", "work from home", "telecommute",
      "flexible hours", "flexible schedule",
    ],
  },
  youth: {
    titleKeywords: [
      "fellowship", "scholar", "scholarship", "training program", "workshop",
      "youth", "young professional", "young leader", "exchange program",
      "volunteer program", "capacity building", "mentorship", "mentoring",
      "graduate program", "trainee", "apprentice", "apprenticeship",
      "summer program", "winter school", "spring school", "summer school",
      "bootcamp", "boot camp", "cohort", "accelerator program",
      "leadership program", "development program", "emerging leader",
      "junior professional", "early career", "entry level", "graduate trainee",
      "research grant", "grant opportunity", "funded program", "fully funded",
      "stipend", "bursary", "award program", "prize", "competition",
    ],
    keywords: [
      "fellowship", "scholarship", "fully funded", "stipend", "bursary",
      "training opportunity", "workshop", "seminar", "conference",
      "exchange", "mobility", "erasmus", "fulbright", "chevening",
      "commonwealth scholarship", "daad", "study abroad",
      "youth empowerment", "youth engagement", "youth development",
      "capacity development", "skill building", "professional development",
      "certificate program", "certification", "diploma program",
      "online course", "mooc", "webinar", "hackathon",
      "incubator", "innovation challenge", "pitch competition",
      "social impact", "civic engagement", "community service",
      "peace building", "sustainable development", "sdg",
      "global south", "developing countries", "emerging markets",
    ],
  },
};

export function classifyJobSkillCategory(title: string, description: string): string | null {
  const titleLower = title.toLowerCase();
  const descLower = (description || "").toLowerCase().substring(0, 2000);

  let bestMatch: string | null = null;
  let bestScore = 0;

  for (const [category, { titleKeywords, keywords }] of Object.entries(SKILL_CATEGORIES)) {
    let score = 0;

    for (const kw of titleKeywords) {
      if (titleLower.includes(kw.toLowerCase())) {
        score += 10;
      }
    }

    for (const kw of keywords) {
      if (titleLower.includes(kw.toLowerCase())) {
        score += 5;
      }
      if (descLower.includes(kw.toLowerCase())) {
        score += 1;
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestMatch = category;
    }
  }

  return bestScore >= 3 ? bestMatch : null;
}

export const SKILL_CATEGORY_LIST = Object.keys(SKILL_CATEGORIES);
