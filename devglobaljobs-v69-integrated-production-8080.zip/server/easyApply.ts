import type { Express, Request, Response } from "express";
import multer from "multer";
import nodemailer from "nodemailer";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "./db";
import { jobs } from "../shared/schema";

const MAX_CV_SIZE = 5 * 1024 * 1024;

interface CvFile {
  originalname: string;
  mimetype: string;
  size: number;
  buffer: Buffer;
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_CV_SIZE,
    files: 1,
  },
});

const easyApplyLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: "Too many applications. Please try again later.",
  },
});

const duplicateApplications = new Map<string, number>();
const DUPLICATE_WINDOW = 10 * 60 * 1000;

const applicationSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(180),
  phone: z.string().trim().min(6).max(40),
  currentCountry: z.string().trim().min(2).max(100),
  nationality: z.string().trim().min(2).max(100),
  currentJobTitle: z.string().trim().min(2).max(150),
  experienceYears: z.string().trim().min(1).max(30),
  qualification: z.string().trim().min(2).max(180),
  linkedin: z.string().trim().max(250).optional().or(z.literal("")),
  availability: z.string().trim().min(2).max(100),
  workAuthorization: z.string().trim().min(2).max(150),
  expectedSalary: z.string().trim().max(100).optional().or(z.literal("")),
  professionalSummary: z.string().trim().min(20).max(2500),
  coverLetter: z.string().trim().min(80).max(7000),
  consent: z.enum(["true"]),
});

const rejectedEmailPrefixes = [
  "support",
  "help",
  "privacy",
  "legal",
  "security",
  "abuse",
  "billing",
  "accounts",
  "webmaster",
  "info",
  "contact",
  "admin",
  "press",
  "media",
  "marketing",
  "sales",
  "noreply",
  "no-reply",
];

const positiveEmailTerms = [
  "apply",
  "application",
  "applications",
  "career",
  "careers",
  "cv",
  "resume",
  "recruit",
  "recruitment",
  "recruiter",
  "hiring",
  "hr",
  "job",
  "jobs",
  "vacancy",
  "talent",
];

function normalizeDescription(input: string): string {
  return input
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&#64;|&commat;/gi, "@")
    .replace(/&#46;|&period;/gi, ".")
    .replace(/\s+/g, " ")
    .replace(/\s*(?:\[at\]|\(at\)|\sat\s)\s*/gi, "@")
    .replace(/\s*(?:\[dot\]|\(dot\)|\sdot\s)\s*/gi, ".");
}

function isValidApplicationEmail(email: string): boolean {
  const value = email.toLowerCase().trim();
  const localPart = value.split("@")[0] || "";

  if (!z.string().email().safeParse(value).success) return false;
  if (value.length > 180) return false;
  if (value.endsWith("@example.com")) return false;
  if (value.endsWith("@example.org")) return false;
  if (rejectedEmailPrefixes.some((prefix) => localPart === prefix)) return false;

  return true;
}

function extractApplicationEmail(description?: string | null): string | null {
  if (!description) return null;

  const text = normalizeDescription(description);
  const matches =
    text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];

  const uniqueEmails = [...new Set(matches.map((email) => email.toLowerCase()))]
    .filter(isValidApplicationEmail);

  if (uniqueEmails.length === 0) return null;

  const scored = uniqueEmails.map((email) => {
    const position = text.toLowerCase().indexOf(email);
    const contextStart = Math.max(0, position - 180);
    const contextEnd = Math.min(text.length, position + email.length + 180);
    const context = text.slice(contextStart, contextEnd).toLowerCase();
    const localPart = email.split("@")[0];

    let score = 0;

    for (const term of positiveEmailTerms) {
      if (context.includes(term)) score += 3;
      if (localPart.includes(term)) score += 6;
    }

    if (/send|submit|forward|email/.test(context)) score += 2;
    if (/support|privacy|complaint|technical|media|press|sales/.test(context)) {
      score -= 10;
    }

    return { email, score };
  });

  scored.sort((a, b) => b.score - a.score);

  return scored[0].score >= 3 ? scored[0].email : null;
}

function resolveApplicationEmail(job: {
  applyEmail?: string | null;
  description?: string | null;
}): string | null {
  const savedEmail = job.applyEmail?.trim().toLowerCase();

  if (savedEmail && isValidApplicationEmail(savedEmail)) {
    return savedEmail;
  }

  return extractApplicationEmail(job.description);
}

function isAllowedCv(file: CvFile): boolean {
  const filename = file.originalname.toLowerCase();
  const extensionAllowed =
    filename.endsWith(".pdf") ||
    filename.endsWith(".doc") ||
    filename.endsWith(".docx");

  if (!extensionAllowed || file.size > MAX_CV_SIZE) return false;

  const bytes = file.buffer;

  const isPdf =
    bytes.length >= 4 &&
    bytes[0] === 0x25 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x44 &&
    bytes[3] === 0x46;

  const isDoc =
    bytes.length >= 8 &&
    bytes[0] === 0xd0 &&
    bytes[1] === 0xcf &&
    bytes[2] === 0x11 &&
    bytes[3] === 0xe0;

  const isDocx =
    bytes.length >= 4 &&
    bytes[0] === 0x50 &&
    bytes[1] === 0x4b &&
    bytes[2] === 0x03 &&
    bytes[3] === 0x04;

  return isPdf || isDoc || isDocx;
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function smtpTransport() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || "465");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    throw new Error("SMTP configuration is incomplete");
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: {
      user,
      pass,
    },
  });
}

export function registerEasyApplyRoutes(app: Express): void {
  app.get(
    "/api/jobs/:id/easy-apply-status",
    async (req: Request, res: Response) => {
      try {
        const id = Number(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id);

        if (!Number.isInteger(id) || id <= 0) {
          return res.status(400).json({ available: false });
        }

        const [job] = await db
          .select({
            id: jobs.id,
            applyEmail: jobs.applyEmail,
            description: jobs.description,
          })
          .from(jobs)
          .where(eq(jobs.id, id))
          .limit(1);

        if (!job) {
          return res.status(404).json({ available: false });
        }

        const recipient = resolveApplicationEmail(job);

        return res.json({
          available: Boolean(recipient),
        });
      } catch (error) {
        console.error("Easy Apply status error:", error);
        return res.status(500).json({ available: false });
      }
    },
  );

  app.post(
    "/api/jobs/:id/easy-apply",
    easyApplyLimiter,
    upload.single("cv"),
    async (req: Request, res: Response) => {
      try {
        const id = Number(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id);

        if (!Number.isInteger(id) || id <= 0) {
          return res.status(400).json({ error: "Invalid job." });
        }

        const parsed = applicationSchema.safeParse(req.body);

        if (!parsed.success) {
          return res.status(400).json({
            error: "Please complete all required fields correctly.",
          });
        }

        const cv = (req as Request & { file?: CvFile }).file;
        if (!cv) {
          return res.status(400).json({
            error: "Please attach your CV.",
          });
        }

        if (!isAllowedCv(cv)) {
          return res.status(400).json({
            error: "CV must be a valid PDF, DOC or DOCX file, maximum 5 MB.",
          });
        }

        const [job] = await db
          .select({
            id: jobs.id,
            title: jobs.title,
            organization: jobs.organization,
            location: jobs.location,
            applyEmail: jobs.applyEmail,
            description: jobs.description,
          })
          .from(jobs)
          .where(eq(jobs.id, id))
          .limit(1);

        if (!job) {
          return res.status(404).json({ error: "Job not found." });
        }

        const recipient = resolveApplicationEmail(job);

        if (!recipient) {
          return res.status(400).json({
            error: "Easy Apply is not available for this job.",
          });
        }

        const data = parsed.data;
        const duplicateKey = `${id}:${data.email.toLowerCase()}`;
        const previousSubmission = duplicateApplications.get(duplicateKey);
        const now = Date.now();

        if (
          previousSubmission &&
          now - previousSubmission < DUPLICATE_WINDOW
        ) {
          return res.status(429).json({
            error: "This application was already submitted recently.",
          });
        }

        duplicateApplications.set(duplicateKey, now);

        for (const [key, submittedAt] of duplicateApplications.entries()) {
          if (now - submittedAt > DUPLICATE_WINDOW) {
            duplicateApplications.delete(key);
          }
        }

        const transporter = smtpTransport();
        const fromAddress =
          process.env.SMTP_FROM || process.env.SMTP_USER || "info@devglobaljobs.com";

        const safe = Object.fromEntries(
          Object.entries(data).map(([key, value]) => [
            key,
            escapeHtml(String(value || "")),
          ]),
        );

        const subject = `Application for ${job.title} - ${data.fullName}`;

        const textBody = `
Dear Hiring Team,

Please find below an application submitted through Dev Global Jobs.

Position: ${job.title}
Organisation: ${job.organization}
Location: ${job.location || "Not specified"}

Candidate Details
Name: ${data.fullName}
Email: ${data.email}
Phone: ${data.phone}
Current Country: ${data.currentCountry}
Nationality: ${data.nationality}
Current Job Title: ${data.currentJobTitle}
Experience: ${data.experienceYears}
Qualification: ${data.qualification}
LinkedIn: ${data.linkedin || "Not provided"}
Availability: ${data.availability}
Work Authorisation: ${data.workAuthorization}
Expected Salary: ${data.expectedSalary || "Not provided"}

Professional Summary
${data.professionalSummary}

Cover Letter
${data.coverLetter}

The candidate's CV is attached.

This application was submitted through Dev Global Jobs.
`;

        const htmlBody = `
<div style="font-family:Arial,sans-serif;max-width:720px;margin:auto;color:#1f2937;line-height:1.6">
  <div style="background:#0f5bd8;color:white;padding:22px;border-radius:12px 12px 0 0">
    <h2 style="margin:0">New Job Application</h2>
    <p style="margin:6px 0 0">${escapeHtml(job.title)}</p>
  </div>

  <div style="border:1px solid #e5e7eb;border-top:0;padding:24px;border-radius:0 0 12px 12px">
    <p>Dear Hiring Team,</p>
    <p>A candidate has submitted an application through <strong>Dev Global Jobs</strong>.</p>

    <h3>Position</h3>
    <p>
      <strong>${escapeHtml(job.title)}</strong><br>
      ${escapeHtml(job.organization)}<br>
      ${escapeHtml(job.location || "Location not specified")}
    </p>

    <h3>Candidate Details</h3>
    <table style="width:100%;border-collapse:collapse">
      <tr><td style="padding:6px 0"><strong>Name</strong></td><td>${safe.fullName}</td></tr>
      <tr><td style="padding:6px 0"><strong>Email</strong></td><td>${safe.email}</td></tr>
      <tr><td style="padding:6px 0"><strong>Phone</strong></td><td>${safe.phone}</td></tr>
      <tr><td style="padding:6px 0"><strong>Current Country</strong></td><td>${safe.currentCountry}</td></tr>
      <tr><td style="padding:6px 0"><strong>Nationality</strong></td><td>${safe.nationality}</td></tr>
      <tr><td style="padding:6px 0"><strong>Current Job Title</strong></td><td>${safe.currentJobTitle}</td></tr>
      <tr><td style="padding:6px 0"><strong>Experience</strong></td><td>${safe.experienceYears}</td></tr>
      <tr><td style="padding:6px 0"><strong>Qualification</strong></td><td>${safe.qualification}</td></tr>
      <tr><td style="padding:6px 0"><strong>LinkedIn</strong></td><td>${safe.linkedin || "Not provided"}</td></tr>
      <tr><td style="padding:6px 0"><strong>Availability</strong></td><td>${safe.availability}</td></tr>
      <tr><td style="padding:6px 0"><strong>Work Authorisation</strong></td><td>${safe.workAuthorization}</td></tr>
      <tr><td style="padding:6px 0"><strong>Expected Salary</strong></td><td>${safe.expectedSalary || "Not provided"}</td></tr>
    </table>

    <h3>Professional Summary</h3>
    <p style="white-space:pre-line">${safe.professionalSummary}</p>

    <h3>Cover Letter</h3>
    <p style="white-space:pre-line">${safe.coverLetter}</p>

    <p><strong>The candidate's CV is attached.</strong></p>

    <hr style="border:0;border-top:1px solid #e5e7eb;margin:24px 0">
    <p style="font-size:12px;color:#6b7280">
      Submitted securely through Dev Global Jobs. Reply directly to this email to contact the candidate.
    </p>
  </div>
</div>
`;

        await transporter.sendMail({
          from: `"Dev Global Jobs" <${fromAddress}>`,
          to: recipient,
          replyTo: data.email,
          subject,
          text: textBody,
          html: htmlBody,
          attachments: [
            {
              filename: cv.originalname.replace(/[^\w.\-() ]/g, "_"),
              content: cv.buffer,
              contentType: cv.mimetype,
            },
          ],
        });

        return res.json({
          success: true,
          message: "Your application has been sent directly to the employer.",
        });
      } catch (error) {
        console.error("Easy Apply submission error:", error);

        if (
          error &&
          typeof error === "object" &&
          "code" in error &&
          error.code === "LIMIT_FILE_SIZE"
        ) {
          return res.status(400).json({
            error: "CV must not exceed 5 MB.",
          });
        }

        return res.status(500).json({
          error: "Application could not be sent. Please try again.",
        });
      }
    },
  );
}
