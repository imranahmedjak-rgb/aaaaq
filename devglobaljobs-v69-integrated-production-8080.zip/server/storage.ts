import { type User, type InsertUser, type Job, type InsertJob, type NewsletterSubscriber, type InsertSubscriber, type BlogPost, type InsertBlogPost, jobs, users, pendingJobs, newsletterSubscribers, blogPosts } from "@shared/schema";
import { db } from "./db";
import { eq, ne, desc, and, sql, or, ilike } from "drizzle-orm";

const SOURCE_CATEGORIES = ["un", "ngo", "remote", "international"];
const SKILL_CATEGORIES = ["technology", "healthcare", "business", "education", "engineering", "creative", "sales", "gig", "youth"];

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getJobs(category?: string): Promise<Job[]>;
  getJobsPaginated(category: string | undefined, limit: number, offset: number, search?: string): Promise<{ jobs: Job[]; total: number }>;
  getJobById(id: number): Promise<Job | undefined>;
  getFeaturedJobs(): Promise<Job[]>;
  getFeaturedEmployerJobs(category?: string): Promise<Job[]>;
  getJobStats(): Promise<Record<string, number>>;
  insertJob(job: InsertJob): Promise<Job>;
  insertJobs(jobsList: InsertJob[]): Promise<void>;
  insertJobsReturningIds(jobsList: InsertJob[]): Promise<number[]>;
  jobExistsBySourceId(sourceId: string, source: string): Promise<boolean>;
  deleteOldJobs(daysOld: number): Promise<void>;
  runFullCleanup(): Promise<{ expiredByClosingDate: number; staleJobs: number; employerRegular: number; employerFeatured: number; duplicates: number }>;
  removeExpiredClosingDateJobs(): Promise<number>;
  removeDuplicateJobs(): Promise<number>;
  createPendingJob(data: any, sessionId: string): Promise<any>;
  getPendingJobBySessionId(sessionId: string): Promise<any | undefined>;
  markPendingJobPublished(sessionId: string): Promise<void>;
  getAllJobIds(): Promise<{ id: number; postedAt: Date | null }[]>;
  getJobsByCountryPaginated(countryCode: string, limit: number, offset: number, search?: string): Promise<{ jobs: Job[]; total: number }>;
  getJobsByCityPaginated(city: string, limit: number, offset: number, search?: string): Promise<{ jobs: Job[]; total: number }>;
  deleteSubscriber(id: number): Promise<void>;
  getCountryStats(): Promise<{ code: string; count: number }[]>;
  getBlogPosts(page: number, limit: number, status?: string): Promise<{ posts: BlogPost[]; total: number }>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  getBlogPostById(id: number): Promise<BlogPost | undefined>;
  createBlogPost(data: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: number, data: Partial<InsertBlogPost>): Promise<BlogPost | undefined>;
  deleteBlogPost(id: number): Promise<void>;
  getJobIdsByCountry(countryCode: string): Promise<{ id: number; postedAt: Date | null }[]>;
  getLatestJobIds(limit: number): Promise<{ id: number; postedAt: Date | null }[]>;
  addSubscriber(data: InsertSubscriber): Promise<NewsletterSubscriber>;
  getSubscribers(): Promise<NewsletterSubscriber[]>;
  getSubscriberByEmail(email: string): Promise<NewsletterSubscriber | undefined>;
  getSubscriberCount(): Promise<number>;
  getSubscriberCountByType(): Promise<{ total: number; employers: number; jobSeekers: number }>;
  getAdminJobs(page: number, limit: number, search?: string, source?: string, category?: string): Promise<{ jobs: Job[]; total: number }>;
  deleteJobById(id: number): Promise<void>;
  updateJobById(id: number, data: Partial<InsertJob>): Promise<Job | undefined>;
  getAdminStats(): Promise<{ total: number; today: number; employer: number; featured: number; sources: number; subscribers: number }>;
  getSourcesList(): Promise<{ source: string; count: number }[]>;
  getRevenueMetrics(): Promise<{
    regular: { today: number; week: number; month: number; year: number; total: number };
    featured: { today: number; week: number; month: number; year: number; total: number };
    revenue: { today: number; week: number; month: number; year: number; total: number };
    projections: { daily: number; weekly: number; monthly: number; yearly: number };
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getJobs(category?: string): Promise<Job[]> {
    if (!category) {
      return db.select().from(jobs).orderBy(desc(jobs.postedAt));
    }
    if (SOURCE_CATEGORIES.includes(category)) {
      if (category === "international") {
        return db.select().from(jobs).where(and(eq(jobs.category, category), ne(jobs.skillCategory, "youth"))).orderBy(desc(jobs.postedAt));
      }
      return db.select().from(jobs).where(eq(jobs.category, category)).orderBy(desc(jobs.postedAt));
    }
    if (SKILL_CATEGORIES.includes(category)) {
      return db.select().from(jobs).where(eq(jobs.skillCategory, category)).orderBy(desc(jobs.postedAt));
    }
    return db.select().from(jobs).orderBy(desc(jobs.postedAt));
  }

  async getJobsPaginated(category: string | undefined, limit: number, offset: number, search?: string): Promise<{ jobs: Job[]; total: number }> {
    const conditions: any[] = [];
    const isAllCategory = !category || category === "all";

    if (category && category !== "all") {
      if (SOURCE_CATEGORIES.includes(category)) {
        conditions.push(eq(jobs.category, category));
        if (category === "international") {
          conditions.push(ne(jobs.skillCategory, "youth"));
        }
      } else if (SKILL_CATEGORIES.includes(category)) {
        conditions.push(eq(jobs.skillCategory, category));
      }
    }

    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      conditions.push(
        or(
          ilike(jobs.title, q),
          ilike(jobs.organization, q),
          ilike(jobs.location, q),
          ilike(jobs.country, q)
        )
      );
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [countResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(jobs)
      .where(whereClause);

    const total = Number(countResult?.count || 0);

    const orderClauses = [sql`CASE WHEN ${jobs.featured} = true AND ${jobs.isEmployerPosted} = true THEN 0 ELSE 1 END`, desc(jobs.postedAt)];

    const result = await db
      .select()
      .from(jobs)
      .where(whereClause)
      .orderBy(...orderClauses)
      .limit(limit)
      .offset(offset);

    return { jobs: result, total };
  }

  async getJobById(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async getFeaturedJobs(): Promise<Job[]> {
    return db.select().from(jobs).orderBy(desc(jobs.postedAt)).limit(500);
  }

  async getFeaturedEmployerJobs(category?: string): Promise<Job[]> {
    const conditions = [eq(jobs.featured, true), eq(jobs.isEmployerPosted, true)];
    if (category && category !== "all") {
      if (SOURCE_CATEGORIES.includes(category)) {
        conditions.push(eq(jobs.category, category));
      } else if (SKILL_CATEGORIES.includes(category)) {
        conditions.push(eq(jobs.skillCategory, category));
      }
    }
    return db.select().from(jobs)
      .where(and(...conditions))
      .orderBy(desc(jobs.postedAt))
.limit(500);
  }

  async getJobStats(): Promise<Record<string, number>> {
    const sourceCounts = await db.select({ category: jobs.category, count: sql<number>`count(*)` })
      .from(jobs)
      .groupBy(jobs.category);

    const skillCounts = await db.select({ skillCategory: jobs.skillCategory, count: sql<number>`count(*)` })
      .from(jobs)
      .groupBy(jobs.skillCategory);

    const [youthInInternational] = await db.select({ count: sql<number>`count(*)` })
      .from(jobs)
      .where(and(eq(jobs.category, "international"), eq(jobs.skillCategory, "youth")));

    const youthInIntlCount = Number(youthInInternational?.count || 0);

    const stats: Record<string, number> = { total: 0 };
    for (const row of sourceCounts) {
      const count = Number(row.count);
      stats.total += count;
      if (row.category === "international") {
        stats[row.category] = count - youthInIntlCount;
      } else {
        stats[row.category] = count;
      }
    }
    for (const row of skillCounts) {
      if (row.skillCategory) {
        stats[row.skillCategory] = Number(row.count);
      }
    }
    return stats;
  }

  async insertJob(job: InsertJob): Promise<Job> {
    const [inserted] = await db.insert(jobs).values(job).returning();
    return inserted;
  }

  async insertJobs(jobsList: InsertJob[]): Promise<void> {
    if (jobsList.length === 0) return;
    const batchSize = 100;
    for (let i = 0; i < jobsList.length; i += batchSize) {
      const batch = jobsList.slice(i, i + batchSize);
      try {
        await db.insert(jobs).values(batch).onConflictDoNothing();
      } catch (err: any) {
        if (err?.message?.includes("duplicate key") || err?.code === "23505") {
          for (const job of batch) {
            try {
              await db.insert(jobs).values(job).onConflictDoNothing();
            } catch (innerErr: any) {
              if (!innerErr?.message?.includes("duplicate key") && innerErr?.code !== "23505") {
                console.error(`Insert job error: ${innerErr.message}`);
              }
            }
          }
        } else {
          console.error(`Batch insert error: ${err.message}`);
        }
      }
    }
  }

  async insertJobsReturningIds(jobsList: InsertJob[]): Promise<number[]> {
    if (jobsList.length === 0) return [];
    const ids: number[] = [];
    const batchSize = 50;
    for (let i = 0; i < jobsList.length; i += batchSize) {
      const batch = jobsList.slice(i, i + batchSize);
      try {
        const result = await db.insert(jobs).values(batch).onConflictDoNothing().returning({ id: jobs.id });
        ids.push(...result.map(r => r.id));
      } catch (err: any) {
        if (err?.message?.includes("duplicate key") || err?.code === "23505") {
          for (const job of batch) {
            try {
              const result = await db.insert(jobs).values(job).onConflictDoNothing().returning({ id: jobs.id });
              ids.push(...result.map(r => r.id));
            } catch (innerErr: any) {
              if (!innerErr?.message?.includes("duplicate key") && innerErr?.code !== "23505") {
                console.error(`Insert job error: ${innerErr.message}`);
              }
            }
          }
        } else {
          console.error(`Batch insert returning error: ${err.message}`);
        }
      }
    }
    return ids;
  }

  async jobExistsBySourceId(sourceId: string, source: string): Promise<boolean> {
    const [existing] = await db.select({ id: jobs.id })
      .from(jobs)
      .where(and(eq(jobs.sourceId, sourceId), eq(jobs.source, source)))
      .limit(500);
    return !!existing;
  }

  async deleteOldJobs(daysOld: number): Promise<void> {
    await db.delete(jobs).where(
      and(
        sql`${jobs.postedAt} < NOW() - INTERVAL '${sql.raw(daysOld.toString())} days'`,
        eq(jobs.isEmployerPosted, false)
      )
    );
    await db.delete(jobs).where(
      and(
        sql`${jobs.postedAt} < NOW() - INTERVAL '30 days'`,
        eq(jobs.isEmployerPosted, true),
        eq(jobs.featured, false)
      )
    );
    await db.delete(jobs).where(
      and(
        sql`${jobs.postedAt} < NOW() - INTERVAL '45 days'`,
        eq(jobs.isEmployerPosted, true),
        eq(jobs.featured, true)
      )
    );
  }

  async removeDuplicateJobs(): Promise<number> {
    const result = await db.execute(sql`
      WITH duplicates AS (
        SELECT id, ROW_NUMBER() OVER (
          PARTITION BY source_id 
          ORDER BY id DESC
        ) as rn
        FROM jobs
        WHERE source_id IS NOT NULL
      )
      DELETE FROM jobs WHERE id IN (
        SELECT id FROM duplicates WHERE rn > 1
      )
    `);
    return Number(result.rowCount) || 0;
  }

  async runFullCleanup(): Promise<{ expiredByClosingDate: number; staleJobs: number; employerRegular: number; employerFeatured: number; duplicates: number }> {
    const stats = { expiredByClosingDate: 0, staleJobs: 0, employerRegular: 0, employerFeatured: 0, duplicates: 0 };

    const r1 = await db.execute(sql`
      DELETE FROM jobs 
      WHERE closing_date IS NOT NULL 
        AND closing_date < NOW()
        AND is_employer_posted = false
    `);
    stats.expiredByClosingDate = Number(r1.rowCount) || 0;

    const r2 = await db.execute(sql`
      DELETE FROM jobs 
      WHERE posted_at < NOW() - INTERVAL '30 days'
        AND is_employer_posted = false
    `);
    stats.staleJobs = Number(r2.rowCount) || 0;

    const r3 = await db.execute(sql`
      DELETE FROM jobs 
      WHERE posted_at < NOW() - INTERVAL '30 days'
        AND is_employer_posted = true
        AND featured = false
    `);
    stats.employerRegular = Number(r3.rowCount) || 0;

    const r4 = await db.execute(sql`
      DELETE FROM jobs 
      WHERE posted_at < NOW() - INTERVAL '45 days'
        AND is_employer_posted = true
        AND featured = true
    `);
    stats.employerFeatured = Number(r4.rowCount) || 0;

    stats.duplicates = await this.removeDuplicateJobs();

    return stats;
  }

  async removeExpiredClosingDateJobs(): Promise<number> {
    const result = await db.execute(sql`
      DELETE FROM jobs
      WHERE closing_date IS NOT NULL
        AND closing_date < NOW()
        AND is_employer_posted = false
    `);
    return Number(result.rowCount) || 0;
  }

  async createPendingJob(data: any, sessionId: string): Promise<any> {
    const [pending] = await db.insert(pendingJobs).values({
      stripeSessionId: sessionId,
      title: data.title,
      organization: data.organization,
      location: data.location,
      category: data.category,
      description: data.description,
      url: data.url || null,
      jobType: data.jobType || null,
      salary: data.salary || null,
      country: data.country || null,
      applyEmail: data.applyEmail || null,
      featured: data.listingType === "featured",
    }).returning();
    return pending;
  }

  async getPendingJobBySessionId(sessionId: string): Promise<any | undefined> {
    const [pending] = await db.select().from(pendingJobs)
      .where(and(eq(pendingJobs.stripeSessionId, sessionId), eq(pendingJobs.published, false)));
    return pending;
  }

  async markPendingJobPublished(sessionId: string): Promise<void> {
    await db.update(pendingJobs)
      .set({ published: true })
      .where(eq(pendingJobs.stripeSessionId, sessionId));
  }

  async getAllJobIds(): Promise<{ id: number; postedAt: Date | null }[]> {
    return db.select({ id: jobs.id, postedAt: jobs.postedAt }).from(jobs).orderBy(desc(jobs.postedAt));
  }

  async getJobsByCountryPaginated(countryCode: string, limit: number, offset: number, search?: string): Promise<{ jobs: Job[]; total: number }> {
    const conditions: any[] = [eq(jobs.country, countryCode.toUpperCase())];

    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      conditions.push(
        or(
          ilike(jobs.title, q),
          ilike(jobs.organization, q),
          ilike(jobs.location, q)
        )
      );
    }

    const whereClause = and(...conditions);

    const [countResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(jobs)
      .where(whereClause);

    const total = Number(countResult?.count || 0);

    const result = await db
      .select()
      .from(jobs)
      .where(whereClause)
      .orderBy(desc(jobs.postedAt))
      .limit(limit)
      .offset(offset);

    return { jobs: result, total };
  }

  async getJobsByCityPaginated(city: string, limit: number, offset: number, search?: string): Promise<{ jobs: Job[]; total: number }> {
    const cityPattern = `%${city.trim()}%`;
    const conditions: any[] = [ilike(jobs.location, cityPattern)];

    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      conditions.push(
        or(
          ilike(jobs.title, q),
          ilike(jobs.organization, q),
        )
      );
    }

    const whereClause = and(...conditions);

    const [countResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(jobs)
      .where(whereClause);

    const total = Number(countResult?.count || 0);

    const result = await db
      .select()
      .from(jobs)
      .where(whereClause)
      .orderBy(desc(jobs.postedAt))
      .limit(limit)
      .offset(offset);

    return { jobs: result, total };
  }

  async getCountryStats(): Promise<{ code: string; count: number }[]> {
    const result = await db
      .select({ code: jobs.country, count: sql<number>`count(*)` })
      .from(jobs)
      .where(sql`${jobs.country} IS NOT NULL AND ${jobs.country} != ''`)
      .groupBy(jobs.country)
      .orderBy(sql`count(*) DESC`);
    return result.map(r => ({ code: r.code || "", count: Number(r.count) }));
  }

  async getJobIdsByCountry(countryCode: string): Promise<{ id: number; postedAt: Date | null }[]> {
    return db.select({ id: jobs.id, postedAt: jobs.postedAt })
      .from(jobs)
      .where(eq(jobs.country, countryCode.toUpperCase()))
      .orderBy(desc(jobs.postedAt));
  }

  async getLatestJobIds(limit: number): Promise<{ id: number; postedAt: Date | null }[]> {
    return db.select({ id: jobs.id, postedAt: jobs.postedAt })
      .from(jobs)
      .orderBy(desc(jobs.postedAt))
      .limit(limit);
  }

  async addSubscriber(data: InsertSubscriber): Promise<NewsletterSubscriber> {
    const [subscriber] = await db.insert(newsletterSubscribers).values(data).returning();
    return subscriber;
  }

  async getSubscribers(): Promise<NewsletterSubscriber[]> {
    return db.select().from(newsletterSubscribers).orderBy(desc(newsletterSubscribers.subscribedAt));
  }

  async getSubscriberByEmail(email: string): Promise<NewsletterSubscriber | undefined> {
    const [subscriber] = await db.select().from(newsletterSubscribers).where(eq(newsletterSubscribers.email, email.toLowerCase()));
    return subscriber;
  }

  async deleteSubscriber(id: number): Promise<void> {
    await db.delete(newsletterSubscribers).where(eq(newsletterSubscribers.id, id));
  }

  async getSubscriberCount(): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)` }).from(newsletterSubscribers);
    return Number(result.count);
  }

  async getSubscriberCountByType(): Promise<{ total: number; employers: number; jobSeekers: number }> {
    const [total] = await db.select({ count: sql<number>`count(*)` }).from(newsletterSubscribers);
    const [employers] = await db.select({ count: sql<number>`count(*)` }).from(newsletterSubscribers).where(eq(newsletterSubscribers.type, "employer"));
    const [jobSeekers] = await db.select({ count: sql<number>`count(*)` }).from(newsletterSubscribers).where(eq(newsletterSubscribers.type, "job_seeker"));
    return {
      total: Number(total.count),
      employers: Number(employers.count),
      jobSeekers: Number(jobSeekers.count),
    };
  }

  async getAdminJobs(page: number, limit: number, search?: string, source?: string, category?: string): Promise<{ jobs: Job[]; total: number }> {
    const offset = (page - 1) * limit;
    const conditions = [];
    if (search) {
      conditions.push(or(
        ilike(jobs.title, `%${search}%`),
        ilike(jobs.organization, `%${search}%`),
        ilike(jobs.location, `%${search}%`),
      ));
    }
    if (source) conditions.push(eq(jobs.source, source));
    if (category) conditions.push(eq(jobs.category, category));

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [countResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(jobs)
      .where(whereClause);

    const jobsList = await db
      .select()
      .from(jobs)
      .where(whereClause)
      .orderBy(desc(jobs.postedAt))
      .limit(limit)
      .offset(offset);

    return { jobs: jobsList, total: Number(countResult.count) };
  }

  async deleteJobById(id: number): Promise<void> {
    await db.delete(jobs).where(eq(jobs.id, id));
  }

  async updateJobById(id: number, data: Partial<InsertJob>): Promise<Job | undefined> {
    const [updated] = await db.update(jobs).set(data).where(eq(jobs.id, id)).returning();
    return updated;
  }

  async getAdminStats(): Promise<{ total: number; today: number; employer: number; featured: number; sources: number; subscribers: number }> {
    const [total] = await db.select({ count: sql<number>`count(*)` }).from(jobs);
    const [today] = await db.select({ count: sql<number>`count(*)` }).from(jobs).where(sql`${jobs.postedAt} >= NOW() - INTERVAL '24 hours'`);
    const [employer] = await db.select({ count: sql<number>`count(*)` }).from(jobs).where(eq(jobs.isEmployerPosted, true));
    const [featured] = await db.select({ count: sql<number>`count(*)` }).from(jobs).where(eq(jobs.featured, true));
    const sourcesResult = await db.selectDistinct({ source: jobs.source }).from(jobs);
    const [subscribers] = await db.select({ count: sql<number>`count(*)` }).from(newsletterSubscribers);
    return {
      total: Number(total.count),
      today: Number(today.count),
      employer: Number(employer.count),
      featured: Number(featured.count),
      sources: sourcesResult.length,
      subscribers: Number(subscribers.count),
    };
  }

  async getSourcesList(): Promise<{ source: string; count: number }[]> {
    const result = await db
      .select({ source: jobs.source, count: sql<number>`count(*)` })
      .from(jobs)
      .groupBy(jobs.source)
      .orderBy(desc(sql`count(*)`));
    return result.map(r => ({ source: r.source, count: Number(r.count) }));
  }

  async getRevenueMetrics(): Promise<{
    regular: { today: number; week: number; month: number; year: number; total: number };
    featured: { today: number; week: number; month: number; year: number; total: number };
    revenue: { today: number; week: number; month: number; year: number; total: number };
    projections: { daily: number; weekly: number; monthly: number; yearly: number };
  }> {
    const REGULAR_PRICE = 29;
    const FEATURED_PRICE = 79;

    const [row] = await db.select({
      regTotal:   sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false)`,
      regToday:   sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= CURRENT_DATE)`,
      regWeek:    sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= NOW() - INTERVAL '7 days')`,
      regMonth:   sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= NOW() - INTERVAL '30 days')`,
      regYear:    sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= NOW() - INTERVAL '365 days')`,
      featTotal:  sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true)`,
      featToday:  sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= CURRENT_DATE)`,
      featWeek:   sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= NOW() - INTERVAL '7 days')`,
      featMonth:  sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= NOW() - INTERVAL '30 days')`,
      featYear:   sql<number>`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= NOW() - INTERVAL '365 days')`,
    }).from(jobs);

    const r = (v: any) => Number(v) || 0;
    const regular = { today: r(row.regToday), week: r(row.regWeek), month: r(row.regMonth), year: r(row.regYear), total: r(row.regTotal) };
    const featured = { today: r(row.featToday), week: r(row.featWeek), month: r(row.featMonth), year: r(row.featYear), total: r(row.featTotal) };

    const rev = (reg: number, feat: number) => reg * REGULAR_PRICE + feat * FEATURED_PRICE;
    const revenue = {
      today:  rev(regular.today,  featured.today),
      week:   rev(regular.week,   featured.week),
      month:  rev(regular.month,  featured.month),
      year:   rev(regular.year,   featured.year),
      total:  rev(regular.total,  featured.total),
    };

    const dailyRegRate = regular.month / 30;
    const dailyFeatRate = featured.month / 30;
    const dailyRev = dailyRegRate * REGULAR_PRICE + dailyFeatRate * FEATURED_PRICE;
    const projections = {
      daily:   Math.round(dailyRev),
      weekly:  Math.round(dailyRev * 7),
      monthly: Math.round(dailyRev * 30),
      yearly:  Math.round(dailyRev * 365),
    };

    return { regular, featured, revenue, projections };
  }

  async getBlogPosts(page: number, limit: number, status?: string): Promise<{ posts: BlogPost[]; total: number }> {
    const offset = (page - 1) * limit;
    const where = status ? eq(blogPosts.status, status) : undefined;
    const [posts, [{ count }]] = await Promise.all([
      db.select().from(blogPosts).where(where).orderBy(desc(blogPosts.createdAt)).limit(limit).offset(offset),
      db.select({ count: sql<number>`count(*)` }).from(blogPosts).where(where),
    ]);
    return { posts, total: Number(count) };
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return post;
  }

  async getBlogPostById(id: number): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post;
  }

  async createBlogPost(data: InsertBlogPost): Promise<BlogPost> {
    const [post] = await db.insert(blogPosts).values(data).returning();
    return post;
  }

  async updateBlogPost(id: number, data: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
    const [post] = await db.update(blogPosts).set({ ...data, updatedAt: new Date() }).where(eq(blogPosts.id, id)).returning();
    return post;
  }

  async deleteBlogPost(id: number): Promise<void> {
    await db.delete(blogPosts).where(eq(blogPosts.id, id));
  }
}

export const storage = new DatabaseStorage();
