import { Request, Response, NextFunction } from "express";
import { db } from "./db";

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session || !(req.session as any).isAdmin) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

export function getAdminUsers() {
  const users: Record<string, string> = {};
  let i = 1;
  while (process.env[`ADMIN_USER_${i}`]) {
    const user = process.env[`ADMIN_USER_${i}`]!;
    const pass = process.env[`ADMIN_PASS_${i}`]!;
    users[user] = pass;
    i++;
  }
  return users;
}

export function getAdminCode(): string {
  return process.env.ADMIN_CODE || "";
}

export function getAdminSalt(): string {
  return process.env.ADMIN_SALT || "";
}
