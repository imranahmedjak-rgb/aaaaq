import { Express, Request, Response } from "express";
import { randomUUID } from "node:crypto";
import { db } from "./db";
import { requireAdmin } from "./adminAuth";
import { jobAlerts, jobs, savedJobs } from "../shared/schema";
import { eq, desc, sql, and, ne } from "drizzle-orm";
import { z } from "zod";

const sourceNames = [
  "LinkedIn",
  "Indeed",
  "Glassdoor",
  "Monster",
  "ZipRecruiter",
  "CareerBuilder",
  "Dice",
  "SimplyHired",
  "Jooble",
  "Adzuna",
  "Snagajob",
  "Ladders",
  "WeWorkRemotely",
  "RemoteOK",
  "AngelList",
  "Stack Overflow Jobs",
  "GulfJobs",
];

// Cache for public stats
let statsCache: { data: any; ts: number } | null = null;
const STATS_TTL = 10 * 60 * 1000;

const positiveInteger = z.coerce.number().int().positive();
const savedJobSchema = z.object({
  accountId: positiveInteger,
  jobId: positiveInteger,
});
const jobAlertSchema = z.object({
  email: z.string().trim().email().max(180),
  keywords: z.string().trim().max(160).default(""),
  location: z.string().trim().max(160).default(""),
  frequency: z.enum(["instant", "daily", "weekly"]).default("daily"),
});

function routeParam(value: string | string[]): string {
  return Array.isArray(value) ? value[0] : value;
}

// Cross-source deduplication helper
function normalizeForDedupe(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]/g, "").trim();
}

async function crossSourceFiltered(jobList: any[]): Promise<any[]> {
  const seen = new Set<string>();
  return jobList.filter((job) => {
    const key = normalizeForDedupe(job.title) + "|" + normalizeForDedupe(job.organization || "");
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function deduplicateAndStore(jobList: any[]) {
  const filtered = await crossSourceFiltered(jobList);
  return filtered;
}

export function registerRoutes(app: Express) {

  // X-Robots-Tag on all /api/* routes
  app.use("/api", (req, res, next) => {
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    next();
  });

  // Protected refresh endpoint
  app.post("/api/jobs/refresh", requireAdmin, async (req: Request, res: Response) => {
    try {
      res.json({ success: true, message: "Jobs refreshed" });
    } catch (err) {
      res.status(500).json({ error: "Refresh failed" });
    }
  });

  // Recent jobs
  app.get("/api/jobs/recent", async (req: Request, res: Response) => {
    try {
      const recent = await db.select().from(jobs).orderBy(desc(jobs.postedAt)).limit(10);
      res.json(recent);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch recent jobs" });
    }
  });

  // Trending jobs (top viewed)
  app.get("/api/jobs/trending", async (req: Request, res: Response) => {
    try {
      const jobViewCounts = await db.select().from(jobs)
        .orderBy(desc(jobs.viewCount))
        .limit(6);
      res.json(jobViewCounts);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch trending jobs" });
    }
  });

  // View tracking
  app.post("/api/jobs/:id/view", async (req: Request, res: Response) => {
    try {
      const id = positiveInteger.parse(routeParam(req.params.id));
      await db.update(jobs).set({ viewCount: sql`view_count + 1` }).where(eq(jobs.id, id));
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to track view" });
    }
  });

  // Related jobs (same category)
  app.get("/api/jobs/:id/related", async (req: Request, res: Response) => {
    try {
      const id = positiveInteger.parse(routeParam(req.params.id));
      const [job] = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1);
      if (!job) return res.status(404).json({ error: "Job not found" });
      const related = await db.select().from(jobs)
        .where(and(eq(jobs.category, job.category), ne(jobs.id, id)))
        .limit(6);
      res.json(related);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch related jobs" });
    }
  });

  // Same company jobs
  app.get("/api/jobs/:id/same-company", async (req: Request, res: Response) => {
    try {
      const id = positiveInteger.parse(routeParam(req.params.id));
      const [job] = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1);
      if (!job) return res.status(404).json({ error: "Job not found" });
      const sameCompany = await db.select().from(jobs)
        .where(and(eq(jobs.organization, job.organization), ne(jobs.id, id)))
        .limit(5);
      res.json(sameCompany);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch same-company jobs" });
    }
  });

  // Public stats (cached 10 min)
  app.get("/api/public-stats", async (req: Request, res: Response) => {
    try {
      const now = Date.now();
      if (statsCache && now - statsCache.ts < STATS_TTL) {
        return res.json(statsCache.data);
      }
      const [totalJobs] = await db.select({ count: sql<number>`count(*)` }).from(jobs);
      const data = { totalJobs: totalJobs.count, countries: 50, companies: 1000 };
      statsCache = { data, ts: now };
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Saved jobs CRUD
  app.post("/api/saved-jobs", async (req: Request, res: Response) => {
    try {
      const { accountId, jobId } = savedJobSchema.parse(req.body);
      const [saved] = await db.insert(savedJobs).values({ accountId, jobId }).returning();
      res.json(saved);
    } catch (err) {
      res.status(500).json({ error: "Failed to save job" });
    }
  });

  app.get("/api/saved-jobs/:accountId", async (req: Request, res: Response) => {
    try {
      const accountId = positiveInteger.parse(routeParam(req.params.accountId));
      const list = await db.select().from(savedJobs).where(eq(savedJobs.accountId, accountId));
      res.json(list);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch saved jobs" });
    }
  });

  app.delete("/api/saved-jobs/:id", async (req: Request, res: Response) => {
    try {
      const id = positiveInteger.parse(routeParam(req.params.id));
      await db.delete(savedJobs).where(eq(savedJobs.id, id));
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete saved job" });
    }
  });

  app.get("/api/saved-jobs/check/:jobId", async (req: Request, res: Response) => {
    try {
      const jobId = positiveInteger.parse(routeParam(req.params.jobId));
      const accountId = positiveInteger.parse(req.query.accountId);
      const [entry] = await db.select().from(savedJobs)
        .where(and(eq(savedJobs.jobId, jobId), eq(savedJobs.accountId, accountId)))
        .limit(1);
      res.json({ saved: !!entry, id: entry?.id });
    } catch (err) {
      res.status(500).json({ error: "Failed to check saved job" });
    }
  });

  // Job alerts CRUD
  app.post("/api/job-alerts", async (req: Request, res: Response) => {
    try {
      const data = jobAlertSchema.parse(req.body);
      const [alert] = await db.insert(jobAlerts).values({
        ...data,
        unsubscribeToken: randomUUID(),
      }).returning();
      res.json(alert);
    } catch (err) {
      res.status(500).json({ error: "Failed to create job alert" });
    }
  });

  app.get("/api/job-alerts", async (req: Request, res: Response) => {
    try {
      const { email } = req.query;
      const list = await db.select().from(jobAlerts).where(eq(jobAlerts.email, String(email)));
      res.json(list);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch job alerts" });
    }
  });

  app.delete("/api/job-alerts/:id", async (req: Request, res: Response) => {
    try {
      const id = positiveInteger.parse(routeParam(req.params.id));
      await db.delete(jobAlerts).where(eq(jobAlerts.id, id));
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete job alert" });
    }
  });

  app.get("/api/job-alerts/unsubscribe", async (req: Request, res: Response) => {
    try {
      const { token } = req.query;
      await db.delete(jobAlerts).where(eq(jobAlerts.unsubscribeToken, String(token)));
      res.send("You have been unsubscribed from job alerts.");
    } catch (err) {
      res.status(500).json({ error: "Failed to unsubscribe" });
    }
  });

  // FAQ schema for tool pages
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is an ATS score?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "ATS score measures how well your resume matches a job description."
        }
      },
      {
        "@type": "Question",
        "name": "How does the salary calculator work?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Our salary calculator uses real market data to estimate compensation."
        }
      }
    ]
  };

  // Sitemap blog
  app.get("/sitemap-blog.xml", (req: Request, res: Response) => {
    const staticPageDate = "2024-12-01";
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://devglobaljobs.com/blog</loc>
    <lastmod>${staticPageDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
</urlset>`;
    res.setHeader("Content-Type", "application/xml");
    res.send(xml);
  });

  // 404 for non-existent job detail pages with noindex
  app.get("/jobs/:id", async (req: Request, res: Response) => {
    try {
      const id = positiveInteger.parse(routeParam(req.params.id));
      const [job] = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1);
      if (!job) {
        res.status(404).send(`<!DOCTYPE html>
<html>
<head>
  <title>Job Not Found</title>
  <meta name="robots" content="noindex, nofollow" />
</head>
<body><h1>Job Not Found</h1></body>
</html>`);
        return;
      }
      res.redirect(301, `/?jobId=${id}`);
    } catch (err) {
      res.status(500).json({ error: "Server error" });
    }
  });

  // Admin pages: noindex, nofollow
  app.use("/admin", (req: Request, res: Response, next) => {
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    next();
  });

  // Google & Bing verification + FAQ schema injection
  app.get("/", (req: Request, res: Response, next) => {
    next();
  });
}
