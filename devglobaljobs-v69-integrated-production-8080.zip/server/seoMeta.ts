// DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27
// Metadata is contract-backed. Update brand-lock/brand-contract.json deliberately, then run the verifier.
export { DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27, getPageMeta, injectMetaTags, generateBreadcrumbSchema, injectJobDetailMeta } from "./brandSeo";
