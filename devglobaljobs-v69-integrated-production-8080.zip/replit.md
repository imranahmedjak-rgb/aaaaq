# Dev Global Jobs

## Overview

Full-stack job portal that aggregates international, remote, and specialized jobs from multiple APIs. Built with React + Express + PostgreSQL. Operated by Trend Nova World Limited (UK).

## Stack

- **Frontend**: React 18, Vite, TailwindCSS, shadcn/ui, Wouter (routing), React Query
- **Backend**: Express 5, TypeScript, tsx (dev), esbuild (prod build)
- **Database**: PostgreSQL + Drizzle ORM
- **Payments**: Wise bank transfer (Company: Trend Nova World Limited, Quick Pay: https://wise.com/pay/business/trendnovaworldlimited)
- **Auth**: express-session (admin panel only), SHA256 password hashing
- **Job Sources**: RemoteOK, Remotive, WorkingNomads, TheMuse, Himalayas, Adzuna (5 countries), USAJobs, RSS feeds (OpportunitiesForYouth, ScholarshipsCorner, FundsForNGOs, ReliefWeb, FindWork, Arbeitnow, Jobicy)
- **Automation**: node-cron (job fetch every 30 min, cleanup every 6 hrs)

## Structure

```text
client/       # React frontend (Vite)
  src/
    pages/    # Route pages (including admin/login.tsx, admin/dashboard.tsx)
    components/ # UI components
    hooks/    # Custom hooks
server/       # Express backend
  index.ts   # Entry point (port 5000) + session middleware
  routes.ts  # API routes (public + admin)
  adminAuth.ts # Admin user store + SHA256 hashing + requireAdmin middleware
  db.ts      # Database connection
  storage.ts # Data access layer
  jobFetcher.ts # Job aggregation from APIs
  jobClassifier.ts # AI job classification
shared/       # Shared types/schema (Drizzle schema)
dist/         # Production build output
```

## Admin Panel

- **URL**: `/admin` (hidden from public, disallowed in robots.txt)
- **Login**: `/admin/login` → session-based auth → `/admin/dashboard`
- **Admin users**: imranusmanf6, maheenbutt110, zakirabbas1, kinzahayat, dolehkhan1
- **Auth**: express-session (in-memory), SHA256+salt password hashing in `server/adminAuth.ts`
- **Features**: Job CRUD, post job form, newsletter subscribers view, job fetcher trigger, paginated+searchable jobs table with delete, site stats

## Pricing

| Plan | Price | Duration |
|------|-------|----------|
| Regular | $29 | 30 days |
| Featured | $79 | 45 days |
| Bulk Posting | Contact info@devglobaljobs.com | Custom |

Payment via Wise bank transfer ONLY — no Stripe on frontend (Stripe backend code still present but unused).

## Scripts

- `npm run dev` — Start dev server (tsx, port 5000)
- `npm run build` — Production build (esbuild → dist/index.cjs)
- `npm run start` — Start production server
- `npm run db:push` — Sync database schema

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| DATABASE_URL | Yes | PostgreSQL connection string |
| SESSION_SECRET | Yes | Session encryption secret (admin panel) |
| ADZUNA_APP_ID | No | Adzuna App ID |
| ADZUNA_APP_KEY | No | Adzuna App Key |
| USAJOBS_API_KEY | No | USAJobs API key |
| ADMIN_POST_CODE | No | Legacy admin code for posting jobs (still works in post-job.tsx) |
| PORT | No | Server port (default: 5000) |

Note: `STRIPE_SECRET_KEY` warning on startup is harmless — Stripe backend routes exist but frontend never uses them.

## VPS Deployment (devglobaljobs.com)

Server: 76.13.127.249 | Ubuntu 24.04 | Hostinger KVM 2

### Quick Deploy (run on VPS via SSH)

```bash
ssh root@76.13.127.249
bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_GITHUB/YOUR_REPO/main/vps-deploy.sh) fresh
```

### Or manual steps:
```bash
# 1. Install Node.js + PostgreSQL + nginx + PM2
apt update && apt install -y nginx certbot python3-certbot-nginx postgresql postgresql-contrib
curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt install -y nodejs
npm install -g pm2

# 2. Set up database
sudo -u postgres psql -c "CREATE USER devjobs WITH PASSWORD 'StrongPass123';"
sudo -u postgres psql -c "CREATE DATABASE devglobaljobs OWNER devjobs;"

# 3. Clone/upload code to /var/www/devglobaljobs
# 4. Install, build, push DB
cd /var/www/devglobaljobs && npm install && npm run db:push && npm run build

# 5. Start with PM2
pm2 start ecosystem.config.cjs && pm2 save && pm2 startup

# 6. Set up nginx + SSL
cp vps-deploy.sh /etc/nginx/... # see vps-deploy.sh for nginx config
certbot --nginx -d devglobaljobs.com -d www.devglobaljobs.com
```

### Files for VPS
- `vps-deploy.sh` — Full automated deploy (fresh install + update)
- `vps-update.sh` — Zero-downtime code update only
- `vps-debug.sh` — Diagnostic script for troubleshooting
- `ecosystem.config.cjs` — PM2 process manager config
- `VPS-SETUP.md` — Detailed setup guide
