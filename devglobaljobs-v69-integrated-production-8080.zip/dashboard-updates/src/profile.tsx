import { useClerk, useUser } from "@clerk/react";
import {
  ArrowLeft,
  BadgeCheck,
  Bell,
  BriefcaseBusiness,
  Check,
  ChevronRight,
  FileText,
  Globe2,
  LockKeyhole,
  MapPin,
  Pencil,
  ShieldCheck,
  Sparkles,
  Target,
  UserRound,
} from "lucide-react";
import { useLocation } from "wouter";

const applications = [
  { role: "Senior Product Designer", company: "Northstar Labs", location: "Remote · Europe", status: "Interview", updated: "Updated 2 hours ago", accent: "bg-violet-50 text-violet-700" },
  { role: "Product Design Lead", company: "Mosaic Health", location: "London · Hybrid", status: "Shortlisted", updated: "Updated yesterday", accent: "bg-emerald-50 text-emerald-700" },
  { role: "UX Strategist", company: "Vela Systems", location: "Remote · Global", status: "Applied", updated: "Updated 3 days ago", accent: "bg-cyan-50 text-cyan-700" },
];

export default function UserProfilePage() {
  const [, setLocation] = useLocation();
  const { user } = useUser();
  const { signOut, openUserProfile } = useClerk();
  const displayName = user?.fullName || user?.firstName || "Global Professional";
  const initials = displayName.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
  const email = user?.primaryEmailAddress?.emailAddress || "Verified account";

  return (
    <div className="min-h-[100dvh] bg-[#eef3f7] text-[#17263a]">
      <header className="sticky top-0 z-30 border-b border-slate-200/90 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-4 sm:px-7 lg:px-10">
          <button type="button" onClick={() => setLocation("/")} className="flex items-center gap-3 text-left">
            <img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs" className="h-11 w-auto object-contain" />
            <span className="hidden border-l border-slate-200 pl-3 text-xs font-semibold text-slate-500 sm:block">International Careers</span>
          </button>
          <div className="flex items-center gap-2">
            <button type="button" className="rounded-xl p-2.5 text-slate-500 transition hover:bg-slate-100" aria-label="Notifications"><Bell size={18} /></button>
            <button type="button" onClick={() => setLocation("/")} className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 transition hover:border-cyan-300"><ArrowLeft size={15} />Back to jobs</button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1440px] px-4 py-6 sm:px-7 lg:px-10 lg:py-10">
        <section className="overflow-hidden rounded-[28px] bg-[#17263a] text-white shadow-2xl shadow-slate-900/10">
          <div className="relative px-5 py-7 sm:px-8 lg:px-10 lg:py-9">
            <div className="absolute right-0 top-0 h-56 w-56 rounded-full bg-cyan-400/10 blur-2xl" />
            <div className="relative flex flex-col justify-between gap-7 lg:flex-row lg:items-center">
              <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
                <div className="relative">
                  {user?.imageUrl ? <img src={user.imageUrl} alt={displayName} className="h-24 w-24 rounded-2xl border-4 border-white/15 object-cover shadow-xl" /> : <div className="flex h-24 w-24 items-center justify-center rounded-2xl border-4 border-white/15 bg-cyan-400 text-2xl font-bold text-[#17263a]">{initials}</div>}
                  <span className="absolute -bottom-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full border-4 border-[#17263a] bg-emerald-400 text-[#17263a]"><Check size={14} strokeWidth={3} /></span>
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.2em] text-cyan-300">Global talent profile</p>
                    <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2 py-1 text-[10px] font-bold text-emerald-200"><BadgeCheck size={12} />Identity verified</span>
                  </div>
                  <h1 className="mt-2 text-3xl font-bold tracking-[-.05em] sm:text-4xl">{displayName}</h1>
                  <p className="mt-2 text-sm text-slate-300">Senior Product Designer · Digital platforms & design systems</p>
                  <div className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-xs text-slate-400"><span className="inline-flex items-center gap-1.5"><MapPin size={13} />Riyadh, Saudi Arabia</span><span className="inline-flex items-center gap-1.5"><Globe2 size={13} />Open to global & remote roles</span></div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => openUserProfile()} className="inline-flex h-11 items-center gap-2 rounded-xl bg-cyan-400 px-4 text-xs font-bold text-[#17263a] transition hover:bg-cyan-300"><Pencil size={15} />Edit profile</button>
                <button type="button" onClick={() => signOut({ redirectUrl: "/" })} className="h-11 rounded-xl border border-white/15 px-4 text-xs font-bold text-slate-200 transition hover:bg-white/10">Sign out</button>
              </div>
            </div>
          </div>
        </section>

        <div className="mt-6 grid gap-6 xl:grid-cols-[320px_minmax(0,1fr)]">
          <aside className="space-y-5">
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between"><div><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Profile strength</p><p className="mt-1 text-2xl font-bold">82%</p></div><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-50 text-cyan-700"><Target size={22} /></div></div>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full w-[82%] rounded-full bg-cyan-500" /></div>
              <p className="mt-3 text-xs leading-5 text-slate-500">Add a portfolio and one more verified skill to reach an excellent profile score.</p>
              <button type="button" onClick={() => openUserProfile()} className="mt-4 flex w-full items-center justify-between rounded-xl bg-slate-50 px-3 py-2.5 text-xs font-bold text-slate-700 hover:bg-cyan-50 hover:text-cyan-800">Complete your profile <ChevronRight size={14} /></button>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Account trust</p>
              <div className="mt-4 space-y-3">
                {[{ icon: BadgeCheck, label: "Email verified", note: email }, { icon: ShieldCheck, label: "Secure account", note: "Protected sign-in" }, { icon: LockKeyhole, label: "Privacy controls", note: "You control visibility" }].map(({ icon: Icon, label, note }) => <div key={label} className="flex items-start gap-3"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-700"><Icon size={16} /></span><span className="min-w-0"><span className="block text-xs font-bold text-slate-700">{label}</span><span className="mt-1 block truncate text-[10px] text-slate-400">{note}</span></span></div>)}
              </div>
            </section>
          </aside>

          <div className="min-w-0 space-y-6">
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                <div><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Career identity</p><h2 className="mt-1 text-xl font-bold tracking-[-.03em]">Your international profile</h2><p className="mt-1 text-xs text-slate-500">The professional information employers use to understand your fit.</p></div>
                <button type="button" onClick={() => openUserProfile()} className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-600 hover:border-cyan-300"><Pencil size={14} />Update details</button>
              </div>
              <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {[{ icon: UserRound, label: "Professional title", value: "Senior Product Designer" }, { icon: BriefcaseBusiness, label: "Experience", value: "8+ years" }, { icon: Globe2, label: "Work preference", value: "Remote · Hybrid" }, { icon: MapPin, label: "Target markets", value: "Europe · GCC · Global" }, { icon: FileText, label: "Primary CV", value: "International format" }, { icon: Sparkles, label: "Availability", value: "Open to opportunities" }].map(({ icon: Icon, label, value }) => <div key={label} className="rounded-xl border border-slate-100 bg-slate-50/70 p-4"><Icon size={17} className="text-cyan-700" /><p className="mt-3 text-[10px] font-bold uppercase tracking-[.12em] text-slate-400">{label}</p><p className="mt-1 text-sm font-bold text-slate-700">{value}</p></div>)}
              </div>
              <div className="mt-5"><p className="text-xs font-bold text-slate-700">Core skills</p><div className="mt-3 flex flex-wrap gap-2">{["Product strategy", "UX research", "Design systems", "Figma", "Team leadership", "Accessibility"].map((skill) => <span key={skill} className="rounded-full border border-cyan-100 bg-cyan-50 px-3 py-1.5 text-[11px] font-bold text-cyan-800">{skill}</span>)}</div></div>
            </section>

            <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm" data-testid="profile-application-tracker">
              <div className="flex flex-col justify-between gap-3 border-b border-slate-100 p-5 sm:flex-row sm:items-end sm:p-6">
                <div><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Private workspace</p><h2 className="mt-1 text-xl font-bold tracking-[-.03em]">Application tracker</h2><p className="mt-1 text-xs text-slate-500">Visible only inside your signed-in profile.</p></div>
                <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-[10px] font-bold text-emerald-700"><ShieldCheck size={13} />Private to you</span>
              </div>
              <div className="divide-y divide-slate-100">
                {applications.map((application) => <button type="button" key={application.role} className="flex w-full flex-col gap-3 p-5 text-left transition hover:bg-slate-50 sm:flex-row sm:items-center sm:p-6"><span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#17263a] text-cyan-300"><BriefcaseBusiness size={19} /></span><span className="min-w-0 flex-1"><span className="block text-sm font-bold text-slate-800">{application.role}</span><span className="mt-1 block text-xs text-slate-500">{application.company} · {application.location}</span><span className="mt-1 block text-[10px] text-slate-400">{application.updated}</span></span><span className={`w-fit rounded-full px-3 py-1.5 text-[10px] font-bold ${application.accent}`}>{application.status}</span><ChevronRight size={16} className="hidden text-slate-300 sm:block" /></button>)}
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}