import { lazy, Suspense, type FormEvent, type ReactNode, useEffect, useState } from "react";
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk, useUser } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Redirect, Route, Router as WouterRouter, Switch, useLocation } from "wouter";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();
const DashboardApp = lazy(() => import("@/dashboard"));
const UserProfilePage = lazy(() => import("@/profile"));
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in .env file");
}

const clerkAppearance = {
  variables: {
    colorPrimary: "#0ea5c7",
    colorForeground: "#17263a",
    colorMutedForeground: "#64748b",
    colorBackground: "#ffffff",
    colorInput: "#f8fbff",
    colorInputForeground: "#17263a",
    colorNeutral: "#dbe4ee",
    fontFamily: "DM Sans, sans-serif",
    borderRadius: "0.9rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-white rounded-3xl w-[440px] max-w-full overflow-hidden shadow-2xl border border-slate-200",
    card: "!shadow-none !border-0 !bg-transparent",
    footer: "!shadow-none !border-0 !bg-transparent",
    headerTitle: "text-[#17263a] font-bold",
    headerSubtitle: "text-slate-500",
    socialButtonsBlockButtonText: "text-slate-700 font-semibold",
    formFieldLabel: "text-slate-700 font-bold",
    footerActionLink: "text-cyan-700 font-bold",
    footerActionText: "text-slate-500",
    dividerText: "text-slate-400",
    formButtonPrimary: "bg-[#17263a] hover:bg-[#243b57] font-bold",
    formFieldInput: "bg-[#f8fbff] text-[#17263a] border-slate-200",
    logoBox: "justify-center",
    logoImage: "h-12 w-auto",
    socialButtonsBlockButton: "border-slate-200",
    dividerLine: "bg-slate-200",
    alert: "bg-rose-50 text-rose-700",
    alertText: "text-rose-700",
    formFieldSuccessText: "text-emerald-700",
    identityPreviewEditButton: "text-cyan-700",
    otpCodeFieldInput: "border-slate-200",
    formFieldRow: "gap-2",
    main: "gap-5",
  },
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
};

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function AuthPage({ kind }: { kind: "sign-in" | "sign-up" }) {
  const fullPath = `${basePath}/${kind}`;
  return (
    <div className="auth-page flex min-h-[100dvh] items-center justify-center bg-[#eef3f7] px-4 py-8">
      {kind === "sign-in" ? (
        <SignIn routing="path" path={fullPath} signUpUrl={`${basePath}/sign-up`} forceRedirectUrl={`${basePath}/employer`} />
      ) : (
        <SignUp routing="path" path={fullPath} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={`${basePath}/employer`} />
      )}
    </div>
  );
}

function AuthLoading({ message }: { message: string }) {
  const [, setLocation] = useLocation();
  const [timedOut, setTimedOut] = useState(false);

  useEffect(() => {
    const timeout = window.setTimeout(() => setTimedOut(true), 5000);
    return () => window.clearTimeout(timeout);
  }, []);

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#eef3f7] px-5">
      <div className="w-full max-w-sm rounded-3xl border border-slate-200 bg-white p-7 text-center shadow-xl">
        <img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs" className="mx-auto h-14 w-auto object-contain" />
        {!timedOut ? (
          <>
            <div className="mx-auto mt-6 h-6 w-6 animate-spin rounded-full border-2 border-slate-200 border-t-cyan-500" aria-label="Loading" />
            <p className="mt-4 text-sm font-semibold text-slate-700">{message}</p>
            <p className="mt-2 text-xs text-slate-400">Connecting securely…</p>
          </>
        ) : (
          <>
            <p className="mt-6 text-lg font-bold text-[#17263a]">Secure connection is taking longer.</p>
            <p className="mt-2 text-sm leading-6 text-slate-500">The page is still responsive. Retry the secure session or return home without losing your place.</p>
            <div className="mt-5 flex gap-2">
              <button type="button" onClick={() => window.location.reload()} className="h-11 flex-1 rounded-xl bg-[#17263a] text-xs font-bold text-white">Retry</button>
              <button type="button" onClick={() => setLocation("/")} className="h-11 flex-1 rounded-xl border border-slate-200 text-xs font-bold text-slate-700">Back home</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function EmployerSignInGate() {
  const [, setLocation] = useLocation();
  const { isSignedIn, isLoaded } = useAuth();
  if (!isLoaded) return <AuthLoading message="Loading secure sign in" />;
  if (isSignedIn) return <Redirect to="/employer" />;
  return (
    <div className="auth-page flex min-h-[100dvh] items-center justify-center bg-[#eef3f7] px-4 py-8">
      <div className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-7 text-center shadow-2xl sm:p-10">
        <img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs" className="mx-auto h-16 w-auto object-contain" />
        <p className="mt-6 font-mono-ui text-[10px] font-bold uppercase tracking-[.2em] text-cyan-700">Employer workspace</p>
        <h1 className="mt-2 text-3xl font-bold tracking-[-.04em] text-[#17263a]">Sign in to hire globally.</h1>
        <p className="mt-3 text-sm leading-6 text-slate-500">Access your jobs, applications, company profile, analytics, plans, billing, and Premium Boost controls.</p>
        <div className="mt-7 space-y-3">
          <button type="button" onClick={() => setLocation("/sign-in")} className="h-12 w-full rounded-xl bg-[#17263a] text-sm font-bold text-white transition hover:bg-[#243b57]" data-testid="button-employer-sign-in">Sign in</button>
          <button type="button" onClick={() => setLocation("/sign-up")} className="h-12 w-full rounded-xl border border-slate-200 bg-white text-sm font-bold text-slate-700 transition hover:border-cyan-300 hover:bg-cyan-50/40" data-testid="button-employer-sign-up">Create employer account</button>
        </div>
        <button type="button" onClick={() => setLocation("/")} className="mt-6 text-xs font-bold text-slate-400 hover:text-cyan-700">Back to Dev Global Jobs</button>
      </div>
    </div>
  );
}

function PostJobEntry() {
  const { isSignedIn, isLoaded } = useAuth();
  if (!isLoaded) return <AuthLoading message="Loading secure sign in" />;
  return isSignedIn ? <EmployerPostJobPage /> : <Redirect to="/employer/sign-in" />;
}

function EmployerPostJobPage() {
  const [, setLocation] = useLocation();
  const [submitted, setSubmitted] = useState(false);
  const [plan, setPlan] = useState("Complimentary");

  const submitJob = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-[100dvh] bg-[#eef3f7] text-[#17263a]">
      <header className="flex items-center justify-between border-b border-slate-200 bg-white px-5 py-4 sm:px-10">
        <button type="button" onClick={() => setLocation("/employer")} className="flex items-center gap-3 text-left"><img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs" className="h-11 w-auto object-contain" /><span className="hidden border-l border-slate-200 pl-3 text-xs font-semibold text-slate-500 sm:block">Employer workspace</span></button>
        <button type="button" onClick={() => setLocation("/employer")} className="rounded-xl px-3 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100">Back to dashboard</button>
      </header>
      <main className="mx-auto max-w-6xl px-5 py-8 sm:px-10 lg:py-12">
        <div className="mb-7"><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.2em] text-cyan-700">Create a vacancy</p><h1 className="mt-2 text-3xl font-bold tracking-[-.05em] sm:text-4xl">Post a job internationally.</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">Share a clear opportunity with qualified professionals across the Dev Global Jobs network.</p></div>
        {submitted ? <div className="rounded-3xl border border-emerald-200 bg-emerald-50 p-8 text-center"><div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500 text-2xl text-white">✓</div><h2 className="mt-5 text-2xl font-bold text-emerald-950">Vacancy saved for review</h2><p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-emerald-900/70">Your job is safely saved as a draft. Our review team will check it before paid publishing or Premium Boost activation.</p><div className="mt-6 flex flex-wrap justify-center gap-3"><button type="button" onClick={() => setLocation("/employer?tab=jobs")} className="h-11 rounded-xl bg-[#17263a] px-5 text-xs font-bold text-white">Open My Jobs</button><button type="button" onClick={() => setSubmitted(false)} className="h-11 rounded-xl border border-emerald-200 bg-white px-5 text-xs font-bold text-emerald-900">Create another vacancy</button></div></div> : <form onSubmit={submitJob} className="grid gap-5 lg:grid-cols-[1fr_360px]"><section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div className="mb-6 flex items-center justify-between"><div><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Job details</p><h2 className="mt-1 text-xl font-bold">Tell candidates about the role</h2></div><span className="rounded-full bg-cyan-50 px-3 py-1.5 font-mono-ui text-[10px] font-bold text-cyan-800">STEP 1 OF 2</span></div><div className="grid gap-4 sm:grid-cols-2"><label className="text-xs font-bold text-slate-700 sm:col-span-2">Job title<input required name="title" className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 px-3 text-sm outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100" placeholder="e.g. Senior Product Designer" /></label><label className="text-xs font-bold text-slate-700">Department<select name="department" className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-cyan-500"><option>Design & Creative</option><option>Engineering & Data</option><option>Business & Operations</option><option>Sales & Marketing</option></select></label><label className="text-xs font-bold text-slate-700">Employment type<select name="employmentType" className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-cyan-500"><option>Full time</option><option>Part time</option><option>Contract</option><option>Internship</option></select></label><label className="text-xs font-bold text-slate-700">Location<input required name="location" className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-cyan-500" placeholder="Remote · EMEA" /></label><label className="text-xs font-bold text-slate-700">Work model<select name="workModel" className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-cyan-500"><option>Remote</option><option>Hybrid</option><option>On-site</option></select></label><label className="text-xs font-bold text-slate-700 sm:col-span-2">Role summary<textarea required name="summary" className="mt-1.5 min-h-32 w-full resize-y rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-cyan-500" placeholder="What will this person own, and why is this role important?" /></label></div></section><aside className="space-y-5"><section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6"><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Select posting type</p><h2 className="mt-1 text-lg font-bold">Choose how to publish</h2><div className="mt-4 space-y-3">{[{ name: "Complimentary", price: "FREE · THEN $29", detail: "Standard visibility with a monthly allowance." }, { name: "Featured Posting", price: "FREE · THEN $49", detail: "Higher commercial ranking for 30 days." }].map((item) => <label key={item.name} className={`block cursor-pointer rounded-2xl border p-4 transition ${plan === item.name ? "border-cyan-500 bg-cyan-50/60 ring-2 ring-cyan-100" : "border-slate-200 hover:border-cyan-200"}`}><input type="radio" name="postingPlan" value={item.name} checked={plan === item.name} onChange={() => setPlan(item.name)} className="sr-only" /><span className="flex items-start justify-between gap-3"><span><span className="block text-sm font-bold text-slate-800">{item.name}</span><span className="mt-1 block font-mono-ui text-[10px] font-bold text-cyan-700">{item.price}</span></span><span className={`mt-1 h-4 w-4 rounded-full border-4 ${plan === item.name ? "border-cyan-500" : "border-slate-200"}`} /></span><span className="mt-3 block text-xs leading-5 text-slate-500">{item.detail}</span></label>)}</div></section><section className="rounded-3xl bg-[#17263a] p-5 text-white shadow-xl sm:p-6"><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-300">Secure employer publishing</p><p className="mt-3 text-sm leading-6 text-slate-300">Your company profile stays separate from candidate data. Paid services activate only after payment verification.</p><button type="submit" className="mt-5 h-12 w-full rounded-xl bg-cyan-400 text-sm font-bold text-[#17263a] transition hover:bg-cyan-300" data-testid="button-submit-job">Save vacancy for review</button><p className="mt-3 text-center text-[10px] text-slate-400">By continuing, you confirm the role is accurate and lawful.</p></section></aside></form>}
      </main>
    </div>
  );
}

function ProtectedEmployerDashboard() {
  const { isSignedIn, isLoaded } = useAuth();
  if (!isLoaded) return <AuthLoading message="Loading your workspace" />;
  if (!isSignedIn) return <Redirect to="/employer/sign-in" />;
  return <DashboardView mode="employer" />;
}

function ProtectedUserProfile() {
  const { isSignedIn, isLoaded } = useAuth();
  if (!isLoaded) return <AuthLoading message="Loading your profile" />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  return (
    <Suspense fallback={<AuthLoading message="Loading your profile" />}>
      <UserProfilePage />
    </Suspense>
  );
}

function DashboardView({ mode }: { mode: "employer" | "admin" }) {
  return <Suspense fallback={<div className="flex min-h-[100dvh] items-center justify-center bg-[#eef3f7] text-sm text-slate-500">Loading workspace…</div>}><DashboardApp mode={mode} /></Suspense>;
}

function WebsiteHome() {
  const [, setLocation] = useLocation();
  const { isSignedIn } = useAuth();
  const { user } = useUser();
  const { signOut } = useClerk();
  return (
    <div className="min-h-[100dvh] bg-[#eef3f7] text-[#17263a]">
      <header className="flex items-center justify-between border-b border-slate-200 bg-white/90 px-5 py-4 backdrop-blur sm:px-10">
        <div className="flex items-center gap-3"><img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs" className="h-12 w-auto object-contain" /><span className="hidden border-l border-slate-200 pl-3 text-xs font-semibold text-slate-500 sm:block">International Careers Platform</span></div>
        <div className="flex items-center gap-2">{isSignedIn ? <><button type="button" onClick={() => setLocation("/employer")} className="rounded-xl bg-[#17263a] px-4 py-2.5 text-xs font-bold text-white">Employer workspace</button><button type="button" onClick={() => signOut({ redirectUrl: basePath || "/" })} className="hidden rounded-xl px-3 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 sm:block">Sign out</button></> : <><button type="button" onClick={() => setLocation("/sign-in")} className="rounded-xl px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100">Sign in</button><button type="button" onClick={() => setLocation("/sign-up")} className="rounded-xl bg-[#17263a] px-4 py-2.5 text-xs font-bold text-white">Create account</button></>}</div>
      </header>
      <main className="mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:px-10 lg:grid-cols-[1.1fr_.9fr] lg:items-center lg:py-24">
        <div><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.22em] text-cyan-700">Dev Global Jobs</p><h1 className="mt-4 max-w-3xl text-5xl font-bold tracking-[-.07em] text-[#17263a] sm:text-6xl">Build your next team across borders.</h1><p className="mt-6 max-w-xl text-base leading-7 text-slate-600">Reach professionals exploring international, remote, and purpose-led careers across the world.</p><div className="mt-8 flex flex-wrap gap-3"><button type="button" onClick={() => setLocation("/post-job")} className="h-12 rounded-xl bg-cyan-500 px-5 text-sm font-bold text-[#17263a] shadow-lg shadow-cyan-900/10 transition hover:-translate-y-0.5" data-testid="button-post-job">Post a job</button><button type="button" onClick={() => setLocation("/admin")} className="h-12 rounded-xl border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 hover:border-cyan-300" data-testid="button-admin-preview">Open admin</button></div></div>
        <div className="grid gap-4 sm:grid-cols-2"><div className="rounded-3xl bg-[#17263a] p-6 text-white shadow-2xl sm:col-span-2"><Globe2Icon /><p className="mt-6 font-mono-ui text-[10px] uppercase tracking-[.18em] text-cyan-300">Global hiring control centre</p><p className="mt-2 text-2xl font-bold">One workspace for every stage of hiring.</p><p className="mt-3 text-sm leading-6 text-slate-300">Jobs, candidates, interviews, analytics, plans, billing, and Premium Boost — organised for modern international teams.</p></div><div className="rounded-2xl border border-slate-200 bg-white p-5"><p className="font-mono-ui text-3xl font-bold">42</p><p className="mt-1 text-xs text-slate-500">markets reached</p></div><div className="rounded-2xl border border-slate-200 bg-white p-5"><p className="font-mono-ui text-3xl font-bold">18k+</p><p className="mt-1 text-xs text-slate-500">active talent profiles</p></div></div>
      </main>
    </div>
  );
}

function Globe2Icon() {
  return <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-cyan-300"><span className="text-xl">◎</span></div>;
}

function ClerkRoutes() {
  return (
    <Switch>
      <Route path="/" component={WebsiteHome} />
      <Route path="/post-job" component={PostJobEntry} />
      <Route path="/employer/post-job" component={PostJobEntry} />
      <Route path="/employer/sign-in" component={EmployerSignInGate} />
      <Route path="/employer" component={ProtectedEmployerDashboard} />
      <Route path="/employer/dashboard" component={ProtectedEmployerDashboard} />
      <Route path="/employer/overview" component={ProtectedEmployerDashboard} />
      <Route path="/employer/jobs" component={ProtectedEmployerDashboard} />
      <Route path="/employer/applications" component={ProtectedEmployerDashboard} />
      <Route path="/employer/analytics" component={ProtectedEmployerDashboard} />
      <Route path="/employer/profile" component={ProtectedEmployerDashboard} />
      <Route path="/employer/reports" component={ProtectedEmployerDashboard} />
      <Route path="/employer/plans" component={ProtectedEmployerDashboard} />
      <Route path="/employer/billing" component={ProtectedEmployerDashboard} />
      <Route path="/employer/boosts" component={ProtectedEmployerDashboard} />
      <Route path="/employer/settings" component={ProtectedEmployerDashboard} />
      <Route path="/employer/support" component={ProtectedEmployerDashboard} />
      <Route path="/profile" component={ProtectedUserProfile} />
      <Route path="/admin" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/dashboard" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/jobs" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/employers" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/seekers" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/applications" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/review" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/reviews" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/revenue" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/revenue-metrics" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/requests" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/reports" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/growth" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/settings" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/support" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/premium" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/sources" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/newsletter" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/codes" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/blog" component={() => <DashboardView mode="admin" />} />
      <Route path="/admin/boosts" component={() => <DashboardView mode="admin" />} />
      <Route path="/sign-in/*?" component={() => <AuthPage kind="sign-in" />} />
      <Route path="/sign-up/*?" component={() => <AuthPage kind="sign-up" />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  function stripBase(path: string) {
    return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || "/" : path;
  }

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <RoutedErrorBoundary><ClerkRoutes /></RoutedErrorBoundary>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;