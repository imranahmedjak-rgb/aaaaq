(function() {
  'use strict';
  function fixLayout() {
    var growth = document.getElementById('dgj-growth-admin');
    var main = document.querySelector('main.dgj57-admin-main') || document.querySelector('main.dgj46-main');
    
    // If the element is mis-parented (often dumped directly onto body or root)
    if (growth && main && growth.parentElement !== main) {
      main.appendChild(growth);
    }
  }
  
  var observer = new MutationObserver(fixLayout);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fixLayout);
  } else {
    fixLayout();
  }
})();
