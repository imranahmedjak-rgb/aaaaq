import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { JobCard, JobCardSkeleton } from "@/components/job-card";
import { Briefcase, ArrowLeft, Globe } from "lucide-react";
import type { Job } from "@shared/schema";

export default function AllOpportunities() {
  const { data: allJobs, isLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs/featured"],
    refetchInterval: 30000,
  });
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-6"><Link href="/"><Button variant="outline" size="sm"><ArrowLeft className="h-4 w-4 mr-1.5" />Back to Home</Button></Link></div>
      <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-md shrink-0"><Globe className="h-6 w-6 text-white" /></div>
          <div>
            <h1 className="text-2xl font-bold">All Opportunities</h1>
            <p className="text-muted-foreground mt-0.5 text-sm">Latest verified jobs from around the world{allJobs && allJobs.length > 0 && <span className="ml-2 text-primary font-semibold">({allJobs.length}+ listings)</span>}</p>
          </div>
        </div>
        <Link href="/jobs/all"><Button variant="outline"><Briefcase className="h-4 w-4 mr-1.5" />Browse All Categories</Button></Link>
      </div>
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{Array.from({ length: 18 }).map((_, i) => <JobCardSkeleton key={i} />)}</div>
      ) : !allJobs || allJobs.length === 0 ? (
        <Card className="p-16 text-center"><Briefcase className="h-8 w-8 text-muted-foreground mx-auto mb-4" /><h3 className="font-bold text-lg">Loading opportunities...</h3></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{allJobs.map((job) => <JobCard key={job.id} job={job} />)}</div>
      )}
    </div>
  );
}