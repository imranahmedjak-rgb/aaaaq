import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  GraduationCap, ExternalLink, Search, Globe, DollarSign,
  Sparkles, MapPin, CheckCircle2, BookOpen, Award, Building2,
} from "lucide-react";

const categories = [
  { id: "all", label: "All" },
  { id: "full", label: "Fully Funded" },
  { id: "government", label: "Government" },
  { id: "university", label: "University" },
  { id: "organization", label: "Organizations" },
  { id: "database", label: "Search Databases" },
];

const scholarships = [
  {
    name: "Chevening Scholarships (UK Government)",
    org: "UK Foreign, Commonwealth & Development Office",
    url: "https://www.chevening.org",
    category: "government",
    location: "United Kingdom",
    coverage: "Fully Funded",
    tags: ["Masters", "Leadership", "160+ Countries"],
    description: "UK government's global scholarship for future leaders. Covers tuition, living costs, flights, and visa. One-year master's at any UK university.",
    highlight: true,
  },
  {
    name: "Fulbright Foreign Student Program",
    org: "US Department of State",
    url: "https://foreign.fulbrightonline.org",
    category: "government",
    location: "United States",
    coverage: "Fully Funded",
    tags: ["Masters/PhD", "Research", "155 Countries"],
    description: "Prestigious US government scholarship for graduate study, research, or teaching. Full funding including tuition, stipend, insurance, and airfare.",
    highlight: true,
  },
  {
    name: "DAAD Scholarships",
    org: "German Academic Exchange Service",
    url: "https://www.daad.de/en/study-and-research-in-germany/scholarships/",
    category: "government",
    location: "Germany",
    coverage: "Fully Funded",
    tags: ["All Levels", "Research", "Global"],
    description: "Germany's largest scholarship organization. Programs for undergrads, masters, PhD, and postdoc researchers from all countries.",
    highlight: true,
  },
  {
    name: "Erasmus Mundus Joint Masters",
    org: "European Union",
    url: "https://erasmus-plus.ec.europa.eu/opportunities/individuals/students/erasmus-mundus-joint-masters-scholarships",
    category: "government",
    location: "Europe (Multiple Countries)",
    coverage: "Fully Funded",
    tags: ["Masters", "Multi-Country", "EU Funded"],
    description: "Study masters programs across 2-3 European countries. Full scholarship covering tuition, travel, installation, and monthly allowance.",
    highlight: true,
  },
  {
    name: "Commonwealth Scholarships",
    org: "Commonwealth Scholarship Commission",
    url: "https://cscuk.fcdo.gov.uk",
    category: "government",
    location: "United Kingdom",
    coverage: "Fully Funded",
    tags: ["Masters/PhD", "Commonwealth Nations", "Development"],
    description: "For citizens of Commonwealth countries to study in the UK. Covers tuition, airfare, stipend, and thesis grant.",
  },
  {
    name: "Australia Awards Scholarships",
    org: "Australian Government",
    url: "https://www.dfat.gov.au/people-to-people/australia-awards",
    category: "government",
    location: "Australia",
    coverage: "Fully Funded",
    tags: ["Masters/PhD", "Developing Countries", "Leadership"],
    description: "Australian government scholarships for developing countries. Full tuition, return air travel, living allowance, and health insurance.",
  },
  {
    name: "Swedish Institute Scholarships (SISS)",
    org: "Swedish Institute",
    url: "https://si.se/en/apply/scholarships/swedish-institute-scholarships-for-global-professionals/",
    category: "government",
    location: "Sweden",
    coverage: "Fully Funded",
    tags: ["Masters", "Global Professionals", "Sustainability"],
    description: "Full scholarships for master's studies in Sweden. Covers tuition, living expenses, travel grant, and insurance.",
  },
  {
    name: "Gates Cambridge Scholarships",
    org: "Bill & Melinda Gates Foundation",
    url: "https://www.gatescambridge.org",
    category: "university",
    location: "Cambridge, UK",
    coverage: "Fully Funded",
    tags: ["All Postgrad", "Leadership", "Competitive"],
    description: "Full-cost scholarship at University of Cambridge for outstanding applicants from outside the UK. One of the most prestigious awards globally.",
    highlight: true,
  },
  {
    name: "Rhodes Scholarships",
    org: "Rhodes Trust",
    url: "https://www.rhodeshouse.ox.ac.uk",
    category: "university",
    location: "Oxford, UK",
    coverage: "Fully Funded",
    tags: ["Postgraduate", "Leadership", "Oldest"],
    description: "The world's oldest international scholarship. Full funding for postgraduate study at University of Oxford.",
  },
  {
    name: "Clarendon Scholarships (Oxford)",
    org: "University of Oxford",
    url: "https://www.ox.ac.uk/clarendon/",
    category: "university",
    location: "Oxford, UK",
    coverage: "Fully Funded",
    tags: ["All Subjects", "Auto-Considered", "140+ Awards"],
    description: "Oxford's flagship scholarship. All graduate applicants are automatically considered. Covers tuition and generous living allowance.",
  },
  {
    name: "ETH Zurich Excellence Scholarships",
    org: "ETH Zurich",
    url: "https://ethz.ch/students/en/studies/financial/scholarships/excellencescholarship.html",
    category: "university",
    location: "Zurich, Switzerland",
    coverage: "Fully Funded",
    tags: ["Masters", "STEM", "Top 10 University"],
    description: "Full scholarship at one of the world's top technical universities. Covers tuition, living costs, and provides a study grant.",
  },
  {
    name: "Schwarzman Scholars (Tsinghua University)",
    org: "Schwarzman Foundation",
    url: "https://www.schwarzmanscholars.org",
    category: "university",
    location: "Beijing, China",
    coverage: "Fully Funded",
    tags: ["Masters", "Leadership", "China Focus"],
    description: "One-year master's in Global Affairs at Tsinghua University. Full funding including tuition, room, board, travel, and personal stipend.",
  },
  {
    name: "Mastercard Foundation Scholars",
    org: "Mastercard Foundation",
    url: "https://mastercardfdn.org/all/scholars/",
    category: "organization",
    location: "Global Partner Universities",
    coverage: "Fully Funded",
    tags: ["African Students", "All Levels", "Mentorship"],
    description: "For academically talented yet economically disadvantaged young people from Africa. Full scholarship at partner universities worldwide.",
  },
  {
    name: "Aga Khan Foundation International Scholarships",
    org: "Aga Khan Foundation",
    url: "https://www.akdn.org/our-agencies/aga-khan-foundation/international-scholarship-programme",
    category: "organization",
    location: "Global",
    coverage: "50% Grant / 50% Loan",
    tags: ["Postgraduate", "Developing Countries", "Need-Based"],
    description: "For outstanding students from developing countries who have no other means of financing their studies. Half grant, half interest-free loan.",
  },
  {
    name: "Joint Japan/World Bank Scholarship",
    org: "World Bank & Japan",
    url: "https://www.worldbank.org/en/programs/scholarships",
    category: "organization",
    location: "Partner Universities Worldwide",
    coverage: "Fully Funded",
    tags: ["Masters", "Development", "Mid-Career"],
    description: "For mid-career professionals from developing countries. Full scholarship for development-related master's programs.",
  },
  {
    name: "Scholarships.com",
    org: "Scholarships.com",
    url: "https://www.scholarships.com",
    category: "database",
    location: "Primarily USA",
    coverage: "Varies",
    tags: ["Search Engine", "3.7M+ Awards", "Free"],
    description: "Free scholarship search engine with 3.7 million+ awards worth over $19 billion. Match with scholarships based on your profile.",
  },
  {
    name: "ScholarshipPortal",
    org: "StudyPortals",
    url: "https://www.scholarshipportal.com",
    category: "database",
    location: "Global",
    coverage: "Varies",
    tags: ["International", "Search Tool", "All Levels"],
    description: "Search 12,000+ international scholarships. Filter by country, subject, and level. Comprehensive global scholarship database.",
  },
  {
    name: "Studyportals Scholarships",
    org: "StudyPortals",
    url: "https://www.studyportals.com/scholarship-search/",
    category: "database",
    location: "Global",
    coverage: "Varies",
    tags: ["Global Search", "Masters/Bachelor", "Free"],
    description: "Find scholarships for studying abroad. Search thousands of funding opportunities across countries and disciplines.",
  },
  {
    name: "IEFA (International Education Financial Aid)",
    org: "IEFA",
    url: "https://www.iefa.org",
    category: "database",
    location: "Global",
    coverage: "Varies",
    tags: ["International Students", "Grants", "Loans"],
    description: "Comprehensive database of financial aid, scholarships, grants and loans for international students studying abroad.",
  },
  {
    name: "After School Africa",
    org: "After School Africa",
    url: "https://www.afterschoolafrica.com",
    category: "database",
    location: "Africa Focus",
    coverage: "Varies",
    tags: ["African Students", "Updated Daily", "Free"],
    description: "Daily updated scholarships, internships, and opportunities for African students. Covers undergraduate to postdoctoral levels.",
  },
];

export default function Scholarships() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = scholarships.filter((s) => {
    const matchesCat = activeCategory === "all" || s.category === activeCategory;
    const matchesSearch = !searchQuery ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.org.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 mb-4">
          <GraduationCap className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-scholarships-title">
          Scholarships & Grants
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Discover fully funded scholarships from governments, universities, and organizations worldwide.
          From Chevening to Fulbright, find funding for your education at every level.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Award className="h-4 w-4" />
            <span>{scholarships.length} Scholarships</span>
          </div>
          <div className="flex items-center gap-1.5">
            <DollarSign className="h-4 w-4" />
            <span>Fully Funded Options</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>160+ Countries</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search scholarships, countries, or providers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-scholarships-search"
          />
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {categories.map((cat) => (
            <Button
              key={cat.id}
              variant={activeCategory === cat.id ? "secondary" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`button-scholarships-filter-${cat.id}`}
              className="toggle-elevate"
            >
              {cat.label}
            </Button>
          ))}
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} scholarship{filtered.length !== 1 ? "s" : ""}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((sch) => (
          <Card key={sch.name} className={`p-5 flex flex-col gap-3 hover-elevate ${sch.highlight ? "border-primary/30" : ""}`} data-testid={`card-scholarship-${sch.name.toLowerCase().replace(/[\s()\/]/g, "-").substring(0, 40)}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <h3 className="font-semibold text-sm leading-snug">{sch.name}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">{sch.org}</p>
              </div>
              <Badge
                variant={sch.coverage === "Fully Funded" ? "default" : "secondary"}
                className="shrink-0 text-[10px]"
              >
                {sch.coverage}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed flex-1">{sch.description}</p>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" />
              <span>{sch.location}</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {sch.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-[10px] font-normal">
                  {tag}
                </Badge>
              ))}
            </div>
            <a href={sch.url} target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline" className="w-full" data-testid={`button-scholarship-visit-${sch.name.toLowerCase().replace(/[\s()\/]/g, "-").substring(0, 30)}`}>
                <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                Apply Now
              </Button>
            </a>
          </Card>
        ))}
      </div>

      <Card className="mt-8 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center shrink-0">
            <Sparkles className="h-5 w-5 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">Scholarship Application Tips</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Start applications early -- most prestigious scholarships have deadlines 6-12 months before the program starts.
              Focus on leadership experience, clear career goals, and strong recommendation letters. Many scholarships
              value community impact over perfect grades.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
