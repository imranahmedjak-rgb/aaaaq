import { Card } from "@/components/ui/card";
import { Link } from "wouter";

export default function Terms() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold mb-6" data-testid="text-terms-title">Terms of Service</h1>
      <Card className="p-6 sm:p-8">
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <p className="text-muted-foreground mb-4">Last updated: {new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })}</p>

          <h2>1. Agreement to Terms</h2>
          <p>By accessing and using Dev Global Jobs ("the Service"), operated by Trend Nova World Limited (Company No. 16709289, registered in the United Kingdom at 27 Old Gloucester Street, London, WC1N 3AX), you agree to be bound by these Terms of Service. If you do not agree, please do not use the Service.</p>

          <h2>2. Description of Service</h2>
          <p>Dev Global Jobs is an international job aggregation and posting platform that:</p>
          <ul>
            <li>Aggregates job listings from 11+ verified sources including UN agencies, NGOs, remote job boards, and international employers</li>
            <li>Allows employers to post paid job listings (Regular at $10 USD or Featured at $25 USD)</li>
            <li>Provides job seekers with free access to browse and apply for positions across 17+ countries</li>
            <li>Automatically refreshes listings every 30 minutes from verified API sources</li>
          </ul>

          <h2>3. Job Listings</h2>
          <p>We aggregate jobs from multiple trusted sources. While we strive for accuracy:</p>
          <ul>
            <li>We do not guarantee the accuracy or completeness of any job listing</li>
            <li>Job details are provided by employers and third-party sources</li>
            <li>We are not responsible for the content of external job postings</li>
            <li>Job availability is subject to change without notice</li>
            <li>Aggregated jobs are automatically removed after 30 days</li>
          </ul>

          <h2>4. Employer Job Postings & Pricing</h2>
          <p>Employers who post jobs agree to:</p>
          <ul>
            <li>Provide accurate and truthful job information</li>
            <li>Not post discriminatory, fraudulent, or misleading listings</li>
            <li>Pay the applicable posting fee as outlined below</li>
            <li>Accept that payments are non-refundable once the listing is published</li>
          </ul>

          <h3>4.1 Pricing Tiers</h3>
          <p>We offer two posting options:</p>
          <ul>
            <li><strong>Regular Posting ($10 USD):</strong> Standard job listing visible across all categories and search results. Active for 30 days from the date of publication.</li>
            <li><strong>Featured Posting ($25 USD):</strong> Premium listing highlighted at the top of the homepage and all category pages with a star badge. Active for 60 days from the date of publication.</li>
          </ul>
          <p>All prices are in US Dollars (USD) and are one-time payments with no recurring charges. For detailed pricing information, visit our <Link href="/pricing" className="text-primary underline">Pricing page</Link>.</p>

          <h3>4.2 Listing Duration</h3>
          <ul>
            <li>Regular postings remain active for 30 days from publication</li>
            <li>Featured postings remain active for 60 days from publication</li>
            <li>After the active period, listings are automatically removed</li>
            <li>No extensions are provided unless a new posting fee is paid</li>
          </ul>

          <h2>5. Payments</h2>
          <p>All payments are processed securely through Stripe. By making a payment:</p>
          <ul>
            <li>You authorize us to charge the specified amount ($10 or $25 USD)</li>
            <li>You agree to Stripe's terms of service</li>
            <li>All payments are processed in USD</li>
            <li>Payments are non-refundable once the job listing is published</li>
            <li>Refunds for unpublished listings are handled on a case-by-case basis</li>
          </ul>

          <h2>6. User Conduct</h2>
          <p>You agree not to:</p>
          <ul>
            <li>Use the Service for any unlawful purpose</li>
            <li>Attempt to scrape, spider, or automatically collect data from the Service</li>
            <li>Post false or misleading job listings</li>
            <li>Interfere with the proper functioning of the Service</li>
            <li>Use the Service to send spam or unsolicited communications</li>
          </ul>

          <h2>7. Intellectual Property</h2>
          <p>The Service and its original content, features, and functionality are owned by Trend Nova World Limited and are protected by international copyright, trademark, and other intellectual property laws.</p>

          <h2>8. Limitation of Liability</h2>
          <p>To the maximum extent permitted by law, Dev Global Jobs and Trend Nova World Limited shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the Service, including but not limited to loss of data, profits, or business opportunities.</p>

          <h2>9. Disclaimer</h2>
          <p>The Service is provided "as is" without warranties of any kind. We do not guarantee that:</p>
          <ul>
            <li>The Service will be uninterrupted or error-free</li>
            <li>Job listings will lead to employment</li>
            <li>Information provided is completely accurate</li>
            <li>All job postings are currently available</li>
          </ul>

          <h2>10. Data Protection</h2>
          <p>We are committed to protecting your personal data in accordance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018. For details, see our <Link href="/privacy" className="text-primary underline">Privacy Policy</Link>.</p>

          <h2>11. Governing Law</h2>
          <p>These Terms shall be governed by and construed in accordance with the laws of England and Wales. Any disputes arising under these Terms shall be subject to the exclusive jurisdiction of the courts of England and Wales.</p>

          <h2>12. Changes to Terms</h2>
          <p>We reserve the right to modify these Terms at any time. We will provide notice of significant changes by posting the updated Terms on this page with a revised "Last updated" date.</p>

          <h2>13. Contact</h2>
          <p>For questions about these Terms, contact us:</p>
          <ul>
            <li>Email: <a href="mailto:info@devglobaljobs.com">info@devglobaljobs.com</a></li>
            <li>Phone: <a href="tel:+447473863903">+44 7473 863903</a> (UK)</li>
            <li>WhatsApp: <a href="https://wa.me/994518673521" target="_blank" rel="noopener noreferrer">+994 51 867 35 21</a></li>
            <li>Address: 27 Old Gloucester Street, London, WC1N 3AX, United Kingdom</li>
            <li>Company: <a href="https://trendnovaworld.com/" target="_blank" rel="noopener noreferrer">Trend Nova World Limited</a></li>
          </ul>
        </div>
      </Card>
    </div>
  );
}
