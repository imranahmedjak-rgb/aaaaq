import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Receipt, Search, Globe, Percent, FileText, Shield,
  CheckCircle2, AlertTriangle, Lightbulb, Landmark,
} from "lucide-react";

const regionFilters = [
  { value: "all", label: "All Regions" },
  { value: "europe", label: "Europe" },
  { value: "north-america", label: "North America" },
  { value: "asia-pacific", label: "Asia-Pacific" },
  { value: "middle-east", label: "Middle East" },
  { value: "latin-america", label: "Latin America" },
  { value: "africa", label: "Africa" },
];

interface TaxCountry {
  name: string;
  flag: string;
  region: string;
  incomeTaxRate: string;
  corporateTaxRate: string;
  vatRate: string;
  digitalNomadTax: string;
  treaties: number;
  highlights: string[];
  tips: string[];
  officialUrl: string;
}

const taxData: TaxCountry[] = [
  { name: "United States", flag: "US", region: "north-america", incomeTaxRate: "10-37%", corporateTaxRate: "21%", vatRate: "0% (Sales tax varies by state)", digitalNomadTax: "No specific digital nomad provisions", treaties: 68, highlights: ["Worldwide taxation for citizens and residents", "FEIE: Exclude up to $126,500 (2024) of foreign earned income", "State tax obligations may persist even abroad", "Self-employment tax (15.3%) applies to freelancers"], tips: ["File annually even when living abroad", "Consider Foreign Tax Credit vs FEIE", "Report foreign bank accounts (FBAR) if aggregate >$10,000", "State tax obligations vary -- some states have no income tax"], officialUrl: "https://www.irs.gov/individuals/international-taxpayers" },
  { name: "United Kingdom", flag: "GB", region: "europe", incomeTaxRate: "20-45%", corporateTaxRate: "25%", vatRate: "20%", digitalNomadTax: "No specific digital nomad visa tax rules", treaties: 130, highlights: ["Statutory Residence Test determines tax residency", "Non-domicile regime allows remittance basis taxation", "National Insurance contributions for self-employed", "Capital gains tax on worldwide income for residents"], tips: ["Track days spent in UK carefully for SRT", "Register for Self Assessment if self-employed", "VAT registration required if turnover exceeds GBP 85,000", "Consider non-dom status if applicable"], officialUrl: "https://www.gov.uk/income-tax" },
  { name: "Germany", flag: "DE", region: "europe", incomeTaxRate: "14-45%", corporateTaxRate: "15% + solidarity surcharge", vatRate: "19%", digitalNomadTax: "No specific provisions; standard tax rules apply", treaties: 96, highlights: ["Tax residency if habitual abode or >183 days", "Solidarity surcharge of 5.5% on income tax", "Church tax (8-9%) if registered member", "Freelancers (Freiberufler) have favorable tax treatment"], tips: ["Register with local tax office upon arrival", "Quarterly advance tax payments required", "VAT exemption for small businesses under EUR 22,000", "Keep records of all business expenses in German"], officialUrl: "https://www.bzst.de/EN/Home/home_node.html" },
  { name: "Netherlands", flag: "NL", region: "europe", incomeTaxRate: "36.97-49.50%", corporateTaxRate: "15-25.8%", vatRate: "21%", digitalNomadTax: "30% ruling for highly skilled migrants", treaties: 95, highlights: ["30% ruling: tax-free allowance for expat workers", "Box system: income, business, savings taxed differently", "Self-employed deduction available", "Social security contributions included in tax rates"], tips: ["Apply for 30% ruling within 4 months of starting work", "Register as freelancer (ZZP) at KVK", "VAT registration required for business activities", "Consider BV (private company) structure for higher earners"], officialUrl: "https://www.belastingdienst.nl/wps/wcm/connect/en/home/home" },
  { name: "Portugal", flag: "PT", region: "europe", incomeTaxRate: "14.5-48%", corporateTaxRate: "21%", vatRate: "23%", digitalNomadTax: "NHR: 20% flat rate for qualifying income", treaties: 79, highlights: ["Non-Habitual Resident (NHR) program: 20% flat rate for 10 years", "Digital nomad visa holders may benefit from NHR", "Foreign pension income potentially tax-free under NHR", "Crypto gains taxed if held less than 365 days"], tips: ["Apply for NHR status within first year of residency", "D8 visa holders should clarify tax status with authorities", "Social security: min EUR 20/month for self-employed", "Consider professional tax advice for NHR optimization"], officialUrl: "https://www.portaldasfinancas.gov.pt/at/html/index.html" },
  { name: "Spain", flag: "ES", region: "europe", incomeTaxRate: "19-47%", corporateTaxRate: "25%", vatRate: "21%", digitalNomadTax: "Beckham Law: 24% flat rate for 6 years", treaties: 93, highlights: ["Digital nomad visa holders can opt for Beckham Law", "Beckham Law: taxed as non-resident (24% on first EUR 600K)", "Wealth tax applies in some regions", "Model 720: declare foreign assets over EUR 50,000"], tips: ["Apply for Beckham Law within 6 months of registration", "Regional tax differences (Basque Country, Navarra)", "Quarterly self-employed (autonomo) tax filings", "Social security minimum ~EUR 294/month for autonomos"], officialUrl: "https://sede.agenciatributaria.gob.es/" },
  { name: "France", flag: "FR", region: "europe", incomeTaxRate: "11-45%", corporateTaxRate: "25%", vatRate: "20%", digitalNomadTax: "No specific digital nomad provisions", treaties: 121, highlights: ["Family quotient system for household taxation", "Social charges (CSG/CRDS) of ~9.7% on income", "Micro-entrepreneur regime: simplified taxation up to EUR 77,700", "Wealth tax on real estate (IFI) above EUR 1.3M"], tips: ["Register as micro-entrepreneur for simplified regime", "Social contributions required even for foreign income", "Report worldwide income to French tax authorities", "Tax residence: center of economic interests or >183 days"], officialUrl: "https://www.impots.gouv.fr/portail/" },
  { name: "Switzerland", flag: "CH", region: "europe", incomeTaxRate: "0-11.5% federal + cantonal", corporateTaxRate: "12-14% effective", vatRate: "8.1%", digitalNomadTax: "Lump-sum taxation for qualifying foreigners", treaties: 100, highlights: ["Three-level taxation: federal, cantonal, communal", "Effective rates vary significantly by canton", "Wealth tax on worldwide net assets", "Lump-sum taxation for non-working wealthy foreigners"], tips: ["Tax rates vary dramatically between cantons (Zug vs Geneva)", "Mandatory social security (AHV/IV/EO) contributions", "Pillar 2 and 3a pension contributions are tax-deductible", "Withholding tax for foreign workers without C permit"], officialUrl: "https://www.estv.admin.ch/estv/en/home.html" },
  { name: "Ireland", flag: "IE", region: "europe", incomeTaxRate: "20-40%", corporateTaxRate: "12.5%", vatRate: "23%", digitalNomadTax: "No specific digital nomad provisions", treaties: 76, highlights: ["Split year treatment for arriving/departing residents", "PRSI (social insurance) and USC additional levies", "12.5% corporation tax attracts tech companies", "Foreign income remittance basis for non-domiciled"], tips: ["Non-domiciled residents can use remittance basis", "Register for income tax with Revenue", "PRSI contributions: 4% for employees", "Consider company structure for contractors"], officialUrl: "https://www.revenue.ie/en/Home.aspx" },
  { name: "UAE", flag: "AE", region: "middle-east", incomeTaxRate: "0%", corporateTaxRate: "9% (above AED 375,000)", vatRate: "5%", digitalNomadTax: "No personal income tax", treaties: 137, highlights: ["Zero personal income tax", "Corporate tax of 9% introduced in 2023 (above threshold)", "Free zones offer 0% corporate tax for qualifying activities", "5% VAT on most goods and services"], tips: ["Still need to file US taxes if American citizen", "Free zone vs mainland company setup differences", "Economic substance requirements for some activities", "Consider health insurance as no public healthcare for expats"], officialUrl: "https://tax.gov.ae/en/" },
  { name: "Singapore", flag: "SG", region: "asia-pacific", incomeTaxRate: "0-22%", corporateTaxRate: "17%", vatRate: "9% (GST)", digitalNomadTax: "No specific digital nomad provisions", treaties: 90, highlights: ["Progressive income tax with generous exemptions", "No capital gains tax", "Territorial tax system (foreign-sourced income generally not taxed)", "Generous tax incentives for startups"], tips: ["First SGD 20,000 income effectively tax-free", "Register for GST if turnover exceeds SGD 1M", "Tax residency based on 183+ days presence", "Company incorporation offers tax advantages"], officialUrl: "https://www.iras.gov.sg/" },
  { name: "Japan", flag: "JP", region: "asia-pacific", incomeTaxRate: "5-45%", corporateTaxRate: "23.2%", vatRate: "10%", digitalNomadTax: "No specific digital nomad provisions", treaties: 84, highlights: ["Residents taxed on worldwide income", "Inhabitant tax (approx. 10%) added to national income tax", "5-year rule: foreign assets taxable after 5 years residency", "Self-employed must file final tax return (kakutei shinkoku)"], tips: ["Register at city office for resident card", "Blue tax return filing offers deductions for self-employed", "Social insurance: health + pension contributions required", "Tax year is January-December, filing by March 15"], officialUrl: "https://www.nta.go.jp/english/" },
  { name: "Thailand", flag: "TH", region: "asia-pacific", incomeTaxRate: "0-35%", corporateTaxRate: "20%", vatRate: "7%", digitalNomadTax: "LTR visa: 17% flat rate for professionals", treaties: 61, highlights: ["Territorial tax system (but remittance rule changes 2024)", "LTR visa holders: reduced 17% income tax rate", "Foreign income remitted same year now taxable (2024+)", "Double taxation agreements with 61 countries"], tips: ["LTR visa offers significant tax advantages", "Register for tax ID if earning income in Thailand", "Keep proof of income earned before vs after residency", "Social security contributions if employed locally"], officialUrl: "https://www.rd.go.th/english/" },
  { name: "Mexico", flag: "MX", region: "latin-america", incomeTaxRate: "1.92-35%", corporateTaxRate: "30%", vatRate: "16%", digitalNomadTax: "No specific digital nomad tax provisions", treaties: 60, highlights: ["Residents taxed on worldwide income", "Tax residency: center of vital interests or >183 days", "ISR (income tax) progressive rates", "Digital services tax on foreign providers"], tips: ["Register RFC (tax ID) for legal work", "SAT (tax authority) requires monthly declarations", "Simplified regime (RESICO) for small taxpayers", "Foreign income credit available under treaties"], officialUrl: "https://www.sat.gob.mx/" },
  { name: "Colombia", flag: "CO", region: "latin-america", incomeTaxRate: "0-39%", corporateTaxRate: "35%", vatRate: "19%", digitalNomadTax: "Digital nomad visa holders may be tax exempt on foreign income", treaties: 17, highlights: ["Tax residency: 183+ days in any 365-day period", "Digital nomad visa: possible tax exemption on foreign income", "Wealth tax on net worth above COP 3.7 billion", "Foreign income credits available"], tips: ["Digital nomad visa may avoid tax residency", "Register RUT (tax ID) if becoming resident", "Mandatory pension and health contributions if employed", "Consult local advisor for optimal structuring"], officialUrl: "https://www.dian.gov.co/" },
  { name: "Brazil", flag: "BR", region: "latin-america", incomeTaxRate: "7.5-27.5%", corporateTaxRate: "15% + 10% surtax", vatRate: "Various (ICMS, ISS, PIS/COFINS)", digitalNomadTax: "Digital nomad visa: no local income tax on foreign earnings", treaties: 34, highlights: ["Residents taxed on worldwide income", "Exit tax on certain assets when leaving Brazil", "Complex indirect tax system (being reformed)", "Digital nomad visa holders exempt from local income tax on foreign income"], tips: ["CPF (tax ID) needed for most financial activities", "Digital nomad visa provides tax advantages", "Complex social security obligations if employed locally", "Annual declaration deadline is April 30"], officialUrl: "https://www.gov.br/receitafederal/en" },
  { name: "Canada", flag: "CA", region: "north-america", incomeTaxRate: "15-33% federal + provincial", corporateTaxRate: "15% federal + provincial", vatRate: "5% GST + provincial", digitalNomadTax: "No specific digital nomad provisions", treaties: 94, highlights: ["Residents taxed on worldwide income", "Provincial tax rates vary significantly", "CPP/EI contributions for self-employed", "RRSP/TFSA tax-advantaged savings accounts"], tips: ["Departure tax may apply when leaving Canada", "GST/HST registration if self-employed revenue >$30,000", "Tax residency can be maintained even living abroad", "Provincial residency affects tax rates significantly"], officialUrl: "https://www.canada.ca/en/revenue-agency.html" },
  { name: "Australia", flag: "AU", region: "asia-pacific", incomeTaxRate: "0-45%", corporateTaxRate: "25-30%", vatRate: "10% (GST)", digitalNomadTax: "No specific digital nomad provisions", treaties: 45, highlights: ["Tax-free threshold of AUD 18,200 for residents", "Medicare levy of 2% on taxable income", "Superannuation (retirement) guarantee at 11.5%", "Foreign residents taxed at higher rates from first dollar"], tips: ["Apply for TFN (tax file number) immediately", "Working holiday makers have special tax rates", "GST registration if turnover exceeds AUD 75,000", "Tax year is July-October filing deadline"], officialUrl: "https://www.ato.gov.au/" },
  { name: "South Africa", flag: "ZA", region: "africa", incomeTaxRate: "18-45%", corporateTaxRate: "27%", vatRate: "15%", digitalNomadTax: "No specific digital nomad provisions", treaties: 80, highlights: ["Residents taxed on worldwide income (with exemptions)", "Foreign employment income exemption up to ZAR 1.25M", "Expat tax: income above ZAR 1.25M taxable", "Exchange control regulations on moving money"], tips: ["183-day and 60-day tests for tax residency", "Emigration for tax purposes requires formal process", "Provisional tax payments twice yearly", "Consider double tax treaty benefits"], officialUrl: "https://www.sars.gov.za/" },
  { name: "Estonia", flag: "EE", region: "europe", incomeTaxRate: "20% flat", corporateTaxRate: "20% (only on distributed profits)", vatRate: "22%", digitalNomadTax: "E-Residency: manage EU company remotely", treaties: 61, highlights: ["Flat 20% income tax rate", "Corporate tax only on distributed profits (unique system)", "E-Residency program for digital entrepreneurs", "Digital nomad visa available for remote workers"], tips: ["E-Residency doesn't grant tax residency", "Company profits reinvested are tax-free", "Register for VAT if selling in EU above thresholds", "Social tax of 33% on employee salaries"], officialUrl: "https://www.emta.ee/en" },
];

const complianceTips = [
  "Determine your tax residency status in each country where you spend time -- this is the foundation of your tax obligations",
  "Keep detailed records of days spent in each country; many use the 183-day rule for tax residency",
  "Understand double taxation treaties between your home country and where you work to avoid paying tax twice",
  "Register for a tax identification number in countries where you have tax obligations",
  "Set aside 25-35% of income for taxes to avoid surprises at filing time",
  "Consult with a tax professional experienced in international taxation -- the cost often saves money",
  "Be aware of social security totalization agreements that prevent double contributions",
  "File taxes on time in all jurisdictions where you have obligations -- penalties for late filing can be severe",
  "Digital nomad visas may or may not create tax residency -- read the fine print carefully",
  "Consider incorporating a company in a tax-efficient jurisdiction for your freelance work",
];

export default function RemoteWorkTax() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeRegion, setActiveRegion] = useState("all");

  const filtered = taxData.filter((c) => {
    const matchSearch = !searchQuery || c.name.toLowerCase().includes(searchQuery.toLowerCase()) || c.highlights.some((h) => h.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchRegion = activeRegion === "all" || c.region === activeRegion;
    return matchSearch && matchRegion;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 mb-4">
          <Receipt className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-remote-work-tax-title">
          Remote Work Tax Guide
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Understand your tax obligations as a remote worker or digital nomad.
          Country-by-country tax rates, treaties, and compliance tips.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>{taxData.length} Countries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <FileText className="h-4 w-4" />
            <span>Tax Treaties</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Landmark className="h-4 w-4" />
            <span>Digital Nomad Rules</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search countries or tax topics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-tax-search"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Region</label>
          <div className="flex flex-wrap gap-2">
            {regionFilters.map((r) => (
              <Button key={r.value} variant={activeRegion === r.value ? "secondary" : "outline"} size="sm" onClick={() => setActiveRegion(r.value)} className="toggle-elevate" data-testid={`button-tax-region-${r.value}`}>
                {r.label}
              </Button>
            ))}
          </div>
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} countr{filtered.length !== 1 ? "ies" : "y"}
      </div>

      <div className="space-y-4 mb-8">
        {filtered.map((country) => (
          <Card key={country.name} className="p-5 hover-elevate" data-testid={`card-tax-${country.flag.toLowerCase()}`}>
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center shrink-0 text-lg font-bold">
                {country.flag}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">{country.name}</h3>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  <Badge variant="secondary" className="text-[10px]">{regionFilters.find((r) => r.value === country.region)?.label}</Badge>
                  <Badge variant="outline" className="text-[10px]">{country.treaties} Tax Treaties</Badge>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
              <div className="p-2 rounded-md bg-muted/50">
                <div className="flex items-center gap-1 mb-0.5">
                  <Percent className="h-3 w-3 text-muted-foreground" />
                  <span className="text-[10px] text-muted-foreground">Income Tax</span>
                </div>
                <div className="text-xs font-medium">{country.incomeTaxRate}</div>
              </div>
              <div className="p-2 rounded-md bg-muted/50">
                <div className="flex items-center gap-1 mb-0.5">
                  <Landmark className="h-3 w-3 text-muted-foreground" />
                  <span className="text-[10px] text-muted-foreground">Corporate Tax</span>
                </div>
                <div className="text-xs font-medium">{country.corporateTaxRate}</div>
              </div>
              <div className="p-2 rounded-md bg-muted/50">
                <div className="flex items-center gap-1 mb-0.5">
                  <Receipt className="h-3 w-3 text-muted-foreground" />
                  <span className="text-[10px] text-muted-foreground">VAT/GST</span>
                </div>
                <div className="text-xs font-medium">{country.vatRate}</div>
              </div>
              <div className="p-2 rounded-md bg-muted/50">
                <div className="flex items-center gap-1 mb-0.5">
                  <Globe className="h-3 w-3 text-muted-foreground" />
                  <span className="text-[10px] text-muted-foreground">Nomad Tax</span>
                </div>
                <div className="text-xs font-medium">{country.digitalNomadTax}</div>
              </div>
            </div>

            <div className="mb-3">
              <div className="text-xs font-medium mb-1.5">Key Tax Highlights:</div>
              <div className="space-y-1">
                {country.highlights.map((h, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <Shield className="h-3 w-3 text-primary shrink-0 mt-0.5" />
                    <span className="text-[11px] text-muted-foreground">{h}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-3">
              <div className="text-xs font-medium mb-1.5">Tips:</div>
              <div className="space-y-1">
                {country.tips.map((t, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <Lightbulb className="h-3 w-3 text-amber-500 shrink-0 mt-0.5" />
                    <span className="text-[11px] text-muted-foreground">{t}</span>
                  </div>
                ))}
              </div>
            </div>

            <a href={country.officialUrl} target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline" className="w-full" data-testid={`button-tax-office-${country.flag.toLowerCase()}`}>
                <FileText className="h-3.5 w-3.5 mr-1.5" />
                Official Tax Authority
              </Button>
            </a>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card className="p-12 text-center mb-8">
          <Receipt className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-30" />
          <p className="text-sm text-muted-foreground">No countries match your search. Try adjusting your filters.</p>
        </Card>
      )}

      <Card className="p-6">
        <div className="flex items-start gap-3 mb-4">
          <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
          <h3 className="font-semibold">Tax Compliance Tips for Remote Workers</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {complianceTips.map((tip, i) => (
            <div key={i} className="flex items-start gap-2">
              <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground">{tip}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mt-4 p-4">
        <div className="flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">
            This guide provides general information only and should not be considered as tax advice.
            Tax laws change frequently. Always consult with a qualified tax professional for your specific situation.
            Data is approximate and based on publicly available information as of 2024.
          </p>
        </div>
      </Card>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Remote Work Tax Guide", item: "https://devglobaljobs.com/tools/remote-work-tax" },
            ],
          }),
        }}
      />
    </div>
  );
}
