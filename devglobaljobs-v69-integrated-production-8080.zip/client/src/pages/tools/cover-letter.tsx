import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  FileText, Copy, CheckCircle2, XCircle, Lightbulb,
  Briefcase, GraduationCap, Globe, Building2, Laptop, Check,
} from "lucide-react";

interface Template {
  id: string;
  title: string;
  icon: typeof FileText;
  description: string;
  sections: { heading: string; content: string; tip: string }[];
}

const templates: Template[] = [
  {
    id: "general",
    title: "General Application",
    icon: Briefcase,
    description: "A versatile template suitable for most job applications across industries.",
    sections: [
      {
        heading: "Header & Contact",
        content: "[Your Full Name]\n[Your Address]\n[City, Country]\n[Email] | [Phone]\n[Date]\n\n[Hiring Manager's Name]\n[Company/Organization Name]\n[Company Address]",
        tip: "Match your header format to your resume. If you don't know the hiring manager's name, use 'Dear Hiring Manager' or 'Dear [Department] Team'.",
      },
      {
        heading: "Opening Paragraph",
        content: "Dear [Hiring Manager's Name],\n\nI am writing to express my strong interest in the [Job Title] position at [Company Name], as advertised on [Where You Found the Job]. With [X years] of experience in [Relevant Field] and a proven track record of [Key Achievement], I am confident in my ability to contribute meaningfully to your team.",
        tip: "Hook the reader immediately. Mention a specific achievement or connection to the company. Avoid generic openings like 'I am writing to apply for...'",
      },
      {
        heading: "Body Paragraph 1 - Qualifications",
        content: "In my current role as [Current Title] at [Current Company], I have [describe 2-3 key responsibilities or achievements]. For example, I [specific accomplishment with quantifiable result]. This experience has equipped me with strong skills in [Relevant Skill 1], [Relevant Skill 2], and [Relevant Skill 3].",
        tip: "Mirror the language from the job description. Use specific numbers and results. Show, don't tell.",
      },
      {
        heading: "Body Paragraph 2 - Value Proposition",
        content: "I am particularly drawn to [Company Name] because of [specific reason -- mission, recent project, company value]. I believe my background in [Relevant Area] would allow me to [specific contribution you can make]. I am especially excited about [specific aspect of the role or company].",
        tip: "Show you've researched the company. Connect your experience to their specific needs and mission.",
      },
      {
        heading: "Closing Paragraph",
        content: "I would welcome the opportunity to discuss how my experience and skills can benefit [Company Name]. I am available for an interview at your convenience and can be reached at [Phone] or [Email]. Thank you for considering my application.\n\nSincerely,\n[Your Full Name]",
        tip: "Include a clear call to action. Express enthusiasm without desperation. Keep it professional and confident.",
      },
    ],
  },
  {
    id: "un-ngo",
    title: "UN / NGO Application",
    icon: Globe,
    description: "Tailored for international organizations, UN agencies, and non-profits. Emphasizes mission alignment and competencies.",
    sections: [
      {
        heading: "Header & Contact",
        content: "[Your Full Name]\n[Nationality]\n[Current Location]\n[Email] | [Phone]\n[Date]\n\nHuman Resources\n[Organization Name]\n[Office Location]",
        tip: "Include nationality as it's relevant for UN/NGO positions. Some organizations have geographic diversity requirements.",
      },
      {
        heading: "Opening - Mission Alignment",
        content: "Dear Hiring Manager,\n\nI am writing to apply for the [Position Title] ([Vacancy Number]) at [Organization]. As a [Professional Title] with [X years] of experience in [Sector], I am deeply committed to [Organization's mission area] and eager to contribute to [specific program or initiative].",
        tip: "Always reference the vacancy number. Show genuine passion for the organization's mission, not just the job.",
      },
      {
        heading: "Body - Competency-Based Evidence",
        content: "My experience directly aligns with the core competencies required for this role:\n\n[Competency 1 from job posting]: In my role at [Organization], I [specific example demonstrating this competency with results].\n\n[Competency 2]: I have demonstrated [competency] through [specific achievement], resulting in [measurable impact, e.g., 'benefiting 5,000+ beneficiaries'].\n\n[Competency 3]: My work in [area] involved [description], which strengthened my ability to [relevant skill].",
        tip: "UN and NGO applications are competency-based. Structure your letter around the listed competencies. Use the STAR method for each.",
      },
      {
        heading: "Body - International & Cross-Cultural Experience",
        content: "Having worked in [countries/regions], I bring a nuanced understanding of [relevant context, e.g., 'humanitarian coordination', 'development programming', 'cross-cultural team management']. I am fluent in [languages] and have experience working with [donor agencies, government counterparts, community organizations].",
        tip: "Highlight international experience, language skills, and cultural competency. These are highly valued in UN/NGO roles.",
      },
      {
        heading: "Closing",
        content: "I am available to relocate to [duty station] and can commence duties [timeframe]. I would welcome the opportunity to discuss how my experience can support [Organization's] mission. Thank you for your consideration.\n\nSincerely,\n[Your Full Name]",
        tip: "Show flexibility on location. Mention availability. Don't forget to include your P-11 or PHF if required.",
      },
    ],
  },
  {
    id: "tech",
    title: "Tech Industry",
    icon: Laptop,
    description: "Optimized for technology companies. Focuses on technical skills, projects, and innovation.",
    sections: [
      {
        heading: "Header",
        content: "[Your Full Name]\n[Email] | [Phone] | [LinkedIn] | [GitHub/Portfolio]\n[Date]\n\n[Company Name]\nAttn: [Team/Department]",
        tip: "Include your GitHub profile, portfolio, or personal website. Tech recruiters often check these first.",
      },
      {
        heading: "Opening - Impact Statement",
        content: "Dear [Hiring Manager/Team],\n\nAs a [Title] with [X years] building [type of products/systems], I was excited to see the [Position] opening at [Company]. Your work on [specific product/technology/initiative] resonates with my passion for [relevant area], and I'd love to bring my experience in [Key Tech Stack] to help [specific goal].",
        tip: "Be specific about the technology you've used. Mention a project or product of theirs that genuinely interests you.",
      },
      {
        heading: "Body - Technical Achievements",
        content: "At [Company], I [key technical achievement with metrics]:\n- Architected [system/feature] that [measurable impact, e.g., 'reduced latency by 40%']\n- Led migration from [old tech] to [new tech], improving [metric]\n- Built [tool/product] using [tech stack] serving [scale]\n\nI'm proficient in [languages/frameworks] and have hands-on experience with [cloud platforms, tools, methodologies].",
        tip: "Use bullet points for technical achievements. Quantify everything: performance improvements, scale, team size, deployment frequency.",
      },
      {
        heading: "Body - Culture & Collaboration",
        content: "Beyond technical skills, I value [Company's] emphasis on [culture aspect]. I thrive in [collaborative/agile/remote] environments and have experience [mentoring, code reviews, open source contributions, tech talks]. I believe great software is built by diverse teams with strong communication.",
        tip: "Show you're not just a coder. Highlight soft skills, collaboration, and cultural fit. Many tech companies value this equally.",
      },
      {
        heading: "Closing",
        content: "I'd love to discuss how I can contribute to [Team/Product]. I'm available for a technical discussion or coding exercise at your convenience.\n\nBest regards,\n[Your Full Name]",
        tip: "Keep it brief. Show willingness to do technical assessments. Skip the formalities that feel out of place in tech culture.",
      },
    ],
  },
  {
    id: "academic",
    title: "Academic / Research",
    icon: GraduationCap,
    description: "For university positions, research roles, and academic fellowships. Emphasizes publications and research.",
    sections: [
      {
        heading: "Header",
        content: "[Your Full Name], [Degree]\n[Department/Affiliation]\n[Institution]\n[Email] | [Phone]\n[ORCID: xxxx-xxxx-xxxx-xxxx]\n[Date]\n\n[Search Committee Chair/Department Head]\n[Department]\n[University/Institution]",
        tip: "Include your highest degree after your name. Add ORCID and academic profiles. Address the search committee specifically.",
      },
      {
        heading: "Opening - Research Identity",
        content: "Dear [Professor/Dr. Last Name / Search Committee],\n\nI am writing to apply for the [Position Title] in the Department of [Department] at [University]. I am currently a [Current Position] at [Current Institution], where my research focuses on [Research Area]. My work at the intersection of [Field 1] and [Field 2] positions me well to contribute to [Department's] strengths in [specific area].",
        tip: "Establish your research identity immediately. Show how your work fits within the department's existing strengths.",
      },
      {
        heading: "Body - Research",
        content: "My research agenda centers on [describe main research questions]. My dissertation/recent work, [Title], [brief description of findings and significance]. This work has been published in [Key Journals] and presented at [Conferences]. I have secured [Grant Name] funding of [$Amount] to pursue [research direction].\n\nMy future research plans include [2-3 sentences about upcoming projects and their significance].",
        tip: "Be specific about your research contributions. Mention publications, grants, and future directions. Show productivity and vision.",
      },
      {
        heading: "Body - Teaching",
        content: "I am committed to teaching excellence and have experience teaching [courses] at the [undergraduate/graduate] level. My teaching philosophy emphasizes [approach], and I have received [teaching awards/positive evaluations]. I am prepared to teach [courses listed in the job ad] and develop new courses in [areas].",
        tip: "Balance research and teaching. Mention specific courses you can teach, especially those listed in the job posting.",
      },
      {
        heading: "Closing & Materials",
        content: "Enclosed please find my curriculum vitae, research statement, teaching statement, and [other requested materials]. I have arranged for [number] letters of recommendation to be sent from [referees]. I welcome the opportunity to discuss my candidacy.\n\nSincerely,\n[Your Full Name], [Degree]",
        tip: "List all enclosed documents. Follow submission instructions precisely. Mention referees by name if appropriate.",
      },
    ],
  },
  {
    id: "government",
    title: "Government / Civil Service",
    icon: Building2,
    description: "For government positions and civil service applications. Follows formal structure and addresses selection criteria.",
    sections: [
      {
        heading: "Header",
        content: "[Your Full Name]\n[Address]\n[Email] | [Phone]\n[Date]\n\n[Selection Panel / HR Department]\n[Department/Ministry Name]\n[Reference Number: XXX]",
        tip: "Always include the reference number. Government applications require strict adherence to format and instructions.",
      },
      {
        heading: "Opening - Position Reference",
        content: "Dear Selection Panel,\n\nI am writing to apply for the position of [Job Title] (Reference: [Number]) in the [Department/Division]. With [X years] of experience in [relevant area] within the [public/private/non-profit] sector, I meet the essential criteria outlined in the position description and am committed to [department's mission].",
        tip: "Reference the exact job title and reference number. State clearly that you meet the essential criteria.",
      },
      {
        heading: "Body - Selection Criteria Response",
        content: "I address each selection criterion below:\n\n1. [Criterion from job posting]: [Your evidence with specific example, demonstrating how you meet or exceed this requirement. Include context, action, and result.]\n\n2. [Criterion]: [Evidence]\n\n3. [Criterion]: [Evidence]",
        tip: "Address EVERY selection criterion explicitly. Use the exact language from the position description. Provide concrete evidence for each.",
      },
      {
        heading: "Body - Public Service Values",
        content: "Throughout my career, I have demonstrated commitment to [relevant public service values: integrity, transparency, accountability, service excellence]. In my role at [Organization], I [specific example demonstrating public service values]. I understand the importance of [compliance, governance, equity] in government operations.",
        tip: "Government positions highly value alignment with public service principles. Show you understand the accountability framework.",
      },
      {
        heading: "Closing",
        content: "I confirm that I meet the eligibility requirements for this position including [citizenship/security clearance if applicable]. I am available for interview and can provide references upon request.\n\nYours faithfully,\n[Your Full Name]",
        tip: "Confirm eligibility. Use 'Yours faithfully' for formal government correspondence. Follow all submission instructions exactly.",
      },
    ],
  },
];

const dos = [
  "Customize every cover letter for each application",
  "Address it to a specific person when possible",
  "Keep it to one page (3-4 paragraphs)",
  "Use the same header/font as your resume",
  "Proofread multiple times and have someone review it",
  "Show enthusiasm for the specific role and organization",
  "Include keywords from the job description",
  "Quantify achievements with numbers and percentages",
];

const donts = [
  "Use a generic template without customization",
  "Start with 'To Whom It May Concern' if avoidable",
  "Repeat your resume word-for-word",
  "Write more than one page",
  "Include salary expectations unless requested",
  "Use overly casual language or humor",
  "Focus on what you want rather than what you offer",
  "Forget to proofread for spelling and grammar errors",
];

export default function CoverLetterGuide() {
  const [activeTemplate, setActiveTemplate] = useState("general");
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const template = templates.find((t) => t.id === activeTemplate)!;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(id);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const copyFullTemplate = () => {
    const full = template.sections.map((s) => `--- ${s.heading} ---\n\n${s.content}`).join("\n\n");
    copyToClipboard(full, "full");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-rose-500 to-pink-600 mb-4">
          <FileText className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-cover-letter-title">
          Cover Letter Guide
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Professional cover letter templates with expert tips for every section.
          Choose your industry, customize, and copy to clipboard.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <FileText className="h-4 w-4" />
            <span>{templates.length} Templates</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Lightbulb className="h-4 w-4" />
            <span>Expert Tips</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Copy className="h-4 w-4" />
            <span>Copy to Clipboard</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <label className="text-xs font-medium mb-2 block text-muted-foreground">Choose Template</label>
        <div className="flex flex-wrap gap-2">
          {templates.map((t) => {
            const Icon = t.icon;
            return (
              <Button
                key={t.id}
                variant={activeTemplate === t.id ? "secondary" : "outline"}
                size="sm"
                onClick={() => setActiveTemplate(t.id)}
                className="toggle-elevate"
                data-testid={`button-template-${t.id}`}
              >
                <Icon className="h-3.5 w-3.5 mr-1.5" />
                {t.title}
              </Button>
            );
          })}
        </div>
      </Card>

      <div className="mb-4 flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="font-semibold">{template.title} Template</h2>
          <p className="text-xs text-muted-foreground">{template.description}</p>
        </div>
        <Button size="sm" onClick={copyFullTemplate} data-testid="button-copy-full">
          {copiedSection === "full" ? (
            <>
              <Check className="h-3.5 w-3.5 mr-1.5" />
              Copied
            </>
          ) : (
            <>
              <Copy className="h-3.5 w-3.5 mr-1.5" />
              Copy Full Template
            </>
          )}
        </Button>
      </div>

      <div className="space-y-4 mb-8">
        {template.sections.map((section, i) => (
          <Card key={i} className="p-5" data-testid={`card-template-section-${i}`}>
            <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
              <h3 className="font-semibold text-sm">{section.heading}</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(section.content, `section-${i}`)}
                data-testid={`button-copy-section-${i}`}
              >
                {copiedSection === `section-${i}` ? (
                  <>
                    <Check className="h-3.5 w-3.5 mr-1.5" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5 mr-1.5" />
                    Copy
                  </>
                )}
              </Button>
            </div>
            <pre className="text-xs whitespace-pre-wrap font-sans bg-muted/50 p-3 rounded-md leading-relaxed mb-3">
              {section.content}
            </pre>
            <div className="flex items-start gap-2 p-3 rounded-md bg-amber-500/5">
              <Lightbulb className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-[11px] text-muted-foreground">{section.tip}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-5">
          <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" />
            Do's
          </h3>
          <div className="space-y-2">
            {dos.map((item, i) => (
              <div key={i} className="flex items-start gap-2">
                <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground">{item}</p>
              </div>
            ))}
          </div>
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
            <XCircle className="h-4 w-4 text-red-500" />
            Don'ts
          </h3>
          <div className="space-y-2">
            {donts.map((item, i) => (
              <div key={i} className="flex items-start gap-2">
                <XCircle className="h-3.5 w-3.5 text-red-500 shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground">{item}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Cover Letter Guide", item: "https://devglobaljobs.com/tools/cover-letter" },
            ],
          }),
        }}
      />
    </div>
  );
}
