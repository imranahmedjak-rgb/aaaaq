import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  MapPin, Home, ShoppingCart, Bus, Zap, Stethoscope,
  Music, TrendingUp, TrendingDown, Minus, Globe, BarChart3, Star,
} from "lucide-react";

interface CityData {
  name: string;
  country: string;
  costIndex: number;
  rent: number;
  food: number;
  transportation: number;
  utilities: number;
  healthcare: number;
  entertainment: number;
  qualityOfLife: number;
  safety: number;
}

const cities: CityData[] = [
  { name: "New York", country: "USA", costIndex: 100, rent: 100, food: 100, transportation: 100, utilities: 100, healthcare: 100, entertainment: 100, qualityOfLife: 72, safety: 65 },
  { name: "San Francisco", country: "USA", costIndex: 105, rent: 110, food: 98, transportation: 95, utilities: 102, healthcare: 105, entertainment: 98, qualityOfLife: 74, safety: 60 },
  { name: "Washington DC", country: "USA", costIndex: 92, rent: 88, food: 95, transportation: 90, utilities: 95, healthcare: 98, entertainment: 92, qualityOfLife: 75, safety: 62 },
  { name: "London", country: "UK", costIndex: 95, rent: 95, food: 88, transportation: 105, utilities: 110, healthcare: 30, entertainment: 95, qualityOfLife: 76, safety: 70 },
  { name: "Paris", country: "France", costIndex: 85, rent: 82, food: 90, transportation: 80, utilities: 95, healthcare: 25, entertainment: 88, qualityOfLife: 78, safety: 68 },
  { name: "Berlin", country: "Germany", costIndex: 70, rent: 60, food: 75, transportation: 72, utilities: 90, healthcare: 20, entertainment: 70, qualityOfLife: 80, safety: 75 },
  { name: "Amsterdam", country: "Netherlands", costIndex: 80, rent: 78, food: 80, transportation: 70, utilities: 100, healthcare: 22, entertainment: 82, qualityOfLife: 82, safety: 78 },
  { name: "Zurich", country: "Switzerland", costIndex: 120, rent: 115, food: 130, transportation: 120, utilities: 105, healthcare: 110, entertainment: 125, qualityOfLife: 88, safety: 90 },
  { name: "Geneva", country: "Switzerland", costIndex: 118, rent: 112, food: 128, transportation: 118, utilities: 103, healthcare: 108, entertainment: 120, qualityOfLife: 87, safety: 89 },
  { name: "Vienna", country: "Austria", costIndex: 72, rent: 62, food: 78, transportation: 68, utilities: 88, healthcare: 18, entertainment: 72, qualityOfLife: 86, safety: 88 },
  { name: "Copenhagen", country: "Denmark", costIndex: 90, rent: 85, food: 95, transportation: 85, utilities: 95, healthcare: 15, entertainment: 90, qualityOfLife: 85, safety: 85 },
  { name: "Stockholm", country: "Sweden", costIndex: 82, rent: 75, food: 85, transportation: 78, utilities: 88, healthcare: 12, entertainment: 80, qualityOfLife: 84, safety: 80 },
  { name: "Oslo", country: "Norway", costIndex: 95, rent: 90, food: 100, transportation: 95, utilities: 92, healthcare: 10, entertainment: 95, qualityOfLife: 86, safety: 87 },
  { name: "Tokyo", country: "Japan", costIndex: 78, rent: 72, food: 70, transportation: 75, utilities: 85, healthcare: 35, entertainment: 80, qualityOfLife: 80, safety: 92 },
  { name: "Singapore", country: "Singapore", costIndex: 88, rent: 95, food: 55, transportation: 60, utilities: 90, healthcare: 45, entertainment: 75, qualityOfLife: 83, safety: 95 },
  { name: "Hong Kong", country: "China", costIndex: 90, rent: 105, food: 60, transportation: 45, utilities: 95, healthcare: 40, entertainment: 78, qualityOfLife: 70, safety: 88 },
  { name: "Seoul", country: "South Korea", costIndex: 72, rent: 65, food: 62, transportation: 45, utilities: 75, healthcare: 30, entertainment: 65, qualityOfLife: 75, safety: 85 },
  { name: "Bangkok", country: "Thailand", costIndex: 38, rent: 25, food: 30, transportation: 20, utilities: 45, healthcare: 20, entertainment: 35, qualityOfLife: 65, safety: 62 },
  { name: "Dubai", country: "UAE", costIndex: 75, rent: 80, food: 65, transportation: 55, utilities: 70, healthcare: 50, entertainment: 85, qualityOfLife: 78, safety: 90 },
  { name: "Abu Dhabi", country: "UAE", costIndex: 70, rent: 72, food: 62, transportation: 50, utilities: 65, healthcare: 48, entertainment: 78, qualityOfLife: 77, safety: 92 },
  { name: "Nairobi", country: "Kenya", costIndex: 35, rent: 22, food: 35, transportation: 18, utilities: 40, healthcare: 25, entertainment: 28, qualityOfLife: 55, safety: 45 },
  { name: "Cape Town", country: "South Africa", costIndex: 38, rent: 28, food: 35, transportation: 22, utilities: 38, healthcare: 22, entertainment: 30, qualityOfLife: 62, safety: 40 },
  { name: "Addis Ababa", country: "Ethiopia", costIndex: 30, rent: 18, food: 25, transportation: 12, utilities: 30, healthcare: 15, entertainment: 20, qualityOfLife: 48, safety: 50 },
  { name: "Mumbai", country: "India", costIndex: 32, rent: 30, food: 22, transportation: 10, utilities: 25, healthcare: 15, entertainment: 22, qualityOfLife: 52, safety: 55 },
  { name: "Delhi", country: "India", costIndex: 28, rent: 22, food: 20, transportation: 8, utilities: 22, healthcare: 12, entertainment: 20, qualityOfLife: 48, safety: 45 },
  { name: "Mexico City", country: "Mexico", costIndex: 35, rent: 25, food: 30, transportation: 15, utilities: 30, healthcare: 18, entertainment: 28, qualityOfLife: 60, safety: 42 },
  { name: "Sao Paulo", country: "Brazil", costIndex: 40, rent: 30, food: 35, transportation: 22, utilities: 35, healthcare: 20, entertainment: 32, qualityOfLife: 58, safety: 38 },
  { name: "Buenos Aires", country: "Argentina", costIndex: 30, rent: 20, food: 28, transportation: 12, utilities: 25, healthcare: 15, entertainment: 25, qualityOfLife: 62, safety: 50 },
  { name: "Toronto", country: "Canada", costIndex: 78, rent: 75, food: 82, transportation: 78, utilities: 85, healthcare: 15, entertainment: 78, qualityOfLife: 80, safety: 78 },
  { name: "Sydney", country: "Australia", costIndex: 82, rent: 80, food: 85, transportation: 82, utilities: 88, healthcare: 18, entertainment: 82, qualityOfLife: 82, safety: 80 },
  { name: "Rome", country: "Italy", costIndex: 68, rent: 55, food: 72, transportation: 62, utilities: 85, healthcare: 15, entertainment: 68, qualityOfLife: 75, safety: 72 },
  { name: "Madrid", country: "Spain", costIndex: 62, rent: 52, food: 65, transportation: 55, utilities: 78, healthcare: 12, entertainment: 60, qualityOfLife: 78, safety: 75 },
  { name: "Lisbon", country: "Portugal", costIndex: 55, rent: 48, food: 55, transportation: 45, utilities: 70, healthcare: 10, entertainment: 50, qualityOfLife: 77, safety: 82 },
];

const categories = [
  { key: "rent" as const, label: "Rent", icon: Home, color: "bg-blue-500" },
  { key: "food" as const, label: "Food & Groceries", icon: ShoppingCart, color: "bg-green-500" },
  { key: "transportation" as const, label: "Transportation", icon: Bus, color: "bg-orange-500" },
  { key: "utilities" as const, label: "Utilities", icon: Zap, color: "bg-yellow-500" },
  { key: "healthcare" as const, label: "Healthcare", icon: Stethoscope, color: "bg-red-500" },
  { key: "entertainment" as const, label: "Entertainment", icon: Music, color: "bg-purple-500" },
];

export default function CostOfLiving() {
  const [cityA, setCityA] = useState("");
  const [cityB, setCityB] = useState("");

  const dataA = cities.find((c) => c.name === cityA);
  const dataB = cities.find((c) => c.name === cityB);
  const hasComparison = dataA && dataB;

  function getDiffIcon(a: number, b: number) {
    if (b > a + 5) return <TrendingUp className="h-3.5 w-3.5 text-red-500" />;
    if (b < a - 5) return <TrendingDown className="h-3.5 w-3.5 text-green-500" />;
    return <Minus className="h-3.5 w-3.5 text-muted-foreground" />;
  }

  function getDiffText(a: number, b: number) {
    const diff = b - a;
    if (Math.abs(diff) <= 5) return "Similar";
    return `${diff > 0 ? "+" : ""}${diff}%`;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-rose-600 mb-4">
          <BarChart3 className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-cost-of-living-title">
          Cost of Living Comparison
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Compare cost of living between major cities worldwide. Make informed decisions
          about relocation with detailed category breakdowns.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>{cities.length} Cities</span>
          </div>
          <div className="flex items-center gap-1.5">
            <BarChart3 className="h-4 w-4" />
            <span>6 Categories</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Star className="h-4 w-4" />
            <span>Quality of Life Index</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-medium mb-1.5 block text-muted-foreground">City A</label>
            <Select value={cityA} onValueChange={setCityA}>
              <SelectTrigger data-testid="select-city-a">
                <SelectValue placeholder="Select first city" />
              </SelectTrigger>
              <SelectContent>
                {cities.map((c) => (
                  <SelectItem key={c.name} value={c.name} disabled={c.name === cityB}>
                    {c.name}, {c.country}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-medium mb-1.5 block text-muted-foreground">City B</label>
            <Select value={cityB} onValueChange={setCityB}>
              <SelectTrigger data-testid="select-city-b">
                <SelectValue placeholder="Select second city" />
              </SelectTrigger>
              <SelectContent>
                {cities.map((c) => (
                  <SelectItem key={c.name} value={c.name} disabled={c.name === cityA}>
                    {c.name}, {c.country}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {hasComparison ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <Card className="p-4 text-center">
              <div className="text-xs text-muted-foreground mb-1">Overall Cost Index</div>
              <div className="flex items-center justify-center gap-3">
                <div>
                  <div className="font-bold text-lg">{dataA.costIndex}</div>
                  <div className="text-xs text-muted-foreground">{dataA.name}</div>
                </div>
                <span className="text-muted-foreground">vs</span>
                <div>
                  <div className="font-bold text-lg">{dataB.costIndex}</div>
                  <div className="text-xs text-muted-foreground">{dataB.name}</div>
                </div>
              </div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-xs text-muted-foreground mb-1">Quality of Life</div>
              <div className="flex items-center justify-center gap-3">
                <div>
                  <div className="font-bold text-lg">{dataA.qualityOfLife}/100</div>
                  <div className="text-xs text-muted-foreground">{dataA.name}</div>
                </div>
                <span className="text-muted-foreground">vs</span>
                <div>
                  <div className="font-bold text-lg">{dataB.qualityOfLife}/100</div>
                  <div className="text-xs text-muted-foreground">{dataB.name}</div>
                </div>
              </div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-xs text-muted-foreground mb-1">Safety Score</div>
              <div className="flex items-center justify-center gap-3">
                <div>
                  <div className="font-bold text-lg">{dataA.safety}/100</div>
                  <div className="text-xs text-muted-foreground">{dataA.name}</div>
                </div>
                <span className="text-muted-foreground">vs</span>
                <div>
                  <div className="font-bold text-lg">{dataB.safety}/100</div>
                  <div className="text-xs text-muted-foreground">{dataB.name}</div>
                </div>
              </div>
            </Card>
          </div>

          <div className="space-y-4">
            {categories.map((cat) => {
              const valA = dataA[cat.key];
              const valB = dataB[cat.key];
              const maxVal = Math.max(valA, valB, 1);
              const Icon = cat.icon;
              return (
                <Card key={cat.key} className="p-4" data-testid={`card-compare-${cat.key}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                    <h3 className="font-semibold text-sm flex-1">{cat.label}</h3>
                    <div className="flex items-center gap-1.5">
                      {getDiffIcon(valA, valB)}
                      <span className="text-xs font-medium">{getDiffText(valA, valB)}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span>{dataA.name}</span>
                        <span className="font-medium">{valA}%</span>
                      </div>
                      <div className="h-3 rounded-full bg-muted overflow-hidden">
                        <div className={`h-full rounded-full ${cat.color} opacity-70`} style={{ width: `${(valA / maxVal) * 100}%` }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span>{dataB.name}</span>
                        <span className="font-medium">{valB}%</span>
                      </div>
                      <div className="h-3 rounded-full bg-muted overflow-hidden">
                        <div className={`h-full rounded-full ${cat.color}`} style={{ width: `${(valB / maxVal) * 100}%` }} />
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          <Card className="mt-6 p-4">
            <p className="text-xs text-muted-foreground">
              Cost indices are relative to New York City (NYC = 100). Values above 100 indicate higher costs than NYC.
              Healthcare costs reflect out-of-pocket expenses; countries with universal healthcare show lower values.
              Data is approximate and based on publicly available cost-of-living surveys.
            </p>
          </Card>
        </>
      ) : (
        <Card className="p-12 text-center">
          <MapPin className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-30" />
          <p className="text-sm text-muted-foreground">Select two cities above to compare their cost of living</p>
        </Card>
      )}

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Cost of Living Comparison", item: "https://devglobaljobs.com/tools/cost-of-living" },
            ],
          }),
        }}
      />
    </div>
  );
}
