import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  TrendingUp, Compass, Clock, DollarSign, Star, BookOpen,
  Target, Users, Lightbulb, Award, Briefcase, GraduationCap,
  Globe, Zap, ChevronRight, BarChart3, MessageSquare, Network,
} from "lucide-react";

const roleLevels = [
  "Entry Level",
  "Mid Level",
  "Senior",
  "Lead/Manager",
  "Director",
  "VP/Executive",
] as const;

const industries = [
  "Technology",
  "Healthcare",
  "Finance",
  "Education",
  "Engineering",
  "Marketing",
  "Legal",
  "Government",
  "International Development",
  "Creative/Design",
] as const;

type RoleLevel = (typeof roleLevels)[number];
type Industry = (typeof industries)[number];

interface CareerStep {
  level: string;
  titles: string[];
  salaryRange: string;
  yearsExperience: string;
  skills: string[];
}

interface SkillItem {
  name: string;
  importance: "Essential" | "Important" | "Nice to have";
  learningTime: string;
}

const technologyPath: CareerStep[] = [
  {
    level: "Entry Level",
    titles: ["Junior Developer", "Associate Engineer", "IT Support Specialist"],
    salaryRange: "$45,000 - $70,000",
    yearsExperience: "0-2 years",
    skills: ["Programming fundamentals", "Version control (Git)", "Problem solving", "Communication"],
  },
  {
    level: "Mid Level",
    titles: ["Software Engineer", "Full Stack Developer", "Systems Analyst"],
    salaryRange: "$70,000 - $110,000",
    yearsExperience: "2-5 years",
    skills: ["System design", "Code review", "Mentoring juniors", "Agile methodologies"],
  },
  {
    level: "Senior",
    titles: ["Senior Software Engineer", "Staff Engineer", "Tech Lead"],
    salaryRange: "$110,000 - $160,000",
    yearsExperience: "5-8 years",
    skills: ["Architecture design", "Technical leadership", "Cross-team collaboration", "Performance optimization"],
  },
  {
    level: "Lead/Manager",
    titles: ["Engineering Manager", "Principal Engineer", "Development Lead"],
    salaryRange: "$140,000 - $200,000",
    yearsExperience: "7-12 years",
    skills: ["Team management", "Strategic planning", "Stakeholder management", "Budget oversight"],
  },
  {
    level: "Director",
    titles: ["Director of Engineering", "VP of Technology", "Head of Product"],
    salaryRange: "$180,000 - $280,000",
    yearsExperience: "10-15 years",
    skills: ["Organizational leadership", "P&L management", "Executive communication", "Innovation strategy"],
  },
  {
    level: "VP/Executive",
    titles: ["CTO", "CIO", "SVP of Engineering"],
    salaryRange: "$250,000 - $500,000+",
    yearsExperience: "15+ years",
    skills: ["Board-level communication", "Corporate strategy", "M&A evaluation", "Industry thought leadership"],
  },
];

const intlDevPath: CareerStep[] = [
  {
    level: "Entry Level",
    titles: ["Program Assistant", "Research Associate", "Field Coordinator"],
    salaryRange: "$35,000 - $55,000",
    yearsExperience: "0-2 years",
    skills: ["Research skills", "Report writing", "Cross-cultural communication", "Data collection"],
  },
  {
    level: "Mid Level",
    titles: ["Program Officer", "M&E Specialist", "Project Manager"],
    salaryRange: "$55,000 - $85,000",
    yearsExperience: "3-6 years",
    skills: ["Project management", "Grant writing", "Stakeholder engagement", "Logical frameworks"],
  },
  {
    level: "Senior",
    titles: ["Senior Program Manager", "Technical Advisor", "Country Representative"],
    salaryRange: "$80,000 - $120,000",
    yearsExperience: "6-10 years",
    skills: ["Strategy development", "Donor relations", "Team leadership", "Policy analysis"],
  },
  {
    level: "Lead/Manager",
    titles: ["Head of Programs", "Regional Director", "Chief of Party"],
    salaryRange: "$100,000 - $160,000",
    yearsExperience: "10-15 years",
    skills: ["Multi-country oversight", "Budget management ($5M+)", "Government liaison", "Consortium leadership"],
  },
  {
    level: "Director",
    titles: ["Country Director", "Director of Operations", "VP of Programs"],
    salaryRange: "$140,000 - $220,000",
    yearsExperience: "15-20 years",
    skills: ["Organizational strategy", "Board governance", "Fundraising leadership", "Crisis management"],
  },
  {
    level: "VP/Executive",
    titles: ["Executive Director", "CEO", "Secretary General"],
    salaryRange: "$180,000 - $350,000+",
    yearsExperience: "20+ years",
    skills: ["Global advocacy", "Institutional partnerships", "Thought leadership", "Transformational leadership"],
  },
];

const genericPath: CareerStep[] = [
  {
    level: "Entry Level",
    titles: ["Associate", "Junior Specialist", "Coordinator"],
    salaryRange: "$35,000 - $55,000",
    yearsExperience: "0-2 years",
    skills: ["Core domain knowledge", "Communication", "Time management", "Teamwork"],
  },
  {
    level: "Mid Level",
    titles: ["Specialist", "Analyst", "Project Lead"],
    salaryRange: "$55,000 - $85,000",
    yearsExperience: "3-5 years",
    skills: ["Advanced domain expertise", "Project management", "Mentoring", "Client relations"],
  },
  {
    level: "Senior",
    titles: ["Senior Specialist", "Senior Analyst", "Team Lead"],
    salaryRange: "$85,000 - $130,000",
    yearsExperience: "5-8 years",
    skills: ["Strategic thinking", "Process optimization", "Cross-functional collaboration", "Leadership"],
  },
  {
    level: "Lead/Manager",
    titles: ["Manager", "Department Head", "Principal"],
    salaryRange: "$110,000 - $170,000",
    yearsExperience: "8-12 years",
    skills: ["People management", "Budget oversight", "Strategic planning", "Change management"],
  },
  {
    level: "Director",
    titles: ["Director", "Senior Director", "VP"],
    salaryRange: "$150,000 - $250,000",
    yearsExperience: "12-18 years",
    skills: ["Organizational leadership", "P&L responsibility", "Executive presence", "Industry expertise"],
  },
  {
    level: "VP/Executive",
    titles: ["C-Suite Executive", "Managing Director", "Partner"],
    salaryRange: "$200,000 - $400,000+",
    yearsExperience: "18+ years",
    skills: ["Corporate governance", "Vision & strategy", "Board relations", "Market leadership"],
  },
];

function getCareerPath(industry: Industry): CareerStep[] {
  if (industry === "Technology") return technologyPath;
  if (industry === "International Development") return intlDevPath;
  return genericPath;
}

function getSkillsForPath(industry: Industry): SkillItem[] {
  if (industry === "Technology") {
    return [
      { name: "Cloud Architecture (AWS/GCP/Azure)", importance: "Essential", learningTime: "6-12 months" },
      { name: "System Design & Scalability", importance: "Essential", learningTime: "12-18 months" },
      { name: "Data Structures & Algorithms", importance: "Essential", learningTime: "3-6 months" },
      { name: "CI/CD & DevOps", importance: "Important", learningTime: "3-6 months" },
      { name: "Machine Learning / AI", importance: "Important", learningTime: "6-12 months" },
      { name: "Cybersecurity Fundamentals", importance: "Important", learningTime: "3-6 months" },
      { name: "Product Management", importance: "Nice to have", learningTime: "6-12 months" },
      { name: "Public Speaking & Tech Talks", importance: "Nice to have", learningTime: "3-6 months" },
      { name: "Open Source Contribution", importance: "Nice to have", learningTime: "Ongoing" },
    ];
  }
  if (industry === "International Development") {
    return [
      { name: "Monitoring & Evaluation (M&E)", importance: "Essential", learningTime: "6-12 months" },
      { name: "Grant Writing & Fundraising", importance: "Essential", learningTime: "6-12 months" },
      { name: "Cross-Cultural Communication", importance: "Essential", learningTime: "Ongoing" },
      { name: "Logical Framework Approach", importance: "Important", learningTime: "3-6 months" },
      { name: "Policy Analysis & Advocacy", importance: "Important", learningTime: "6-12 months" },
      { name: "Data Analysis (SPSS/Stata/R)", importance: "Important", learningTime: "3-6 months" },
      { name: "Foreign Language Proficiency", importance: "Nice to have", learningTime: "12-24 months" },
      { name: "GIS & Mapping Tools", importance: "Nice to have", learningTime: "3-6 months" },
      { name: "Humanitarian Standards (Sphere)", importance: "Nice to have", learningTime: "1-3 months" },
    ];
  }
  return [
    { name: "Leadership & Management", importance: "Essential", learningTime: "Ongoing" },
    { name: "Strategic Planning", importance: "Essential", learningTime: "6-12 months" },
    { name: "Communication & Presentation", importance: "Essential", learningTime: "3-6 months" },
    { name: "Financial Literacy", importance: "Important", learningTime: "3-6 months" },
    { name: "Data Analysis", importance: "Important", learningTime: "3-6 months" },
    { name: "Project Management (PMP/Agile)", importance: "Important", learningTime: "3-6 months" },
    { name: "Negotiation Skills", importance: "Nice to have", learningTime: "3-6 months" },
    { name: "Industry Certifications", importance: "Nice to have", learningTime: "6-12 months" },
    { name: "Networking & Relationship Building", importance: "Nice to have", learningTime: "Ongoing" },
  ];
}

const careerTips = [
  { icon: Target, title: "Set Clear Goals", description: "Define 1-year, 3-year, and 5-year career objectives with measurable milestones." },
  { icon: BookOpen, title: "Never Stop Learning", description: "Dedicate at least 5 hours per week to professional development and skill building." },
  { icon: Users, title: "Build Your Network", description: "Attend industry events, join professional associations, and nurture meaningful connections." },
  { icon: MessageSquare, title: "Seek Feedback", description: "Regularly ask for constructive feedback from managers, peers, and mentors." },
  { icon: Award, title: "Document Achievements", description: "Keep a running log of accomplishments, metrics, and positive feedback for reviews." },
  { icon: Globe, title: "Gain Global Exposure", description: "Seek international assignments or cross-cultural projects to broaden your perspective." },
  { icon: Lightbulb, title: "Be a Problem Solver", description: "Proactively identify challenges and propose solutions before being asked." },
  { icon: Network, title: "Find a Mentor", description: "Identify senior professionals who can guide your career decisions and growth." },
];

function getImportanceBadgeVariant(importance: string) {
  if (importance === "Essential") return "default";
  if (importance === "Important") return "secondary";
  return "outline";
}

export default function CareerPath() {
  const [selectedLevel, setSelectedLevel] = useState<RoleLevel | "">("");
  const [selectedIndustry, setSelectedIndustry] = useState<Industry | "">("");
  const [showResults, setShowResults] = useState(false);

  const handleExplore = () => {
    if (selectedLevel && selectedIndustry) {
      setShowResults(true);
    }
  };

  const handleReset = () => {
    setShowResults(false);
    setSelectedLevel("");
    setSelectedIndustry("");
  };

  const fullPath = selectedIndustry ? getCareerPath(selectedIndustry as Industry) : [];
  const levelIndex = fullPath.findIndex((step) => step.level === selectedLevel);
  const visiblePath = levelIndex >= 0 ? fullPath.slice(levelIndex) : fullPath;
  const skills = selectedIndustry ? getSkillsForPath(selectedIndustry as Industry) : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 mb-4">
          <Compass className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-career-path-title">
          Career Path Explorer
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Discover your career progression, required skills, and salary expectations.
          Select your current level and industry to explore your path to the top.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            <span>Career Roadmap</span>
          </div>
          <div className="flex items-center gap-1.5">
            <BarChart3 className="h-4 w-4" />
            <span>Skills Analysis</span>
          </div>
          <div className="flex items-center gap-1.5">
            <DollarSign className="h-4 w-4" />
            <span>Salary Ranges</span>
          </div>
        </div>
      </div>

      <Card className="p-6 mb-8" data-testid="card-career-selector">
        <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
          <Briefcase className="h-5 w-5 text-muted-foreground" />
          Select Your Career Profile
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="text-sm text-muted-foreground mb-1.5 block">Current Role Level</label>
            <Select
              value={selectedLevel}
              onValueChange={(val) => {
                setSelectedLevel(val as RoleLevel);
                setShowResults(false);
              }}
            >
              <SelectTrigger data-testid="select-role-level">
                <SelectValue placeholder="Select your level" />
              </SelectTrigger>
              <SelectContent>
                {roleLevels.map((level) => (
                  <SelectItem key={level} value={level} data-testid={`option-level-${level.toLowerCase().replace(/[\s/]/g, "-")}`}>
                    {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-1.5 block">Industry</label>
            <Select
              value={selectedIndustry}
              onValueChange={(val) => {
                setSelectedIndustry(val as Industry);
                setShowResults(false);
              }}
            >
              <SelectTrigger data-testid="select-industry">
                <SelectValue placeholder="Select your industry" />
              </SelectTrigger>
              <SelectContent>
                {industries.map((ind) => (
                  <SelectItem key={ind} value={ind} data-testid={`option-industry-${ind.toLowerCase().replace(/[\s/]/g, "-")}`}>
                    {ind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Button
            onClick={handleExplore}
            disabled={!selectedLevel || !selectedIndustry}
            data-testid="button-explore-career"
          >
            <Compass className="h-4 w-4 mr-2" />
            Explore Career Path
          </Button>
          {showResults && (
            <Button variant="outline" onClick={handleReset} data-testid="button-reset-career">
              Reset
            </Button>
          )}
        </div>
      </Card>

      {showResults && (
        <>
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-1 flex items-center gap-2" data-testid="text-path-heading">
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
              Career Progression: {selectedIndustry}
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              Your roadmap from {selectedLevel} to executive leadership
            </p>

            <div className="relative pl-8">
              <div className="absolute left-[15px] top-0 bottom-0 w-0.5 bg-border" />
              <div className="space-y-4">
                {visiblePath.map((step, idx) => (
                  <div key={step.level} className="relative" data-testid={`card-career-step-${idx}`}>
                    <div className="absolute -left-8 top-5 w-[13px] h-[13px] rounded-full border-2 border-primary bg-background z-10" />
                    <Card className={`p-5 ${idx === 0 ? "ring-2 ring-primary/20" : ""}`}>
                      <div className="flex items-start justify-between gap-2 flex-wrap mb-3">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-semibold">{step.level}</h3>
                            {idx === 0 && (
                              <Badge variant="default" className="text-[10px]">Current</Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1 flex-wrap">
                            <Clock className="h-3 w-3" />
                            <span>{step.yearsExperience}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-1 text-sm font-medium">
                            <DollarSign className="h-3.5 w-3.5 text-green-600" />
                            {step.salaryRange}
                          </div>
                        </div>
                      </div>
                      <div className="mb-3">
                        <p className="text-xs text-muted-foreground mb-1.5">Typical Titles</p>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {step.titles.map((title) => (
                            <Badge key={title} variant="secondary" className="text-[11px]">
                              {title}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1.5">Key Skills to Develop</p>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {step.skills.map((skill) => (
                            <span key={skill} className="text-xs flex items-center gap-1 text-muted-foreground">
                              <ChevronRight className="h-3 w-3" />
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    </Card>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-1 flex items-center gap-2" data-testid="text-skills-heading">
              <Zap className="h-5 w-5 text-muted-foreground" />
              Skills Gap Analysis
            </h2>
            <p className="text-sm text-muted-foreground mb-4">
              Key skills for advancing in {selectedIndustry}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {skills.map((skill, idx) => (
                <Card key={skill.name} className="p-4" data-testid={`card-skill-${idx}`}>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="text-sm font-medium">{skill.name}</h3>
                    <Badge variant={getImportanceBadgeVariant(skill.importance)} className="text-[10px] shrink-0">
                      {skill.importance}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>{skill.learningTime}</span>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </>
      )}

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-1 flex items-center gap-2" data-testid="text-tips-heading">
          <Star className="h-5 w-5 text-muted-foreground" />
          Career Growth Tips
        </h2>
        <p className="text-sm text-muted-foreground mb-4">
          Professional advice for advancing your career
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {careerTips.map((tip, idx) => {
            const Icon = tip.icon;
            return (
              <Card key={tip.title} className="p-4" data-testid={`card-tip-${idx}`}>
                <div className="flex items-center gap-2 mb-2">
                  <Icon className="h-4 w-4 text-muted-foreground shrink-0" />
                  <h3 className="text-sm font-medium">{tip.title}</h3>
                </div>
                <p className="text-xs text-muted-foreground">{tip.description}</p>
              </Card>
            );
          })}
        </div>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Career Path Explorer", item: "https://devglobaljobs.com/tools/career-path" },
            ],
          }),
        }}
      />
    </div>
  );
}
