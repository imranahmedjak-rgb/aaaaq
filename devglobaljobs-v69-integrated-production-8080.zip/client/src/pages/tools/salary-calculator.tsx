import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Calculator, DollarSign, MapPin, TrendingUp, Info,
  Briefcase, Building2, AlertTriangle,
} from "lucide-react";

const grades = [
  { value: "G-1", label: "G-1 (General Service)", category: "gs" },
  { value: "G-2", label: "G-2 (General Service)", category: "gs" },
  { value: "G-3", label: "G-3 (General Service)", category: "gs" },
  { value: "G-4", label: "G-4 (General Service)", category: "gs" },
  { value: "G-5", label: "G-5 (General Service)", category: "gs" },
  { value: "G-6", label: "G-6 (General Service)", category: "gs" },
  { value: "G-7", label: "G-7 (General Service)", category: "gs" },
  { value: "P-1", label: "P-1 (Professional)", category: "p" },
  { value: "P-2", label: "P-2 (Professional)", category: "p" },
  { value: "P-3", label: "P-3 (Professional)", category: "p" },
  { value: "P-4", label: "P-4 (Professional)", category: "p" },
  { value: "P-5", label: "P-5 (Professional)", category: "p" },
  { value: "D-1", label: "D-1 (Director)", category: "d" },
  { value: "D-2", label: "D-2 (Director)", category: "d" },
];

const steps = Array.from({ length: 15 }, (_, i) => ({
  value: String(i + 1),
  label: `Step ${i + 1}`,
}));

const dutyStations = [
  { value: "new-york", label: "New York, USA", adjustment: 67.5 },
  { value: "geneva", label: "Geneva, Switzerland", adjustment: 83.2 },
  { value: "vienna", label: "Vienna, Austria", adjustment: 57.8 },
  { value: "nairobi", label: "Nairobi, Kenya", adjustment: 42.3 },
  { value: "bangkok", label: "Bangkok, Thailand", adjustment: 38.7 },
  { value: "rome", label: "Rome, Italy", adjustment: 52.1 },
  { value: "addis-ababa", label: "Addis Ababa, Ethiopia", adjustment: 44.6 },
  { value: "paris", label: "Paris, France", adjustment: 62.4 },
  { value: "the-hague", label: "The Hague, Netherlands", adjustment: 55.3 },
  { value: "santiago", label: "Santiago, Chile", adjustment: 35.9 },
];

const baseSalaries: Record<string, number[]> = {
  "G-1": [25800, 26500, 27200, 27900, 28600, 29300, 30000, 30700, 31400, 32100, 32800, 33500, 34200, 34900, 35600],
  "G-2": [29400, 30200, 31000, 31800, 32600, 33400, 34200, 35000, 35800, 36600, 37400, 38200, 39000, 39800, 40600],
  "G-3": [33600, 34500, 35400, 36300, 37200, 38100, 39000, 39900, 40800, 41700, 42600, 43500, 44400, 45300, 46200],
  "G-4": [38400, 39500, 40600, 41700, 42800, 43900, 45000, 46100, 47200, 48300, 49400, 50500, 51600, 52700, 53800],
  "G-5": [43800, 45100, 46400, 47700, 49000, 50300, 51600, 52900, 54200, 55500, 56800, 58100, 59400, 60700, 62000],
  "G-6": [49800, 51300, 52800, 54300, 55800, 57300, 58800, 60300, 61800, 63300, 64800, 66300, 67800, 69300, 70800],
  "G-7": [56400, 58100, 59800, 61500, 63200, 64900, 66600, 68300, 70000, 71700, 73400, 75100, 76800, 78500, 80200],
  "P-1": [37000, 38200, 39400, 40600, 41800, 43000, 44200, 45400, 46600, 47800, 49000, 50200, 51400, 52600, 53800],
  "P-2": [50377, 52000, 53623, 55246, 56869, 58492, 60115, 61738, 63361, 64984, 66607, 68230, 69853, 71476, 73099],
  "P-3": [62692, 64600, 66508, 68416, 70324, 72232, 74140, 76048, 77956, 79864, 81772, 83680, 85588, 87496, 89404],
  "P-4": [77326, 79600, 81874, 84148, 86422, 88696, 90970, 93244, 95518, 97792, 100066, 102340, 104614, 106888, 109162],
  "P-5": [92731, 95400, 98069, 100738, 103407, 106076, 108745, 111414, 114083, 116752, 119421, 122090, 124759, 127428, 130097],
  "D-1": [107460, 110500, 113540, 116580, 119620, 122660, 125700, 128740, 131780, 134820, 137860, 140900, 143940, 146980, 150020],
  "D-2": [119945, 123300, 126655, 130010, 133365, 136720, 140075, 143430, 146785, 150140, 153495, 156850, 160205, 163560, 166915],
};

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(amount);
}

export default function SalaryCalculator() {
  const [grade, setGrade] = useState("");
  const [step, setStep] = useState("");
  const [station, setStation] = useState("");

  const selectedStation = dutyStations.find((s) => s.value === station);
  const baseSalary = grade && step ? baseSalaries[grade]?.[parseInt(step) - 1] || 0 : 0;
  const postAdjustment = selectedStation ? Math.round(baseSalary * (selectedStation.adjustment / 100)) : 0;
  const grossSalary = baseSalary + postAdjustment;
  const staffAssessment = Math.round(grossSalary * 0.22);
  const netSalary = grossSalary - staffAssessment;

  const hasResult = grade && step && station && baseSalary > 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 mb-4">
          <Calculator className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-salary-calculator-title">
          UN Salary Calculator
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Estimate your United Nations salary based on grade level, step, and duty station.
          Includes post adjustment and net salary breakdown.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Briefcase className="h-4 w-4" />
            <span>14 Grade Levels</span>
          </div>
          <div className="flex items-center gap-1.5">
            <MapPin className="h-4 w-4" />
            <span>{dutyStations.length} Duty Stations</span>
          </div>
          <div className="flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            <span>15 Steps</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <Building2 className="h-5 w-5 text-muted-foreground" />
            Select Your Parameters
          </h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Grade Level</label>
              <Select value={grade} onValueChange={setGrade}>
                <SelectTrigger data-testid="select-grade">
                  <SelectValue placeholder="Select grade level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="header-gs" disabled>General Service</SelectItem>
                  {grades.filter((g) => g.category === "gs").map((g) => (
                    <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>
                  ))}
                  <SelectItem value="header-p" disabled>Professional</SelectItem>
                  {grades.filter((g) => g.category === "p").map((g) => (
                    <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>
                  ))}
                  <SelectItem value="header-d" disabled>Director</SelectItem>
                  {grades.filter((g) => g.category === "d").map((g) => (
                    <SelectItem key={g.value} value={g.value}>{g.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Step</label>
              <Select value={step} onValueChange={setStep}>
                <SelectTrigger data-testid="select-step">
                  <SelectValue placeholder="Select step" />
                </SelectTrigger>
                <SelectContent>
                  {steps.map((s) => (
                    <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Duty Station</label>
              <Select value={station} onValueChange={setStation}>
                <SelectTrigger data-testid="select-station">
                  <SelectValue placeholder="Select duty station" />
                </SelectTrigger>
                <SelectContent>
                  {dutyStations.map((s) => (
                    <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedStation && (
            <div className="mt-4 p-3 rounded-md bg-muted/50">
              <div className="flex items-center gap-2 text-sm">
                <Info className="h-4 w-4 text-muted-foreground shrink-0" />
                <span className="text-muted-foreground">
                  Post adjustment multiplier for {selectedStation.label}: <strong>{selectedStation.adjustment}%</strong>
                </span>
              </div>
            </div>
          )}
        </Card>

        <Card className="p-6">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-muted-foreground" />
            Salary Breakdown (Annual)
          </h2>
          {hasResult ? (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                  <span className="text-sm">Base Salary</span>
                  <span className="font-semibold" data-testid="text-base-salary">{formatCurrency(baseSalary)}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                  <span className="text-sm">Post Adjustment ({selectedStation?.adjustment}%)</span>
                  <span className="font-semibold text-green-600" data-testid="text-post-adjustment">+{formatCurrency(postAdjustment)}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md border-t">
                  <span className="text-sm font-medium">Gross Salary</span>
                  <span className="font-bold" data-testid="text-gross-salary">{formatCurrency(grossSalary)}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                  <span className="text-sm">Staff Assessment (~22%)</span>
                  <span className="font-semibold text-red-500" data-testid="text-staff-assessment">-{formatCurrency(staffAssessment)}</span>
                </div>
              </div>

              <div className="p-4 rounded-md bg-primary/5 border border-primary/10">
                <div className="text-sm text-muted-foreground mb-1">Estimated Net Annual Salary</div>
                <div className="text-2xl font-bold" data-testid="text-net-salary">{formatCurrency(netSalary)}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  Approx. {formatCurrency(Math.round(netSalary / 12))}/month
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">{grade}</Badge>
                <Badge variant="outline">Step {step}</Badge>
                <Badge variant="secondary">{selectedStation?.label}</Badge>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Calculator className="h-12 w-12 mb-3 opacity-30" />
              <p className="text-sm">Select grade, step, and duty station to calculate</p>
            </div>
          )}
        </Card>
      </div>

      <Card className="mt-6 p-5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-sm mb-1">Disclaimer</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              These salary figures are approximate estimates based on publicly available UN salary scale data.
              Actual compensation may vary based on dependency status, tax exemptions, allowances (rental subsidy,
              education grant, hardship allowance), and periodic adjustments by the International Civil Service Commission (ICSC).
              For official salary scales, please visit the <a href="https://icsc.un.org/" target="_blank" rel="noopener noreferrer" className="underline">ICSC website</a>.
            </p>
          </div>
        </div>
      </Card>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "UN Salary Calculator", item: "https://devglobaljobs.com/tools/salary-calculator" },
            ],
          }),
        }}
      />
    </div>
  );
}
