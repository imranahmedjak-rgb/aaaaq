import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  CheckCircle2, XCircle, AlertTriangle, ArrowRight,
  User, FileText, Briefcase, Award, GraduationCap,
  Star, Image, Link2, Camera, Target, TrendingUp,
  Lightbulb, Search, BarChart3, Zap, Shield,
  Eye, RotateCcw, ChevronRight, Users, BookOpen,
  MessageSquare, Hash,
} from "lucide-react";
import { SiLinkedin } from "react-icons/si";

const INDUSTRY_KEYWORDS: Record<string, string[]> = {
  "Technology": [
    "Software Engineer", "Full Stack Developer", "Cloud Architect", "DevOps",
    "Machine Learning", "AI", "Data Science", "Cybersecurity", "SaaS",
    "Agile", "Scrum", "Product Manager", "Tech Lead", "Innovation",
  ],
  "Healthcare": [
    "Patient Care", "Clinical Research", "Health Informatics", "Telemedicine",
    "Public Health", "Epidemiology", "Healthcare Management", "HIPAA",
    "Pharmaceutical", "Biotech", "Medical Devices", "Wellness",
  ],
  "Finance": [
    "Financial Analysis", "Risk Management", "Investment Banking", "Fintech",
    "Portfolio Management", "Compliance", "CFA", "Blockchain", "ESG",
    "Asset Management", "Private Equity", "Venture Capital",
  ],
  "Education": [
    "Curriculum Development", "EdTech", "Student Success", "E-Learning",
    "Academic Research", "STEM Education", "Instructional Design",
    "Higher Education", "K-12", "Educational Leadership", "Assessment",
  ],
  "NGO/Development": [
    "International Development", "Humanitarian Aid", "Program Management",
    "Monitoring & Evaluation", "Grant Writing", "Capacity Building",
    "Sustainable Development", "SDGs", "USAID", "UN", "Donor Relations",
    "Gender Equality", "Climate Action", "Food Security",
  ],
  "Marketing": [
    "Digital Marketing", "SEO", "Content Strategy", "Brand Management",
    "Growth Hacking", "Marketing Automation", "Social Media", "Analytics",
    "Demand Generation", "ABM", "Conversion Optimization", "Copywriting",
  ],
  "Engineering": [
    "Project Engineering", "CAD", "Process Optimization", "Quality Assurance",
    "Lean Manufacturing", "Six Sigma", "AutoCAD", "PMP", "Safety Compliance",
    "Sustainability", "Civil Engineering", "Mechanical Engineering",
  ],
  "Legal": [
    "Corporate Law", "Compliance", "Contract Negotiation", "IP Law",
    "Litigation", "Legal Tech", "Regulatory Affairs", "Due Diligence",
    "Mergers & Acquisitions", "International Law", "Privacy Law", "GDPR",
  ],
  "Creative": [
    "UX/UI Design", "Brand Identity", "Visual Storytelling", "Adobe Creative Suite",
    "Motion Graphics", "Art Direction", "User Research", "Design Thinking",
    "Figma", "Prototyping", "Creative Direction", "Photography",
  ],
  "Sales": [
    "Business Development", "Account Management", "SaaS Sales", "B2B",
    "Pipeline Management", "Salesforce", "Negotiation", "Revenue Growth",
    "Key Account Management", "Strategic Partnerships", "CRM", "Closing",
  ],
};

const HEADLINE_EXAMPLES = [
  {
    before: "Software Developer at XYZ Company",
    after: "Senior Full Stack Developer | React & Node.js | Building Scalable SaaS Products | Open Source Contributor",
    tip: "Add specializations, technologies, and value propositions",
  },
  {
    before: "Marketing Manager",
    after: "Digital Marketing Manager | SEO & Content Strategy | Drove 300% Traffic Growth | HubSpot Certified",
    tip: "Include metrics, certifications, and specific expertise",
  },
  {
    before: "Project Manager at NGO",
    after: "International Development Program Manager | M&E Specialist | USAID & UN Projects | 15+ Countries",
    tip: "Highlight scope, donor experience, and geographic reach",
  },
  {
    before: "Recent Graduate",
    after: "Computer Science Graduate | Python & Machine Learning Enthusiast | Seeking Data Science Opportunities",
    tip: "Show skills, passion, and career direction even without experience",
  },
  {
    before: "Looking for opportunities",
    after: "Healthcare Administrator | 10+ Years in Hospital Operations | Patient Experience Champion | MBA",
    tip: "Never use 'looking for' - lead with your value and expertise",
  },
];

const SECTION_TIPS = [
  {
    section: "Headline",
    icon: Hash,
    tips: [
      "Use all 220 characters available",
      "Include your specialty, industry, and unique value",
      "Add relevant keywords recruiters search for",
      "Separate key points with | or symbols",
      "Avoid generic titles like 'Looking for opportunities'",
    ],
  },
  {
    section: "Summary / About",
    icon: FileText,
    tips: [
      "Write in first person for a personal touch",
      "Open with a compelling hook in the first 2 lines",
      "Include measurable achievements and results",
      "Add a clear call-to-action at the end",
      "Use all 2,600 characters - longer summaries rank higher",
      "Include industry keywords naturally throughout",
    ],
  },
  {
    section: "Experience",
    icon: Briefcase,
    tips: [
      "Add at least 3 positions with detailed descriptions",
      "Use bullet points starting with action verbs",
      "Include quantifiable achievements (%, $, numbers)",
      "Add media: presentations, articles, or project links",
      "Write descriptions with ATS-friendly keywords",
    ],
  },
  {
    section: "Skills & Endorsements",
    icon: Zap,
    tips: [
      "Add the maximum 50 skills allowed",
      "Pin your top 3 most relevant skills",
      "Request endorsements from colleagues",
      "Match skills to job descriptions you want",
      "Include both technical and soft skills",
    ],
  },
  {
    section: "Education",
    icon: GraduationCap,
    tips: [
      "Include all degrees, certifications, and relevant courses",
      "Add activities, societies, and achievements",
      "Link to thesis or research papers if applicable",
      "Include relevant online courses (Coursera, edX, etc.)",
    ],
  },
  {
    section: "Recommendations",
    icon: MessageSquare,
    tips: [
      "Aim for at least 5 recommendations",
      "Request from supervisors, colleagues, and clients",
      "Give recommendations to receive them back",
      "Ensure recommendations highlight different strengths",
      "Recent recommendations carry more weight",
    ],
  },
  {
    section: "Featured Section",
    icon: Star,
    tips: [
      "Showcase your best work: articles, presentations, projects",
      "Add links to your portfolio or personal website",
      "Include media coverage or press mentions",
      "Feature your most impressive achievements",
      "Update regularly with fresh content",
    ],
  },
];

const SEO_BEST_PRACTICES = [
  { title: "Use keywords in your headline", description: "Recruiters search by job title and skills. Include the exact terms they use in your headline for maximum visibility." },
  { title: "Customize your LinkedIn URL", description: "Change your URL to linkedin.com/in/yourname for a cleaner look and better search ranking." },
  { title: "Complete every section", description: "LinkedIn's algorithm favors complete profiles. Fill out all sections to achieve 'All-Star' status." },
  { title: "Post content regularly", description: "Active profiles appear higher in search results. Share articles, insights, or industry news weekly." },
  { title: "Engage with others' content", description: "Commenting and sharing boosts your visibility. Aim for meaningful engagement, not just likes." },
  { title: "Use hashtags strategically", description: "Follow and use relevant industry hashtags in your posts to reach a wider audience." },
  { title: "Update your profile regularly", description: "LinkedIn boosts recently updated profiles in search results. Make small updates monthly." },
  { title: "Add alt text to images", description: "Include descriptive alt text on any images you upload to improve accessibility and SEO." },
];

const COMMON_MISTAKES = [
  { title: "Using a selfie or informal photo", description: "Your profile photo should be professional, high-quality, and show your face clearly against a clean background." },
  { title: "Leaving the headline as default", description: "The auto-generated 'Job Title at Company' misses a huge opportunity to showcase your value and attract recruiters." },
  { title: "Writing in third person", description: "Your summary should be in first person. Third person sounds impersonal and creates distance with the reader." },
  { title: "No summary at all", description: "The About section is prime real estate. An empty summary means you're invisible to search algorithms." },
  { title: "Listing duties instead of achievements", description: "Don't just list responsibilities. Show impact with numbers: 'Increased revenue by 40%' beats 'Responsible for revenue.'" },
  { title: "Having fewer than 50 connections", description: "LinkedIn shows profiles with 500+ connections more often. Build your network actively." },
  { title: "Ignoring recommendations", description: "Profiles with recommendations rank higher and build trust. Ask for them proactively." },
  { title: "Not engaging with content", description: "A profile without activity looks dormant. Post, comment, and share at least once a week." },
];

interface AuditInput {
  headline: string;
  summary: string;
  experienceCount: string;
  skillsCount: string;
  hasEducation: boolean;
  hasCertifications: boolean;
  recommendationsCount: string;
  hasCustomUrl: boolean;
  hasProfilePhoto: boolean;
  hasBannerImage: boolean;
}

interface SectionScore {
  section: string;
  score: number;
  maxScore: number;
  feedback: string;
  status: "good" | "warning" | "poor";
}

function calculateAudit(input: AuditInput): { totalScore: number; sections: SectionScore[] } {
  const sections: SectionScore[] = [];

  const headlineLen = input.headline.trim().length;
  let headlineScore = 0;
  let headlineFeedback = "";
  if (headlineLen === 0) {
    headlineFeedback = "Missing headline. Add a keyword-rich headline up to 220 characters.";
  } else if (headlineLen < 40) {
    headlineScore = 5;
    headlineFeedback = "Headline is too short. Use more of the 220 characters to include keywords and specialties.";
  } else if (headlineLen < 100) {
    headlineScore = 10;
    headlineFeedback = "Good start, but expand your headline with more keywords, skills, or your unique value proposition.";
  } else {
    headlineScore = 15;
    headlineFeedback = "Excellent headline length! Make sure it includes relevant industry keywords.";
  }
  sections.push({ section: "Headline", score: headlineScore, maxScore: 15, feedback: headlineFeedback, status: headlineScore >= 10 ? "good" : headlineScore >= 5 ? "warning" : "poor" });

  const summaryLen = input.summary.trim().length;
  let summaryScore = 0;
  let summaryFeedback = "";
  if (summaryLen === 0) {
    summaryFeedback = "Missing summary. Write a compelling About section with keywords and achievements.";
  } else if (summaryLen < 200) {
    summaryScore = 5;
    summaryFeedback = "Summary is too short. Aim for at least 500 characters with measurable achievements.";
  } else if (summaryLen < 500) {
    summaryScore = 10;
    summaryFeedback = "Good summary, but add more detail. Include achievements, skills, and a call-to-action.";
  } else {
    summaryScore = 20;
    summaryFeedback = "Strong summary length! Ensure it includes a hook, achievements, and a CTA.";
  }
  sections.push({ section: "Summary", score: summaryScore, maxScore: 20, feedback: summaryFeedback, status: summaryScore >= 10 ? "good" : summaryScore >= 5 ? "warning" : "poor" });

  const expCount = parseInt(input.experienceCount) || 0;
  let expScore = 0;
  let expFeedback = "";
  if (expCount === 0) {
    expFeedback = "Add at least 1 work experience with detailed descriptions and achievements.";
  } else if (expCount < 3) {
    expScore = 8;
    expFeedback = "Add more positions. Even volunteer work, internships, and freelance projects count.";
  } else {
    expScore = 15;
    expFeedback = "Good number of positions. Ensure each has bullet points with quantifiable results.";
  }
  sections.push({ section: "Experience", score: expScore, maxScore: 15, feedback: expFeedback, status: expScore >= 10 ? "good" : expScore >= 5 ? "warning" : "poor" });

  const skillsNum = parseInt(input.skillsCount) || 0;
  let skillsScore = 0;
  let skillsFeedback = "";
  if (skillsNum === 0) {
    skillsFeedback = "Add skills to your profile. LinkedIn allows up to 50 skills.";
  } else if (skillsNum < 10) {
    skillsScore = 3;
    skillsFeedback = "Add more skills. Aim for 30-50 skills covering both technical and soft skills.";
  } else if (skillsNum < 30) {
    skillsScore = 7;
    skillsFeedback = "Good skills count. Try to reach 50 and get endorsements on your top skills.";
  } else {
    skillsScore = 10;
    skillsFeedback = "Excellent skills count! Pin your top 3 most relevant skills and seek endorsements.";
  }
  sections.push({ section: "Skills", score: skillsScore, maxScore: 10, feedback: skillsFeedback, status: skillsScore >= 7 ? "good" : skillsScore >= 3 ? "warning" : "poor" });

  const eduScore = input.hasEducation ? 8 : 0;
  sections.push({
    section: "Education",
    score: eduScore,
    maxScore: 8,
    feedback: input.hasEducation
      ? "Education listed. Add coursework, activities, and academic achievements for more impact."
      : "Add your education, including degrees, certifications, and relevant online courses.",
    status: input.hasEducation ? "good" : "poor",
  });

  const certScore = input.hasCertifications ? 7 : 0;
  sections.push({
    section: "Certifications",
    score: certScore,
    maxScore: 7,
    feedback: input.hasCertifications
      ? "Certifications added. Keep them current and add any new ones as you earn them."
      : "Add relevant certifications. They significantly boost profile visibility and credibility.",
    status: input.hasCertifications ? "good" : "warning",
  });

  const recCount = parseInt(input.recommendationsCount) || 0;
  let recScore = 0;
  let recFeedback = "";
  if (recCount === 0) {
    recFeedback = "No recommendations yet. Ask supervisors and colleagues for recommendations.";
  } else if (recCount < 3) {
    recScore = 4;
    recFeedback = "Good start on recommendations. Aim for at least 5 from diverse professional contacts.";
  } else if (recCount < 5) {
    recScore = 7;
    recFeedback = "Solid recommendation count. Continue building with recommendations that highlight different strengths.";
  } else {
    recScore = 10;
    recFeedback = "Excellent recommendations! These significantly boost your profile credibility.";
  }
  sections.push({ section: "Recommendations", score: recScore, maxScore: 10, feedback: recFeedback, status: recScore >= 7 ? "good" : recScore >= 4 ? "warning" : "poor" });

  const urlScore = input.hasCustomUrl ? 5 : 0;
  sections.push({
    section: "Custom URL",
    score: urlScore,
    maxScore: 5,
    feedback: input.hasCustomUrl
      ? "Custom URL set. This looks professional on resumes and business cards."
      : "Set a custom URL (linkedin.com/in/yourname) for better branding and SEO.",
    status: input.hasCustomUrl ? "good" : "warning",
  });

  const photoScore = input.hasProfilePhoto ? 5 : 0;
  sections.push({
    section: "Profile Photo",
    score: photoScore,
    maxScore: 5,
    feedback: input.hasProfilePhoto
      ? "Profile photo added. Ensure it's professional, high-quality, and recent."
      : "Add a professional profile photo. Profiles with photos get 21x more views.",
    status: input.hasProfilePhoto ? "good" : "poor",
  });

  const bannerScore = input.hasBannerImage ? 5 : 0;
  sections.push({
    section: "Banner Image",
    score: bannerScore,
    maxScore: 5,
    feedback: input.hasBannerImage
      ? "Banner image added. Use it to reinforce your personal brand or industry."
      : "Add a banner image. It's free visual real estate to showcase your brand.",
    status: input.hasBannerImage ? "good" : "warning",
  });

  const totalScore = sections.reduce((sum, s) => sum + s.score, 0);

  return { totalScore, sections };
}

export default function LinkedInOptimizer() {
  const [auditInput, setAuditInput] = useState<AuditInput>({
    headline: "",
    summary: "",
    experienceCount: "",
    skillsCount: "",
    hasEducation: false,
    hasCertifications: false,
    recommendationsCount: "",
    hasCustomUrl: false,
    hasProfilePhoto: false,
    hasBannerImage: false,
  });
  const [hasAudited, setHasAudited] = useState(false);

  const auditResult = useMemo(() => {
    if (!hasAudited) return null;
    return calculateAudit(auditInput);
  }, [hasAudited, auditInput]);

  const handleAudit = () => {
    setHasAudited(true);
  };

  const handleReset = () => {
    setAuditInput({
      headline: "",
      summary: "",
      experienceCount: "",
      skillsCount: "",
      hasEducation: false,
      hasCertifications: false,
      recommendationsCount: "",
      hasCustomUrl: false,
      hasProfilePhoto: false,
      hasBannerImage: false,
    });
    setHasAudited(false);
  };

  function getScoreColor(score: number) {
    if (score >= 70) return "text-green-600";
    if (score >= 40) return "text-amber-500";
    return "text-red-500";
  }

  function getScoreLabel(score: number) {
    if (score >= 80) return "All-Star Profile";
    if (score >= 60) return "Strong Profile";
    if (score >= 40) return "Intermediate";
    if (score >= 20) return "Needs Improvement";
    return "Beginner";
  }

  function getStatusIcon(status: "good" | "warning" | "poor") {
    if (status === "good") return <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />;
    if (status === "warning") return <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" />;
    return <XCircle className="h-4 w-4 text-red-500 shrink-0" />;
  }

  const circumference = 2 * Math.PI * 45;
  const totalScore = auditResult?.totalScore ?? 0;
  const strokeDashoffset = circumference - (totalScore / 100) * circumference;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <nav className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 flex-wrap" data-testid="nav-breadcrumb">
        <Link href="/" className="hover:text-foreground transition-colors" data-testid="link-home">Home</Link>
        <ChevronRight className="h-3.5 w-3.5" />
        <span>Tools</span>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="text-foreground font-medium">LinkedIn Profile Optimizer</span>
      </nav>

      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-800 mb-4">
          <SiLinkedin className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-linkedin-optimizer-title">
          LinkedIn Profile Optimizer
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Audit your LinkedIn profile, get a completeness score, and receive actionable tips to attract recruiters and boost your visibility in search results.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Target className="h-4 w-4" />
            <span>Profile Audit</span>
          </div>
          <div className="flex items-center gap-1.5">
            <BarChart3 className="h-4 w-4" />
            <span>Score Analysis</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Search className="h-4 w-4" />
            <span>SEO Keywords</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5" data-testid="card-audit-form">
            <div className="flex items-center gap-2 mb-4">
              <User className="h-5 w-5 text-muted-foreground" />
              <h2 className="font-semibold text-sm flex-1">Profile Audit Checker</h2>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="headline" className="text-sm">Your LinkedIn Headline</Label>
                <Input
                  id="headline"
                  placeholder="e.g. Senior Software Engineer | React & Node.js | Building Scalable Products"
                  value={auditInput.headline}
                  onChange={(e) => setAuditInput({ ...auditInput, headline: e.target.value })}
                  data-testid="input-headline"
                />
                <p className="text-[11px] text-muted-foreground">{auditInput.headline.length}/220 characters</p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="summary" className="text-sm">Your Summary / About Section</Label>
                <Textarea
                  id="summary"
                  placeholder="Paste or type your LinkedIn summary here..."
                  className="min-h-[120px] text-sm resize-y"
                  value={auditInput.summary}
                  onChange={(e) => setAuditInput({ ...auditInput, summary: e.target.value })}
                  data-testid="textarea-summary"
                />
                <p className="text-[11px] text-muted-foreground">{auditInput.summary.length}/2,600 characters</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="experienceCount" className="text-sm">Number of Experience Entries</Label>
                  <Input
                    id="experienceCount"
                    type="number"
                    min={0}
                    placeholder="e.g. 4"
                    value={auditInput.experienceCount}
                    onChange={(e) => setAuditInput({ ...auditInput, experienceCount: e.target.value })}
                    data-testid="input-experience-count"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="skillsCount" className="text-sm">Number of Skills Listed</Label>
                  <Input
                    id="skillsCount"
                    type="number"
                    min={0}
                    max={50}
                    placeholder="e.g. 25"
                    value={auditInput.skillsCount}
                    onChange={(e) => setAuditInput({ ...auditInput, skillsCount: e.target.value })}
                    data-testid="input-skills-count"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="recommendationsCount" className="text-sm">Number of Recommendations</Label>
                  <Input
                    id="recommendationsCount"
                    type="number"
                    min={0}
                    placeholder="e.g. 3"
                    value={auditInput.recommendationsCount}
                    onChange={(e) => setAuditInput({ ...auditInput, recommendationsCount: e.target.value })}
                    data-testid="input-recommendations-count"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="hasEducation"
                    checked={auditInput.hasEducation}
                    onCheckedChange={(checked) => setAuditInput({ ...auditInput, hasEducation: checked === true })}
                    data-testid="checkbox-education"
                  />
                  <Label htmlFor="hasEducation" className="text-sm cursor-pointer">Education Added</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="hasCertifications"
                    checked={auditInput.hasCertifications}
                    onCheckedChange={(checked) => setAuditInput({ ...auditInput, hasCertifications: checked === true })}
                    data-testid="checkbox-certifications"
                  />
                  <Label htmlFor="hasCertifications" className="text-sm cursor-pointer">Certifications Added</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="hasCustomUrl"
                    checked={auditInput.hasCustomUrl}
                    onCheckedChange={(checked) => setAuditInput({ ...auditInput, hasCustomUrl: checked === true })}
                    data-testid="checkbox-custom-url"
                  />
                  <Label htmlFor="hasCustomUrl" className="text-sm cursor-pointer">Custom URL Set</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="hasProfilePhoto"
                    checked={auditInput.hasProfilePhoto}
                    onCheckedChange={(checked) => setAuditInput({ ...auditInput, hasProfilePhoto: checked === true })}
                    data-testid="checkbox-profile-photo"
                  />
                  <Label htmlFor="hasProfilePhoto" className="text-sm cursor-pointer">Profile Photo</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="hasBannerImage"
                    checked={auditInput.hasBannerImage}
                    onCheckedChange={(checked) => setAuditInput({ ...auditInput, hasBannerImage: checked === true })}
                    data-testid="checkbox-banner-image"
                  />
                  <Label htmlFor="hasBannerImage" className="text-sm cursor-pointer">Banner Image</Label>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 mt-4 flex-wrap">
              <Button onClick={handleAudit} data-testid="button-audit-profile">
                <Target className="h-4 w-4 mr-2" />
                Audit My Profile
              </Button>
              {hasAudited && (
                <Button variant="outline" onClick={handleReset} data-testid="button-reset-audit">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset
                </Button>
              )}
            </div>
          </Card>

          {hasAudited && auditResult && (
            <Card className="p-5" data-testid="card-section-scores">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 className="h-5 w-5 text-muted-foreground" />
                <h2 className="font-semibold text-sm flex-1">Section-by-Section Results</h2>
              </div>
              <div className="space-y-3">
                {auditResult.sections.map((section) => (
                  <div
                    key={section.section}
                    className="flex items-start gap-3 p-3 rounded-md bg-muted/30"
                    data-testid={`section-score-${section.section.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {getStatusIcon(section.status)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 flex-wrap mb-1">
                        <span className="text-sm font-medium">{section.section}</span>
                        <Badge
                          variant={section.status === "good" ? "default" : section.status === "warning" ? "secondary" : "outline"}
                          className="text-[10px]"
                        >
                          {section.score}/{section.maxScore}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{section.feedback}</p>
                      <div className="h-1.5 rounded-full bg-muted overflow-hidden mt-2">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            section.status === "good" ? "bg-green-500" : section.status === "warning" ? "bg-amber-500" : "bg-red-500"
                          }`}
                          style={{ width: `${(section.score / section.maxScore) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>

        <div>
          <Card className="p-6 sticky top-20" data-testid="card-score-panel">
            <h2 className="font-semibold mb-4 text-center">Profile Score</h2>
            {hasAudited && auditResult ? (
              <>
                <div className="flex justify-center mb-4">
                  <div className="relative w-28 h-28">
                    <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="6" className="text-muted/30" />
                      <circle
                        cx="50" cy="50" r="45" fill="none" strokeWidth="6"
                        stroke="currentColor"
                        className={getScoreColor(totalScore)}
                        strokeLinecap="round"
                        strokeDasharray={circumference}
                        strokeDashoffset={strokeDashoffset}
                        style={{ transition: "stroke-dashoffset 0.5s ease" }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className={`text-2xl font-bold ${getScoreColor(totalScore)}`} data-testid="text-profile-score">{totalScore}%</span>
                      <span className="text-[10px] text-muted-foreground">{getScoreLabel(totalScore)}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {auditResult.sections.map((s) => (
                    <div key={s.section} className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">{s.section}</span>
                      <span className={s.status === "good" ? "text-green-600" : s.status === "warning" ? "text-amber-500" : "text-red-500"}>
                        {s.score}/{s.maxScore}
                      </span>
                    </div>
                  ))}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={handleReset}
                  data-testid="button-reset-sidebar"
                >
                  <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
                  New Audit
                </Button>
              </>
            ) : (
              <div className="text-center py-8">
                <Eye className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground" data-testid="text-audit-prompt">
                  Fill in your profile details and click "Audit My Profile" to see your score
                </p>
                <div className="mt-4 space-y-2 text-left">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <User className="h-3.5 w-3.5" />
                    <span>Headline & Summary</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Briefcase className="h-3.5 w-3.5" />
                    <span>Experience & Skills</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Camera className="h-3.5 w-3.5" />
                    <span>Photo & Branding</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Link2 className="h-3.5 w-3.5" />
                    <span>URL & Featured</span>
                  </div>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-headline-examples-heading">
          <Lightbulb className="h-5 w-5 text-blue-600" />
          Before & After Headline Examples
        </h2>
        <div className="space-y-4">
          {HEADLINE_EXAMPLES.map((example, idx) => (
            <Card key={idx} className="p-5" data-testid={`card-headline-example-${idx}`}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                <div>
                  <p className="text-[11px] text-muted-foreground mb-1 flex items-center gap-1">
                    <XCircle className="h-3 w-3 text-red-500" /> Before
                  </p>
                  <p className="text-sm bg-red-50 dark:bg-red-950/20 text-red-700 dark:text-red-400 rounded-md p-2.5">
                    {example.before}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-muted-foreground mb-1 flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-green-500" /> After
                  </p>
                  <p className="text-sm bg-green-50 dark:bg-green-950/20 text-green-700 dark:text-green-400 rounded-md p-2.5">
                    {example.after}
                  </p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                <ArrowRight className="h-3 w-3 shrink-0" />
                {example.tip}
              </p>
            </Card>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-industry-keywords-heading">
          <Search className="h-5 w-5 text-blue-600" />
          Industry Keyword Suggestions
        </h2>
        <p className="text-sm text-muted-foreground mb-4">
          Include these keywords in your headline and summary to appear in recruiter searches
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(INDUSTRY_KEYWORDS).map(([industry, keywords]) => (
            <Card key={industry} className="p-4" data-testid={`card-industry-${industry.toLowerCase().replace(/[/\s]+/g, "-")}`}>
              <h3 className="font-semibold text-sm mb-3">{industry}</h3>
              <div className="flex flex-wrap gap-1.5">
                {keywords.map((kw) => (
                  <Badge key={kw} variant="secondary" className="text-[10px]">
                    {kw}
                  </Badge>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-section-tips-heading">
          <BookOpen className="h-5 w-5 text-blue-600" />
          Section-by-Section Tips
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {SECTION_TIPS.map((sec, idx) => {
            const Icon = sec.icon;
            return (
              <Card key={sec.section} className="p-4" data-testid={`card-section-tip-${idx}`}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="inline-flex items-center justify-center w-8 h-8 rounded-md bg-blue-500/10 shrink-0">
                    <Icon className="h-4 w-4 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-sm">{sec.section}</h3>
                </div>
                <ul className="space-y-1.5">
                  {sec.tips.map((tip, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                      <ArrowRight className="h-3 w-3 mt-0.5 shrink-0" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            );
          })}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-seo-practices-heading">
          <TrendingUp className="h-5 w-5 text-blue-600" />
          LinkedIn SEO Best Practices
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {SEO_BEST_PRACTICES.map((practice, idx) => (
            <Card key={idx} className="p-4" data-testid={`card-seo-practice-${idx}`}>
              <div className="flex items-start gap-3">
                <div className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-blue-500/10 text-sm font-bold text-blue-600 shrink-0">
                  {idx + 1}
                </div>
                <div>
                  <h3 className="text-sm font-medium mb-1">{practice.title}</h3>
                  <p className="text-xs text-muted-foreground">{practice.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-mistakes-heading">
          <Shield className="h-5 w-5 text-blue-600" />
          Common Mistakes to Avoid
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {COMMON_MISTAKES.map((mistake, idx) => (
            <Card key={idx} className="p-4" data-testid={`card-mistake-${idx}`}>
              <div className="flex items-start gap-3">
                <XCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
                <div>
                  <h3 className="text-sm font-medium mb-1">{mistake.title}</h3>
                  <p className="text-xs text-muted-foreground">{mistake.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <Card className="p-6 text-center mb-6" data-testid="card-cta-employers">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Users className="h-5 w-5 text-blue-600" />
          <h3 className="font-semibold">Trusted by International Employers</h3>
        </div>
        <p className="text-sm text-muted-foreground max-w-xl mx-auto mb-4">
          Dev Global Jobs connects optimized professionals with leading international employers, NGOs, and organizations worldwide.
        </p>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <Link href="/post-job">
            <Button data-testid="link-post-job">
              <Briefcase className="h-4 w-4 mr-2" />
              Post a Job
            </Button>
          </Link>
          <Link href="/pricing">
            <Button variant="outline" data-testid="link-pricing">
              View Pricing
            </Button>
          </Link>
        </div>
      </Card>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "LinkedIn Profile Optimizer", item: "https://devglobaljobs.com/tools/linkedin-optimizer" },
            ],
          }),
        }}
      />
    </div>
  );
}
