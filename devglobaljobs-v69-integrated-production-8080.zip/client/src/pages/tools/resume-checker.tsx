import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  FileText, CheckCircle2, AlertCircle, User, Target,
  Briefcase, GraduationCap, Wrench, Palette, RotateCcw,
  Award,
} from "lucide-react";

interface ChecklistItem {
  id: string;
  label: string;
  tip: string;
}

interface ChecklistSection {
  title: string;
  icon: typeof FileText;
  items: ChecklistItem[];
}

const sections: ChecklistSection[] = [
  {
    title: "Contact Information",
    icon: User,
    items: [
      { id: "c1", label: "Full name is clearly displayed at the top", tip: "Use a larger font for your name to make it stand out" },
      { id: "c2", label: "Professional email address included", tip: "Use a professional email like firstname.lastname@email.com" },
      { id: "c3", label: "Phone number with country code", tip: "Include country code for international applications" },
      { id: "c4", label: "LinkedIn profile URL included", tip: "Customize your LinkedIn URL for a professional look" },
      { id: "c5", label: "Location (city/country) mentioned", tip: "Include city and country, especially for international roles" },
      { id: "c6", label: "No unnecessary personal details (age, photo, marital status)", tip: "Most international organizations prefer no photo or personal details to avoid bias" },
    ],
  },
  {
    title: "Summary / Objective",
    icon: Target,
    items: [
      { id: "s1", label: "Professional summary is 2-4 sentences", tip: "Keep it concise and highlight your unique value proposition" },
      { id: "s2", label: "Summary is tailored to the target role", tip: "Customize for each application; mention the organization by name" },
      { id: "s3", label: "Key achievements or specializations mentioned", tip: "Include 1-2 quantifiable achievements to hook the reader" },
      { id: "s4", label: "Relevant keywords from job description included", tip: "Many organizations use ATS systems; matching keywords increases visibility" },
    ],
  },
  {
    title: "Work Experience",
    icon: Briefcase,
    items: [
      { id: "e1", label: "Listed in reverse chronological order", tip: "Most recent experience first is the standard format" },
      { id: "e2", label: "Each role has company name, title, dates, and location", tip: "Include month/year format for dates" },
      { id: "e3", label: "Bullet points start with action verbs", tip: "Use verbs like Led, Managed, Developed, Implemented, Delivered" },
      { id: "e4", label: "Achievements are quantified with numbers/percentages", tip: "E.g., 'Managed $2M budget' or 'Increased efficiency by 35%'" },
      { id: "e5", label: "Experience is relevant to the target position", tip: "Prioritize relevant experience; you can omit unrelated short-term roles" },
      { id: "e6", label: "No unexplained gaps in employment", tip: "Address gaps positively -- mention training, volunteering, or personal projects" },
      { id: "e7", label: "Descriptions focus on impact, not just duties", tip: "Show what you accomplished, not just what you were supposed to do" },
    ],
  },
  {
    title: "Education",
    icon: GraduationCap,
    items: [
      { id: "d1", label: "Degrees listed with institution, field, and graduation year", tip: "Include honors, GPA only if impressive (3.5+ or equivalent)" },
      { id: "d2", label: "Relevant certifications included", tip: "List professional certifications with issuing body and date" },
      { id: "d3", label: "Relevant coursework or thesis mentioned (if recent graduate)", tip: "Only include if directly relevant to the position" },
      { id: "d4", label: "Professional development / training listed", tip: "Include recent workshops, MOOCs, or professional courses" },
    ],
  },
  {
    title: "Skills",
    icon: Wrench,
    items: [
      { id: "k1", label: "Technical skills relevant to the role listed", tip: "Group by category: Programming, Tools, Methodologies" },
      { id: "k2", label: "Language proficiency levels specified", tip: "Use standard levels: Native, Fluent, Professional, Intermediate, Basic" },
      { id: "k3", label: "Soft skills demonstrated through experience (not just listed)", tip: "Instead of listing 'leadership,' show it through achievements" },
      { id: "k4", label: "Skills match key requirements from the job posting", tip: "Mirror the exact terminology from the job description" },
    ],
  },
  {
    title: "Format & Design",
    icon: Palette,
    items: [
      { id: "f1", label: "Resume is 1-2 pages (appropriate for experience level)", tip: "1 page for <5 years experience, 2 pages for senior roles" },
      { id: "f2", label: "Consistent formatting throughout (fonts, spacing, bullets)", tip: "Use one font family, consistent heading sizes, and uniform spacing" },
      { id: "f3", label: "Readable font used (10-12pt body, 14-16pt headers)", tip: "Calibri, Arial, Garamond, or Cambria are professional choices" },
      { id: "f4", label: "Adequate white space and margins", tip: "Use 0.5-1 inch margins; avoid cramming text" },
      { id: "f5", label: "No spelling or grammatical errors", tip: "Use spell-check AND have someone else review your resume" },
      { id: "f6", label: "Saved as PDF for submission", tip: "PDF preserves formatting across devices; always name the file professionally" },
      { id: "f7", label: "File named professionally (e.g., FirstName_LastName_Resume.pdf)", tip: "Avoid generic names like 'resume.pdf' or 'CV_final_v3.pdf'" },
    ],
  },
];

const totalItems = sections.reduce((acc, s) => acc + s.items.length, 0);

export default function ResumeChecker() {
  const [checked, setChecked] = useState<Set<string>>(new Set());

  const toggleItem = (id: string) => {
    setChecked((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const score = Math.round((checked.size / totalItems) * 100);

  function getScoreColor() {
    if (score >= 80) return "text-green-600";
    if (score >= 50) return "text-amber-500";
    return "text-red-500";
  }

  function getScoreLabel() {
    if (score >= 90) return "Excellent";
    if (score >= 80) return "Very Good";
    if (score >= 60) return "Good";
    if (score >= 40) return "Needs Work";
    return "Getting Started";
  }

  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-violet-600 mb-4">
          <FileText className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-resume-checker-title">
          Resume / CV Checker
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Review your resume against industry best practices. Check off each item
          to get your resume score and improvement suggestions.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4" />
            <span>{totalItems} Checkpoints</span>
          </div>
          <div className="flex items-center gap-1.5">
            <FileText className="h-4 w-4" />
            <span>{sections.length} Sections</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Award className="h-4 w-4" />
            <span>Score Tracker</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          {sections.map((section) => {
            const Icon = section.icon;
            const sectionChecked = section.items.filter((item) => checked.has(item.id)).length;
            return (
              <Card key={section.title} className="p-5" data-testid={`card-section-${section.title.toLowerCase().replace(/[\s/&]/g, "-")}`}>
                <div className="flex items-center gap-2 mb-4">
                  <Icon className="h-5 w-5 text-muted-foreground" />
                  <h2 className="font-semibold text-sm flex-1">{section.title}</h2>
                  <Badge variant="secondary" className="text-[10px]">
                    {sectionChecked}/{section.items.length}
                  </Badge>
                </div>
                <div className="space-y-3">
                  {section.items.map((item) => (
                    <div key={item.id} className="flex items-start gap-3">
                      <Checkbox
                        id={item.id}
                        checked={checked.has(item.id)}
                        onCheckedChange={() => toggleItem(item.id)}
                        data-testid={`checkbox-${item.id}`}
                      />
                      <div className="flex-1 space-y-0.5">
                        <label htmlFor={item.id} className="text-sm cursor-pointer leading-tight">
                          {item.label}
                        </label>
                        <p className="text-[11px] text-muted-foreground">{item.tip}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>

        <div>
          <Card className="p-6 sticky top-20">
            <h2 className="font-semibold mb-4 text-center">Your Resume Score</h2>
            <div className="flex justify-center mb-4">
              <div className="relative w-28 h-28">
                <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="6" className="text-muted/30" />
                  <circle
                    cx="50" cy="50" r="45" fill="none" strokeWidth="6"
                    stroke="currentColor"
                    className={getScoreColor()}
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    style={{ transition: "stroke-dashoffset 0.5s ease" }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={`text-2xl font-bold ${getScoreColor()}`} data-testid="text-resume-score">{score}%</span>
                  <span className="text-[10px] text-muted-foreground">{getScoreLabel()}</span>
                </div>
              </div>
            </div>
            <div className="text-center mb-4">
              <div className="text-sm text-muted-foreground">
                {checked.size} of {totalItems} items checked
              </div>
            </div>
            <div className="space-y-2 mb-4">
              {sections.map((section) => {
                const sectionChecked = section.items.filter((item) => checked.has(item.id)).length;
                const pct = Math.round((sectionChecked / section.items.length) * 100);
                return (
                  <div key={section.title}>
                    <div className="flex items-center justify-between text-xs mb-0.5">
                      <span className="text-muted-foreground">{section.title}</span>
                      <span>{pct}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-primary transition-all duration-300"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => setChecked(new Set())}
              data-testid="button-reset-checker"
            >
              <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
              Reset All
            </Button>
          </Card>
        </div>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Resume Checker", item: "https://devglobaljobs.com/tools/resume-checker" },
            ],
          }),
        }}
      />
    </div>
  );
}
