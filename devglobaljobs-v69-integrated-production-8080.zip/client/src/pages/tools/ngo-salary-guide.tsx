import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DollarSign, TrendingUp, Users, Globe, Lightbulb,
  Building2, BarChart3, CheckCircle2,
} from "lucide-react";

const roleLevels = [
  { value: "all", label: "All Levels" },
  { value: "entry", label: "Entry Level" },
  { value: "mid", label: "Mid Level" },
  { value: "senior", label: "Senior Level" },
  { value: "director", label: "Director / Leadership" },
];

const orgSizes = [
  { value: "all", label: "All Sizes" },
  { value: "small", label: "Small (<50 staff)" },
  { value: "medium", label: "Medium (50-250 staff)" },
  { value: "large", label: "Large (250-1000 staff)" },
  { value: "international", label: "International (1000+ staff)" },
];

const regions = [
  { value: "all", label: "All Regions" },
  { value: "north-america", label: "North America" },
  { value: "europe", label: "Europe" },
  { value: "asia", label: "Asia" },
  { value: "africa", label: "Africa" },
  { value: "latin-america", label: "Latin America" },
  { value: "middle-east", label: "Middle East" },
];

interface SalaryData {
  title: string;
  level: string;
  orgSize: string;
  region: string;
  minSalary: number;
  maxSalary: number;
  median: number;
}

const salaryData: SalaryData[] = [
  { title: "Program Assistant", level: "entry", orgSize: "small", region: "north-america", minSalary: 32000, maxSalary: 42000, median: 37000 },
  { title: "Program Assistant", level: "entry", orgSize: "international", region: "north-america", minSalary: 38000, maxSalary: 52000, median: 45000 },
  { title: "Program Assistant", level: "entry", orgSize: "medium", region: "europe", minSalary: 28000, maxSalary: 38000, median: 33000 },
  { title: "Program Assistant", level: "entry", orgSize: "small", region: "asia", minSalary: 12000, maxSalary: 22000, median: 17000 },
  { title: "Program Assistant", level: "entry", orgSize: "medium", region: "africa", minSalary: 10000, maxSalary: 20000, median: 15000 },
  { title: "Program Assistant", level: "entry", orgSize: "small", region: "latin-america", minSalary: 14000, maxSalary: 24000, median: 19000 },
  { title: "Program Assistant", level: "entry", orgSize: "medium", region: "middle-east", minSalary: 18000, maxSalary: 30000, median: 24000 },
  { title: "Communications Officer", level: "entry", orgSize: "medium", region: "north-america", minSalary: 36000, maxSalary: 48000, median: 42000 },
  { title: "Communications Officer", level: "entry", orgSize: "international", region: "europe", minSalary: 34000, maxSalary: 46000, median: 40000 },
  { title: "M&E Officer", level: "entry", orgSize: "large", region: "africa", minSalary: 15000, maxSalary: 28000, median: 21500 },
  { title: "Program Coordinator", level: "mid", orgSize: "small", region: "north-america", minSalary: 45000, maxSalary: 60000, median: 52000 },
  { title: "Program Coordinator", level: "mid", orgSize: "international", region: "north-america", minSalary: 55000, maxSalary: 75000, median: 65000 },
  { title: "Program Coordinator", level: "mid", orgSize: "medium", region: "europe", minSalary: 40000, maxSalary: 55000, median: 47000 },
  { title: "Program Coordinator", level: "mid", orgSize: "large", region: "asia", minSalary: 25000, maxSalary: 42000, median: 33000 },
  { title: "Program Coordinator", level: "mid", orgSize: "medium", region: "africa", minSalary: 20000, maxSalary: 35000, median: 27000 },
  { title: "Program Coordinator", level: "mid", orgSize: "medium", region: "latin-america", minSalary: 22000, maxSalary: 38000, median: 30000 },
  { title: "Program Coordinator", level: "mid", orgSize: "large", region: "middle-east", minSalary: 30000, maxSalary: 50000, median: 40000 },
  { title: "Project Manager", level: "mid", orgSize: "large", region: "north-america", minSalary: 55000, maxSalary: 78000, median: 66000 },
  { title: "Project Manager", level: "mid", orgSize: "international", region: "europe", minSalary: 50000, maxSalary: 72000, median: 61000 },
  { title: "Grants Manager", level: "mid", orgSize: "international", region: "north-america", minSalary: 58000, maxSalary: 80000, median: 69000 },
  { title: "Policy Analyst", level: "mid", orgSize: "large", region: "europe", minSalary: 45000, maxSalary: 65000, median: 55000 },
  { title: "Senior Program Manager", level: "senior", orgSize: "small", region: "north-america", minSalary: 65000, maxSalary: 85000, median: 75000 },
  { title: "Senior Program Manager", level: "senior", orgSize: "international", region: "north-america", minSalary: 80000, maxSalary: 110000, median: 95000 },
  { title: "Senior Program Manager", level: "senior", orgSize: "large", region: "europe", minSalary: 60000, maxSalary: 90000, median: 75000 },
  { title: "Senior Program Manager", level: "senior", orgSize: "international", region: "asia", minSalary: 50000, maxSalary: 80000, median: 65000 },
  { title: "Senior Program Manager", level: "senior", orgSize: "large", region: "africa", minSalary: 40000, maxSalary: 65000, median: 52000 },
  { title: "Senior Program Manager", level: "senior", orgSize: "medium", region: "latin-america", minSalary: 38000, maxSalary: 58000, median: 48000 },
  { title: "Senior Program Manager", level: "senior", orgSize: "large", region: "middle-east", minSalary: 50000, maxSalary: 80000, median: 65000 },
  { title: "Senior Advisor", level: "senior", orgSize: "international", region: "north-america", minSalary: 85000, maxSalary: 120000, median: 102000 },
  { title: "Head of Programs", level: "senior", orgSize: "international", region: "europe", minSalary: 75000, maxSalary: 105000, median: 90000 },
  { title: "Country Director", level: "director", orgSize: "international", region: "north-america", minSalary: 110000, maxSalary: 160000, median: 135000 },
  { title: "Country Director", level: "director", orgSize: "large", region: "europe", minSalary: 90000, maxSalary: 140000, median: 115000 },
  { title: "Country Director", level: "director", orgSize: "international", region: "asia", minSalary: 80000, maxSalary: 130000, median: 105000 },
  { title: "Country Director", level: "director", orgSize: "international", region: "africa", minSalary: 75000, maxSalary: 120000, median: 97000 },
  { title: "Country Director", level: "director", orgSize: "large", region: "latin-america", minSalary: 70000, maxSalary: 110000, median: 90000 },
  { title: "Country Director", level: "director", orgSize: "international", region: "middle-east", minSalary: 85000, maxSalary: 135000, median: 110000 },
  { title: "Executive Director", level: "director", orgSize: "small", region: "north-america", minSalary: 80000, maxSalary: 120000, median: 100000 },
  { title: "Executive Director", level: "director", orgSize: "international", region: "north-america", minSalary: 140000, maxSalary: 220000, median: 180000 },
  { title: "VP of Operations", level: "director", orgSize: "international", region: "europe", minSalary: 100000, maxSalary: 170000, median: 135000 },
  { title: "Chief of Party", level: "director", orgSize: "international", region: "africa", minSalary: 90000, maxSalary: 150000, median: 120000 },
];

const negotiationTips = [
  "Research salary benchmarks using sites like Glassdoor, Idealist, and Devex before negotiations",
  "Consider the total compensation package including health insurance, retirement, leave, and professional development",
  "Highlight your language skills, field experience, and sector-specific expertise",
  "Be prepared to discuss salary in terms of ranges rather than fixed numbers",
  "Understand the organization's funding constraints -- many NGOs have donor-restricted budgets",
  "Negotiate for non-monetary benefits like flexible work, remote options, or additional leave days",
  "If relocating internationally, factor in cost-of-living adjustments and hardship allowances",
  "Ask about salary progression and performance review timelines during negotiations",
];

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(amount);
}

export default function NgoSalaryGuide() {
  const [level, setLevel] = useState("all");
  const [orgSize, setOrgSize] = useState("all");
  const [region, setRegion] = useState("all");

  const filtered = salaryData.filter((s) => {
    const matchLevel = level === "all" || s.level === level;
    const matchOrg = orgSize === "all" || s.orgSize === orgSize;
    const matchRegion = region === "all" || s.region === region;
    return matchLevel && matchOrg && matchRegion;
  });

  const maxSalaryInView = Math.max(...filtered.map((s) => s.maxSalary), 1);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 mb-4">
          <BarChart3 className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-ngo-salary-title">
          NGO Salary Guide
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Comprehensive salary benchmarks for NGO and non-profit positions worldwide.
          Compare compensation across roles, organization sizes, and regions.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Users className="h-4 w-4" />
            <span>{salaryData.length} Data Points</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>6 Regions</span>
          </div>
          <div className="flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            <span>4 Role Levels</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-xs font-medium mb-1 block text-muted-foreground">Role Level</label>
            <Select value={level} onValueChange={setLevel}>
              <SelectTrigger data-testid="select-ngo-level">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {roleLevels.map((r) => (
                  <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-medium mb-1 block text-muted-foreground">Organization Size</label>
            <Select value={orgSize} onValueChange={setOrgSize}>
              <SelectTrigger data-testid="select-ngo-orgsize">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {orgSizes.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-medium mb-1 block text-muted-foreground">Region</label>
            <Select value={region} onValueChange={setRegion}>
              <SelectTrigger data-testid="select-ngo-region">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {regions.map((r) => (
                  <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} salary benchmark{filtered.length !== 1 ? "s" : ""}
      </div>

      <div className="space-y-3 mb-8">
        {filtered.length === 0 ? (
          <Card className="p-8 text-center">
            <DollarSign className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-30" />
            <p className="text-sm text-muted-foreground">No data matches your filters. Try adjusting your selection.</p>
          </Card>
        ) : (
          filtered.map((item, i) => {
            const barMin = (item.minSalary / maxSalaryInView) * 100;
            const barMax = (item.maxSalary / maxSalaryInView) * 100;
            const barMedian = (item.median / maxSalaryInView) * 100;
            return (
              <Card key={i} className="p-4 hover-elevate" data-testid={`card-salary-${i}`}>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm">{item.title}</h3>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      <Badge variant="outline" className="text-[10px]">{roleLevels.find((r) => r.value === item.level)?.label}</Badge>
                      <Badge variant="outline" className="text-[10px]">{orgSizes.find((o) => o.value === item.orgSize)?.label}</Badge>
                      <Badge variant="secondary" className="text-[10px]">{regions.find((r) => r.value === item.region)?.label}</Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-sm">{formatCurrency(item.median)}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatCurrency(item.minSalary)} - {formatCurrency(item.maxSalary)}
                    </div>
                  </div>
                </div>
                <div className="relative h-4 rounded-full bg-muted overflow-hidden">
                  <div
                    className="absolute h-full rounded-full bg-primary/20"
                    style={{ left: `${barMin}%`, width: `${barMax - barMin}%` }}
                  />
                  <div
                    className="absolute top-0 h-full w-0.5 bg-primary"
                    style={{ left: `${barMedian}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                  <span>Min: {formatCurrency(item.minSalary)}</span>
                  <span>Median: {formatCurrency(item.median)}</span>
                  <span>Max: {formatCurrency(item.maxSalary)}</span>
                </div>
              </Card>
            );
          })
        )}
      </div>

      <Card className="p-6">
        <div className="flex items-start gap-3 mb-4">
          <Lightbulb className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
          <h3 className="font-semibold">Salary Negotiation Tips for NGO/Non-Profit Roles</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {negotiationTips.map((tip, i) => (
            <div key={i} className="flex items-start gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground">{tip}</p>
            </div>
          ))}
        </div>
      </Card>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "NGO Salary Guide", item: "https://devglobaljobs.com/tools/ngo-salary-guide" },
            ],
          }),
        }}
      />
    </div>
  );
}
