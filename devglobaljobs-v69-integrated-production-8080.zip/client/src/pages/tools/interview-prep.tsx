import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  MessageSquare, Search, Lightbulb, Star, ChevronDown,
  ChevronUp, Users, Briefcase, Target, BookOpen,
} from "lucide-react";

const interviewTypes = [
  { value: "all", label: "All Types" },
  { value: "behavioral", label: "Behavioral" },
  { value: "technical", label: "Technical" },
  { value: "case-study", label: "Case Study" },
  { value: "panel", label: "Panel" },
];

const industries = [
  { value: "all", label: "All Industries" },
  { value: "tech", label: "Tech" },
  { value: "finance", label: "Finance" },
  { value: "healthcare", label: "Healthcare" },
  { value: "ngo", label: "NGO" },
  { value: "un", label: "UN" },
  { value: "government", label: "Government" },
];

interface Question {
  id: number;
  question: string;
  type: string;
  industry: string;
  tip: string;
}

const questions: Question[] = [
  { id: 1, question: "Tell me about yourself and your career journey.", type: "behavioral", industry: "tech", tip: "Keep it to 2 minutes. Focus on relevant experience and what motivates you for this specific role." },
  { id: 2, question: "Describe a time you led a team through a difficult project.", type: "behavioral", industry: "tech", tip: "Use the STAR method. Emphasize how you motivated the team and the measurable outcome." },
  { id: 3, question: "How do you handle conflict with a colleague?", type: "behavioral", industry: "ngo", tip: "Show emotional intelligence. Describe the situation, your approach to resolution, and the positive result." },
  { id: 4, question: "Tell me about a time you failed and what you learned.", type: "behavioral", industry: "finance", tip: "Be honest but strategic. Choose a failure that led to meaningful growth and improved processes." },
  { id: 5, question: "Describe a situation where you had to adapt to change quickly.", type: "behavioral", industry: "un", tip: "Highlight flexibility and resilience. Show how you maintained performance during transition." },
  { id: 6, question: "Give an example of when you went above and beyond.", type: "behavioral", industry: "healthcare", tip: "Demonstrate initiative without seeming like you don't respect boundaries. Show impact." },
  { id: 7, question: "How do you prioritize when you have multiple deadlines?", type: "behavioral", industry: "government", tip: "Describe your system (urgent/important matrix, tools used) with a concrete example." },
  { id: 8, question: "Tell me about a time you influenced a decision without authority.", type: "behavioral", industry: "ngo", tip: "Show persuasion skills through data, relationship building, or coalition building." },
  { id: 9, question: "Describe your experience working with diverse teams.", type: "behavioral", industry: "un", tip: "Emphasize cultural sensitivity, communication adaptation, and inclusive leadership." },
  { id: 10, question: "How do you handle receiving critical feedback?", type: "behavioral", industry: "tech", tip: "Show openness to feedback with a specific example of how you improved based on criticism." },
  { id: 11, question: "Design a system that handles 10 million requests per second.", type: "technical", industry: "tech", tip: "Discuss load balancing, caching, database sharding, CDNs, and horizontal scaling." },
  { id: 12, question: "Explain the difference between SQL and NoSQL databases.", type: "technical", industry: "tech", tip: "Cover use cases, ACID vs BASE, scaling patterns, and when to choose each." },
  { id: 13, question: "How would you optimize a slow database query?", type: "technical", industry: "tech", tip: "Discuss indexing, query plans, denormalization, caching, and pagination strategies." },
  { id: 14, question: "Walk me through your approach to data security.", type: "technical", industry: "finance", tip: "Cover encryption, access controls, audit trails, compliance frameworks (SOC2, GDPR)." },
  { id: 15, question: "How would you design a monitoring and evaluation framework?", type: "technical", industry: "ngo", tip: "Discuss theory of change, indicators (output/outcome/impact), data collection methods, and reporting." },
  { id: 16, question: "Explain how you would build a results-based management system.", type: "technical", industry: "un", tip: "Cover logical framework, KPIs, baseline data, targets, and adaptive management." },
  { id: 17, question: "Describe your experience with healthcare data standards.", type: "technical", industry: "healthcare", tip: "Discuss HL7, FHIR, ICD codes, HIPAA compliance, and interoperability challenges." },
  { id: 18, question: "How do you ensure compliance with government regulations?", type: "technical", industry: "government", tip: "Show systematic approach: regulatory tracking, impact assessment, policy implementation, audit." },
  { id: 19, question: "Explain your approach to API design and documentation.", type: "technical", industry: "tech", tip: "Cover REST/GraphQL principles, versioning, authentication, rate limiting, and OpenAPI specs." },
  { id: 20, question: "How would you implement a machine learning pipeline?", type: "technical", industry: "tech", tip: "Discuss data collection, preprocessing, model selection, training, evaluation, deployment, monitoring." },
  { id: 21, question: "A company's revenue dropped 20% in Q3. Diagnose the issue.", type: "case-study", industry: "finance", tip: "Structure: clarify scope, segment revenue streams, identify changes, analyze causes, recommend actions." },
  { id: 22, question: "An NGO wants to expand to 3 new countries. How should they prioritize?", type: "case-study", industry: "ngo", tip: "Consider: need assessment, capacity, funding, partnerships, regulatory environment, scaling strategy." },
  { id: 23, question: "A hospital ER wait time has doubled. How would you address this?", type: "case-study", industry: "healthcare", tip: "Analyze bottlenecks: triage, staffing, patient flow, resources. Propose systematic improvements." },
  { id: 24, question: "Design a digital transformation strategy for a government agency.", type: "case-study", industry: "government", tip: "Cover: current state assessment, stakeholder buy-in, phased rollout, change management, KPIs." },
  { id: 25, question: "How would you launch a new product in an emerging market?", type: "case-study", industry: "tech", tip: "Address: market research, localization, pricing strategy, distribution, partnerships, regulatory." },
  { id: 26, question: "A UN agency needs to respond to a refugee crisis. Outline a plan.", type: "case-study", industry: "un", tip: "Cover: needs assessment, coordination (cluster system), logistics, protection, funding appeal, M&E." },
  { id: 27, question: "Evaluate whether a microfinance program should scale regionally.", type: "case-study", industry: "ngo", tip: "Analyze: impact data, financial sustainability, operational capacity, risk factors, partnerships needed." },
  { id: 28, question: "A fintech startup is losing customers. Develop a retention strategy.", type: "case-study", industry: "finance", tip: "Segment customers, analyze churn causes, propose personalized interventions, calculate ROI of retention." },
  { id: 29, question: "How should a health system prepare for the next pandemic?", type: "case-study", industry: "healthcare", tip: "Cover: surveillance systems, stockpiling, workforce planning, communication strategy, international cooperation." },
  { id: 30, question: "Design a public transit improvement plan for a growing city.", type: "case-study", industry: "government", tip: "Assess current state, identify gaps, propose solutions (routes, frequency, tech), budget, timeline." },
  { id: 31, question: "Tell us about your experience relevant to this role (asked by 5 panel members).", type: "panel", industry: "un", tip: "Prepare a 3-minute overview. Make eye contact with all panelists. Address different aspects for each." },
  { id: 32, question: "How would you handle a disagreement with your supervisor?", type: "panel", industry: "government", tip: "Show professionalism and respect for hierarchy while demonstrating you can advocate for your position." },
  { id: 33, question: "Where do you see yourself in 5 years?", type: "panel", industry: "finance", tip: "Show ambition aligned with the organization's mission. Be realistic but enthusiastic." },
  { id: 34, question: "What is your management style?", type: "panel", industry: "ngo", tip: "Describe your approach with examples. Show adaptability to different team needs and cultural contexts." },
  { id: 35, question: "How do you stay updated with industry trends?", type: "panel", industry: "tech", tip: "Mention specific publications, conferences, communities, and how you apply new knowledge." },
  { id: 36, question: "Describe your approach to stakeholder management.", type: "panel", industry: "un", tip: "Discuss mapping stakeholders, understanding interests, communication strategies, and managing expectations." },
  { id: 37, question: "What is your greatest weakness?", type: "panel", industry: "healthcare", tip: "Be genuine. Choose a real area for growth and show what you are doing to improve." },
  { id: 38, question: "Why should we hire you over other candidates?", type: "panel", industry: "tech", tip: "Highlight your unique combination of skills, experience, and passion that directly addresses their needs." },
  { id: 39, question: "How do you ensure ethical decision-making in your work?", type: "panel", industry: "ngo", tip: "Discuss frameworks, transparency, accountability, and specific examples of ethical dilemmas you've navigated." },
  { id: 40, question: "What questions do you have for us?", type: "panel", industry: "finance", tip: "Prepare 3-5 thoughtful questions about team culture, strategic priorities, and expectations for the role." },
  { id: 41, question: "Describe a time you had to deliver results under resource constraints.", type: "behavioral", industry: "ngo", tip: "Show creativity and prioritization. Highlight how you maximized impact with limited resources." },
  { id: 42, question: "How do you approach cross-cultural communication challenges?", type: "behavioral", industry: "un", tip: "Give specific examples of adapting your communication style for different cultural contexts." },
  { id: 43, question: "Walk us through a complex project you managed from start to finish.", type: "panel", industry: "government", tip: "Use a structured narrative: objectives, planning, execution, challenges, results, lessons learned." },
];

const starMethod = {
  title: "The STAR Method",
  description: "A structured approach to answering behavioral interview questions effectively.",
  steps: [
    { letter: "S", word: "Situation", description: "Set the scene. Describe the context and background of the specific event or challenge." },
    { letter: "T", word: "Task", description: "Explain your responsibility. What was your role and what was expected of you?" },
    { letter: "A", word: "Action", description: "Detail the steps you took. Focus on YOUR actions and decisions, not the team's." },
    { letter: "R", word: "Result", description: "Share the outcome. Quantify results where possible and mention what you learned." },
  ],
};

const typeTips: Record<string, string[]> = {
  behavioral: [
    "Prepare 8-10 STAR stories that can be adapted to different questions",
    "Practice out loud to keep answers to 2-3 minutes",
    "Focus on recent examples (last 3-5 years) unless older ones are more relevant",
    "Always end with a positive result, even if the situation was challenging",
  ],
  technical: [
    "Think out loud -- interviewers want to see your problem-solving process",
    "Ask clarifying questions before diving into answers",
    "Be honest about what you don't know, then explain how you'd find the answer",
    "Use whiteboards or diagrams when available to visualize complex solutions",
  ],
  "case-study": [
    "Structure your response with a clear framework (e.g., issue tree, MECE)",
    "Take 30-60 seconds to think before answering -- this is expected and appreciated",
    "Make assumptions explicit and state them clearly",
    "Summarize your key recommendation at the end with supporting evidence",
  ],
  panel: [
    "Address each panel member by name and make eye contact with all",
    "Bring extra copies of your resume for each panel member",
    "If one panelist asks a follow-up, acknowledge others' perspectives too",
    "Thank each panel member individually at the end of the interview",
  ],
};

export default function InterviewPrep() {
  const [activeType, setActiveType] = useState("all");
  const [activeIndustry, setActiveIndustry] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  const toggleExpand = (id: number) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const filtered = questions.filter((q) => {
    const matchType = activeType === "all" || q.type === activeType;
    const matchIndustry = activeIndustry === "all" || q.industry === activeIndustry;
    const matchSearch = !searchQuery || q.question.toLowerCase().includes(searchQuery.toLowerCase()) || q.tip.toLowerCase().includes(searchQuery.toLowerCase());
    return matchType && matchIndustry && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 mb-4">
          <MessageSquare className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-interview-prep-title">
          Interview Preparation Guide
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Practice with {questions.length}+ interview questions organized by type and industry.
          Get expert tips and master the STAR method for behavioral interviews.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <MessageSquare className="h-4 w-4" />
            <span>{questions.length} Questions</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Target className="h-4 w-4" />
            <span>4 Question Types</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Briefcase className="h-4 w-4" />
            <span>6 Industries</span>
          </div>
        </div>
      </div>

      <Card className="p-5 mb-6">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Star className="h-4 w-4 text-amber-500" />
          {starMethod.title}
        </h3>
        <p className="text-xs text-muted-foreground mb-4">{starMethod.description}</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {starMethod.steps.map((step) => (
            <div key={step.letter} className="p-3 rounded-md bg-muted/50">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-7 h-7 rounded-md bg-primary/10 flex items-center justify-center font-bold text-sm text-primary">{step.letter}</span>
                <span className="font-semibold text-sm">{step.word}</span>
              </div>
              <p className="text-[11px] text-muted-foreground">{step.description}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-4 mb-6">
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-interview-search"
          />
        </div>
        <div className="space-y-2">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Interview Type</label>
            <div className="flex flex-wrap gap-2">
              {interviewTypes.map((t) => (
                <Button
                  key={t.value}
                  variant={activeType === t.value ? "secondary" : "outline"}
                  size="sm"
                  onClick={() => setActiveType(t.value)}
                  className="toggle-elevate"
                  data-testid={`button-type-${t.value}`}
                >
                  {t.label}
                </Button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Industry</label>
            <div className="flex flex-wrap gap-2">
              {industries.map((ind) => (
                <Button
                  key={ind.value}
                  variant={activeIndustry === ind.value ? "secondary" : "outline"}
                  size="sm"
                  onClick={() => setActiveIndustry(ind.value)}
                  className="toggle-elevate"
                  data-testid={`button-industry-${ind.value}`}
                >
                  {ind.label}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {activeType !== "all" && typeTips[activeType] && (
        <Card className="p-4 mb-6">
          <div className="flex items-start gap-2 mb-3">
            <Lightbulb className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
            <h3 className="font-semibold text-sm">Tips for {interviewTypes.find((t) => t.value === activeType)?.label} Interviews</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {typeTips[activeType].map((tip, i) => (
              <div key={i} className="flex items-start gap-2">
                <BookOpen className="h-3.5 w-3.5 text-muted-foreground shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground">{tip}</p>
              </div>
            ))}
          </div>
        </Card>
      )}

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} question{filtered.length !== 1 ? "s" : ""}
      </div>

      <div className="space-y-3">
        {filtered.map((q) => (
          <Card
            key={q.id}
            className="overflow-visible hover-elevate cursor-pointer"
            data-testid={`card-question-${q.id}`}
            onClick={() => toggleExpand(q.id)}
          >
            <div className="p-4">
              <div className="flex items-start gap-3">
                <span className="w-7 h-7 rounded-md bg-muted flex items-center justify-center text-xs font-medium shrink-0">{q.id}</span>
                <div className="flex-1">
                  <p className="text-sm font-medium leading-snug">{q.question}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    <Badge variant="outline" className="text-[10px]">{interviewTypes.find((t) => t.value === q.type)?.label}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{industries.find((ind) => ind.value === q.industry)?.label}</Badge>
                  </div>
                </div>
                {expanded.has(q.id) ? (
                  <ChevronUp className="h-4 w-4 text-muted-foreground shrink-0" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
                )}
              </div>
              {expanded.has(q.id) && (
                <div className="mt-3 pt-3 border-t">
                  <div className="flex items-start gap-2">
                    <Lightbulb className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-xs font-medium">Tip for answering:</span>
                      <p className="text-xs text-muted-foreground mt-0.5">{q.tip}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card className="p-12 text-center">
          <MessageSquare className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-30" />
          <p className="text-sm text-muted-foreground">No questions match your filters. Try adjusting your selection.</p>
        </Card>
      )}

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Interview Preparation", item: "https://devglobaljobs.com/tools/interview-prep" },
            ],
          }),
        }}
      />
    </div>
  );
}
