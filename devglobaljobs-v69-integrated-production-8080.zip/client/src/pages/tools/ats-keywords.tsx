import { useState, useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Search, Cpu, Users, Globe, Zap, RotateCcw,
  Lightbulb, CheckCircle2, BarChart3, FileText,
  Target, TrendingUp, ArrowRight,
} from "lucide-react";

const HARD_SKILLS = [
  "python", "java", "javascript", "typescript", "c\\+\\+", "c#", "ruby", "php", "swift", "kotlin",
  "go", "golang", "rust", "scala", "r\\b", "matlab", "sql", "nosql", "html", "css",
  "react", "angular", "vue", "node\\.js", "nodejs", "express", "django", "flask", "spring",
  "docker", "kubernetes", "aws", "azure", "gcp", "google cloud", "terraform", "ansible",
  "jenkins", "git", "github", "gitlab", "ci/cd", "ci cd", "devops", "agile", "scrum",
  "machine learning", "deep learning", "artificial intelligence", "ai", "ml", "nlp",
  "natural language processing", "computer vision", "data science", "data analysis",
  "data engineering", "big data", "hadoop", "spark", "kafka", "elasticsearch",
  "mongodb", "postgresql", "mysql", "redis", "dynamodb", "oracle", "sap",
  "tableau", "power bi", "excel", "powerpoint", "salesforce", "jira", "confluence",
  "figma", "sketch", "adobe", "photoshop", "illustrator", "indesign",
  "rest api", "restful", "graphql", "microservices", "api", "sdk",
  "linux", "unix", "windows server", "networking", "tcp/ip", "dns",
  "cybersecurity", "information security", "penetration testing", "encryption",
  "blockchain", "cloud computing", "saas", "paas", "iaas",
  "project management", "pmp", "prince2", "six sigma", "lean",
  "financial modeling", "accounting", "bookkeeping", "quickbooks",
  "crm", "erp", "supply chain", "logistics",
  "autocad", "solidworks", "matlab", "labview",
  "gis", "arcgis", "qgis",
  "stata", "spss", "sas",
  "sharepoint", "office 365", "microsoft office",
  "wordpress", "drupal", "cms",
  "seo", "sem", "google analytics", "google ads",
  "a/b testing", "ux", "ui", "user experience", "user interface",
  "mobile development", "ios", "android", "flutter", "react native",
  "unit testing", "integration testing", "qa", "quality assurance",
  "etl", "data warehouse", "data lake", "snowflake", "redshift",
  "power automate", "rpa", "robotic process automation",
  "itil", "iso 27001", "gdpr", "hipaa", "sox compliance",
  "cpa", "cfa", "acca", "chartered accountant",
  "phr", "shrm", "certified", "certification",
];

const SOFT_SKILLS = [
  "leadership", "communication", "teamwork", "collaboration", "problem solving",
  "problem-solving", "critical thinking", "analytical", "adaptability", "flexibility",
  "creativity", "innovation", "time management", "organizational", "attention to detail",
  "detail-oriented", "interpersonal", "negotiation", "conflict resolution",
  "decision making", "decision-making", "strategic thinking", "strategic planning",
  "mentoring", "coaching", "emotional intelligence", "empathy", "resilience",
  "self-motivated", "initiative", "proactive", "multitasking", "multi-tasking",
  "presentation skills", "public speaking", "written communication",
  "stakeholder management", "stakeholder engagement", "relationship building",
  "cross-functional", "cross-cultural", "cultural awareness", "diversity",
  "inclusive", "inclusivity", "accountability", "integrity", "work ethic",
  "customer service", "client relations", "client-facing", "customer-oriented",
  "persuasion", "influence", "facilitation", "delegation", "prioritization",
  "results-driven", "goal-oriented", "deadline-driven", "pressure",
  "team building", "team player", "supervisory", "managerial",
];

const INDUSTRY_KEYWORDS = [
  "sustainability", "sustainable development", "climate change", "environmental",
  "humanitarian", "human rights", "gender equality", "social impact",
  "capacity building", "monitoring and evaluation", "m&e", "program management",
  "grant management", "donor relations", "fundraising", "advocacy",
  "policy development", "public policy", "governance", "compliance",
  "risk management", "risk assessment", "due diligence", "audit",
  "digital transformation", "innovation", "startup", "entrepreneurship",
  "e-commerce", "fintech", "healthtech", "edtech", "agritech",
  "market research", "competitive analysis", "business development",
  "revenue growth", "profit margin", "roi", "kpi", "okr",
  "talent acquisition", "recruitment", "onboarding", "retention",
  "employee engagement", "performance management", "compensation",
  "budget management", "financial planning", "forecasting",
  "regulatory", "legal compliance", "intellectual property",
  "clinical trials", "fda", "gmp", "pharmaceutical",
  "research and development", "r&d", "product development", "product management",
  "go-to-market", "brand management", "content strategy", "social media",
  "public relations", "corporate communications", "crisis management",
  "international development", "ngos", "non-profit", "nonprofit",
  "united nations", "world bank", "bilateral", "multilateral",
  "peacekeeping", "post-conflict", "refugee", "displacement",
  "food security", "water sanitation", "wash", "shelter",
  "education sector", "health sector", "agriculture", "livelihood",
  "microfinance", "impact investing", "csr", "esg",
  "supply chain management", "procurement", "vendor management",
  "manufacturing", "quality control", "iso", "lean manufacturing",
];

const ACTION_VERBS = [
  "managed", "led", "directed", "supervised", "oversaw", "coordinated",
  "developed", "designed", "created", "built", "established", "launched",
  "implemented", "executed", "deployed", "delivered", "administered",
  "analyzed", "assessed", "evaluated", "researched", "investigated",
  "improved", "enhanced", "optimized", "streamlined", "increased",
  "reduced", "decreased", "minimized", "eliminated", "resolved",
  "negotiated", "persuaded", "influenced", "advocated", "facilitated",
  "trained", "mentored", "coached", "educated", "instructed",
  "collaborated", "partnered", "consulted", "advised", "supported",
  "presented", "communicated", "authored", "drafted", "published",
  "planned", "organized", "prioritized", "scheduled", "budgeted",
  "monitored", "tracked", "reported", "documented", "maintained",
  "generated", "produced", "achieved", "exceeded", "accomplished",
  "spearheaded", "pioneered", "transformed", "revamped", "restructured",
  "integrated", "consolidated", "unified", "standardized", "automated",
  "secured", "protected", "ensured", "verified", "validated",
  "recruited", "hired", "onboarded", "retained", "engaged",
  "forecasted", "projected", "modeled", "calculated", "quantified",
  "championed", "initiated", "proposed", "recommended", "formulated",
];

interface KeywordMatch {
  keyword: string;
  count: number;
}

interface ScanResults {
  hardSkills: KeywordMatch[];
  softSkills: KeywordMatch[];
  industryKeywords: KeywordMatch[];
  actionVerbs: KeywordMatch[];
  totalWords: number;
  uniqueKeywords: number;
  keywordDensity: number;
}

function extractKeywords(text: string): ScanResults {
  const lower = text.toLowerCase();
  const totalWords = text.split(/\s+/).filter(Boolean).length;

  function matchCategory(dictionary: string[]): KeywordMatch[] {
    const matches: KeywordMatch[] = [];
    for (const term of dictionary) {
      const regex = new RegExp(`\\b${term}\\b`, "gi");
      const found = lower.match(regex);
      if (found && found.length > 0) {
        const display = term
          .replace(/\\\+/g, "+")
          .replace(/\\\./g, ".")
          .replace(/\\b/g, "");
        matches.push({ keyword: display, count: found.length });
      }
    }
    return matches.sort((a, b) => b.count - a.count);
  }

  const hardSkills = matchCategory(HARD_SKILLS);
  const softSkills = matchCategory(SOFT_SKILLS);
  const industryKeywords = matchCategory(INDUSTRY_KEYWORDS);
  const actionVerbs = matchCategory(ACTION_VERBS);

  const uniqueKeywords =
    hardSkills.length + softSkills.length + industryKeywords.length + actionVerbs.length;
  const totalKeywordOccurrences =
    hardSkills.reduce((s, k) => s + k.count, 0) +
    softSkills.reduce((s, k) => s + k.count, 0) +
    industryKeywords.reduce((s, k) => s + k.count, 0) +
    actionVerbs.reduce((s, k) => s + k.count, 0);
  const keywordDensity = totalWords > 0 ? Math.round((totalKeywordOccurrences / totalWords) * 100) : 0;

  return { hardSkills, softSkills, industryKeywords, actionVerbs, totalWords, uniqueKeywords, keywordDensity };
}

const CATEGORY_CONFIG = [
  { key: "hardSkills" as const, label: "Hard Skills", icon: Cpu, badgeClass: "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 border-blue-200 dark:border-blue-800" },
  { key: "softSkills" as const, label: "Soft Skills", icon: Users, badgeClass: "bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300 border-green-200 dark:border-green-800" },
  { key: "industryKeywords" as const, label: "Industry Keywords", icon: Globe, badgeClass: "bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-300 border-purple-200 dark:border-purple-800" },
  { key: "actionVerbs" as const, label: "Action Verbs", icon: Zap, badgeClass: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300 border-amber-200 dark:border-amber-800" },
];

const ATS_TIPS = [
  { title: "Use exact keywords from the job description", description: "ATS systems look for exact matches. If the job says 'project management,' use that exact phrase rather than 'managing projects.'" },
  { title: "Include both acronyms and full terms", description: "Write 'Search Engine Optimization (SEO)' so ATS catches both variations." },
  { title: "Place keywords in context", description: "Don't just list keywords. Use them naturally in your experience bullet points to pass both ATS and human review." },
  { title: "Prioritize hard skills in your skills section", description: "Technical skills and tools are the most commonly scanned keywords. List them prominently." },
  { title: "Mirror the job title", description: "If the job posting says 'Senior Data Analyst,' consider using that exact title in your summary or experience section." },
  { title: "Avoid images, tables, and headers/footers", description: "Many ATS systems cannot read content in images, complex tables, or header/footer areas." },
  { title: "Use standard section headings", description: "Stick to 'Experience,' 'Education,' 'Skills,' and 'Summary.' Creative headings may confuse ATS parsers." },
  { title: "Submit in the right format", description: "Unless specified otherwise, PDF or DOCX formats are the safest for ATS compatibility." },
];

export default function AtsKeywords() {
  const [jobDescription, setJobDescription] = useState("");
  const [results, setResults] = useState<ScanResults | null>(null);
  const [hasScanned, setHasScanned] = useState(false);

  const handleScan = () => {
    if (!jobDescription.trim()) return;
    const scanResults = extractKeywords(jobDescription);
    setResults(scanResults);
    setHasScanned(true);
  };

  const handleReset = () => {
    setJobDescription("");
    setResults(null);
    setHasScanned(false);
  };

  const overallScore = useMemo(() => {
    if (!results) return 0;
    const hardWeight = Math.min(results.hardSkills.length * 3, 30);
    const softWeight = Math.min(results.softSkills.length * 2, 20);
    const industryWeight = Math.min(results.industryKeywords.length * 2.5, 25);
    const verbWeight = Math.min(results.actionVerbs.length * 1.5, 25);
    return Math.min(Math.round(hardWeight + softWeight + industryWeight + verbWeight), 100);
  }, [results]);

  function getScoreColor(score: number) {
    if (score >= 70) return "text-green-600";
    if (score >= 40) return "text-amber-500";
    return "text-red-500";
  }

  function getScoreLabel(score: number) {
    if (score >= 80) return "Keyword Rich";
    if (score >= 60) return "Good Coverage";
    if (score >= 40) return "Moderate";
    if (score >= 20) return "Needs More Keywords";
    return "Low Keyword Density";
  }

  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (overallScore / 100) * circumference;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 mb-4">
          <Search className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-ats-keywords-title">
          ATS Resume Keywords Scanner
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Paste a job description below to extract and categorize ATS-friendly keywords.
          Optimize your resume by incorporating these keywords to pass Applicant Tracking Systems.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Cpu className="h-4 w-4" />
            <span>Smart Extraction</span>
          </div>
          <div className="flex items-center gap-1.5">
            <BarChart3 className="h-4 w-4" />
            <span>Density Analysis</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Target className="h-4 w-4" />
            <span>4 Categories</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5" data-testid="card-job-description-input">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="h-5 w-5 text-muted-foreground" />
              <h2 className="font-semibold text-sm flex-1">Job Description</h2>
            </div>
            <Textarea
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste the full job description here to scan for ATS keywords. Include the job title, responsibilities, requirements, and qualifications for best results..."
              className="min-h-[200px] text-sm resize-y"
              data-testid="textarea-job-description"
            />
            <div className="flex items-center gap-3 mt-4 flex-wrap">
              <Button
                onClick={handleScan}
                disabled={!jobDescription.trim()}
                data-testid="button-scan-keywords"
              >
                <Search className="h-4 w-4 mr-2" />
                Scan Keywords
              </Button>
              {hasScanned && (
                <Button variant="outline" onClick={handleReset} data-testid="button-reset-scanner">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset
                </Button>
              )}
              <span className="text-xs text-muted-foreground ml-auto">
                {jobDescription.split(/\s+/).filter(Boolean).length} words
              </span>
            </div>
          </Card>

          {hasScanned && results && (
            <>
              {CATEGORY_CONFIG.map((cat) => {
                const Icon = cat.icon;
                const keywords = results[cat.key];
                return (
                  <Card key={cat.key} className="p-5" data-testid={`card-category-${cat.key}`}>
                    <div className="flex items-center gap-2 mb-4">
                      <Icon className="h-5 w-5 text-muted-foreground" />
                      <h2 className="font-semibold text-sm flex-1">{cat.label}</h2>
                      <Badge variant="secondary" className="text-[10px]">
                        {keywords.length} found
                      </Badge>
                    </div>
                    {keywords.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {keywords.map((kw) => (
                          <span
                            key={kw.keyword}
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border ${cat.badgeClass}`}
                            data-testid={`badge-keyword-${kw.keyword.replace(/\s+/g, "-")}`}
                          >
                            {kw.keyword}
                            {kw.count > 1 && (
                              <span className="opacity-60">x{kw.count}</span>
                            )}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground" data-testid={`text-no-${cat.key}`}>
                        No {cat.label.toLowerCase()} detected in this job description.
                      </p>
                    )}
                  </Card>
                );
              })}
            </>
          )}

          <Card className="p-5" data-testid="card-ats-tips">
            <div className="flex items-center gap-2 mb-4">
              <Lightbulb className="h-5 w-5 text-muted-foreground" />
              <h2 className="font-semibold text-sm">ATS Optimization Tips</h2>
            </div>
            <div className="space-y-3">
              {ATS_TIPS.map((tip, i) => (
                <div key={i} className="flex items-start gap-3" data-testid={`tip-item-${i}`}>
                  <ArrowRight className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                  <div className="space-y-0.5">
                    <p className="text-sm font-medium">{tip.title}</p>
                    <p className="text-[11px] text-muted-foreground">{tip.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div>
          <Card className="p-6 sticky top-20" data-testid="card-score-panel">
            <h2 className="font-semibold mb-4 text-center">Keyword Analysis</h2>
            {hasScanned && results ? (
              <>
                <div className="flex justify-center mb-4">
                  <div className="relative w-28 h-28">
                    <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="6" className="text-muted/30" />
                      <circle
                        cx="50" cy="50" r="45" fill="none" strokeWidth="6"
                        stroke="currentColor"
                        className={getScoreColor(overallScore)}
                        strokeLinecap="round"
                        strokeDasharray={circumference}
                        strokeDashoffset={strokeDashoffset}
                        style={{ transition: "stroke-dashoffset 0.5s ease" }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className={`text-2xl font-bold ${getScoreColor(overallScore)}`} data-testid="text-keyword-score">{overallScore}%</span>
                      <span className="text-[10px] text-muted-foreground">{getScoreLabel(overallScore)}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Total Words</span>
                    <span data-testid="text-total-words">{results.totalWords}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Unique Keywords</span>
                    <span data-testid="text-unique-keywords">{results.uniqueKeywords}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Keyword Density</span>
                    <span data-testid="text-keyword-density">{results.keywordDensity}%</span>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {CATEGORY_CONFIG.map((cat) => {
                    const count = results[cat.key].length;
                    const max = cat.key === "hardSkills" ? 10 : cat.key === "actionVerbs" ? 15 : 8;
                    const pct = Math.min(Math.round((count / max) * 100), 100);
                    return (
                      <div key={cat.key}>
                        <div className="flex items-center justify-between text-xs mb-0.5">
                          <span className="text-muted-foreground">{cat.label}</span>
                          <span>{count}</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                          <div
                            className="h-full rounded-full bg-primary transition-all duration-300"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={handleReset}
                  data-testid="button-reset-sidebar"
                >
                  <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
                  New Scan
                </Button>
              </>
            ) : (
              <div className="text-center py-8">
                <TrendingUp className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground" data-testid="text-scan-prompt">
                  Paste a job description and click "Scan Keywords" to see your analysis
                </p>
                <div className="mt-4 space-y-2 text-left">
                  {CATEGORY_CONFIG.map((cat) => {
                    const Icon = cat.icon;
                    return (
                      <div key={cat.key} className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Icon className="h-3.5 w-3.5" />
                        <span>{cat.label}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "ATS Resume Keywords Scanner", item: "https://devglobaljobs.com/tools/ats-keywords" },
            ],
          }),
        }}
      />
    </div>
  );
}
