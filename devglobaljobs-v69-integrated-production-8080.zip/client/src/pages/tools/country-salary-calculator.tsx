import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Calculator, Globe, DollarSign, TrendingUp, MapPin,
  Briefcase, BarChart3, Building2, GraduationCap, Lightbulb,
} from "lucide-react";

interface CountryInfo {
  name: string;
  currency: string;
  currencySymbol: string;
  usdRate: number;
  costOfLivingIndex: number;
}

interface SalaryRange {
  min: number;
  max: number;
}

type ExperienceLevel = "entry" | "mid" | "senior" | "lead" | "executive";
type Industry = "technology" | "healthcare" | "finance" | "engineering" | "education" | "marketing" | "legal" | "manufacturing" | "hospitality" | "retail" | "government" | "creative";

const experienceLevels: { value: ExperienceLevel; label: string }[] = [
  { value: "entry", label: "Entry Level (0-2 years)" },
  { value: "mid", label: "Mid Level (3-5 years)" },
  { value: "senior", label: "Senior (6-10 years)" },
  { value: "lead", label: "Lead / Director (10-15 years)" },
  { value: "executive", label: "Executive (15+ years)" },
];

const industries: { value: Industry; label: string }[] = [
  { value: "technology", label: "Technology" },
  { value: "healthcare", label: "Healthcare" },
  { value: "finance", label: "Finance" },
  { value: "engineering", label: "Engineering" },
  { value: "education", label: "Education" },
  { value: "marketing", label: "Marketing" },
  { value: "legal", label: "Legal" },
  { value: "manufacturing", label: "Manufacturing" },
  { value: "hospitality", label: "Hospitality" },
  { value: "retail", label: "Retail" },
  { value: "government", label: "Government" },
  { value: "creative", label: "Creative / Media" },
];

const countries: Record<string, CountryInfo> = {
  us: { name: "United States", currency: "USD", currencySymbol: "$", usdRate: 1, costOfLivingIndex: 100 },
  uk: { name: "United Kingdom", currency: "GBP", currencySymbol: "£", usdRate: 1.27, costOfLivingIndex: 85 },
  ca: { name: "Canada", currency: "CAD", currencySymbol: "C$", usdRate: 0.74, costOfLivingIndex: 78 },
  au: { name: "Australia", currency: "AUD", currencySymbol: "A$", usdRate: 0.65, costOfLivingIndex: 82 },
  de: { name: "Germany", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 70 },
  fr: { name: "France", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 74 },
  nl: { name: "Netherlands", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 80 },
  ch: { name: "Switzerland", currency: "CHF", currencySymbol: "CHF ", usdRate: 1.13, costOfLivingIndex: 122 },
  sg: { name: "Singapore", currency: "SGD", currencySymbol: "S$", usdRate: 0.74, costOfLivingIndex: 88 },
  jp: { name: "Japan", currency: "JPY", currencySymbol: "¥", usdRate: 0.0067, costOfLivingIndex: 78 },
  in: { name: "India", currency: "INR", currencySymbol: "₹", usdRate: 0.012, costOfLivingIndex: 25 },
  br: { name: "Brazil", currency: "BRL", currencySymbol: "R$", usdRate: 0.20, costOfLivingIndex: 35 },
  za: { name: "South Africa", currency: "ZAR", currencySymbol: "R", usdRate: 0.055, costOfLivingIndex: 33 },
  ae: { name: "UAE", currency: "AED", currencySymbol: "د.إ", usdRate: 0.27, costOfLivingIndex: 72 },
  pl: { name: "Poland", currency: "PLN", currencySymbol: "zł", usdRate: 0.25, costOfLivingIndex: 42 },
  it: { name: "Italy", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 68 },
  es: { name: "Spain", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 58 },
  se: { name: "Sweden", currency: "SEK", currencySymbol: "kr", usdRate: 0.095, costOfLivingIndex: 82 },
  no: { name: "Norway", currency: "NOK", currencySymbol: "kr", usdRate: 0.093, costOfLivingIndex: 95 },
  dk: { name: "Denmark", currency: "DKK", currencySymbol: "kr", usdRate: 0.145, costOfLivingIndex: 90 },
  ie: { name: "Ireland", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 84 },
  be: { name: "Belgium", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 75 },
  at: { name: "Austria", currency: "EUR", currencySymbol: "€", usdRate: 1.08, costOfLivingIndex: 72 },
  nz: { name: "New Zealand", currency: "NZD", currencySymbol: "NZ$", usdRate: 0.61, costOfLivingIndex: 75 },
  kr: { name: "South Korea", currency: "KRW", currencySymbol: "₩", usdRate: 0.00074, costOfLivingIndex: 72 },
  cn: { name: "China", currency: "CNY", currencySymbol: "¥", usdRate: 0.14, costOfLivingIndex: 40 },
  mx: { name: "Mexico", currency: "MXN", currencySymbol: "MX$", usdRate: 0.058, costOfLivingIndex: 32 },
  tr: { name: "Turkey", currency: "TRY", currencySymbol: "₺", usdRate: 0.031, costOfLivingIndex: 28 },
  ng: { name: "Nigeria", currency: "NGN", currencySymbol: "₦", usdRate: 0.00065, costOfLivingIndex: 22 },
  ke: { name: "Kenya", currency: "KES", currencySymbol: "KSh", usdRate: 0.0078, costOfLivingIndex: 28 },
  pk: { name: "Pakistan", currency: "PKR", currencySymbol: "₨", usdRate: 0.0036, costOfLivingIndex: 20 },
  ph: { name: "Philippines", currency: "PHP", currencySymbol: "₱", usdRate: 0.018, costOfLivingIndex: 28 },
  th: { name: "Thailand", currency: "THB", currencySymbol: "฿", usdRate: 0.029, costOfLivingIndex: 35 },
  my: { name: "Malaysia", currency: "MYR", currencySymbol: "RM", usdRate: 0.22, costOfLivingIndex: 35 },
};

const salaryData: Record<string, Record<Industry, Record<ExperienceLevel, SalaryRange>>> = {
  us: {
    technology: { entry: { min: 70000, max: 90000 }, mid: { min: 100000, max: 140000 }, senior: { min: 150000, max: 200000 }, lead: { min: 180000, max: 260000 }, executive: { min: 250000, max: 400000 } },
    healthcare: { entry: { min: 50000, max: 65000 }, mid: { min: 70000, max: 95000 }, senior: { min: 100000, max: 150000 }, lead: { min: 140000, max: 200000 }, executive: { min: 200000, max: 350000 } },
    finance: { entry: { min: 60000, max: 85000 }, mid: { min: 90000, max: 130000 }, senior: { min: 140000, max: 200000 }, lead: { min: 180000, max: 280000 }, executive: { min: 250000, max: 500000 } },
    engineering: { entry: { min: 65000, max: 85000 }, mid: { min: 90000, max: 120000 }, senior: { min: 120000, max: 170000 }, lead: { min: 160000, max: 220000 }, executive: { min: 200000, max: 350000 } },
    education: { entry: { min: 38000, max: 48000 }, mid: { min: 48000, max: 65000 }, senior: { min: 60000, max: 85000 }, lead: { min: 80000, max: 120000 }, executive: { min: 110000, max: 180000 } },
    marketing: { entry: { min: 45000, max: 60000 }, mid: { min: 65000, max: 90000 }, senior: { min: 95000, max: 135000 }, lead: { min: 130000, max: 180000 }, executive: { min: 170000, max: 300000 } },
    legal: { entry: { min: 65000, max: 90000 }, mid: { min: 95000, max: 150000 }, senior: { min: 150000, max: 250000 }, lead: { min: 200000, max: 350000 }, executive: { min: 300000, max: 600000 } },
    manufacturing: { entry: { min: 42000, max: 55000 }, mid: { min: 55000, max: 75000 }, senior: { min: 75000, max: 110000 }, lead: { min: 100000, max: 150000 }, executive: { min: 140000, max: 250000 } },
    hospitality: { entry: { min: 30000, max: 40000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 80000 }, lead: { min: 75000, max: 120000 }, executive: { min: 110000, max: 200000 } },
    retail: { entry: { min: 28000, max: 38000 }, mid: { min: 38000, max: 52000 }, senior: { min: 52000, max: 75000 }, lead: { min: 70000, max: 110000 }, executive: { min: 100000, max: 180000 } },
    government: { entry: { min: 40000, max: 55000 }, mid: { min: 55000, max: 78000 }, senior: { min: 78000, max: 110000 }, lead: { min: 100000, max: 145000 }, executive: { min: 130000, max: 200000 } },
    creative: { entry: { min: 38000, max: 52000 }, mid: { min: 55000, max: 80000 }, senior: { min: 80000, max: 120000 }, lead: { min: 110000, max: 160000 }, executive: { min: 150000, max: 280000 } },
  },
  uk: {
    technology: { entry: { min: 28000, max: 38000 }, mid: { min: 45000, max: 65000 }, senior: { min: 70000, max: 100000 }, lead: { min: 90000, max: 130000 }, executive: { min: 120000, max: 200000 } },
    healthcare: { entry: { min: 25000, max: 32000 }, mid: { min: 35000, max: 50000 }, senior: { min: 50000, max: 80000 }, lead: { min: 75000, max: 110000 }, executive: { min: 100000, max: 180000 } },
    finance: { entry: { min: 30000, max: 45000 }, mid: { min: 50000, max: 75000 }, senior: { min: 80000, max: 120000 }, lead: { min: 110000, max: 170000 }, executive: { min: 150000, max: 350000 } },
    engineering: { entry: { min: 27000, max: 35000 }, mid: { min: 38000, max: 55000 }, senior: { min: 55000, max: 80000 }, lead: { min: 75000, max: 110000 }, executive: { min: 100000, max: 170000 } },
    education: { entry: { min: 25000, max: 30000 }, mid: { min: 30000, max: 42000 }, senior: { min: 40000, max: 58000 }, lead: { min: 55000, max: 80000 }, executive: { min: 75000, max: 120000 } },
    marketing: { entry: { min: 24000, max: 32000 }, mid: { min: 35000, max: 50000 }, senior: { min: 50000, max: 75000 }, lead: { min: 70000, max: 100000 }, executive: { min: 90000, max: 160000 } },
    legal: { entry: { min: 30000, max: 45000 }, mid: { min: 50000, max: 80000 }, senior: { min: 80000, max: 130000 }, lead: { min: 120000, max: 200000 }, executive: { min: 180000, max: 400000 } },
    manufacturing: { entry: { min: 22000, max: 28000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 60000 }, lead: { min: 55000, max: 80000 }, executive: { min: 75000, max: 130000 } },
    hospitality: { entry: { min: 20000, max: 25000 }, mid: { min: 25000, max: 35000 }, senior: { min: 35000, max: 50000 }, lead: { min: 45000, max: 70000 }, executive: { min: 65000, max: 120000 } },
    retail: { entry: { min: 19000, max: 24000 }, mid: { min: 24000, max: 32000 }, senior: { min: 32000, max: 48000 }, lead: { min: 45000, max: 65000 }, executive: { min: 60000, max: 110000 } },
    government: { entry: { min: 25000, max: 32000 }, mid: { min: 32000, max: 45000 }, senior: { min: 45000, max: 65000 }, lead: { min: 60000, max: 85000 }, executive: { min: 80000, max: 130000 } },
    creative: { entry: { min: 22000, max: 30000 }, mid: { min: 32000, max: 48000 }, senior: { min: 48000, max: 70000 }, lead: { min: 65000, max: 95000 }, executive: { min: 85000, max: 150000 } },
  },
  ca: {
    technology: { entry: { min: 55000, max: 75000 }, mid: { min: 80000, max: 110000 }, senior: { min: 110000, max: 150000 }, lead: { min: 140000, max: 190000 }, executive: { min: 180000, max: 300000 } },
    healthcare: { entry: { min: 48000, max: 62000 }, mid: { min: 65000, max: 90000 }, senior: { min: 90000, max: 130000 }, lead: { min: 120000, max: 170000 }, executive: { min: 160000, max: 280000 } },
    finance: { entry: { min: 52000, max: 70000 }, mid: { min: 75000, max: 105000 }, senior: { min: 105000, max: 150000 }, lead: { min: 140000, max: 200000 }, executive: { min: 190000, max: 350000 } },
    engineering: { entry: { min: 55000, max: 72000 }, mid: { min: 75000, max: 100000 }, senior: { min: 100000, max: 140000 }, lead: { min: 130000, max: 180000 }, executive: { min: 170000, max: 280000 } },
    education: { entry: { min: 42000, max: 55000 }, mid: { min: 55000, max: 75000 }, senior: { min: 72000, max: 95000 }, lead: { min: 90000, max: 120000 }, executive: { min: 110000, max: 170000 } },
    marketing: { entry: { min: 42000, max: 55000 }, mid: { min: 58000, max: 80000 }, senior: { min: 80000, max: 115000 }, lead: { min: 110000, max: 150000 }, executive: { min: 140000, max: 240000 } },
    legal: { entry: { min: 55000, max: 75000 }, mid: { min: 80000, max: 120000 }, senior: { min: 120000, max: 180000 }, lead: { min: 160000, max: 250000 }, executive: { min: 220000, max: 400000 } },
    manufacturing: { entry: { min: 40000, max: 52000 }, mid: { min: 55000, max: 72000 }, senior: { min: 72000, max: 100000 }, lead: { min: 95000, max: 135000 }, executive: { min: 130000, max: 220000 } },
    hospitality: { entry: { min: 32000, max: 42000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 80000 }, lead: { min: 75000, max: 110000 }, executive: { min: 100000, max: 180000 } },
    retail: { entry: { min: 30000, max: 40000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 78000 }, lead: { min: 72000, max: 105000 }, executive: { min: 95000, max: 170000 } },
    government: { entry: { min: 45000, max: 58000 }, mid: { min: 60000, max: 80000 }, senior: { min: 80000, max: 110000 }, lead: { min: 105000, max: 140000 }, executive: { min: 130000, max: 200000 } },
    creative: { entry: { min: 38000, max: 50000 }, mid: { min: 52000, max: 72000 }, senior: { min: 72000, max: 100000 }, lead: { min: 95000, max: 135000 }, executive: { min: 125000, max: 220000 } },
  },
  au: {
    technology: { entry: { min: 65000, max: 85000 }, mid: { min: 95000, max: 130000 }, senior: { min: 130000, max: 180000 }, lead: { min: 170000, max: 230000 }, executive: { min: 220000, max: 350000 } },
    healthcare: { entry: { min: 55000, max: 72000 }, mid: { min: 75000, max: 100000 }, senior: { min: 100000, max: 150000 }, lead: { min: 140000, max: 200000 }, executive: { min: 190000, max: 320000 } },
    finance: { entry: { min: 60000, max: 80000 }, mid: { min: 85000, max: 120000 }, senior: { min: 120000, max: 170000 }, lead: { min: 160000, max: 230000 }, executive: { min: 220000, max: 400000 } },
    engineering: { entry: { min: 62000, max: 82000 }, mid: { min: 85000, max: 115000 }, senior: { min: 115000, max: 160000 }, lead: { min: 150000, max: 210000 }, executive: { min: 200000, max: 320000 } },
    education: { entry: { min: 55000, max: 68000 }, mid: { min: 70000, max: 90000 }, senior: { min: 88000, max: 115000 }, lead: { min: 110000, max: 145000 }, executive: { min: 135000, max: 200000 } },
    marketing: { entry: { min: 50000, max: 65000 }, mid: { min: 70000, max: 95000 }, senior: { min: 95000, max: 135000 }, lead: { min: 130000, max: 175000 }, executive: { min: 165000, max: 280000 } },
    legal: { entry: { min: 65000, max: 85000 }, mid: { min: 90000, max: 130000 }, senior: { min: 130000, max: 200000 }, lead: { min: 180000, max: 280000 }, executive: { min: 250000, max: 450000 } },
    manufacturing: { entry: { min: 50000, max: 65000 }, mid: { min: 68000, max: 90000 }, senior: { min: 90000, max: 125000 }, lead: { min: 120000, max: 165000 }, executive: { min: 155000, max: 260000 } },
    hospitality: { entry: { min: 42000, max: 55000 }, mid: { min: 55000, max: 72000 }, senior: { min: 72000, max: 100000 }, lead: { min: 95000, max: 135000 }, executive: { min: 125000, max: 210000 } },
    retail: { entry: { min: 40000, max: 52000 }, mid: { min: 52000, max: 70000 }, senior: { min: 70000, max: 95000 }, lead: { min: 90000, max: 130000 }, executive: { min: 120000, max: 200000 } },
    government: { entry: { min: 55000, max: 70000 }, mid: { min: 72000, max: 95000 }, senior: { min: 95000, max: 130000 }, lead: { min: 125000, max: 165000 }, executive: { min: 155000, max: 230000 } },
    creative: { entry: { min: 45000, max: 60000 }, mid: { min: 62000, max: 85000 }, senior: { min: 85000, max: 120000 }, lead: { min: 115000, max: 160000 }, executive: { min: 150000, max: 260000 } },
  },
  de: {
    technology: { entry: { min: 42000, max: 55000 }, mid: { min: 58000, max: 78000 }, senior: { min: 78000, max: 105000 }, lead: { min: 100000, max: 135000 }, executive: { min: 130000, max: 200000 } },
    healthcare: { entry: { min: 38000, max: 48000 }, mid: { min: 50000, max: 68000 }, senior: { min: 68000, max: 95000 }, lead: { min: 90000, max: 125000 }, executive: { min: 120000, max: 190000 } },
    finance: { entry: { min: 45000, max: 58000 }, mid: { min: 62000, max: 85000 }, senior: { min: 85000, max: 120000 }, lead: { min: 110000, max: 160000 }, executive: { min: 150000, max: 280000 } },
    engineering: { entry: { min: 45000, max: 55000 }, mid: { min: 58000, max: 75000 }, senior: { min: 75000, max: 100000 }, lead: { min: 95000, max: 130000 }, executive: { min: 125000, max: 200000 } },
    education: { entry: { min: 35000, max: 42000 }, mid: { min: 42000, max: 55000 }, senior: { min: 55000, max: 72000 }, lead: { min: 68000, max: 90000 }, executive: { min: 85000, max: 130000 } },
    marketing: { entry: { min: 35000, max: 45000 }, mid: { min: 48000, max: 65000 }, senior: { min: 65000, max: 90000 }, lead: { min: 85000, max: 120000 }, executive: { min: 110000, max: 180000 } },
    legal: { entry: { min: 42000, max: 55000 }, mid: { min: 58000, max: 80000 }, senior: { min: 80000, max: 120000 }, lead: { min: 110000, max: 165000 }, executive: { min: 150000, max: 280000 } },
    manufacturing: { entry: { min: 35000, max: 45000 }, mid: { min: 48000, max: 62000 }, senior: { min: 62000, max: 85000 }, lead: { min: 80000, max: 115000 }, executive: { min: 110000, max: 180000 } },
    hospitality: { entry: { min: 24000, max: 30000 }, mid: { min: 30000, max: 40000 }, senior: { min: 40000, max: 55000 }, lead: { min: 52000, max: 75000 }, executive: { min: 70000, max: 120000 } },
    retail: { entry: { min: 24000, max: 30000 }, mid: { min: 30000, max: 40000 }, senior: { min: 40000, max: 55000 }, lead: { min: 52000, max: 75000 }, executive: { min: 70000, max: 120000 } },
    government: { entry: { min: 35000, max: 45000 }, mid: { min: 45000, max: 60000 }, senior: { min: 60000, max: 80000 }, lead: { min: 78000, max: 105000 }, executive: { min: 100000, max: 150000 } },
    creative: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 80000 }, lead: { min: 75000, max: 105000 }, executive: { min: 100000, max: 170000 } },
  },
  fr: {
    technology: { entry: { min: 35000, max: 45000 }, mid: { min: 48000, max: 65000 }, senior: { min: 65000, max: 90000 }, lead: { min: 85000, max: 115000 }, executive: { min: 110000, max: 180000 } },
    healthcare: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 80000 }, lead: { min: 75000, max: 110000 }, executive: { min: 100000, max: 170000 } },
    finance: { entry: { min: 38000, max: 50000 }, mid: { min: 55000, max: 75000 }, senior: { min: 75000, max: 110000 }, lead: { min: 100000, max: 150000 }, executive: { min: 140000, max: 260000 } },
    engineering: { entry: { min: 35000, max: 45000 }, mid: { min: 48000, max: 62000 }, senior: { min: 62000, max: 85000 }, lead: { min: 80000, max: 115000 }, executive: { min: 110000, max: 180000 } },
    education: { entry: { min: 28000, max: 35000 }, mid: { min: 35000, max: 48000 }, senior: { min: 48000, max: 62000 }, lead: { min: 58000, max: 78000 }, executive: { min: 72000, max: 110000 } },
    marketing: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 80000 }, lead: { min: 75000, max: 105000 }, executive: { min: 100000, max: 165000 } },
    legal: { entry: { min: 35000, max: 48000 }, mid: { min: 50000, max: 72000 }, senior: { min: 72000, max: 110000 }, lead: { min: 100000, max: 155000 }, executive: { min: 140000, max: 260000 } },
    manufacturing: { entry: { min: 28000, max: 36000 }, mid: { min: 38000, max: 50000 }, senior: { min: 50000, max: 70000 }, lead: { min: 65000, max: 95000 }, executive: { min: 90000, max: 150000 } },
    hospitality: { entry: { min: 22000, max: 28000 }, mid: { min: 28000, max: 38000 }, senior: { min: 38000, max: 52000 }, lead: { min: 48000, max: 70000 }, executive: { min: 65000, max: 110000 } },
    retail: { entry: { min: 22000, max: 28000 }, mid: { min: 28000, max: 38000 }, senior: { min: 38000, max: 52000 }, lead: { min: 48000, max: 68000 }, executive: { min: 62000, max: 105000 } },
    government: { entry: { min: 28000, max: 38000 }, mid: { min: 38000, max: 52000 }, senior: { min: 52000, max: 72000 }, lead: { min: 68000, max: 95000 }, executive: { min: 90000, max: 140000 } },
    creative: { entry: { min: 26000, max: 35000 }, mid: { min: 38000, max: 52000 }, senior: { min: 52000, max: 72000 }, lead: { min: 68000, max: 95000 }, executive: { min: 90000, max: 155000 } },
  },
  nl: {
    technology: { entry: { min: 38000, max: 50000 }, mid: { min: 55000, max: 75000 }, senior: { min: 75000, max: 100000 }, lead: { min: 95000, max: 130000 }, executive: { min: 125000, max: 195000 } },
    healthcare: { entry: { min: 32000, max: 42000 }, mid: { min: 45000, max: 60000 }, senior: { min: 60000, max: 85000 }, lead: { min: 80000, max: 115000 }, executive: { min: 110000, max: 175000 } },
    finance: { entry: { min: 40000, max: 55000 }, mid: { min: 58000, max: 80000 }, senior: { min: 80000, max: 115000 }, lead: { min: 110000, max: 155000 }, executive: { min: 145000, max: 270000 } },
    engineering: { entry: { min: 38000, max: 50000 }, mid: { min: 52000, max: 70000 }, senior: { min: 70000, max: 95000 }, lead: { min: 90000, max: 125000 }, executive: { min: 120000, max: 190000 } },
    education: { entry: { min: 32000, max: 40000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 72000 }, lead: { min: 68000, max: 90000 }, executive: { min: 85000, max: 130000 } },
    marketing: { entry: { min: 32000, max: 42000 }, mid: { min: 45000, max: 62000 }, senior: { min: 62000, max: 85000 }, lead: { min: 80000, max: 115000 }, executive: { min: 105000, max: 170000 } },
    legal: { entry: { min: 40000, max: 52000 }, mid: { min: 55000, max: 78000 }, senior: { min: 78000, max: 115000 }, lead: { min: 105000, max: 160000 }, executive: { min: 145000, max: 270000 } },
    manufacturing: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 80000 }, lead: { min: 75000, max: 108000 }, executive: { min: 100000, max: 170000 } },
    hospitality: { entry: { min: 24000, max: 30000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 58000 }, lead: { min: 55000, max: 78000 }, executive: { min: 72000, max: 125000 } },
    retail: { entry: { min: 24000, max: 30000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 58000 }, lead: { min: 55000, max: 78000 }, executive: { min: 72000, max: 125000 } },
    government: { entry: { min: 32000, max: 42000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 78000 }, lead: { min: 75000, max: 102000 }, executive: { min: 95000, max: 148000 } },
    creative: { entry: { min: 28000, max: 38000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 78000 }, lead: { min: 72000, max: 102000 }, executive: { min: 95000, max: 165000 } },
  },
  ch: {
    technology: { entry: { min: 80000, max: 100000 }, mid: { min: 105000, max: 135000 }, senior: { min: 135000, max: 175000 }, lead: { min: 165000, max: 220000 }, executive: { min: 210000, max: 350000 } },
    healthcare: { entry: { min: 70000, max: 88000 }, mid: { min: 90000, max: 120000 }, senior: { min: 120000, max: 160000 }, lead: { min: 150000, max: 200000 }, executive: { min: 190000, max: 320000 } },
    finance: { entry: { min: 85000, max: 108000 }, mid: { min: 110000, max: 150000 }, senior: { min: 150000, max: 200000 }, lead: { min: 190000, max: 260000 }, executive: { min: 250000, max: 450000 } },
    engineering: { entry: { min: 78000, max: 98000 }, mid: { min: 100000, max: 130000 }, senior: { min: 130000, max: 170000 }, lead: { min: 160000, max: 215000 }, executive: { min: 200000, max: 330000 } },
    education: { entry: { min: 65000, max: 80000 }, mid: { min: 80000, max: 100000 }, senior: { min: 100000, max: 125000 }, lead: { min: 120000, max: 155000 }, executive: { min: 145000, max: 210000 } },
    marketing: { entry: { min: 60000, max: 78000 }, mid: { min: 80000, max: 105000 }, senior: { min: 105000, max: 140000 }, lead: { min: 135000, max: 180000 }, executive: { min: 170000, max: 280000 } },
    legal: { entry: { min: 80000, max: 100000 }, mid: { min: 105000, max: 140000 }, senior: { min: 140000, max: 200000 }, lead: { min: 190000, max: 270000 }, executive: { min: 250000, max: 450000 } },
    manufacturing: { entry: { min: 58000, max: 72000 }, mid: { min: 75000, max: 98000 }, senior: { min: 98000, max: 130000 }, lead: { min: 125000, max: 168000 }, executive: { min: 160000, max: 260000 } },
    hospitality: { entry: { min: 45000, max: 58000 }, mid: { min: 58000, max: 75000 }, senior: { min: 75000, max: 100000 }, lead: { min: 95000, max: 130000 }, executive: { min: 120000, max: 200000 } },
    retail: { entry: { min: 42000, max: 55000 }, mid: { min: 55000, max: 72000 }, senior: { min: 72000, max: 95000 }, lead: { min: 90000, max: 125000 }, executive: { min: 115000, max: 195000 } },
    government: { entry: { min: 65000, max: 82000 }, mid: { min: 82000, max: 108000 }, senior: { min: 108000, max: 140000 }, lead: { min: 135000, max: 175000 }, executive: { min: 165000, max: 240000 } },
    creative: { entry: { min: 52000, max: 68000 }, mid: { min: 70000, max: 92000 }, senior: { min: 92000, max: 125000 }, lead: { min: 120000, max: 162000 }, executive: { min: 155000, max: 260000 } },
  },
  sg: {
    technology: { entry: { min: 48000, max: 66000 }, mid: { min: 72000, max: 102000 }, senior: { min: 102000, max: 144000 }, lead: { min: 138000, max: 192000 }, executive: { min: 180000, max: 300000 } },
    healthcare: { entry: { min: 40000, max: 55000 }, mid: { min: 58000, max: 82000 }, senior: { min: 82000, max: 120000 }, lead: { min: 110000, max: 160000 }, executive: { min: 150000, max: 260000 } },
    finance: { entry: { min: 52000, max: 72000 }, mid: { min: 78000, max: 110000 }, senior: { min: 110000, max: 160000 }, lead: { min: 150000, max: 220000 }, executive: { min: 200000, max: 400000 } },
    engineering: { entry: { min: 45000, max: 62000 }, mid: { min: 65000, max: 90000 }, senior: { min: 90000, max: 130000 }, lead: { min: 125000, max: 175000 }, executive: { min: 165000, max: 280000 } },
    education: { entry: { min: 38000, max: 50000 }, mid: { min: 52000, max: 72000 }, senior: { min: 72000, max: 95000 }, lead: { min: 90000, max: 125000 }, executive: { min: 115000, max: 180000 } },
    marketing: { entry: { min: 38000, max: 52000 }, mid: { min: 55000, max: 78000 }, senior: { min: 78000, max: 110000 }, lead: { min: 105000, max: 148000 }, executive: { min: 140000, max: 240000 } },
    legal: { entry: { min: 48000, max: 68000 }, mid: { min: 72000, max: 105000 }, senior: { min: 105000, max: 155000 }, lead: { min: 145000, max: 215000 }, executive: { min: 200000, max: 380000 } },
    manufacturing: { entry: { min: 35000, max: 48000 }, mid: { min: 50000, max: 70000 }, senior: { min: 70000, max: 100000 }, lead: { min: 95000, max: 135000 }, executive: { min: 128000, max: 220000 } },
    hospitality: { entry: { min: 28000, max: 38000 }, mid: { min: 38000, max: 55000 }, senior: { min: 55000, max: 78000 }, lead: { min: 72000, max: 105000 }, executive: { min: 95000, max: 170000 } },
    retail: { entry: { min: 26000, max: 36000 }, mid: { min: 36000, max: 52000 }, senior: { min: 52000, max: 75000 }, lead: { min: 70000, max: 100000 }, executive: { min: 92000, max: 165000 } },
    government: { entry: { min: 42000, max: 58000 }, mid: { min: 60000, max: 82000 }, senior: { min: 82000, max: 112000 }, lead: { min: 108000, max: 148000 }, executive: { min: 140000, max: 220000 } },
    creative: { entry: { min: 32000, max: 45000 }, mid: { min: 48000, max: 68000 }, senior: { min: 68000, max: 98000 }, lead: { min: 92000, max: 132000 }, executive: { min: 125000, max: 215000 } },
  },
  jp: {
    technology: { entry: { min: 3500000, max: 5000000 }, mid: { min: 5500000, max: 8000000 }, senior: { min: 8000000, max: 12000000 }, lead: { min: 11000000, max: 16000000 }, executive: { min: 15000000, max: 25000000 } },
    healthcare: { entry: { min: 3200000, max: 4500000 }, mid: { min: 5000000, max: 7000000 }, senior: { min: 7000000, max: 10000000 }, lead: { min: 9500000, max: 14000000 }, executive: { min: 13000000, max: 22000000 } },
    finance: { entry: { min: 4000000, max: 5500000 }, mid: { min: 6000000, max: 9000000 }, senior: { min: 9000000, max: 14000000 }, lead: { min: 13000000, max: 19000000 }, executive: { min: 18000000, max: 35000000 } },
    engineering: { entry: { min: 3500000, max: 4800000 }, mid: { min: 5200000, max: 7500000 }, senior: { min: 7500000, max: 11000000 }, lead: { min: 10500000, max: 15000000 }, executive: { min: 14000000, max: 24000000 } },
    education: { entry: { min: 2800000, max: 3800000 }, mid: { min: 3800000, max: 5200000 }, senior: { min: 5200000, max: 7200000 }, lead: { min: 7000000, max: 9500000 }, executive: { min: 9000000, max: 14000000 } },
    marketing: { entry: { min: 3000000, max: 4200000 }, mid: { min: 4500000, max: 6500000 }, senior: { min: 6500000, max: 9500000 }, lead: { min: 9000000, max: 13000000 }, executive: { min: 12000000, max: 20000000 } },
    legal: { entry: { min: 4000000, max: 5500000 }, mid: { min: 6000000, max: 9000000 }, senior: { min: 9000000, max: 14000000 }, lead: { min: 13000000, max: 19000000 }, executive: { min: 17000000, max: 32000000 } },
    manufacturing: { entry: { min: 3000000, max: 4000000 }, mid: { min: 4200000, max: 5800000 }, senior: { min: 5800000, max: 8200000 }, lead: { min: 8000000, max: 11500000 }, executive: { min: 11000000, max: 18000000 } },
    hospitality: { entry: { min: 2500000, max: 3200000 }, mid: { min: 3200000, max: 4500000 }, senior: { min: 4500000, max: 6500000 }, lead: { min: 6000000, max: 9000000 }, executive: { min: 8500000, max: 15000000 } },
    retail: { entry: { min: 2500000, max: 3200000 }, mid: { min: 3200000, max: 4500000 }, senior: { min: 4500000, max: 6500000 }, lead: { min: 6000000, max: 8800000 }, executive: { min: 8200000, max: 14000000 } },
    government: { entry: { min: 3200000, max: 4200000 }, mid: { min: 4200000, max: 5800000 }, senior: { min: 5800000, max: 8000000 }, lead: { min: 7500000, max: 10500000 }, executive: { min: 10000000, max: 16000000 } },
    creative: { entry: { min: 2800000, max: 3800000 }, mid: { min: 4000000, max: 5800000 }, senior: { min: 5800000, max: 8500000 }, lead: { min: 8000000, max: 11500000 }, executive: { min: 11000000, max: 19000000 } },
  },
  in: {
    technology: { entry: { min: 400000, max: 800000 }, mid: { min: 1000000, max: 1800000 }, senior: { min: 2000000, max: 4000000 }, lead: { min: 3500000, max: 6000000 }, executive: { min: 5000000, max: 10000000 } },
    healthcare: { entry: { min: 300000, max: 600000 }, mid: { min: 600000, max: 1200000 }, senior: { min: 1200000, max: 2500000 }, lead: { min: 2200000, max: 4000000 }, executive: { min: 3500000, max: 7000000 } },
    finance: { entry: { min: 400000, max: 750000 }, mid: { min: 800000, max: 1500000 }, senior: { min: 1500000, max: 3000000 }, lead: { min: 2800000, max: 5000000 }, executive: { min: 4500000, max: 9000000 } },
    engineering: { entry: { min: 350000, max: 700000 }, mid: { min: 800000, max: 1500000 }, senior: { min: 1500000, max: 3000000 }, lead: { min: 2500000, max: 4500000 }, executive: { min: 4000000, max: 8000000 } },
    education: { entry: { min: 200000, max: 400000 }, mid: { min: 400000, max: 700000 }, senior: { min: 700000, max: 1200000 }, lead: { min: 1000000, max: 1800000 }, executive: { min: 1500000, max: 3000000 } },
    marketing: { entry: { min: 250000, max: 500000 }, mid: { min: 500000, max: 1000000 }, senior: { min: 1000000, max: 2000000 }, lead: { min: 1800000, max: 3200000 }, executive: { min: 2800000, max: 5500000 } },
    legal: { entry: { min: 350000, max: 700000 }, mid: { min: 700000, max: 1400000 }, senior: { min: 1400000, max: 3000000 }, lead: { min: 2500000, max: 5000000 }, executive: { min: 4000000, max: 8500000 } },
    manufacturing: { entry: { min: 250000, max: 450000 }, mid: { min: 450000, max: 850000 }, senior: { min: 850000, max: 1600000 }, lead: { min: 1400000, max: 2500000 }, executive: { min: 2200000, max: 4500000 } },
    hospitality: { entry: { min: 180000, max: 300000 }, mid: { min: 300000, max: 550000 }, senior: { min: 550000, max: 1000000 }, lead: { min: 900000, max: 1600000 }, executive: { min: 1400000, max: 2800000 } },
    retail: { entry: { min: 180000, max: 300000 }, mid: { min: 300000, max: 550000 }, senior: { min: 550000, max: 1000000 }, lead: { min: 900000, max: 1500000 }, executive: { min: 1300000, max: 2600000 } },
    government: { entry: { min: 300000, max: 500000 }, mid: { min: 500000, max: 850000 }, senior: { min: 850000, max: 1400000 }, lead: { min: 1200000, max: 2000000 }, executive: { min: 1800000, max: 3500000 } },
    creative: { entry: { min: 200000, max: 400000 }, mid: { min: 400000, max: 800000 }, senior: { min: 800000, max: 1500000 }, lead: { min: 1300000, max: 2300000 }, executive: { min: 2000000, max: 4000000 } },
  },
  br: {
    technology: { entry: { min: 48000, max: 72000 }, mid: { min: 84000, max: 132000 }, senior: { min: 144000, max: 216000 }, lead: { min: 204000, max: 300000 }, executive: { min: 288000, max: 480000 } },
    healthcare: { entry: { min: 36000, max: 60000 }, mid: { min: 66000, max: 108000 }, senior: { min: 108000, max: 180000 }, lead: { min: 168000, max: 252000 }, executive: { min: 240000, max: 408000 } },
    finance: { entry: { min: 48000, max: 78000 }, mid: { min: 84000, max: 138000 }, senior: { min: 144000, max: 228000 }, lead: { min: 216000, max: 336000 }, executive: { min: 312000, max: 540000 } },
    engineering: { entry: { min: 48000, max: 72000 }, mid: { min: 78000, max: 120000 }, senior: { min: 120000, max: 192000 }, lead: { min: 180000, max: 270000 }, executive: { min: 252000, max: 420000 } },
    education: { entry: { min: 24000, max: 42000 }, mid: { min: 42000, max: 66000 }, senior: { min: 66000, max: 102000 }, lead: { min: 96000, max: 144000 }, executive: { min: 132000, max: 216000 } },
    marketing: { entry: { min: 30000, max: 48000 }, mid: { min: 54000, max: 84000 }, senior: { min: 84000, max: 138000 }, lead: { min: 126000, max: 198000 }, executive: { min: 180000, max: 312000 } },
    legal: { entry: { min: 42000, max: 72000 }, mid: { min: 78000, max: 132000 }, senior: { min: 132000, max: 216000 }, lead: { min: 204000, max: 324000 }, executive: { min: 300000, max: 516000 } },
    manufacturing: { entry: { min: 30000, max: 48000 }, mid: { min: 48000, max: 78000 }, senior: { min: 78000, max: 126000 }, lead: { min: 120000, max: 180000 }, executive: { min: 168000, max: 288000 } },
    hospitality: { entry: { min: 18000, max: 30000 }, mid: { min: 30000, max: 48000 }, senior: { min: 48000, max: 78000 }, lead: { min: 72000, max: 114000 }, executive: { min: 102000, max: 180000 } },
    retail: { entry: { min: 18000, max: 30000 }, mid: { min: 30000, max: 48000 }, senior: { min: 48000, max: 78000 }, lead: { min: 72000, max: 108000 }, executive: { min: 96000, max: 168000 } },
    government: { entry: { min: 36000, max: 54000 }, mid: { min: 54000, max: 84000 }, senior: { min: 84000, max: 126000 }, lead: { min: 120000, max: 174000 }, executive: { min: 162000, max: 264000 } },
    creative: { entry: { min: 24000, max: 42000 }, mid: { min: 42000, max: 72000 }, senior: { min: 72000, max: 120000 }, lead: { min: 108000, max: 168000 }, executive: { min: 156000, max: 270000 } },
  },
  za: {
    technology: { entry: { min: 250000, max: 400000 }, mid: { min: 450000, max: 700000 }, senior: { min: 750000, max: 1100000 }, lead: { min: 1000000, max: 1500000 }, executive: { min: 1400000, max: 2400000 } },
    healthcare: { entry: { min: 200000, max: 350000 }, mid: { min: 380000, max: 600000 }, senior: { min: 600000, max: 950000 }, lead: { min: 850000, max: 1300000 }, executive: { min: 1200000, max: 2000000 } },
    finance: { entry: { min: 280000, max: 420000 }, mid: { min: 480000, max: 750000 }, senior: { min: 780000, max: 1200000 }, lead: { min: 1100000, max: 1700000 }, executive: { min: 1600000, max: 2800000 } },
    engineering: { entry: { min: 250000, max: 380000 }, mid: { min: 420000, max: 650000 }, senior: { min: 680000, max: 1050000 }, lead: { min: 950000, max: 1400000 }, executive: { min: 1300000, max: 2200000 } },
    education: { entry: { min: 160000, max: 260000 }, mid: { min: 280000, max: 420000 }, senior: { min: 420000, max: 620000 }, lead: { min: 580000, max: 850000 }, executive: { min: 800000, max: 1300000 } },
    marketing: { entry: { min: 180000, max: 300000 }, mid: { min: 320000, max: 520000 }, senior: { min: 540000, max: 820000 }, lead: { min: 780000, max: 1150000 }, executive: { min: 1050000, max: 1800000 } },
    legal: { entry: { min: 280000, max: 420000 }, mid: { min: 460000, max: 750000 }, senior: { min: 780000, max: 1250000 }, lead: { min: 1100000, max: 1800000 }, executive: { min: 1600000, max: 2900000 } },
    manufacturing: { entry: { min: 160000, max: 260000 }, mid: { min: 280000, max: 440000 }, senior: { min: 460000, max: 700000 }, lead: { min: 650000, max: 1000000 }, executive: { min: 920000, max: 1600000 } },
    hospitality: { entry: { min: 100000, max: 180000 }, mid: { min: 190000, max: 300000 }, senior: { min: 320000, max: 500000 }, lead: { min: 460000, max: 720000 }, executive: { min: 660000, max: 1150000 } },
    retail: { entry: { min: 100000, max: 170000 }, mid: { min: 180000, max: 290000 }, senior: { min: 300000, max: 480000 }, lead: { min: 440000, max: 680000 }, executive: { min: 620000, max: 1080000 } },
    government: { entry: { min: 200000, max: 320000 }, mid: { min: 340000, max: 520000 }, senior: { min: 540000, max: 780000 }, lead: { min: 720000, max: 1050000 }, executive: { min: 960000, max: 1550000 } },
    creative: { entry: { min: 140000, max: 240000 }, mid: { min: 260000, max: 440000 }, senior: { min: 460000, max: 720000 }, lead: { min: 660000, max: 1000000 }, executive: { min: 920000, max: 1600000 } },
  },
  ae: {
    technology: { entry: { min: 120000, max: 180000 }, mid: { min: 200000, max: 320000 }, senior: { min: 340000, max: 500000 }, lead: { min: 480000, max: 680000 }, executive: { min: 650000, max: 1100000 } },
    healthcare: { entry: { min: 100000, max: 160000 }, mid: { min: 170000, max: 280000 }, senior: { min: 290000, max: 440000 }, lead: { min: 420000, max: 600000 }, executive: { min: 570000, max: 960000 } },
    finance: { entry: { min: 140000, max: 200000 }, mid: { min: 220000, max: 360000 }, senior: { min: 380000, max: 560000 }, lead: { min: 540000, max: 780000 }, executive: { min: 750000, max: 1300000 } },
    engineering: { entry: { min: 110000, max: 170000 }, mid: { min: 180000, max: 290000 }, senior: { min: 300000, max: 460000 }, lead: { min: 440000, max: 640000 }, executive: { min: 600000, max: 1000000 } },
    education: { entry: { min: 80000, max: 130000 }, mid: { min: 140000, max: 210000 }, senior: { min: 220000, max: 320000 }, lead: { min: 300000, max: 440000 }, executive: { min: 400000, max: 650000 } },
    marketing: { entry: { min: 90000, max: 140000 }, mid: { min: 150000, max: 240000 }, senior: { min: 250000, max: 380000 }, lead: { min: 360000, max: 520000 }, executive: { min: 500000, max: 850000 } },
    legal: { entry: { min: 130000, max: 200000 }, mid: { min: 210000, max: 350000 }, senior: { min: 370000, max: 560000 }, lead: { min: 540000, max: 780000 }, executive: { min: 720000, max: 1250000 } },
    manufacturing: { entry: { min: 80000, max: 130000 }, mid: { min: 140000, max: 220000 }, senior: { min: 230000, max: 360000 }, lead: { min: 340000, max: 500000 }, executive: { min: 480000, max: 800000 } },
    hospitality: { entry: { min: 60000, max: 100000 }, mid: { min: 110000, max: 170000 }, senior: { min: 180000, max: 280000 }, lead: { min: 260000, max: 400000 }, executive: { min: 380000, max: 650000 } },
    retail: { entry: { min: 55000, max: 90000 }, mid: { min: 100000, max: 160000 }, senior: { min: 170000, max: 260000 }, lead: { min: 240000, max: 370000 }, executive: { min: 350000, max: 600000 } },
    government: { entry: { min: 100000, max: 160000 }, mid: { min: 170000, max: 260000 }, senior: { min: 270000, max: 400000 }, lead: { min: 380000, max: 540000 }, executive: { min: 510000, max: 800000 } },
    creative: { entry: { min: 80000, max: 130000 }, mid: { min: 140000, max: 230000 }, senior: { min: 240000, max: 370000 }, lead: { min: 350000, max: 510000 }, executive: { min: 480000, max: 820000 } },
  },
  pl: {
    technology: { entry: { min: 60000, max: 96000 }, mid: { min: 108000, max: 168000 }, senior: { min: 180000, max: 276000 }, lead: { min: 264000, max: 384000 }, executive: { min: 360000, max: 600000 } },
    healthcare: { entry: { min: 42000, max: 66000 }, mid: { min: 72000, max: 108000 }, senior: { min: 114000, max: 180000 }, lead: { min: 168000, max: 252000 }, executive: { min: 240000, max: 400000 } },
    finance: { entry: { min: 60000, max: 90000 }, mid: { min: 96000, max: 156000 }, senior: { min: 168000, max: 264000 }, lead: { min: 252000, max: 372000 }, executive: { min: 348000, max: 588000 } },
    engineering: { entry: { min: 54000, max: 84000 }, mid: { min: 90000, max: 144000 }, senior: { min: 150000, max: 240000 }, lead: { min: 228000, max: 336000 }, executive: { min: 312000, max: 528000 } },
    education: { entry: { min: 36000, max: 54000 }, mid: { min: 54000, max: 78000 }, senior: { min: 78000, max: 114000 }, lead: { min: 108000, max: 156000 }, executive: { min: 144000, max: 240000 } },
    marketing: { entry: { min: 42000, max: 66000 }, mid: { min: 72000, max: 108000 }, senior: { min: 114000, max: 174000 }, lead: { min: 162000, max: 240000 }, executive: { min: 228000, max: 384000 } },
    legal: { entry: { min: 54000, max: 84000 }, mid: { min: 90000, max: 144000 }, senior: { min: 150000, max: 252000 }, lead: { min: 240000, max: 372000 }, executive: { min: 348000, max: 588000 } },
    manufacturing: { entry: { min: 42000, max: 60000 }, mid: { min: 66000, max: 96000 }, senior: { min: 102000, max: 156000 }, lead: { min: 144000, max: 216000 }, executive: { min: 204000, max: 348000 } },
    hospitality: { entry: { min: 30000, max: 42000 }, mid: { min: 42000, max: 60000 }, senior: { min: 60000, max: 90000 }, lead: { min: 84000, max: 126000 }, executive: { min: 114000, max: 198000 } },
    retail: { entry: { min: 28000, max: 42000 }, mid: { min: 42000, max: 60000 }, senior: { min: 60000, max: 90000 }, lead: { min: 84000, max: 120000 }, executive: { min: 108000, max: 186000 } },
    government: { entry: { min: 42000, max: 60000 }, mid: { min: 60000, max: 90000 }, senior: { min: 90000, max: 132000 }, lead: { min: 126000, max: 180000 }, executive: { min: 168000, max: 276000 } },
    creative: { entry: { min: 36000, max: 54000 }, mid: { min: 60000, max: 90000 }, senior: { min: 96000, max: 150000 }, lead: { min: 138000, max: 210000 }, executive: { min: 198000, max: 336000 } },
  },
  it: {
    technology: { entry: { min: 28000, max: 36000 }, mid: { min: 38000, max: 52000 }, senior: { min: 52000, max: 75000 }, lead: { min: 70000, max: 100000 }, executive: { min: 95000, max: 160000 } },
    healthcare: { entry: { min: 25000, max: 34000 }, mid: { min: 36000, max: 50000 }, senior: { min: 50000, max: 72000 }, lead: { min: 68000, max: 95000 }, executive: { min: 90000, max: 150000 } },
    finance: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 60000 }, senior: { min: 60000, max: 90000 }, lead: { min: 85000, max: 130000 }, executive: { min: 120000, max: 220000 } },
    engineering: { entry: { min: 27000, max: 35000 }, mid: { min: 37000, max: 50000 }, senior: { min: 50000, max: 72000 }, lead: { min: 68000, max: 98000 }, executive: { min: 92000, max: 155000 } },
    education: { entry: { min: 22000, max: 28000 }, mid: { min: 28000, max: 38000 }, senior: { min: 38000, max: 52000 }, lead: { min: 48000, max: 68000 }, executive: { min: 62000, max: 98000 } },
    marketing: { entry: { min: 24000, max: 32000 }, mid: { min: 34000, max: 48000 }, senior: { min: 48000, max: 68000 }, lead: { min: 64000, max: 92000 }, executive: { min: 85000, max: 145000 } },
    legal: { entry: { min: 28000, max: 38000 }, mid: { min: 40000, max: 58000 }, senior: { min: 58000, max: 88000 }, lead: { min: 82000, max: 128000 }, executive: { min: 115000, max: 215000 } },
    manufacturing: { entry: { min: 24000, max: 30000 }, mid: { min: 32000, max: 42000 }, senior: { min: 42000, max: 60000 }, lead: { min: 56000, max: 82000 }, executive: { min: 78000, max: 130000 } },
    hospitality: { entry: { min: 18000, max: 24000 }, mid: { min: 24000, max: 34000 }, senior: { min: 34000, max: 48000 }, lead: { min: 44000, max: 65000 }, executive: { min: 60000, max: 105000 } },
    retail: { entry: { min: 18000, max: 24000 }, mid: { min: 24000, max: 32000 }, senior: { min: 32000, max: 46000 }, lead: { min: 42000, max: 62000 }, executive: { min: 58000, max: 100000 } },
    government: { entry: { min: 24000, max: 32000 }, mid: { min: 32000, max: 45000 }, senior: { min: 45000, max: 62000 }, lead: { min: 58000, max: 82000 }, executive: { min: 78000, max: 125000 } },
    creative: { entry: { min: 20000, max: 28000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 62000 }, lead: { min: 58000, max: 85000 }, executive: { min: 80000, max: 140000 } },
  },
  es: {
    technology: { entry: { min: 24000, max: 32000 }, mid: { min: 34000, max: 48000 }, senior: { min: 48000, max: 68000 }, lead: { min: 65000, max: 92000 }, executive: { min: 85000, max: 145000 } },
    healthcare: { entry: { min: 22000, max: 30000 }, mid: { min: 32000, max: 45000 }, senior: { min: 45000, max: 65000 }, lead: { min: 60000, max: 88000 }, executive: { min: 82000, max: 135000 } },
    finance: { entry: { min: 26000, max: 36000 }, mid: { min: 38000, max: 55000 }, senior: { min: 55000, max: 82000 }, lead: { min: 78000, max: 118000 }, executive: { min: 108000, max: 200000 } },
    engineering: { entry: { min: 24000, max: 32000 }, mid: { min: 34000, max: 46000 }, senior: { min: 46000, max: 66000 }, lead: { min: 62000, max: 90000 }, executive: { min: 85000, max: 142000 } },
    education: { entry: { min: 20000, max: 26000 }, mid: { min: 26000, max: 35000 }, senior: { min: 35000, max: 48000 }, lead: { min: 44000, max: 62000 }, executive: { min: 58000, max: 92000 } },
    marketing: { entry: { min: 22000, max: 28000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 60000 }, lead: { min: 56000, max: 82000 }, executive: { min: 75000, max: 130000 } },
    legal: { entry: { min: 24000, max: 34000 }, mid: { min: 36000, max: 52000 }, senior: { min: 52000, max: 78000 }, lead: { min: 72000, max: 115000 }, executive: { min: 105000, max: 195000 } },
    manufacturing: { entry: { min: 20000, max: 26000 }, mid: { min: 28000, max: 38000 }, senior: { min: 38000, max: 55000 }, lead: { min: 52000, max: 75000 }, executive: { min: 70000, max: 120000 } },
    hospitality: { entry: { min: 16000, max: 22000 }, mid: { min: 22000, max: 30000 }, senior: { min: 30000, max: 44000 }, lead: { min: 40000, max: 60000 }, executive: { min: 55000, max: 95000 } },
    retail: { entry: { min: 16000, max: 22000 }, mid: { min: 22000, max: 30000 }, senior: { min: 30000, max: 42000 }, lead: { min: 38000, max: 56000 }, executive: { min: 52000, max: 88000 } },
    government: { entry: { min: 22000, max: 28000 }, mid: { min: 28000, max: 40000 }, senior: { min: 40000, max: 56000 }, lead: { min: 52000, max: 75000 }, executive: { min: 70000, max: 112000 } },
    creative: { entry: { min: 18000, max: 26000 }, mid: { min: 28000, max: 40000 }, senior: { min: 40000, max: 58000 }, lead: { min: 54000, max: 78000 }, executive: { min: 72000, max: 125000 } },
  },
  se: {
    technology: { entry: { min: 360000, max: 480000 }, mid: { min: 520000, max: 700000 }, senior: { min: 720000, max: 960000 }, lead: { min: 920000, max: 1200000 }, executive: { min: 1150000, max: 1800000 } },
    healthcare: { entry: { min: 320000, max: 420000 }, mid: { min: 440000, max: 600000 }, senior: { min: 620000, max: 840000 }, lead: { min: 800000, max: 1060000 }, executive: { min: 1000000, max: 1600000 } },
    finance: { entry: { min: 380000, max: 500000 }, mid: { min: 540000, max: 740000 }, senior: { min: 760000, max: 1040000 }, lead: { min: 1000000, max: 1360000 }, executive: { min: 1300000, max: 2100000 } },
    engineering: { entry: { min: 360000, max: 468000 }, mid: { min: 500000, max: 672000 }, senior: { min: 690000, max: 924000 }, lead: { min: 888000, max: 1164000 }, executive: { min: 1110000, max: 1740000 } },
    education: { entry: { min: 300000, max: 380000 }, mid: { min: 390000, max: 500000 }, senior: { min: 510000, max: 660000 }, lead: { min: 640000, max: 840000 }, executive: { min: 800000, max: 1200000 } },
    marketing: { entry: { min: 300000, max: 400000 }, mid: { min: 420000, max: 580000 }, senior: { min: 600000, max: 820000 }, lead: { min: 780000, max: 1060000 }, executive: { min: 1000000, max: 1650000 } },
    legal: { entry: { min: 360000, max: 480000 }, mid: { min: 500000, max: 700000 }, senior: { min: 720000, max: 1000000 }, lead: { min: 960000, max: 1340000 }, executive: { min: 1280000, max: 2100000 } },
    manufacturing: { entry: { min: 300000, max: 384000 }, mid: { min: 400000, max: 540000 }, senior: { min: 560000, max: 756000 }, lead: { min: 720000, max: 984000 }, executive: { min: 940000, max: 1500000 } },
    hospitality: { entry: { min: 240000, max: 312000 }, mid: { min: 320000, max: 432000 }, senior: { min: 450000, max: 612000 }, lead: { min: 588000, max: 804000 }, executive: { min: 768000, max: 1250000 } },
    retail: { entry: { min: 240000, max: 312000 }, mid: { min: 316000, max: 420000 }, senior: { min: 432000, max: 588000 }, lead: { min: 564000, max: 768000 }, executive: { min: 732000, max: 1200000 } },
    government: { entry: { min: 312000, max: 408000 }, mid: { min: 420000, max: 564000 }, senior: { min: 576000, max: 768000 }, lead: { min: 744000, max: 996000 }, executive: { min: 948000, max: 1450000 } },
    creative: { entry: { min: 276000, max: 372000 }, mid: { min: 390000, max: 540000 }, senior: { min: 552000, max: 756000 }, lead: { min: 720000, max: 996000 }, executive: { min: 948000, max: 1560000 } },
  },
  no: {
    technology: { entry: { min: 480000, max: 620000 }, mid: { min: 660000, max: 880000 }, senior: { min: 900000, max: 1200000 }, lead: { min: 1150000, max: 1500000 }, executive: { min: 1450000, max: 2200000 } },
    healthcare: { entry: { min: 420000, max: 550000 }, mid: { min: 580000, max: 760000 }, senior: { min: 780000, max: 1050000 }, lead: { min: 1000000, max: 1320000 }, executive: { min: 1260000, max: 2000000 } },
    finance: { entry: { min: 500000, max: 650000 }, mid: { min: 700000, max: 940000 }, senior: { min: 960000, max: 1300000 }, lead: { min: 1250000, max: 1700000 }, executive: { min: 1650000, max: 2600000 } },
    engineering: { entry: { min: 470000, max: 610000 }, mid: { min: 640000, max: 860000 }, senior: { min: 880000, max: 1180000 }, lead: { min: 1120000, max: 1480000 }, executive: { min: 1400000, max: 2150000 } },
    education: { entry: { min: 400000, max: 500000 }, mid: { min: 510000, max: 660000 }, senior: { min: 670000, max: 860000 }, lead: { min: 830000, max: 1080000 }, executive: { min: 1030000, max: 1550000 } },
    marketing: { entry: { min: 400000, max: 520000 }, mid: { min: 540000, max: 740000 }, senior: { min: 760000, max: 1020000 }, lead: { min: 980000, max: 1320000 }, executive: { min: 1260000, max: 2050000 } },
    legal: { entry: { min: 480000, max: 630000 }, mid: { min: 660000, max: 900000 }, senior: { min: 920000, max: 1260000 }, lead: { min: 1200000, max: 1680000 }, executive: { min: 1620000, max: 2600000 } },
    manufacturing: { entry: { min: 390000, max: 500000 }, mid: { min: 520000, max: 700000 }, senior: { min: 720000, max: 980000 }, lead: { min: 940000, max: 1280000 }, executive: { min: 1220000, max: 1950000 } },
    hospitality: { entry: { min: 320000, max: 410000 }, mid: { min: 420000, max: 560000 }, senior: { min: 580000, max: 790000 }, lead: { min: 760000, max: 1040000 }, executive: { min: 1000000, max: 1600000 } },
    retail: { entry: { min: 310000, max: 400000 }, mid: { min: 410000, max: 540000 }, senior: { min: 560000, max: 760000 }, lead: { min: 730000, max: 1000000 }, executive: { min: 960000, max: 1540000 } },
    government: { entry: { min: 420000, max: 540000 }, mid: { min: 560000, max: 740000 }, senior: { min: 760000, max: 1000000 }, lead: { min: 960000, max: 1280000 }, executive: { min: 1220000, max: 1850000 } },
    creative: { entry: { min: 360000, max: 480000 }, mid: { min: 500000, max: 690000 }, senior: { min: 710000, max: 970000 }, lead: { min: 930000, max: 1280000 }, executive: { min: 1220000, max: 2000000 } },
  },
  dk: {
    technology: { entry: { min: 360000, max: 468000 }, mid: { min: 500000, max: 672000 }, senior: { min: 690000, max: 924000 }, lead: { min: 888000, max: 1164000 }, executive: { min: 1110000, max: 1740000 } },
    healthcare: { entry: { min: 320000, max: 420000 }, mid: { min: 440000, max: 588000 }, senior: { min: 600000, max: 816000 }, lead: { min: 780000, max: 1032000 }, executive: { min: 984000, max: 1560000 } },
    finance: { entry: { min: 384000, max: 504000 }, mid: { min: 540000, max: 720000 }, senior: { min: 740000, max: 1008000 }, lead: { min: 972000, max: 1320000 }, executive: { min: 1260000, max: 2040000 } },
    engineering: { entry: { min: 350000, max: 456000 }, mid: { min: 480000, max: 648000 }, senior: { min: 660000, max: 888000 }, lead: { min: 852000, max: 1128000 }, executive: { min: 1080000, max: 1680000 } },
    education: { entry: { min: 312000, max: 396000 }, mid: { min: 408000, max: 528000 }, senior: { min: 540000, max: 696000 }, lead: { min: 672000, max: 876000 }, executive: { min: 840000, max: 1260000 } },
    marketing: { entry: { min: 300000, max: 396000 }, mid: { min: 420000, max: 576000 }, senior: { min: 588000, max: 804000 }, lead: { min: 768000, max: 1044000 }, executive: { min: 996000, max: 1620000 } },
    legal: { entry: { min: 360000, max: 480000 }, mid: { min: 504000, max: 696000 }, senior: { min: 720000, max: 984000 }, lead: { min: 948000, max: 1320000 }, executive: { min: 1260000, max: 2040000 } },
    manufacturing: { entry: { min: 300000, max: 384000 }, mid: { min: 396000, max: 540000 }, senior: { min: 552000, max: 744000 }, lead: { min: 720000, max: 972000 }, executive: { min: 936000, max: 1500000 } },
    hospitality: { entry: { min: 252000, max: 324000 }, mid: { min: 336000, max: 450000 }, senior: { min: 462000, max: 636000 }, lead: { min: 612000, max: 840000 }, executive: { min: 804000, max: 1296000 } },
    retail: { entry: { min: 244000, max: 312000 }, mid: { min: 324000, max: 432000 }, senior: { min: 444000, max: 612000 }, lead: { min: 588000, max: 804000 }, executive: { min: 768000, max: 1248000 } },
    government: { entry: { min: 324000, max: 420000 }, mid: { min: 432000, max: 576000 }, senior: { min: 588000, max: 780000 }, lead: { min: 756000, max: 1008000 }, executive: { min: 972000, max: 1500000 } },
    creative: { entry: { min: 288000, max: 384000 }, mid: { min: 396000, max: 552000 }, senior: { min: 564000, max: 768000 }, lead: { min: 744000, max: 1020000 }, executive: { min: 972000, max: 1596000 } },
  },
  ie: {
    technology: { entry: { min: 35000, max: 48000 }, mid: { min: 52000, max: 72000 }, senior: { min: 75000, max: 105000 }, lead: { min: 100000, max: 140000 }, executive: { min: 130000, max: 210000 } },
    healthcare: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 60000 }, senior: { min: 60000, max: 88000 }, lead: { min: 82000, max: 118000 }, executive: { min: 110000, max: 185000 } },
    finance: { entry: { min: 38000, max: 52000 }, mid: { min: 55000, max: 80000 }, senior: { min: 82000, max: 120000 }, lead: { min: 115000, max: 165000 }, executive: { min: 155000, max: 280000 } },
    engineering: { entry: { min: 34000, max: 46000 }, mid: { min: 48000, max: 68000 }, senior: { min: 68000, max: 98000 }, lead: { min: 92000, max: 132000 }, executive: { min: 125000, max: 200000 } },
    education: { entry: { min: 30000, max: 38000 }, mid: { min: 38000, max: 52000 }, senior: { min: 52000, max: 68000 }, lead: { min: 65000, max: 88000 }, executive: { min: 82000, max: 130000 } },
    marketing: { entry: { min: 28000, max: 38000 }, mid: { min: 40000, max: 58000 }, senior: { min: 58000, max: 82000 }, lead: { min: 78000, max: 110000 }, executive: { min: 102000, max: 170000 } },
    legal: { entry: { min: 35000, max: 48000 }, mid: { min: 52000, max: 75000 }, senior: { min: 78000, max: 118000 }, lead: { min: 110000, max: 165000 }, executive: { min: 152000, max: 280000 } },
    manufacturing: { entry: { min: 28000, max: 38000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 78000 }, lead: { min: 72000, max: 105000 }, executive: { min: 98000, max: 165000 } },
    hospitality: { entry: { min: 24000, max: 30000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 58000 }, lead: { min: 54000, max: 78000 }, executive: { min: 72000, max: 125000 } },
    retail: { entry: { min: 22000, max: 28000 }, mid: { min: 28000, max: 40000 }, senior: { min: 40000, max: 56000 }, lead: { min: 52000, max: 74000 }, executive: { min: 68000, max: 118000 } },
    government: { entry: { min: 30000, max: 40000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 75000 }, lead: { min: 72000, max: 98000 }, executive: { min: 92000, max: 145000 } },
    creative: { entry: { min: 26000, max: 36000 }, mid: { min: 38000, max: 54000 }, senior: { min: 54000, max: 78000 }, lead: { min: 72000, max: 105000 }, executive: { min: 98000, max: 168000 } },
  },
  be: {
    technology: { entry: { min: 36000, max: 48000 }, mid: { min: 50000, max: 68000 }, senior: { min: 68000, max: 92000 }, lead: { min: 88000, max: 120000 }, executive: { min: 115000, max: 185000 } },
    healthcare: { entry: { min: 32000, max: 42000 }, mid: { min: 44000, max: 60000 }, senior: { min: 60000, max: 82000 }, lead: { min: 78000, max: 108000 }, executive: { min: 102000, max: 168000 } },
    finance: { entry: { min: 38000, max: 50000 }, mid: { min: 54000, max: 74000 }, senior: { min: 74000, max: 105000 }, lead: { min: 100000, max: 145000 }, executive: { min: 135000, max: 250000 } },
    engineering: { entry: { min: 35000, max: 46000 }, mid: { min: 48000, max: 66000 }, senior: { min: 66000, max: 90000 }, lead: { min: 85000, max: 118000 }, executive: { min: 112000, max: 182000 } },
    education: { entry: { min: 30000, max: 38000 }, mid: { min: 38000, max: 50000 }, senior: { min: 50000, max: 66000 }, lead: { min: 62000, max: 84000 }, executive: { min: 78000, max: 122000 } },
    marketing: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 80000 }, lead: { min: 76000, max: 108000 }, executive: { min: 100000, max: 165000 } },
    legal: { entry: { min: 35000, max: 48000 }, mid: { min: 50000, max: 70000 }, senior: { min: 70000, max: 102000 }, lead: { min: 96000, max: 145000 }, executive: { min: 135000, max: 250000 } },
    manufacturing: { entry: { min: 28000, max: 38000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 76000 }, lead: { min: 72000, max: 102000 }, executive: { min: 96000, max: 160000 } },
    hospitality: { entry: { min: 24000, max: 30000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 58000 }, lead: { min: 54000, max: 76000 }, executive: { min: 70000, max: 118000 } },
    retail: { entry: { min: 22000, max: 28000 }, mid: { min: 28000, max: 40000 }, senior: { min: 40000, max: 56000 }, lead: { min: 52000, max: 72000 }, executive: { min: 66000, max: 112000 } },
    government: { entry: { min: 30000, max: 40000 }, mid: { min: 40000, max: 55000 }, senior: { min: 55000, max: 74000 }, lead: { min: 70000, max: 96000 }, executive: { min: 90000, max: 140000 } },
    creative: { entry: { min: 26000, max: 36000 }, mid: { min: 38000, max: 54000 }, senior: { min: 54000, max: 76000 }, lead: { min: 72000, max: 102000 }, executive: { min: 96000, max: 162000 } },
  },
  at: {
    technology: { entry: { min: 38000, max: 50000 }, mid: { min: 52000, max: 72000 }, senior: { min: 72000, max: 98000 }, lead: { min: 92000, max: 128000 }, executive: { min: 120000, max: 195000 } },
    healthcare: { entry: { min: 34000, max: 44000 }, mid: { min: 46000, max: 62000 }, senior: { min: 62000, max: 88000 }, lead: { min: 82000, max: 115000 }, executive: { min: 108000, max: 175000 } },
    finance: { entry: { min: 40000, max: 52000 }, mid: { min: 56000, max: 76000 }, senior: { min: 76000, max: 110000 }, lead: { min: 105000, max: 152000 }, executive: { min: 140000, max: 260000 } },
    engineering: { entry: { min: 38000, max: 48000 }, mid: { min: 50000, max: 68000 }, senior: { min: 68000, max: 94000 }, lead: { min: 88000, max: 122000 }, executive: { min: 115000, max: 188000 } },
    education: { entry: { min: 32000, max: 40000 }, mid: { min: 40000, max: 52000 }, senior: { min: 52000, max: 70000 }, lead: { min: 66000, max: 88000 }, executive: { min: 82000, max: 128000 } },
    marketing: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 82000 }, lead: { min: 78000, max: 110000 }, executive: { min: 102000, max: 168000 } },
    legal: { entry: { min: 38000, max: 50000 }, mid: { min: 52000, max: 74000 }, senior: { min: 74000, max: 110000 }, lead: { min: 102000, max: 152000 }, executive: { min: 140000, max: 260000 } },
    manufacturing: { entry: { min: 30000, max: 40000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 80000 }, lead: { min: 76000, max: 108000 }, executive: { min: 102000, max: 168000 } },
    hospitality: { entry: { min: 24000, max: 30000 }, mid: { min: 30000, max: 42000 }, senior: { min: 42000, max: 58000 }, lead: { min: 54000, max: 78000 }, executive: { min: 72000, max: 122000 } },
    retail: { entry: { min: 22000, max: 28000 }, mid: { min: 28000, max: 40000 }, senior: { min: 40000, max: 56000 }, lead: { min: 52000, max: 74000 }, executive: { min: 68000, max: 115000 } },
    government: { entry: { min: 32000, max: 42000 }, mid: { min: 42000, max: 58000 }, senior: { min: 58000, max: 78000 }, lead: { min: 74000, max: 100000 }, executive: { min: 94000, max: 148000 } },
    creative: { entry: { min: 28000, max: 38000 }, mid: { min: 40000, max: 56000 }, senior: { min: 56000, max: 78000 }, lead: { min: 74000, max: 105000 }, executive: { min: 98000, max: 165000 } },
  },
  nz: {
    technology: { entry: { min: 55000, max: 72000 }, mid: { min: 78000, max: 105000 }, senior: { min: 108000, max: 148000 }, lead: { min: 140000, max: 190000 }, executive: { min: 180000, max: 290000 } },
    healthcare: { entry: { min: 48000, max: 62000 }, mid: { min: 65000, max: 88000 }, senior: { min: 90000, max: 130000 }, lead: { min: 120000, max: 168000 }, executive: { min: 155000, max: 260000 } },
    finance: { entry: { min: 52000, max: 70000 }, mid: { min: 75000, max: 102000 }, senior: { min: 105000, max: 148000 }, lead: { min: 140000, max: 195000 }, executive: { min: 185000, max: 330000 } },
    engineering: { entry: { min: 52000, max: 68000 }, mid: { min: 72000, max: 98000 }, senior: { min: 100000, max: 140000 }, lead: { min: 132000, max: 182000 }, executive: { min: 170000, max: 275000 } },
    education: { entry: { min: 48000, max: 58000 }, mid: { min: 58000, max: 75000 }, senior: { min: 75000, max: 98000 }, lead: { min: 92000, max: 122000 }, executive: { min: 115000, max: 175000 } },
    marketing: { entry: { min: 42000, max: 56000 }, mid: { min: 58000, max: 80000 }, senior: { min: 82000, max: 115000 }, lead: { min: 108000, max: 150000 }, executive: { min: 140000, max: 235000 } },
    legal: { entry: { min: 52000, max: 70000 }, mid: { min: 75000, max: 105000 }, senior: { min: 108000, max: 155000 }, lead: { min: 145000, max: 210000 }, executive: { min: 200000, max: 350000 } },
    manufacturing: { entry: { min: 42000, max: 55000 }, mid: { min: 58000, max: 78000 }, senior: { min: 78000, max: 108000 }, lead: { min: 102000, max: 142000 }, executive: { min: 135000, max: 220000 } },
    hospitality: { entry: { min: 38000, max: 48000 }, mid: { min: 48000, max: 62000 }, senior: { min: 62000, max: 85000 }, lead: { min: 80000, max: 112000 }, executive: { min: 105000, max: 178000 } },
    retail: { entry: { min: 36000, max: 46000 }, mid: { min: 46000, max: 60000 }, senior: { min: 60000, max: 82000 }, lead: { min: 78000, max: 108000 }, executive: { min: 100000, max: 168000 } },
    government: { entry: { min: 48000, max: 60000 }, mid: { min: 62000, max: 82000 }, senior: { min: 82000, max: 108000 }, lead: { min: 102000, max: 138000 }, executive: { min: 130000, max: 198000 } },
    creative: { entry: { min: 38000, max: 52000 }, mid: { min: 54000, max: 74000 }, senior: { min: 76000, max: 105000 }, lead: { min: 100000, max: 140000 }, executive: { min: 132000, max: 220000 } },
  },
  kr: {
    technology: { entry: { min: 35000000, max: 48000000 }, mid: { min: 52000000, max: 72000000 }, senior: { min: 75000000, max: 105000000 }, lead: { min: 100000000, max: 140000000 }, executive: { min: 130000000, max: 220000000 } },
    healthcare: { entry: { min: 30000000, max: 42000000 }, mid: { min: 45000000, max: 62000000 }, senior: { min: 65000000, max: 90000000 }, lead: { min: 85000000, max: 120000000 }, executive: { min: 110000000, max: 190000000 } },
    finance: { entry: { min: 38000000, max: 52000000 }, mid: { min: 55000000, max: 78000000 }, senior: { min: 80000000, max: 115000000 }, lead: { min: 110000000, max: 160000000 }, executive: { min: 150000000, max: 260000000 } },
    engineering: { entry: { min: 34000000, max: 46000000 }, mid: { min: 48000000, max: 68000000 }, senior: { min: 70000000, max: 98000000 }, lead: { min: 92000000, max: 132000000 }, executive: { min: 125000000, max: 210000000 } },
    education: { entry: { min: 28000000, max: 36000000 }, mid: { min: 38000000, max: 50000000 }, senior: { min: 52000000, max: 70000000 }, lead: { min: 66000000, max: 90000000 }, executive: { min: 85000000, max: 135000000 } },
    marketing: { entry: { min: 28000000, max: 40000000 }, mid: { min: 42000000, max: 60000000 }, senior: { min: 62000000, max: 88000000 }, lead: { min: 82000000, max: 118000000 }, executive: { min: 110000000, max: 190000000 } },
    legal: { entry: { min: 35000000, max: 48000000 }, mid: { min: 52000000, max: 75000000 }, senior: { min: 78000000, max: 112000000 }, lead: { min: 105000000, max: 155000000 }, executive: { min: 145000000, max: 250000000 } },
    manufacturing: { entry: { min: 28000000, max: 38000000 }, mid: { min: 40000000, max: 55000000 }, senior: { min: 58000000, max: 80000000 }, lead: { min: 76000000, max: 108000000 }, executive: { min: 100000000, max: 170000000 } },
    hospitality: { entry: { min: 22000000, max: 30000000 }, mid: { min: 32000000, max: 44000000 }, senior: { min: 46000000, max: 64000000 }, lead: { min: 60000000, max: 86000000 }, executive: { min: 80000000, max: 138000000 } },
    retail: { entry: { min: 22000000, max: 30000000 }, mid: { min: 30000000, max: 42000000 }, senior: { min: 44000000, max: 62000000 }, lead: { min: 58000000, max: 82000000 }, executive: { min: 76000000, max: 130000000 } },
    government: { entry: { min: 30000000, max: 40000000 }, mid: { min: 42000000, max: 56000000 }, senior: { min: 58000000, max: 78000000 }, lead: { min: 74000000, max: 100000000 }, executive: { min: 95000000, max: 150000000 } },
    creative: { entry: { min: 25000000, max: 35000000 }, mid: { min: 38000000, max: 54000000 }, senior: { min: 56000000, max: 80000000 }, lead: { min: 76000000, max: 108000000 }, executive: { min: 100000000, max: 175000000 } },
  },
  cn: {
    technology: { entry: { min: 120000, max: 200000 }, mid: { min: 220000, max: 380000 }, senior: { min: 400000, max: 650000 }, lead: { min: 600000, max: 950000 }, executive: { min: 900000, max: 1600000 } },
    healthcare: { entry: { min: 80000, max: 140000 }, mid: { min: 150000, max: 260000 }, senior: { min: 280000, max: 450000 }, lead: { min: 420000, max: 680000 }, executive: { min: 640000, max: 1100000 } },
    finance: { entry: { min: 130000, max: 220000 }, mid: { min: 240000, max: 400000 }, senior: { min: 420000, max: 700000 }, lead: { min: 660000, max: 1050000 }, executive: { min: 1000000, max: 1800000 } },
    engineering: { entry: { min: 100000, max: 180000 }, mid: { min: 200000, max: 340000 }, senior: { min: 360000, max: 580000 }, lead: { min: 540000, max: 860000 }, executive: { min: 800000, max: 1400000 } },
    education: { entry: { min: 60000, max: 100000 }, mid: { min: 110000, max: 180000 }, senior: { min: 190000, max: 300000 }, lead: { min: 280000, max: 440000 }, executive: { min: 400000, max: 700000 } },
    marketing: { entry: { min: 80000, max: 140000 }, mid: { min: 150000, max: 260000 }, senior: { min: 280000, max: 450000 }, lead: { min: 420000, max: 680000 }, executive: { min: 640000, max: 1100000 } },
    legal: { entry: { min: 100000, max: 180000 }, mid: { min: 200000, max: 360000 }, senior: { min: 380000, max: 640000 }, lead: { min: 600000, max: 980000 }, executive: { min: 920000, max: 1650000 } },
    manufacturing: { entry: { min: 72000, max: 120000 }, mid: { min: 130000, max: 220000 }, senior: { min: 240000, max: 380000 }, lead: { min: 360000, max: 560000 }, executive: { min: 520000, max: 900000 } },
    hospitality: { entry: { min: 48000, max: 84000 }, mid: { min: 90000, max: 150000 }, senior: { min: 160000, max: 260000 }, lead: { min: 240000, max: 400000 }, executive: { min: 380000, max: 660000 } },
    retail: { entry: { min: 48000, max: 80000 }, mid: { min: 85000, max: 145000 }, senior: { min: 150000, max: 250000 }, lead: { min: 230000, max: 380000 }, executive: { min: 360000, max: 620000 } },
    government: { entry: { min: 72000, max: 120000 }, mid: { min: 130000, max: 210000 }, senior: { min: 220000, max: 350000 }, lead: { min: 330000, max: 520000 }, executive: { min: 480000, max: 800000 } },
    creative: { entry: { min: 60000, max: 110000 }, mid: { min: 120000, max: 220000 }, senior: { min: 240000, max: 400000 }, lead: { min: 380000, max: 600000 }, executive: { min: 560000, max: 980000 } },
  },
  mx: {
    technology: { entry: { min: 180000, max: 300000 }, mid: { min: 320000, max: 520000 }, senior: { min: 540000, max: 840000 }, lead: { min: 800000, max: 1200000 }, executive: { min: 1100000, max: 1900000 } },
    healthcare: { entry: { min: 120000, max: 210000 }, mid: { min: 230000, max: 380000 }, senior: { min: 400000, max: 640000 }, lead: { min: 600000, max: 920000 }, executive: { min: 860000, max: 1450000 } },
    finance: { entry: { min: 180000, max: 300000 }, mid: { min: 320000, max: 540000 }, senior: { min: 560000, max: 880000 }, lead: { min: 840000, max: 1300000 }, executive: { min: 1200000, max: 2100000 } },
    engineering: { entry: { min: 160000, max: 270000 }, mid: { min: 290000, max: 470000 }, senior: { min: 490000, max: 770000 }, lead: { min: 730000, max: 1100000 }, executive: { min: 1000000, max: 1750000 } },
    education: { entry: { min: 84000, max: 150000 }, mid: { min: 160000, max: 260000 }, senior: { min: 270000, max: 420000 }, lead: { min: 400000, max: 600000 }, executive: { min: 560000, max: 920000 } },
    marketing: { entry: { min: 120000, max: 200000 }, mid: { min: 220000, max: 360000 }, senior: { min: 380000, max: 600000 }, lead: { min: 560000, max: 860000 }, executive: { min: 800000, max: 1380000 } },
    legal: { entry: { min: 160000, max: 280000 }, mid: { min: 300000, max: 500000 }, senior: { min: 520000, max: 840000 }, lead: { min: 800000, max: 1250000 }, executive: { min: 1150000, max: 2000000 } },
    manufacturing: { entry: { min: 108000, max: 180000 }, mid: { min: 192000, max: 310000 }, senior: { min: 320000, max: 510000 }, lead: { min: 480000, max: 740000 }, executive: { min: 700000, max: 1200000 } },
    hospitality: { entry: { min: 72000, max: 120000 }, mid: { min: 130000, max: 210000 }, senior: { min: 220000, max: 360000 }, lead: { min: 340000, max: 530000 }, executive: { min: 500000, max: 870000 } },
    retail: { entry: { min: 72000, max: 120000 }, mid: { min: 125000, max: 200000 }, senior: { min: 210000, max: 340000 }, lead: { min: 320000, max: 500000 }, executive: { min: 470000, max: 810000 } },
    government: { entry: { min: 108000, max: 180000 }, mid: { min: 190000, max: 300000 }, senior: { min: 310000, max: 480000 }, lead: { min: 460000, max: 690000 }, executive: { min: 650000, max: 1050000 } },
    creative: { entry: { min: 96000, max: 168000 }, mid: { min: 180000, max: 300000 }, senior: { min: 320000, max: 510000 }, lead: { min: 480000, max: 740000 }, executive: { min: 700000, max: 1200000 } },
  },
  tr: {
    technology: { entry: { min: 350000, max: 550000 }, mid: { min: 600000, max: 950000 }, senior: { min: 1000000, max: 1600000 }, lead: { min: 1500000, max: 2300000 }, executive: { min: 2100000, max: 3600000 } },
    healthcare: { entry: { min: 250000, max: 400000 }, mid: { min: 430000, max: 700000 }, senior: { min: 730000, max: 1200000 }, lead: { min: 1100000, max: 1700000 }, executive: { min: 1550000, max: 2700000 } },
    finance: { entry: { min: 380000, max: 580000 }, mid: { min: 620000, max: 1000000 }, senior: { min: 1050000, max: 1700000 }, lead: { min: 1600000, max: 2500000 }, executive: { min: 2300000, max: 4000000 } },
    engineering: { entry: { min: 320000, max: 500000 }, mid: { min: 530000, max: 850000 }, senior: { min: 880000, max: 1400000 }, lead: { min: 1300000, max: 2000000 }, executive: { min: 1850000, max: 3200000 } },
    education: { entry: { min: 180000, max: 300000 }, mid: { min: 320000, max: 500000 }, senior: { min: 520000, max: 800000 }, lead: { min: 750000, max: 1100000 }, executive: { min: 1000000, max: 1700000 } },
    marketing: { entry: { min: 240000, max: 380000 }, mid: { min: 400000, max: 650000 }, senior: { min: 680000, max: 1100000 }, lead: { min: 1000000, max: 1550000 }, executive: { min: 1400000, max: 2450000 } },
    legal: { entry: { min: 320000, max: 520000 }, mid: { min: 550000, max: 900000 }, senior: { min: 940000, max: 1550000 }, lead: { min: 1450000, max: 2300000 }, executive: { min: 2100000, max: 3700000 } },
    manufacturing: { entry: { min: 220000, max: 350000 }, mid: { min: 370000, max: 580000 }, senior: { min: 600000, max: 960000 }, lead: { min: 900000, max: 1380000 }, executive: { min: 1300000, max: 2200000 } },
    hospitality: { entry: { min: 150000, max: 240000 }, mid: { min: 260000, max: 400000 }, senior: { min: 420000, max: 680000 }, lead: { min: 640000, max: 1000000 }, executive: { min: 940000, max: 1600000 } },
    retail: { entry: { min: 145000, max: 230000 }, mid: { min: 250000, max: 380000 }, senior: { min: 400000, max: 640000 }, lead: { min: 600000, max: 940000 }, executive: { min: 880000, max: 1500000 } },
    government: { entry: { min: 220000, max: 360000 }, mid: { min: 380000, max: 580000 }, senior: { min: 600000, max: 900000 }, lead: { min: 850000, max: 1250000 }, executive: { min: 1150000, max: 1900000 } },
    creative: { entry: { min: 200000, max: 330000 }, mid: { min: 350000, max: 570000 }, senior: { min: 600000, max: 960000 }, lead: { min: 900000, max: 1400000 }, executive: { min: 1300000, max: 2250000 } },
  },
  ng: {
    technology: { entry: { min: 3000000, max: 5500000 }, mid: { min: 6000000, max: 10000000 }, senior: { min: 11000000, max: 18000000 }, lead: { min: 16000000, max: 26000000 }, executive: { min: 24000000, max: 42000000 } },
    healthcare: { entry: { min: 2000000, max: 3800000 }, mid: { min: 4000000, max: 7000000 }, senior: { min: 7500000, max: 13000000 }, lead: { min: 12000000, max: 19000000 }, executive: { min: 17000000, max: 30000000 } },
    finance: { entry: { min: 3000000, max: 5500000 }, mid: { min: 6000000, max: 10000000 }, senior: { min: 11000000, max: 18000000 }, lead: { min: 17000000, max: 27000000 }, executive: { min: 25000000, max: 44000000 } },
    engineering: { entry: { min: 2500000, max: 4500000 }, mid: { min: 5000000, max: 8500000 }, senior: { min: 9000000, max: 15000000 }, lead: { min: 14000000, max: 22000000 }, executive: { min: 20000000, max: 35000000 } },
    education: { entry: { min: 1200000, max: 2200000 }, mid: { min: 2400000, max: 4000000 }, senior: { min: 4200000, max: 7000000 }, lead: { min: 6500000, max: 10000000 }, executive: { min: 9000000, max: 16000000 } },
    marketing: { entry: { min: 1800000, max: 3200000 }, mid: { min: 3500000, max: 6000000 }, senior: { min: 6500000, max: 11000000 }, lead: { min: 10000000, max: 16000000 }, executive: { min: 14000000, max: 25000000 } },
    legal: { entry: { min: 2500000, max: 4500000 }, mid: { min: 5000000, max: 8500000 }, senior: { min: 9000000, max: 16000000 }, lead: { min: 15000000, max: 24000000 }, executive: { min: 22000000, max: 40000000 } },
    manufacturing: { entry: { min: 1500000, max: 2800000 }, mid: { min: 3000000, max: 5200000 }, senior: { min: 5500000, max: 9000000 }, lead: { min: 8500000, max: 14000000 }, executive: { min: 13000000, max: 22000000 } },
    hospitality: { entry: { min: 900000, max: 1800000 }, mid: { min: 2000000, max: 3500000 }, senior: { min: 3800000, max: 6500000 }, lead: { min: 6000000, max: 10000000 }, executive: { min: 9000000, max: 16000000 } },
    retail: { entry: { min: 850000, max: 1700000 }, mid: { min: 1800000, max: 3200000 }, senior: { min: 3500000, max: 6000000 }, lead: { min: 5500000, max: 9000000 }, executive: { min: 8500000, max: 15000000 } },
    government: { entry: { min: 1500000, max: 2800000 }, mid: { min: 3000000, max: 5000000 }, senior: { min: 5200000, max: 8500000 }, lead: { min: 8000000, max: 12500000 }, executive: { min: 11500000, max: 19000000 } },
    creative: { entry: { min: 1200000, max: 2400000 }, mid: { min: 2600000, max: 4800000 }, senior: { min: 5000000, max: 8800000 }, lead: { min: 8200000, max: 13000000 }, executive: { min: 12000000, max: 21000000 } },
  },
  ke: {
    technology: { entry: { min: 480000, max: 900000 }, mid: { min: 960000, max: 1680000 }, senior: { min: 1800000, max: 3000000 }, lead: { min: 2700000, max: 4200000 }, executive: { min: 3900000, max: 6600000 } },
    healthcare: { entry: { min: 360000, max: 660000 }, mid: { min: 720000, max: 1260000 }, senior: { min: 1320000, max: 2200000 }, lead: { min: 2000000, max: 3200000 }, executive: { min: 2900000, max: 5000000 } },
    finance: { entry: { min: 480000, max: 840000 }, mid: { min: 900000, max: 1560000 }, senior: { min: 1680000, max: 2800000 }, lead: { min: 2600000, max: 4100000 }, executive: { min: 3800000, max: 6500000 } },
    engineering: { entry: { min: 420000, max: 780000 }, mid: { min: 840000, max: 1440000 }, senior: { min: 1500000, max: 2500000 }, lead: { min: 2300000, max: 3700000 }, executive: { min: 3400000, max: 5800000 } },
    education: { entry: { min: 240000, max: 420000 }, mid: { min: 450000, max: 720000 }, senior: { min: 750000, max: 1200000 }, lead: { min: 1100000, max: 1700000 }, executive: { min: 1550000, max: 2600000 } },
    marketing: { entry: { min: 300000, max: 540000 }, mid: { min: 600000, max: 1020000 }, senior: { min: 1080000, max: 1800000 }, lead: { min: 1680000, max: 2600000 }, executive: { min: 2400000, max: 4100000 } },
    legal: { entry: { min: 420000, max: 780000 }, mid: { min: 840000, max: 1440000 }, senior: { min: 1500000, max: 2600000 }, lead: { min: 2400000, max: 3900000 }, executive: { min: 3600000, max: 6200000 } },
    manufacturing: { entry: { min: 240000, max: 450000 }, mid: { min: 480000, max: 840000 }, senior: { min: 900000, max: 1500000 }, lead: { min: 1400000, max: 2200000 }, executive: { min: 2000000, max: 3500000 } },
    hospitality: { entry: { min: 180000, max: 330000 }, mid: { min: 360000, max: 600000 }, senior: { min: 640000, max: 1080000 }, lead: { min: 1000000, max: 1600000 }, executive: { min: 1450000, max: 2500000 } },
    retail: { entry: { min: 168000, max: 300000 }, mid: { min: 320000, max: 560000 }, senior: { min: 600000, max: 1000000 }, lead: { min: 940000, max: 1500000 }, executive: { min: 1380000, max: 2350000 } },
    government: { entry: { min: 300000, max: 540000 }, mid: { min: 570000, max: 900000 }, senior: { min: 960000, max: 1500000 }, lead: { min: 1400000, max: 2100000 }, executive: { min: 1950000, max: 3200000 } },
    creative: { entry: { min: 240000, max: 420000 }, mid: { min: 450000, max: 780000 }, senior: { min: 840000, max: 1400000 }, lead: { min: 1300000, max: 2100000 }, executive: { min: 1900000, max: 3300000 } },
  },
  pk: {
    technology: { entry: { min: 600000, max: 1200000 }, mid: { min: 1400000, max: 2600000 }, senior: { min: 2800000, max: 5000000 }, lead: { min: 4500000, max: 7500000 }, executive: { min: 7000000, max: 12000000 } },
    healthcare: { entry: { min: 400000, max: 800000 }, mid: { min: 900000, max: 1700000 }, senior: { min: 1800000, max: 3500000 }, lead: { min: 3200000, max: 5500000 }, executive: { min: 5000000, max: 9000000 } },
    finance: { entry: { min: 500000, max: 1000000 }, mid: { min: 1200000, max: 2200000 }, senior: { min: 2400000, max: 4200000 }, lead: { min: 3800000, max: 6500000 }, executive: { min: 6000000, max: 10500000 } },
    engineering: { entry: { min: 500000, max: 1000000 }, mid: { min: 1100000, max: 2000000 }, senior: { min: 2200000, max: 4000000 }, lead: { min: 3600000, max: 6000000 }, executive: { min: 5500000, max: 9500000 } },
    education: { entry: { min: 300000, max: 550000 }, mid: { min: 600000, max: 1000000 }, senior: { min: 1100000, max: 1800000 }, lead: { min: 1600000, max: 2600000 }, executive: { min: 2400000, max: 4200000 } },
    marketing: { entry: { min: 350000, max: 700000 }, mid: { min: 800000, max: 1400000 }, senior: { min: 1500000, max: 2800000 }, lead: { min: 2500000, max: 4200000 }, executive: { min: 3800000, max: 6800000 } },
    legal: { entry: { min: 450000, max: 900000 }, mid: { min: 1000000, max: 2000000 }, senior: { min: 2200000, max: 4000000 }, lead: { min: 3600000, max: 6200000 }, executive: { min: 5800000, max: 10000000 } },
    manufacturing: { entry: { min: 350000, max: 650000 }, mid: { min: 700000, max: 1300000 }, senior: { min: 1400000, max: 2400000 }, lead: { min: 2200000, max: 3700000 }, executive: { min: 3400000, max: 6000000 } },
    hospitality: { entry: { min: 240000, max: 450000 }, mid: { min: 500000, max: 900000 }, senior: { min: 950000, max: 1700000 }, lead: { min: 1500000, max: 2600000 }, executive: { min: 2400000, max: 4200000 } },
    retail: { entry: { min: 220000, max: 420000 }, mid: { min: 460000, max: 840000 }, senior: { min: 900000, max: 1600000 }, lead: { min: 1400000, max: 2400000 }, executive: { min: 2200000, max: 3900000 } },
    government: { entry: { min: 400000, max: 700000 }, mid: { min: 750000, max: 1300000 }, senior: { min: 1400000, max: 2200000 }, lead: { min: 2000000, max: 3200000 }, executive: { min: 3000000, max: 5200000 } },
    creative: { entry: { min: 300000, max: 600000 }, mid: { min: 650000, max: 1200000 }, senior: { min: 1300000, max: 2200000 }, lead: { min: 2000000, max: 3400000 }, executive: { min: 3200000, max: 5600000 } },
  },
  ph: {
    technology: { entry: { min: 300000, max: 540000 }, mid: { min: 600000, max: 1020000 }, senior: { min: 1080000, max: 1800000 }, lead: { min: 1680000, max: 2640000 }, executive: { min: 2400000, max: 4200000 } },
    healthcare: { entry: { min: 200000, max: 380000 }, mid: { min: 420000, max: 720000 }, senior: { min: 780000, max: 1320000 }, lead: { min: 1200000, max: 1920000 }, executive: { min: 1740000, max: 3000000 } },
    finance: { entry: { min: 280000, max: 500000 }, mid: { min: 540000, max: 960000 }, senior: { min: 1020000, max: 1680000 }, lead: { min: 1560000, max: 2520000 }, executive: { min: 2280000, max: 4000000 } },
    engineering: { entry: { min: 260000, max: 480000 }, mid: { min: 520000, max: 900000 }, senior: { min: 960000, max: 1560000 }, lead: { min: 1440000, max: 2280000 }, executive: { min: 2100000, max: 3600000 } },
    education: { entry: { min: 180000, max: 300000 }, mid: { min: 320000, max: 520000 }, senior: { min: 540000, max: 860000 }, lead: { min: 800000, max: 1260000 }, executive: { min: 1140000, max: 1920000 } },
    marketing: { entry: { min: 200000, max: 380000 }, mid: { min: 420000, max: 720000 }, senior: { min: 780000, max: 1260000 }, lead: { min: 1140000, max: 1800000 }, executive: { min: 1680000, max: 2880000 } },
    legal: { entry: { min: 260000, max: 480000 }, mid: { min: 520000, max: 920000 }, senior: { min: 980000, max: 1620000 }, lead: { min: 1500000, max: 2460000 }, executive: { min: 2280000, max: 4000000 } },
    manufacturing: { entry: { min: 180000, max: 320000 }, mid: { min: 340000, max: 580000 }, senior: { min: 620000, max: 1020000 }, lead: { min: 960000, max: 1500000 }, executive: { min: 1380000, max: 2400000 } },
    hospitality: { entry: { min: 140000, max: 240000 }, mid: { min: 260000, max: 440000 }, senior: { min: 480000, max: 780000 }, lead: { min: 720000, max: 1140000 }, executive: { min: 1040000, max: 1800000 } },
    retail: { entry: { min: 130000, max: 230000 }, mid: { min: 250000, max: 420000 }, senior: { min: 450000, max: 740000 }, lead: { min: 680000, max: 1080000 }, executive: { min: 980000, max: 1700000 } },
    government: { entry: { min: 200000, max: 360000 }, mid: { min: 380000, max: 620000 }, senior: { min: 660000, max: 1040000 }, lead: { min: 980000, max: 1520000 }, executive: { min: 1400000, max: 2360000 } },
    creative: { entry: { min: 160000, max: 300000 }, mid: { min: 320000, max: 580000 }, senior: { min: 620000, max: 1020000 }, lead: { min: 960000, max: 1500000 }, executive: { min: 1380000, max: 2400000 } },
  },
  th: {
    technology: { entry: { min: 360000, max: 600000 }, mid: { min: 660000, max: 1080000 }, senior: { min: 1140000, max: 1860000 }, lead: { min: 1740000, max: 2700000 }, executive: { min: 2520000, max: 4200000 } },
    healthcare: { entry: { min: 260000, max: 440000 }, mid: { min: 480000, max: 800000 }, senior: { min: 840000, max: 1380000 }, lead: { min: 1280000, max: 2000000 }, executive: { min: 1860000, max: 3120000 } },
    finance: { entry: { min: 360000, max: 600000 }, mid: { min: 660000, max: 1080000 }, senior: { min: 1140000, max: 1860000 }, lead: { min: 1740000, max: 2760000 }, executive: { min: 2580000, max: 4380000 } },
    engineering: { entry: { min: 320000, max: 540000 }, mid: { min: 580000, max: 960000 }, senior: { min: 1000000, max: 1640000 }, lead: { min: 1520000, max: 2400000 }, executive: { min: 2220000, max: 3780000 } },
    education: { entry: { min: 200000, max: 340000 }, mid: { min: 360000, max: 580000 }, senior: { min: 600000, max: 960000 }, lead: { min: 900000, max: 1380000 }, executive: { min: 1280000, max: 2100000 } },
    marketing: { entry: { min: 240000, max: 420000 }, mid: { min: 460000, max: 760000 }, senior: { min: 800000, max: 1300000 }, lead: { min: 1200000, max: 1900000 }, executive: { min: 1780000, max: 3000000 } },
    legal: { entry: { min: 320000, max: 540000 }, mid: { min: 580000, max: 980000 }, senior: { min: 1020000, max: 1700000 }, lead: { min: 1580000, max: 2540000 }, executive: { min: 2360000, max: 4100000 } },
    manufacturing: { entry: { min: 200000, max: 360000 }, mid: { min: 380000, max: 640000 }, senior: { min: 680000, max: 1100000 }, lead: { min: 1020000, max: 1600000 }, executive: { min: 1480000, max: 2520000 } },
    hospitality: { entry: { min: 160000, max: 280000 }, mid: { min: 300000, max: 500000 }, senior: { min: 520000, max: 860000 }, lead: { min: 800000, max: 1280000 }, executive: { min: 1180000, max: 2000000 } },
    retail: { entry: { min: 150000, max: 260000 }, mid: { min: 280000, max: 460000 }, senior: { min: 480000, max: 800000 }, lead: { min: 740000, max: 1180000 }, executive: { min: 1100000, max: 1880000 } },
    government: { entry: { min: 240000, max: 400000 }, mid: { min: 420000, max: 680000 }, senior: { min: 720000, max: 1100000 }, lead: { min: 1020000, max: 1560000 }, executive: { min: 1460000, max: 2400000 } },
    creative: { entry: { min: 200000, max: 360000 }, mid: { min: 380000, max: 640000 }, senior: { min: 680000, max: 1100000 }, lead: { min: 1020000, max: 1620000 }, executive: { min: 1500000, max: 2580000 } },
  },
  my: {
    technology: { entry: { min: 36000, max: 60000 }, mid: { min: 66000, max: 108000 }, senior: { min: 114000, max: 180000 }, lead: { min: 168000, max: 252000 }, executive: { min: 240000, max: 396000 } },
    healthcare: { entry: { min: 28000, max: 48000 }, mid: { min: 52000, max: 84000 }, senior: { min: 90000, max: 144000 }, lead: { min: 132000, max: 204000 }, executive: { min: 192000, max: 324000 } },
    finance: { entry: { min: 36000, max: 60000 }, mid: { min: 66000, max: 108000 }, senior: { min: 114000, max: 180000 }, lead: { min: 168000, max: 264000 }, executive: { min: 252000, max: 420000 } },
    engineering: { entry: { min: 32000, max: 54000 }, mid: { min: 58000, max: 96000 }, senior: { min: 102000, max: 162000 }, lead: { min: 150000, max: 234000 }, executive: { min: 216000, max: 360000 } },
    education: { entry: { min: 24000, max: 40000 }, mid: { min: 42000, max: 66000 }, senior: { min: 70000, max: 108000 }, lead: { min: 102000, max: 156000 }, executive: { min: 144000, max: 240000 } },
    marketing: { entry: { min: 26000, max: 44000 }, mid: { min: 48000, max: 78000 }, senior: { min: 84000, max: 132000 }, lead: { min: 126000, max: 192000 }, executive: { min: 180000, max: 300000 } },
    legal: { entry: { min: 36000, max: 60000 }, mid: { min: 66000, max: 108000 }, senior: { min: 114000, max: 186000 }, lead: { min: 174000, max: 270000 }, executive: { min: 252000, max: 420000 } },
    manufacturing: { entry: { min: 24000, max: 40000 }, mid: { min: 42000, max: 72000 }, senior: { min: 76000, max: 120000 }, lead: { min: 114000, max: 174000 }, executive: { min: 162000, max: 276000 } },
    hospitality: { entry: { min: 18000, max: 30000 }, mid: { min: 32000, max: 54000 }, senior: { min: 58000, max: 94000 }, lead: { min: 88000, max: 138000 }, executive: { min: 128000, max: 216000 } },
    retail: { entry: { min: 18000, max: 30000 }, mid: { min: 30000, max: 50000 }, senior: { min: 54000, max: 88000 }, lead: { min: 82000, max: 130000 }, executive: { min: 120000, max: 204000 } },
    government: { entry: { min: 26000, max: 42000 }, mid: { min: 44000, max: 72000 }, senior: { min: 76000, max: 116000 }, lead: { min: 110000, max: 168000 }, executive: { min: 156000, max: 258000 } },
    creative: { entry: { min: 22000, max: 38000 }, mid: { min: 40000, max: 68000 }, senior: { min: 72000, max: 114000 }, lead: { min: 108000, max: 168000 }, executive: { min: 156000, max: 264000 } },
  },
};

function formatLocalCurrency(amount: number, countryCode: string): string {
  const country = countries[countryCode];
  if (!country) return String(amount);
  const sym = country.currencySymbol;

  if (amount >= 10000000) return `${sym}${(amount / 10000000).toFixed(1)}Cr`;
  if (amount >= 100000 && countryCode === "in") return `${sym}${(amount / 100000).toFixed(1)}L`;
  if (amount >= 1000000) return `${sym}${(amount / 1000000).toFixed(1)}M`;
  if (amount >= 1000) return `${sym}${(amount / 1000).toFixed(0)}K`;
  return `${sym}${amount}`;
}

function formatUSD(amount: number): string {
  if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
  if (amount >= 1000) return `$${Math.round(amount / 1000)}K`;
  return `$${amount}`;
}

function getCostOfLivingLabel(index: number): string {
  if (index >= 100) return "Very High";
  if (index >= 80) return "High";
  if (index >= 60) return "Above Average";
  if (index >= 40) return "Moderate";
  if (index >= 25) return "Low";
  return "Very Low";
}

function getCostOfLivingColor(index: number): string {
  if (index >= 100) return "text-red-500";
  if (index >= 80) return "text-orange-500";
  if (index >= 60) return "text-yellow-600";
  if (index >= 40) return "text-blue-500";
  return "text-green-500";
}

const negotiationTips = [
  {
    title: "Research Local Market Rates",
    description: "Always research the local market rates before negotiating. Salary expectations vary significantly between countries and even cities within the same country.",
  },
  {
    title: "Consider Total Compensation",
    description: "In many countries, base salary is only part of the package. Consider benefits like healthcare, pension contributions, bonuses, equity, and paid leave.",
  },
  {
    title: "Understand Tax Implications",
    description: "Tax rates vary dramatically between countries. A higher gross salary might result in lower take-home pay depending on the tax structure.",
  },
  {
    title: "Factor in Cost of Living",
    description: "A lower salary in a low cost-of-living country might provide a better lifestyle than a higher salary in an expensive city.",
  },
  {
    title: "Know Local Negotiation Culture",
    description: "Negotiation styles differ globally. Some cultures expect negotiation while others consider it inappropriate. Research local customs before negotiating.",
  },
  {
    title: "Account for Currency Fluctuations",
    description: "If comparing offers across countries, consider exchange rate volatility. A stable local currency salary may be preferable to one subject to frequent fluctuations.",
  },
];

export default function CountrySalaryCalculator() {
  const [country, setCountry] = useState("");
  const [industry, setIndustry] = useState<Industry | "">("");
  const [experience, setExperience] = useState<ExperienceLevel | "">("");

  const countryInfo = country ? countries[country] : null;
  const salaryRange = country && industry && experience
    ? salaryData[country]?.[industry as Industry]?.[experience as ExperienceLevel]
    : null;

  const usSalary = industry && experience
    ? salaryData.us?.[industry as Industry]?.[experience as ExperienceLevel]
    : null;

  const usdMin = salaryRange && countryInfo ? Math.round(salaryRange.min * countryInfo.usdRate) : 0;
  const usdMax = salaryRange && countryInfo ? Math.round(salaryRange.max * countryInfo.usdRate) : 0;
  const usdMidpoint = Math.round((usdMin + usdMax) / 2);
  const usAvgMidpoint = usSalary ? Math.round((usSalary.min + usSalary.max) / 2) : 0;
  const vsUsPercent = usAvgMidpoint > 0 ? Math.round(((usdMidpoint - usAvgMidpoint) / usAvgMidpoint) * 100) : 0;

  const monthlyMin = salaryRange ? Math.round(salaryRange.min / 12) : 0;
  const monthlyMax = salaryRange ? Math.round(salaryRange.max / 12) : 0;

  const hasResult = salaryRange && countryInfo;

  const handleReset = () => {
    setCountry("");
    setIndustry("");
    setExperience("");
  };

  const sortedCountries = Object.entries(countries).sort((a, b) => a[1].name.localeCompare(b[1].name));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 mb-4">
          <Globe className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-country-salary-title">
          Country-wise Salary Calculator
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Compare salaries across 34 countries and 12 industries. Get realistic salary ranges
          in local currency and USD with cost of living context.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <MapPin className="h-4 w-4" />
            <span>34 Countries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Briefcase className="h-4 w-4" />
            <span>12 Industries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <BarChart3 className="h-4 w-4" />
            <span>5 Experience Levels</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <Building2 className="h-5 w-5 text-muted-foreground" />
            Select Parameters
          </h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Country</label>
              <Select value={country} onValueChange={setCountry}>
                <SelectTrigger data-testid="select-country">
                  <SelectValue placeholder="Select a country" />
                </SelectTrigger>
                <SelectContent>
                  {sortedCountries.map(([code, info]) => (
                    <SelectItem key={code} value={code}>
                      {info.name} ({info.currency})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Industry</label>
              <Select value={industry} onValueChange={(v) => setIndustry(v as Industry)}>
                <SelectTrigger data-testid="select-industry">
                  <SelectValue placeholder="Select an industry" />
                </SelectTrigger>
                <SelectContent>
                  {industries.map((ind) => (
                    <SelectItem key={ind.value} value={ind.value}>{ind.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Experience Level</label>
              <Select value={experience} onValueChange={(v) => setExperience(v as ExperienceLevel)}>
                <SelectTrigger data-testid="select-experience">
                  <SelectValue placeholder="Select experience level" />
                </SelectTrigger>
                <SelectContent>
                  {experienceLevels.map((exp) => (
                    <SelectItem key={exp.value} value={exp.value}>{exp.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {hasResult && (
              <Button variant="outline" onClick={handleReset} data-testid="button-reset" className="w-full">
                Reset Selection
              </Button>
            )}
          </div>

          {countryInfo && (
            <div className="mt-4 p-3 rounded-md bg-muted/50">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="text-sm">
                  <span className="text-muted-foreground">Cost of Living: </span>
                  <span className={`font-semibold ${getCostOfLivingColor(countryInfo.costOfLivingIndex)}`}>
                    {getCostOfLivingLabel(countryInfo.costOfLivingIndex)}
                  </span>
                </div>
                <Badge variant="outline">{countryInfo.costOfLivingIndex}/100 vs NYC</Badge>
              </div>
              <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500"
                  style={{ width: `${Math.min(countryInfo.costOfLivingIndex, 100)}%` }}
                />
              </div>
            </div>
          )}
        </Card>

        <Card className="p-6">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-muted-foreground" />
            Salary Breakdown
          </h2>
          {hasResult ? (
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-md bg-muted/50 flex-wrap gap-1">
                  <span className="text-sm">Annual Salary Range</span>
                  <span className="font-semibold" data-testid="text-annual-range">
                    {formatLocalCurrency(salaryRange.min, country)} - {formatLocalCurrency(salaryRange.max, country)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-muted/50 flex-wrap gap-1">
                  <span className="text-sm">Monthly Salary</span>
                  <span className="font-semibold" data-testid="text-monthly-range">
                    {formatLocalCurrency(monthlyMin, country)} - {formatLocalCurrency(monthlyMax, country)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-muted/50 flex-wrap gap-1">
                  <span className="text-sm">USD Equivalent (Annual)</span>
                  <span className="font-semibold text-green-600" data-testid="text-usd-equivalent">
                    {formatUSD(usdMin)} - {formatUSD(usdMax)}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-md bg-primary/5 border border-primary/10">
                <div className="text-sm text-muted-foreground mb-1">Comparison to US Average</div>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="text-2xl font-bold" data-testid="text-us-comparison">
                    {vsUsPercent > 0 ? "+" : ""}{vsUsPercent}%
                  </div>
                  <div className="flex items-center gap-1">
                    <TrendingUp className={`h-4 w-4 ${vsUsPercent >= 0 ? "text-green-500" : "text-red-500"}`} />
                    <span className="text-xs text-muted-foreground">
                      {vsUsPercent >= 0 ? "above" : "below"} US average for this role
                    </span>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground mt-2">
                  US range: {formatUSD(usSalary?.min || 0)} - {formatUSD(usSalary?.max || 0)}
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">{countryInfo.name}</Badge>
                <Badge variant="outline">{countryInfo.currency}</Badge>
                <Badge variant="secondary">
                  {industries.find((i) => i.value === industry)?.label}
                </Badge>
                <Badge variant="secondary">
                  {experienceLevels.find((e) => e.value === experience)?.label.split(" (")[0]}
                </Badge>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Calculator className="h-12 w-12 mb-3 opacity-30" />
              <p className="text-sm">Select country, industry, and experience level to calculate</p>
            </div>
          )}
        </Card>
      </div>

      <Card className="mt-6 p-6">
        <h2 className="font-semibold mb-4 flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-muted-foreground" />
          International Salary Negotiation Tips
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {negotiationTips.map((tip) => (
            <div key={tip.title} className="p-4 rounded-md bg-muted/50">
              <h3 className="font-medium text-sm mb-1.5 flex items-center gap-1.5">
                <GraduationCap className="h-4 w-4 text-muted-foreground shrink-0" />
                {tip.title}
              </h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{tip.description}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mt-4 p-4">
        <p className="text-xs text-muted-foreground leading-relaxed">
          Salary data represents approximate annual compensation ranges for 2024-2025. Figures may vary based on
          company size, specific role, location within the country, and individual qualifications. Exchange rates
          are approximate and subject to market fluctuations. Cost of living index uses New York City as the
          baseline (100). This tool is for informational purposes only and should not be the sole basis for
          salary negotiations or career decisions.
        </p>
      </Card>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Country Salary Calculator", item: "https://devglobaljobs.com/tools/country-salary-calculator" },
            ],
          }),
        }}
      />
    </div>
  );
}
