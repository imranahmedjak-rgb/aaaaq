import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DollarSign, TrendingUp, Target, Shield, Clock, Mail,
  Copy, Check, Briefcase, Award, Eye, MessageSquare,
  ThumbsUp, ThumbsDown, Lightbulb, Users, BarChart3,
  Zap, Heart, Scale, BookOpen, Star, CheckCircle2,
} from "lucide-react";

const industries = [
  "Technology", "Healthcare", "Finance", "Education", "Engineering",
  "Marketing", "Legal", "Government", "Nonprofit", "Consulting",
  "Media", "Other",
] as const;

const industryMultipliers: Record<string, number> = {
  Technology: 1.15,
  Healthcare: 1.08,
  Finance: 1.20,
  Education: 0.90,
  Engineering: 1.12,
  Marketing: 1.05,
  Legal: 1.18,
  Government: 0.92,
  Nonprofit: 0.85,
  Consulting: 1.14,
  Media: 1.00,
  Other: 1.00,
};

interface CalculatorResult {
  counterOfferLow: number;
  counterOfferHigh: number;
  negotiationPower: number;
  industryAverage: number;
  powerLabel: string;
}

function calculateStrategy(
  currentOffer: number,
  desiredSalary: number,
  yearsExp: number,
  industry: string
): CalculatorResult {
  const multiplier = industryMultipliers[industry] || 1.0;
  const expFactor = Math.min(yearsExp / 30, 1) * 0.15 + 0.85;
  const industryAverage = currentOffer * multiplier;
  const gap = desiredSalary - currentOffer;
  const gapPercent = (gap / currentOffer) * 100;

  let negotiationPower = 50;
  if (yearsExp >= 10) negotiationPower += 15;
  else if (yearsExp >= 5) negotiationPower += 10;
  else if (yearsExp >= 3) negotiationPower += 5;

  if (multiplier >= 1.1) negotiationPower += 10;
  else if (multiplier >= 1.0) negotiationPower += 5;

  if (gapPercent <= 10) negotiationPower += 15;
  else if (gapPercent <= 20) negotiationPower += 10;
  else if (gapPercent <= 30) negotiationPower += 5;
  else negotiationPower -= 5;

  if (desiredSalary <= industryAverage) negotiationPower += 10;

  negotiationPower = Math.min(Math.max(negotiationPower, 10), 100);

  const counterOfferLow = Math.round(currentOffer + gap * 0.6 * expFactor);
  const counterOfferHigh = Math.round(currentOffer + gap * 1.1 * expFactor);

  let powerLabel = "Low";
  if (negotiationPower >= 80) powerLabel = "Very Strong";
  else if (negotiationPower >= 65) powerLabel = "Strong";
  else if (negotiationPower >= 50) powerLabel = "Moderate";
  else if (negotiationPower >= 35) powerLabel = "Fair";

  return { counterOfferLow, counterOfferHigh, negotiationPower, industryAverage: Math.round(industryAverage), powerLabel };
}

const scripts = [
  {
    title: "Initial Counter-Offer",
    icon: MessageSquare,
    scenario: "When you receive an offer below your expectations",
    body: `Dear [Hiring Manager],

Thank you so much for extending the offer for the [Position] role. I am genuinely excited about the opportunity to contribute to [Company Name] and the team's mission.

After carefully reviewing the compensation package, I would like to discuss the base salary. Based on my research of industry standards, my [X] years of experience, and the value I can bring to this role, I was hoping for a salary in the range of $[Your Target]. 

I am confident that my skills in [Key Skill 1] and [Key Skill 2] will allow me to make a significant impact from day one. I would love to find a number that reflects both the value of the role and my qualifications.

Would you be open to discussing this? I am very enthusiastic about joining the team and hope we can reach an agreement that works for both of us.

Best regards,
[Your Name]`,
  },
  {
    title: "Requesting Time to Consider",
    icon: Clock,
    scenario: "When you need more time to evaluate the offer",
    body: `Dear [Hiring Manager],

Thank you very much for the offer for the [Position] role at [Company Name]. I am thrilled about this opportunity and appreciate the time and effort the team has invested in the interview process.

I want to give this offer the careful consideration it deserves. Would it be possible to have until [Date, typically 3-5 business days] to review the full compensation package and provide my response?

I remain very excited about the role and look forward to discussing any final details.

Thank you for your understanding.

Best regards,
[Your Name]`,
  },
  {
    title: "Negotiating Remote Work",
    icon: Briefcase,
    scenario: "When you want to negotiate flexible or remote arrangements",
    body: `Dear [Hiring Manager],

Thank you for the generous offer for the [Position] role. I am excited to join [Company Name] and contribute to the team's success.

I wanted to discuss the possibility of a flexible work arrangement. Given my experience working effectively in remote/hybrid settings, I believe I can maintain — and even increase — my productivity with [X days remote per week / fully remote arrangement].

In my previous role, I successfully [specific achievement while working remotely], and I am confident I can deliver the same results in this position. I am happy to discuss a trial period or any structure that works best for the team.

I look forward to hearing your thoughts on this.

Best regards,
[Your Name]`,
  },
  {
    title: "Negotiating Benefits (Salary is Firm)",
    icon: Heart,
    scenario: "When the salary cannot be changed but you want better benefits",
    body: `Dear [Hiring Manager],

Thank you for the offer and for the transparent conversation about the salary range for the [Position] role. I understand the base salary is firm, and I appreciate your openness.

I would like to explore whether there is flexibility in other areas of the compensation package. Specifically, I am interested in discussing:

- Additional vacation days (e.g., [X] days instead of the standard)
- A signing bonus to bridge the gap
- Professional development budget for certifications and conferences
- Stock options or equity participation
- Performance-based bonus structure

I believe these adjustments would make the overall package more competitive and reflect my commitment to a long-term career at [Company Name].

Would you be open to exploring any of these options?

Best regards,
[Your Name]`,
  },
  {
    title: "Accepting with Conditions",
    icon: ThumbsUp,
    scenario: "When you want to accept but with specific conditions documented",
    body: `Dear [Hiring Manager],

I am delighted to accept the offer for the [Position] role at [Company Name]. Thank you for working with me to reach a mutually agreeable package.

To confirm, I am accepting based on the following terms we discussed:
- Base salary: $[Amount]
- Start date: [Date]
- [Any negotiated benefit, e.g., "3 days remote work per week"]
- [Any other agreed condition, e.g., "6-month performance review for salary adjustment"]

I would appreciate receiving these details in the updated offer letter for my records. Please let me know if there is any additional paperwork or onboarding steps I should complete before my start date.

I am truly excited to join the team and contribute to [Company Name]'s goals.

Best regards,
[Your Name]`,
  },
  {
    title: "Declining Professionally",
    icon: ThumbsDown,
    scenario: "When you need to decline an offer gracefully",
    body: `Dear [Hiring Manager],

Thank you so much for offering me the [Position] role at [Company Name]. I sincerely appreciate the time the team spent during the interview process and the confidence you have shown in my abilities.

After careful consideration, I have decided to pursue another opportunity that more closely aligns with my career goals and compensation expectations at this time.

This was not an easy decision, as I was genuinely impressed by the team and the company's mission. I hope we can stay connected, and I would welcome the opportunity to collaborate in the future.

Thank you again for your time and consideration. I wish you and the team continued success.

Best regards,
[Your Name]`,
  },
];

const goldenRules = [
  { icon: BookOpen, title: "Research First", description: "Know your market value before any negotiation. Use salary databases, industry reports, and networking to understand the range for your role." },
  { icon: Clock, title: "Never Accept Immediately", description: "Always ask for time to consider. Rushing leads to regret. A professional employer will respect your need to evaluate." },
  { icon: Target, title: "Aim Higher Than Your Target", description: "Start with a number 10-20% above your actual target. This gives room for compromise while still reaching your goal." },
  { icon: Shield, title: "Never Reveal Your Current Salary", description: "Your current salary is irrelevant to your market value. Focus the conversation on the value you bring and industry benchmarks." },
  { icon: Users, title: "Practice Your Pitch", description: "Rehearse your negotiation points with a friend or mentor. Confidence comes from preparation, not improvisation." },
  { icon: BarChart3, title: "Use Data, Not Emotions", description: "Support your ask with market data, accomplishments, and metrics. Numbers are more persuasive than feelings." },
  { icon: Zap, title: "Negotiate the Total Package", description: "Salary is just one component. Consider bonuses, equity, PTO, remote work, professional development, and other benefits." },
  { icon: Scale, title: "Know Your Walk-Away Point", description: "Determine your minimum acceptable offer before negotiating. Be prepared to walk away if the offer does not meet your needs." },
  { icon: Star, title: "Get Everything in Writing", description: "Verbal promises mean nothing. Ensure all agreed terms are documented in your official offer letter before accepting." },
  { icon: Lightbulb, title: "Be Collaborative, Not Adversarial", description: "Frame the negotiation as finding a mutual win. Use language like 'I would love to find a number that works for both of us.'" },
];

export default function SalaryNegotiation() {
  const [currentOffer, setCurrentOffer] = useState("");
  const [desiredSalary, setDesiredSalary] = useState("");
  const [yearsExp, setYearsExp] = useState("");
  const [industry, setIndustry] = useState("");
  const [result, setResult] = useState<CalculatorResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleCalculate = () => {
    const offer = parseFloat(currentOffer);
    const desired = parseFloat(desiredSalary);
    const years = parseInt(yearsExp);
    if (!offer || !desired || !years || !industry) return;
    setResult(calculateStrategy(offer, desired, years, industry));
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(val);

  function getPowerColor(score: number) {
    if (score >= 70) return "text-green-600";
    if (score >= 50) return "text-amber-500";
    return "text-red-500";
  }

  const circumference = 2 * Math.PI * 45;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 mb-4">
          <DollarSign className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-salary-negotiation-title">
          Salary Negotiation Guide & Calculator
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Calculate your optimal counter-offer, access professional negotiation scripts, and master the art of salary negotiation with proven strategies.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            <span>Strategy Calculator</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Mail className="h-4 w-4" />
            <span>6 Email Templates</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Award className="h-4 w-4" />
            <span>10 Golden Rules</span>
          </div>
        </div>
      </div>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-calculator-heading">
          <TrendingUp className="h-5 w-5 text-emerald-600" />
          Salary Negotiation Calculator
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 p-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div className="space-y-1.5">
                <Label htmlFor="currentOffer" className="text-sm">Current Salary Offer ($)</Label>
                <Input
                  id="currentOffer"
                  type="number"
                  placeholder="e.g. 75000"
                  value={currentOffer}
                  onChange={(e) => setCurrentOffer(e.target.value)}
                  data-testid="input-current-offer"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="desiredSalary" className="text-sm">Your Desired Salary ($)</Label>
                <Input
                  id="desiredSalary"
                  type="number"
                  placeholder="e.g. 90000"
                  value={desiredSalary}
                  onChange={(e) => setDesiredSalary(e.target.value)}
                  data-testid="input-desired-salary"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="yearsExp" className="text-sm">Years of Experience</Label>
                <Input
                  id="yearsExp"
                  type="number"
                  min={1}
                  max={30}
                  placeholder="e.g. 5"
                  value={yearsExp}
                  onChange={(e) => setYearsExp(e.target.value)}
                  data-testid="input-years-experience"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="industry" className="text-sm">Industry</Label>
                <Select value={industry} onValueChange={setIndustry}>
                  <SelectTrigger data-testid="select-industry">
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {industries.map((ind) => (
                      <SelectItem key={ind} value={ind} data-testid={`option-industry-${ind.toLowerCase()}`}>
                        {ind}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={handleCalculate} className="w-full sm:w-auto" data-testid="button-calculate-strategy">
              <Target className="h-4 w-4 mr-2" />
              Calculate Strategy
            </Button>
          </Card>

          <Card className="p-5">
            {result ? (
              <div className="space-y-4">
                <h3 className="font-semibold text-sm text-center">Your Negotiation Strategy</h3>
                <div className="flex justify-center">
                  <div className="relative w-24 h-24">
                    <svg className="w-24 h-24 -rotate-90" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="6" className="text-muted/30" />
                      <circle
                        cx="50" cy="50" r="45" fill="none" strokeWidth="6"
                        stroke="currentColor"
                        className={getPowerColor(result.negotiationPower)}
                        strokeLinecap="round"
                        strokeDasharray={circumference}
                        strokeDashoffset={circumference - (result.negotiationPower / 100) * circumference}
                        style={{ transition: "stroke-dashoffset 0.5s ease" }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className={`text-xl font-bold ${getPowerColor(result.negotiationPower)}`} data-testid="text-power-score">
                        {result.negotiationPower}%
                      </span>
                      <span className="text-[9px] text-muted-foreground">{result.powerLabel}</span>
                    </div>
                  </div>
                </div>
                <div className="text-center text-xs text-muted-foreground">Negotiation Power</div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Counter-Offer Range</span>
                    <Badge variant="secondary" data-testid="text-counter-offer-range">
                      {formatCurrency(result.counterOfferLow)} - {formatCurrency(result.counterOfferHigh)}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Industry Average</span>
                    <Badge variant="secondary" data-testid="text-industry-average">
                      {formatCurrency(result.industryAverage)}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Your Desired</span>
                    <Badge variant="secondary">
                      {formatCurrency(parseFloat(desiredSalary))}
                    </Badge>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center py-8">
                <Eye className="h-10 w-10 text-muted-foreground/40 mb-3" />
                <p className="text-sm text-muted-foreground">Fill in the form and click "Calculate Strategy" to see your personalized negotiation plan.</p>
              </div>
            )}
          </Card>
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-scripts-heading">
          <Mail className="h-5 w-5 text-emerald-600" />
          Negotiation Email Scripts
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {scripts.map((script, index) => {
            const Icon = script.icon;
            return (
              <Card key={index} className="p-5" data-testid={`card-script-${index}`}>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 flex-1 flex-wrap">
                    <Icon className="h-5 w-5 text-muted-foreground shrink-0" />
                    <h3 className="font-semibold text-sm">{script.title}</h3>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleCopy(script.body, index)}
                    data-testid={`button-copy-script-${index}`}
                  >
                    {copiedIndex === index ? (
                      <Check className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mb-3">{script.scenario}</p>
                <pre className="text-xs whitespace-pre-wrap font-sans bg-muted/50 rounded-md p-3 max-h-48 overflow-y-auto" data-testid={`text-script-body-${index}`}>
                  {script.body}
                </pre>
              </Card>
            );
          })}
        </div>
      </section>

      <section className="mb-10">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-golden-rules-heading">
          <Award className="h-5 w-5 text-emerald-600" />
          10 Golden Rules of Salary Negotiation
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {goldenRules.map((rule, index) => {
            const Icon = rule.icon;
            return (
              <Card key={index} className="p-5" data-testid={`card-rule-${index}`}>
                <div className="flex items-center gap-2 mb-2">
                  <div className="inline-flex items-center justify-center w-8 h-8 rounded-md bg-emerald-500/10 shrink-0">
                    <Icon className="h-4 w-4 text-emerald-600" />
                  </div>
                  <h3 className="font-semibold text-sm">{rule.title}</h3>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{rule.description}</p>
              </Card>
            );
          })}
        </div>
      </section>

      <Card className="p-5 text-center mb-6">
        <div className="flex items-center justify-center gap-2 mb-2">
          <CheckCircle2 className="h-5 w-5 text-emerald-600" />
          <h3 className="font-semibold text-sm">Ready to Negotiate?</h3>
        </div>
        <p className="text-xs text-muted-foreground max-w-xl mx-auto">
          Remember: The worst they can say is no. Most employers expect candidates to negotiate, and failing to do so can leave thousands of dollars on the table over your career.
        </p>
      </Card>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Salary Negotiation", item: "https://devglobaljobs.com/tools/salary-negotiation" },
            ],
          }),
        }}
      />
    </div>
  );
}
