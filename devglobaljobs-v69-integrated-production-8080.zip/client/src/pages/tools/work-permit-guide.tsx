import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Globe, Search, ExternalLink, Clock, FileText,
  AlertTriangle, DollarSign, CheckCircle2, Shield,
} from "lucide-react";

const regionFilters = [
  { value: "all", label: "All Regions" },
  { value: "europe", label: "Europe" },
  { value: "north-america", label: "North America" },
  { value: "asia-pacific", label: "Asia-Pacific" },
  { value: "middle-east", label: "Middle East" },
  { value: "africa", label: "Africa" },
  { value: "latin-america", label: "Latin America" },
];

const speedFilters = [
  { value: "all", label: "All Speeds" },
  { value: "fast", label: "Fast (<1 month)" },
  { value: "medium", label: "Medium (1-3 months)" },
  { value: "slow", label: "Slow (3+ months)" },
];

const difficultyFilters = [
  { value: "all", label: "All Levels" },
  { value: "easy", label: "Easy" },
  { value: "moderate", label: "Moderate" },
  { value: "difficult", label: "Difficult" },
];

interface WorkPermitCountry {
  name: string;
  flag: string;
  region: string;
  permitTypes: string[];
  processingTime: string;
  speed: string;
  difficulty: string;
  cost: string;
  requirements: string[];
  immigrationUrl: string;
  notes: string;
}

const countries: WorkPermitCountry[] = [
  { name: "United States", flag: "US", region: "north-america", permitTypes: ["H-1B", "L-1", "O-1", "E-2", "TN"], processingTime: "3-6 months", speed: "slow", difficulty: "difficult", cost: "$1,710 - $10,000+", requirements: ["Employer sponsorship required", "Bachelor's degree or equivalent", "Specialty occupation", "Lottery selection (H-1B)"], immigrationUrl: "https://www.uscis.gov/working-in-the-united-states", notes: "H-1B cap of 85,000/year. Premium processing available for $2,805." },
  { name: "Canada", flag: "CA", region: "north-america", permitTypes: ["LMIA Work Permit", "IEC", "NAFTA/CUSMA", "Intra-Company Transfer"], processingTime: "2-4 months", speed: "medium", difficulty: "moderate", cost: "CAD $155 - $1,000", requirements: ["Job offer from Canadian employer", "LMIA or LMIA-exempt category", "Valid passport", "No criminal record"], immigrationUrl: "https://www.canada.ca/en/immigration-refugees-citizenship/services/work-canada.html", notes: "Express Entry system for permanent residence. IEC for youth 18-35." },
  { name: "United Kingdom", flag: "GB", region: "europe", permitTypes: ["Skilled Worker", "Global Talent", "Scale-up", "Youth Mobility"], processingTime: "3-8 weeks", speed: "medium", difficulty: "moderate", cost: "GBP 625 - $1,423 + IHS", requirements: ["Certificate of Sponsorship from employer", "Salary threshold (GBP 38,700+)", "English proficiency (B1)", "Maintenance funds"], immigrationUrl: "https://www.gov.uk/browse/visas-immigration/work-visas", notes: "Immigration Health Surcharge (IHS) of GBP 1,035/year additional." },
  { name: "Germany", flag: "DE", region: "europe", permitTypes: ["EU Blue Card", "Skilled Worker", "ICT", "Freelance"], processingTime: "4-12 weeks", speed: "medium", difficulty: "moderate", cost: "EUR 75 - 140", requirements: ["Recognized qualification", "Job offer with minimum salary", "Health insurance", "Basic German (varies)"], immigrationUrl: "https://www.make-it-in-germany.com/en/visa-residence/types/work", notes: "EU Blue Card requires EUR 45,300+ salary. IT workers may not need degree." },
  { name: "France", flag: "FR", region: "europe", permitTypes: ["Talent Passport", "Salaried Worker", "Seasonal Worker", "ICT"], processingTime: "1-3 months", speed: "medium", difficulty: "moderate", cost: "EUR 99 - 269", requirements: ["Employment contract", "Employer must prove labor market test", "Qualifications relevant to role", "Health insurance"], immigrationUrl: "https://france-visas.gouv.fr/en/web/france-visas", notes: "Talent Passport for high-skilled workers valid up to 4 years." },
  { name: "Netherlands", flag: "NL", region: "europe", permitTypes: ["Highly Skilled Migrant", "EU Blue Card", "Startup", "Self-employed"], processingTime: "2-4 weeks", speed: "fast", difficulty: "moderate", cost: "EUR 350 - 1,445", requirements: ["Recognized sponsor employer", "Minimum salary (age-dependent)", "Valid passport", "No public order concerns"], immigrationUrl: "https://ind.nl/en/work", notes: "30% tax ruling available for highly skilled migrants. Fast processing." },
  { name: "Switzerland", flag: "CH", region: "europe", permitTypes: ["L Permit", "B Permit", "G Permit (Cross-border)"], processingTime: "4-8 weeks", speed: "medium", difficulty: "difficult", cost: "CHF 65 - 150", requirements: ["Job offer from Swiss employer", "Employer must prove no suitable local candidate", "Relevant qualifications", "Adequate housing"], immigrationUrl: "https://www.sem.admin.ch/sem/en/home/themen/arbeit.html", notes: "Quota system for non-EU nationals. High salary expectations." },
  { name: "Ireland", flag: "IE", region: "europe", permitTypes: ["Critical Skills", "General Work", "Intra-Company Transfer", "Dependant/Partner"], processingTime: "4-8 weeks", speed: "medium", difficulty: "moderate", cost: "EUR 1,000", requirements: ["Job offer with minimum salary", "Employer registered in Ireland", "Relevant qualifications", "Private health insurance"], immigrationUrl: "https://enterprise.gov.ie/en/what-we-do/workplace-and-skills/employment-permits/", notes: "Critical Skills permits for in-demand occupations. No labor market test." },
  { name: "Sweden", flag: "SE", region: "europe", permitTypes: ["Work Permit", "EU Blue Card", "Researcher", "Self-employed"], processingTime: "1-4 months", speed: "medium", difficulty: "moderate", cost: "SEK 2,000", requirements: ["Job offer with terms equal to Swedish standards", "Minimum salary SEK 13,000/month", "Health insurance from employer", "Valid passport"], immigrationUrl: "https://www.migrationsverket.se/English/Private-individuals/Working-in-Sweden.html", notes: "Employer must advertise position in EU for 10 days. Strong worker protections." },
  { name: "Norway", flag: "NO", region: "europe", permitTypes: ["Skilled Worker", "Seasonal Worker", "Self-employed"], processingTime: "1-3 months", speed: "medium", difficulty: "moderate", cost: "NOK 6,300", requirements: ["Job offer with Norwegian conditions", "Relevant qualifications or experience", "Full-time position (min 80%)", "Adequate housing"], immigrationUrl: "https://www.udi.no/en/want-to-apply/work-immigration/", notes: "Not EU but EEA. High cost of living offset by strong social benefits." },
  { name: "Denmark", flag: "DK", region: "europe", permitTypes: ["Pay Limit Scheme", "Positive List", "Fast-track", "Startup"], processingTime: "1-2 months", speed: "medium", difficulty: "moderate", cost: "DKK 4,665", requirements: ["Job offer meeting salary threshold", "Relevant qualifications", "Valid passport", "Proof of accommodation"], immigrationUrl: "https://www.nyidanmark.dk/en-GB/You-want-to-apply/Work", notes: "Pay Limit: DKK 475,000+ annual salary. Fast-track for certified companies." },
  { name: "Spain", flag: "ES", region: "europe", permitTypes: ["Work Authorization", "Highly Qualified", "ICT", "Entrepreneur"], processingTime: "1-3 months", speed: "medium", difficulty: "moderate", cost: "EUR 80 - 400", requirements: ["Job offer from Spanish employer", "Labor market situation considered", "Relevant qualifications", "No criminal record"], immigrationUrl: "https://www.exteriores.gob.es/en/Paginas/index.aspx", notes: "Startup law passed 2022 with digital nomad and entrepreneur provisions." },
  { name: "Italy", flag: "IT", region: "europe", permitTypes: ["Nulla Osta", "EU Blue Card", "Self-employed", "Seasonal"], processingTime: "2-4 months", speed: "medium", difficulty: "moderate", cost: "EUR 80 - 200", requirements: ["Work authorization (Nulla Osta)", "Annual quota allocation", "Employer sponsorship", "Adequate accommodation"], immigrationUrl: "https://www.esteri.it/en/servizi-consolari-e-visti/", notes: "Annual quota (Decreto Flussi) limits non-EU work permits. Apply early." },
  { name: "Portugal", flag: "PT", region: "europe", permitTypes: ["Work Visa", "Tech Visa", "D7 Passive Income", "Digital Nomad (D8)"], processingTime: "2-3 months", speed: "medium", difficulty: "easy", cost: "EUR 90 - 170", requirements: ["Job offer or self-employment proof", "Valid passport", "Criminal record certificate", "Health insurance"], immigrationUrl: "https://www.sef.pt/en/pages/conteudo-detalhe.aspx?nID=21", notes: "Tech Visa fast-track for certified tech companies. NHR tax benefits." },
  { name: "Australia", flag: "AU", region: "asia-pacific", permitTypes: ["TSS 482", "Skilled Independent 189", "Employer Sponsored 494", "Working Holiday"], processingTime: "1-6 months", speed: "medium", difficulty: "moderate", cost: "AUD 330 - $4,115", requirements: ["Skills assessment", "Occupation on skilled list", "English proficiency (IELTS 5+)", "Health and character checks"], immigrationUrl: "https://immi.homeaffairs.gov.au/visas/working-in-australia", notes: "Points-tested system for permanent migration. Regional visas offer pathway." },
  { name: "New Zealand", flag: "NZ", region: "asia-pacific", permitTypes: ["Essential Skills", "Skilled Migrant", "Working Holiday", "Specific Purpose"], processingTime: "2-6 months", speed: "medium", difficulty: "moderate", cost: "NZD 495 - $680", requirements: ["Job offer from accredited employer", "Relevant skills/qualifications", "Health and character requirements", "English proficiency"], immigrationUrl: "https://www.immigration.govt.nz/new-zealand-visas/options/work", notes: "Accredited Employer Work Visa (AEWV) is the main temporary work visa." },
  { name: "Japan", flag: "JP", region: "asia-pacific", permitTypes: ["Engineer/Specialist", "Highly Skilled Professional", "Specified Skilled Worker", "Intra-Company Transfer"], processingTime: "1-3 months", speed: "medium", difficulty: "moderate", cost: "JPY 4,000 - 6,000", requirements: ["Job offer from Japanese company", "Relevant degree or 10+ years experience", "Certificate of Eligibility from immigration", "Valid passport"], immigrationUrl: "https://www.moj.go.jp/isa/applications/procedures/index.html", notes: "Highly Skilled Professional visa offers fast-track to permanent residence." },
  { name: "South Korea", flag: "KR", region: "asia-pacific", permitTypes: ["E-7 Professional", "D-8 Corporate Investment", "E-1 to E-5 Specialized", "H-1 Working Holiday"], processingTime: "2-4 weeks", speed: "fast", difficulty: "moderate", cost: "KRW 60,000 - 130,000", requirements: ["Employment contract", "Employer sponsorship", "Relevant qualifications", "Criminal background check"], immigrationUrl: "https://www.visa.go.kr/", notes: "E-7 visa is the main work visa. Points system for residence conversion." },
  { name: "Singapore", flag: "SG", region: "asia-pacific", permitTypes: ["Employment Pass", "S Pass", "EntrePass", "ONE Pass"], processingTime: "3-8 weeks", speed: "fast", difficulty: "moderate", cost: "SGD 105 - 225", requirements: ["Job offer from Singapore employer", "Minimum salary (SGD 5,000+)", "Acceptable qualifications", "COMPASS framework assessment"], immigrationUrl: "https://www.mom.gov.sg/passes-and-permits", notes: "COMPASS points system since 2023. ONE Pass for top talent earning SGD 30,000+/month." },
  { name: "Hong Kong", flag: "HK", region: "asia-pacific", permitTypes: ["General Employment", "Top Talent Pass", "IANG", "Technology Talent"], processingTime: "4-6 weeks", speed: "fast", difficulty: "easy", cost: "HKD 230", requirements: ["Job offer from HK employer (most visas)", "Relevant qualifications or experience", "No criminal record", "Employer must justify hiring non-local"], immigrationUrl: "https://www.immd.gov.hk/eng/services/visas/employment.html", notes: "Top Talent Pass for graduates of top-100 universities or high earners." },
  { name: "UAE", flag: "AE", region: "middle-east", permitTypes: ["Employment Visa", "Golden Visa", "Green Visa", "Freelance Permit"], processingTime: "2-4 weeks", speed: "fast", difficulty: "easy", cost: "AED 3,000 - 5,000", requirements: ["Employment contract (employer-sponsored)", "Medical fitness test", "Emirates ID application", "Employer handles most processing"], immigrationUrl: "https://u.ae/en/information-and-services/visa-and-emirates-id", notes: "Golden Visa 10-year for investors, entrepreneurs, and skilled professionals." },
  { name: "Saudi Arabia", flag: "SA", region: "middle-east", permitTypes: ["Work Visa (Iqama)", "Premium Residency", "Seasonal Work"], processingTime: "2-6 weeks", speed: "fast", difficulty: "moderate", cost: "SAR 2,000 - 5,000", requirements: ["Employer sponsorship", "Medical examination", "Attested educational certificates", "No criminal record"], immigrationUrl: "https://www.moi.gov.sa/wps/portal/Home/sectors/passports/!ut/p/z0/04_Sj9CPykssy0xPLMnMz0vMAfIjo8ziPQO8nT28TQz8LAKDnA0czTwDLJ29fYwN3E30C7IdFQE7XFNI/", notes: "Kafala (sponsorship) system. Premium Residency for high-net-worth individuals." },
  { name: "Qatar", flag: "QA", region: "middle-east", permitTypes: ["Work Visa", "Permanent Residency"], processingTime: "2-4 weeks", speed: "fast", difficulty: "moderate", cost: "QAR 200 - 500", requirements: ["Job offer from Qatari employer", "Medical examination", "Educational certificate attestation", "Employer sponsorship"], immigrationUrl: "https://portal.moi.gov.qa/wps/portal/MOI/home/immigration", notes: "Permanent residency now available for qualifying expats after 20+ years." },
  { name: "India", flag: "IN", region: "asia-pacific", permitTypes: ["Employment Visa", "Business Visa", "Project Visa"], processingTime: "2-4 weeks", speed: "fast", difficulty: "easy", cost: "USD 100 - 300", requirements: ["Employment contract with Indian company", "Minimum salary USD 25,000/year", "Relevant qualifications", "Company registration in India"], immigrationUrl: "https://www.mea.gov.in/visa-faqs.htm", notes: "Employment visa requires salary above USD 25,000/year (some exceptions)." },
  { name: "South Africa", flag: "ZA", region: "africa", permitTypes: ["General Work Visa", "Critical Skills Visa", "Intra-Company Transfer", "Corporate Visa"], processingTime: "4-8 weeks", speed: "medium", difficulty: "moderate", cost: "ZAR 1,520", requirements: ["Proof that position can't be filled locally", "Relevant qualifications (SAQA evaluation)", "Criminal clearance from all countries lived in", "Medical certificate"], immigrationUrl: "https://www.dha.gov.za/index.php/immigration-services", notes: "Critical Skills visa for occupations on the Critical Skills List. No job offer needed." },
  { name: "Kenya", flag: "KE", region: "africa", permitTypes: ["Class D Work Permit", "Class G Specific Trade", "Special Pass"], processingTime: "4-8 weeks", speed: "medium", difficulty: "moderate", cost: "KES 200,000 - 500,000", requirements: ["Employer must demonstrate need for foreign worker", "Relevant qualifications and experience", "Valid passport", "Company registration in Kenya"], immigrationUrl: "https://fns.immigration.go.ke/", notes: "ePermit system for online applications. High permit fees." },
  { name: "Nigeria", flag: "NG", region: "africa", permitTypes: ["STR Visa", "TWP (Temporary Work Permit)", "Combined Expatriate Residence Permit"], processingTime: "2-6 weeks", speed: "medium", difficulty: "moderate", cost: "USD 200 - 2,000", requirements: ["Employer sponsorship", "Expatriate quota approval", "Medical certificate", "Valid passport with 6+ months validity"], immigrationUrl: "https://immigration.gov.ng/", notes: "Expatriate quota must be obtained by employer before work permit application." },
  { name: "Brazil", flag: "BR", region: "latin-america", permitTypes: ["Work Visa (VITEM V)", "Digital Nomad", "Investor Visa"], processingTime: "2-4 weeks", speed: "fast", difficulty: "easy", cost: "BRL 400 - 1,200", requirements: ["Job offer from Brazilian company", "Employer must register with Ministry of Justice", "Relevant qualifications", "Clean criminal record"], immigrationUrl: "https://www.gov.br/mre/en", notes: "Digital nomad visa available since 2022 for remote workers." },
  { name: "Mexico", flag: "MX", region: "latin-america", permitTypes: ["Temporary Resident (Work)", "Permanent Resident", "NAFTA/USMCA"], processingTime: "2-4 weeks", speed: "fast", difficulty: "easy", cost: "MXN 3,000 - 5,000", requirements: ["Job offer from Mexican employer", "Employer must register with INM", "Valid passport", "Application at Mexican consulate"], immigrationUrl: "https://www.gob.mx/inm", notes: "USMCA provisions for professionals from US and Canada. Relatively straightforward." },
  { name: "Chile", flag: "CL", region: "latin-america", permitTypes: ["Work Visa", "Temporary Residence", "Tech Visa"], processingTime: "2-6 weeks", speed: "medium", difficulty: "easy", cost: "USD 100 - 300", requirements: ["Employment contract", "Employer registration", "Criminal background check", "Valid passport"], immigrationUrl: "https://serviciomigraciones.cl/", notes: "Tech Visa program for fast-track processing for tech workers and startups." },
  { name: "Colombia", flag: "CO", region: "latin-america", permitTypes: ["M-Type Visa (Work)", "V-Type Visitor", "Digital Nomad"], processingTime: "1-2 weeks", speed: "fast", difficulty: "easy", cost: "USD 52 - 177", requirements: ["Employment contract or work proof", "Valid passport", "Health insurance", "Criminal record certificate"], immigrationUrl: "https://www.cancilleria.gov.co/en/procedures_services/visas", notes: "Digital nomad visa valid for 2 years. Very affordable application fees." },
];

export default function WorkPermitGuide() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeRegion, setActiveRegion] = useState("all");
  const [activeSpeed, setActiveSpeed] = useState("all");
  const [activeDifficulty, setActiveDifficulty] = useState("all");

  const filtered = countries.filter((c) => {
    const matchSearch = !searchQuery || c.name.toLowerCase().includes(searchQuery.toLowerCase()) || c.permitTypes.some((p) => p.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchRegion = activeRegion === "all" || c.region === activeRegion;
    const matchSpeed = activeSpeed === "all" || c.speed === activeSpeed;
    const matchDifficulty = activeDifficulty === "all" || c.difficulty === activeDifficulty;
    return matchSearch && matchRegion && matchSpeed && matchDifficulty;
  });

  function getDifficultyColor(d: string) {
    if (d === "easy") return "bg-green-500/10 text-green-700";
    if (d === "moderate") return "bg-amber-500/10 text-amber-700";
    return "bg-red-500/10 text-red-700";
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 mb-4">
          <Shield className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-work-permit-title">
          Work Permit Guide
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Country-by-country work permit requirements, processing times, costs, and links
          to official immigration offices. Plan your international career move.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>{countries.length} Countries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <FileText className="h-4 w-4" />
            <span>100+ Permit Types</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock className="h-4 w-4" />
            <span>Processing Times</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search countries or permit types..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-work-permit-search"
          />
        </div>
        <div className="space-y-2">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Region</label>
            <div className="flex flex-wrap gap-2">
              {regionFilters.map((r) => (
                <Button key={r.value} variant={activeRegion === r.value ? "secondary" : "outline"} size="sm" onClick={() => setActiveRegion(r.value)} className="toggle-elevate" data-testid={`button-region-${r.value}`}>
                  {r.label}
                </Button>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap gap-4">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Processing Speed</label>
              <div className="flex flex-wrap gap-2">
                {speedFilters.map((s) => (
                  <Button key={s.value} variant={activeSpeed === s.value ? "secondary" : "outline"} size="sm" onClick={() => setActiveSpeed(s.value)} className="toggle-elevate" data-testid={`button-speed-${s.value}`}>
                    {s.label}
                  </Button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Difficulty</label>
              <div className="flex flex-wrap gap-2">
                {difficultyFilters.map((d) => (
                  <Button key={d.value} variant={activeDifficulty === d.value ? "secondary" : "outline"} size="sm" onClick={() => setActiveDifficulty(d.value)} className="toggle-elevate" data-testid={`button-difficulty-${d.value}`}>
                    {d.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} countr{filtered.length !== 1 ? "ies" : "y"}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((country) => (
          <Card key={country.name} className="p-5 hover-elevate" data-testid={`card-country-${country.flag.toLowerCase()}`}>
            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center shrink-0 text-lg font-bold">
                {country.flag}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-sm">{country.name}</h3>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {country.permitTypes.map((p) => (
                    <Badge key={p} variant="outline" className="text-[10px]">{p}</Badge>
                  ))}
                </div>
              </div>
              <Badge className={`text-[10px] shrink-0 ${getDifficultyColor(country.difficulty)}`}>
                {country.difficulty}
              </Badge>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="p-2 rounded-md bg-muted/50 text-center">
                <Clock className="h-3.5 w-3.5 mx-auto mb-0.5 text-muted-foreground" />
                <div className="text-[10px] text-muted-foreground">Processing</div>
                <div className="text-xs font-medium">{country.processingTime}</div>
              </div>
              <div className="p-2 rounded-md bg-muted/50 text-center">
                <DollarSign className="h-3.5 w-3.5 mx-auto mb-0.5 text-muted-foreground" />
                <div className="text-[10px] text-muted-foreground">Cost</div>
                <div className="text-xs font-medium">{country.cost}</div>
              </div>
              <div className="p-2 rounded-md bg-muted/50 text-center">
                <Globe className="h-3.5 w-3.5 mx-auto mb-0.5 text-muted-foreground" />
                <div className="text-[10px] text-muted-foreground">Region</div>
                <div className="text-xs font-medium">{regionFilters.find((r) => r.value === country.region)?.label}</div>
              </div>
            </div>

            <div className="mb-3">
              <div className="text-xs font-medium mb-1.5">Key Requirements:</div>
              <div className="space-y-1">
                {country.requirements.map((req, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <CheckCircle2 className="h-3 w-3 text-green-500 shrink-0 mt-0.5" />
                    <span className="text-[11px] text-muted-foreground">{req}</span>
                  </div>
                ))}
              </div>
            </div>

            {country.notes && (
              <div className="flex items-start gap-1.5 mb-3 p-2 rounded-md bg-amber-500/5">
                <AlertTriangle className="h-3 w-3 text-amber-500 shrink-0 mt-0.5" />
                <span className="text-[10px] text-muted-foreground">{country.notes}</span>
              </div>
            )}

            <a href={country.immigrationUrl} target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline" className="w-full" data-testid={`button-immigration-${country.flag.toLowerCase()}`}>
                <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                Official Immigration Office
              </Button>
            </a>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card className="p-12 text-center">
          <Globe className="h-12 w-12 mx-auto mb-3 text-muted-foreground opacity-30" />
          <p className="text-sm text-muted-foreground">No countries match your filters. Try adjusting your search.</p>
        </Card>
      )}

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://devglobaljobs.com/tools" },
              { "@type": "ListItem", position: 3, name: "Work Permit Guide", item: "https://devglobaljobs.com/tools/work-permit-guide" },
            ],
          }),
        }}
      />
    </div>
  );
}
