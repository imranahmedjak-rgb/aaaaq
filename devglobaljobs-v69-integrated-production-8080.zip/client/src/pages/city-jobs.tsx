import { useState, useEffect, useRef } from "react";
import { useInfiniteQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { MapPin, Search, RefreshCw, ArrowUp, Building2, Globe } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { JobCard } from "@/components/job-card";
import type { Job } from "@shared/schema";

interface CityJobsProps {
  city: string;
}

interface CityJobsPage {
  jobs: Job[];
  total: number;
  hasMore: boolean;
  city: { name: string; slug: string };
}

export default function CityJobs({ city }: CityJobsProps) {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const queryClient = useQueryClient();
  const sentinelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 350);
    return () => clearTimeout(t);
  }, [search]);

  const cityDisplay = city.replace(/-/g, " ").split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading, refetch } = useInfiniteQuery<CityJobsPage>({
    queryKey: ["/api/jobs/city", city, debouncedSearch],
    queryFn: async ({ pageParam = 0 }) => {
      const params = new URLSearchParams({ limit: "30", offset: String(pageParam) });
      if (debouncedSearch) params.set("search", debouncedSearch);
      const res = await fetch(`/api/jobs/city/${encodeURIComponent(city)}?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to load city jobs");
      return res.json();
    },
    getNextPageParam: (last: CityJobsPage) => last.hasMore ? (last.jobs.length === 0 ? undefined : undefined) : undefined,
    initialPageParam: 0,
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => { if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) fetchNextPage(); },
      { rootMargin: "400px" }
    );
    const sentinel = sentinelRef.current;
    if (sentinel) observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 600);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const pageTitle = `Jobs in ${cityDisplay} | International Careers — Dev Global Jobs`;
    const pageDesc = `Browse verified job opportunities in ${cityDisplay}. Find international, remote, tech, finance, and professional roles from top employers hiring in ${cityDisplay}. Updated daily.`;
    document.title = pageTitle;
    const descEl = document.querySelector("meta[name='description']");
    if (descEl) descEl.setAttribute("content", pageDesc);
    const ogTitle = document.querySelector("meta[property='og:title']");
    if (ogTitle) ogTitle.setAttribute("content", pageTitle);
    const breadcrumb = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://devglobaljobs.com/" },
        { "@type": "ListItem", "position": 2, "name": "All Jobs", "item": "https://devglobaljobs.com/jobs/all" },
        { "@type": "ListItem", "position": 3, "name": `Jobs in ${cityDisplay}`, "item": `https://devglobaljobs.com/jobs/city/${city}` },
      ],
    };
    const existing = document.getElementById("city-breadcrumb-jsonld");
    if (existing) existing.remove();
    const script = document.createElement("script");
    script.id = "city-breadcrumb-jsonld";
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(breadcrumb);
    document.head.appendChild(script);
    return () => { document.getElementById("city-breadcrumb-jsonld")?.remove(); };
  }, [city, cityDisplay]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["/api/jobs/city", city] });
    await refetch();
    setIsRefreshing(false);
  };

  const allJobs = data?.pages.flatMap(p => p.jobs) ?? [];
  const total = data?.pages[0]?.total ?? 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
          <Link href="/" className="hover:text-primary transition-colors">Home</Link>
          <span>/</span>
          <Link href="/jobs/all" className="hover:text-primary transition-colors">All Jobs</Link>
          <span>/</span>
          <span className="text-foreground font-medium">Jobs in {cityDisplay}</span>
        </div>
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
              <MapPin className="h-7 w-7 text-primary shrink-0" />
              Jobs in {cityDisplay}
            </h1>
            <p className="text-muted-foreground mt-2">
              {isLoading ? "Loading..." : `${total.toLocaleString()} verified jobs in ${cityDisplay} from international employers`}
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing} className="shrink-0">
            <RefreshCw className={`h-4 w-4 mr-1.5 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        <div className="mt-4 relative max-w-lg">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search jobs in ${cityDisplay}...`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-28 rounded-xl bg-muted/50 animate-pulse" />
          ))}
        </div>
      ) : allJobs.length === 0 ? (
        <div className="text-center py-20">
          <MapPin className="h-14 w-14 text-muted-foreground/40 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">No jobs found in {cityDisplay}</h2>
          <p className="text-muted-foreground mb-6">Try browsing all international jobs or another city</p>
          <Link href="/jobs/all">
            <Button>Browse All Jobs</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {allJobs.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
          <div ref={sentinelRef} className="h-4" />
          {isFetchingNextPage && (
            <div className="space-y-3 mt-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-28 rounded-xl bg-muted/50 animate-pulse" />
              ))}
            </div>
          )}
          {!hasNextPage && allJobs.length > 0 && (
            <p className="text-center text-sm text-muted-foreground py-6">
              All {allJobs.length} jobs in {cityDisplay} loaded
            </p>
          )}
        </div>
      )}

      <div className="mt-14 pt-8 border-t border-border">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Globe className="h-5 w-5 text-primary" />
          Explore Other Major Cities
        </h2>
        <div className="flex flex-wrap gap-2">
          {[
            "london","new-york","dubai","toronto","sydney","berlin","paris","amsterdam",
            "singapore","tokyo","zurich","stockholm","geneva","vienna","brussels",
            "melbourne","vancouver","boston","san-francisco","chicago","dublin",
            "madrid","barcelona","oslo","copenhagen","helsinki","seoul","hong-kong",
            "kuala-lumpur","bangkok","montreal","lisbon","abu-dhabi","warsaw","prague"
          ].filter(c => c !== city).slice(0, 24).map(c => {
            const label = c.replace(/-/g, " ").split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
            return (
              <Link key={c} href={`/jobs/city/${c}`}>
                <Badge variant="outline" className="cursor-pointer hover:bg-primary/10 hover:border-primary/30 transition-colors text-xs px-3 py-1">
                  <Building2 className="h-3 w-3 mr-1" />
                  {label}
                </Badge>
              </Link>
            );
          })}
        </div>
      </div>

      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-50 p-3 bg-primary text-primary-foreground rounded-full shadow-lg hover:bg-primary/90 transition-all"
          aria-label="Scroll to top"
        >
          <ArrowUp className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}
