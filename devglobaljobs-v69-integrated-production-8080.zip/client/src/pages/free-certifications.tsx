import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Award, ExternalLink, Search, Shield, Monitor, Code,
  TrendingUp, Globe, Sparkles, CheckCircle2, Clock, Briefcase,
} from "lucide-react";

const categories = [
  { id: "all", label: "All" },
  { id: "tech", label: "Technology" },
  { id: "cloud", label: "Cloud & DevOps" },
  { id: "data", label: "Data & AI" },
  { id: "business", label: "Business" },
  { id: "marketing", label: "Marketing" },
  { id: "pm", label: "Project Management" },
  { id: "cyber", label: "Cybersecurity" },
];

const certifications = [
  {
    name: "Google IT Support Professional Certificate",
    provider: "Google (via Coursera)",
    url: "https://www.coursera.org/professional-certificates/google-it-support",
    category: "tech",
    duration: "6 months",
    tags: ["Entry-Level", "Help Desk", "Networking"],
    description: "Prepare for an entry-level IT support role. No experience needed. Google's own training program with hands-on labs.",
    free: "Financial Aid Available",
  },
  {
    name: "Google Data Analytics Certificate",
    provider: "Google (via Coursera)",
    url: "https://www.coursera.org/professional-certificates/google-data-analytics",
    category: "data",
    duration: "6 months",
    tags: ["Data Analytics", "SQL", "Tableau"],
    description: "Learn in-demand data analytics skills including SQL, R programming, data visualization with Tableau.",
    free: "Financial Aid Available",
  },
  {
    name: "Google Project Management Certificate",
    provider: "Google (via Coursera)",
    url: "https://www.coursera.org/professional-certificates/google-project-management",
    category: "pm",
    duration: "6 months",
    tags: ["Agile", "Scrum", "Planning"],
    description: "Learn project management from Google. No experience needed. Prepares you for the PMI CAPM exam.",
    free: "Financial Aid Available",
  },
  {
    name: "Google UX Design Certificate",
    provider: "Google (via Coursera)",
    url: "https://www.coursera.org/professional-certificates/google-ux-design",
    category: "tech",
    duration: "6 months",
    tags: ["UX Design", "Figma", "Portfolio"],
    description: "Design user experiences for products. Build a professional UX portfolio with 3 real-world projects.",
    free: "Financial Aid Available",
  },
  {
    name: "Google Cybersecurity Certificate",
    provider: "Google (via Coursera)",
    url: "https://www.coursera.org/professional-certificates/google-cybersecurity",
    category: "cyber",
    duration: "6 months",
    tags: ["SIEM", "Python", "Linux"],
    description: "Get job-ready for cybersecurity roles. Learn SIEM tools, Python, Linux, and network security.",
    free: "Financial Aid Available",
  },
  {
    name: "IBM Data Science Professional Certificate",
    provider: "IBM (via Coursera)",
    url: "https://www.coursera.org/professional-certificates/ibm-data-science",
    category: "data",
    duration: "5 months",
    tags: ["Python", "Machine Learning", "SQL"],
    description: "Master data science, machine learning and AI. Build a portfolio with 10 applied learning projects.",
    free: "Financial Aid Available",
  },
  {
    name: "AWS Cloud Practitioner Essentials",
    provider: "Amazon Web Services",
    url: "https://explore.skillbuilder.aws/learn/course/external/view/elearning/134/aws-cloud-practitioner-essentials",
    category: "cloud",
    duration: "6 hours",
    tags: ["AWS", "Cloud Basics", "Free"],
    description: "Free foundational AWS cloud knowledge. Understand AWS services, security, architecture and pricing.",
    free: "100% Free",
  },
  {
    name: "Microsoft Azure Fundamentals (AZ-900)",
    provider: "Microsoft Learn",
    url: "https://learn.microsoft.com/en-us/certifications/azure-fundamentals/",
    category: "cloud",
    duration: "10 hours",
    tags: ["Azure", "Cloud", "Free Training"],
    description: "Learn cloud concepts, Azure services, security, privacy, and pricing. Free training, exam vouchers sometimes available.",
    free: "Free Training",
  },
  {
    name: "HubSpot Inbound Marketing Certification",
    provider: "HubSpot Academy",
    url: "https://academy.hubspot.com/courses/inbound-marketing",
    category: "marketing",
    duration: "5 hours",
    tags: ["Inbound", "Content", "SEO"],
    description: "Learn inbound marketing strategy, content creation, social promotion. Industry-recognized free certification.",
    free: "100% Free",
  },
  {
    name: "HubSpot Content Marketing Certification",
    provider: "HubSpot Academy",
    url: "https://academy.hubspot.com/courses/content-marketing",
    category: "marketing",
    duration: "6 hours",
    tags: ["Content Strategy", "Blogging", "Video"],
    description: "Master content creation, blogging, video marketing and content promotion strategies.",
    free: "100% Free",
  },
  {
    name: "Google Ads Certification",
    provider: "Google Skillshop",
    url: "https://skillshop.exceedlms.com/student/catalog/list?category_ids=53-google-ads-certifications",
    category: "marketing",
    duration: "Self-Paced",
    tags: ["Google Ads", "PPC", "Display"],
    description: "Official Google Ads certification covering Search, Display, Video, Shopping and Apps campaigns.",
    free: "100% Free",
  },
  {
    name: "Google Analytics Certification",
    provider: "Google Skillshop",
    url: "https://skillshop.exceedlms.com/student/catalog/list?category_ids=6431-google-analytics-702",
    category: "marketing",
    duration: "Self-Paced",
    tags: ["GA4", "Web Analytics", "Reports"],
    description: "Learn Google Analytics 4. Understand data collection, reporting, conversion tracking and audience insights.",
    free: "100% Free",
  },
  {
    name: "Meta Social Media Marketing Certificate",
    provider: "Meta (via Coursera)",
    url: "https://www.coursera.org/professional-certificates/facebook-social-media-marketing",
    category: "marketing",
    duration: "7 months",
    tags: ["Social Media", "Facebook", "Instagram"],
    description: "Learn social media management, advertising on Facebook/Instagram, and community management from Meta.",
    free: "Financial Aid Available",
  },
  {
    name: "Cisco Networking Academy",
    provider: "Cisco",
    url: "https://www.netacad.com/courses/all-courses",
    category: "tech",
    duration: "Varies",
    tags: ["Networking", "CCNA Prep", "IoT"],
    description: "Free courses in networking, cybersecurity, programming. Prepare for Cisco CCNA certification.",
    free: "Free Courses",
  },
  {
    name: "MongoDB University",
    provider: "MongoDB",
    url: "https://learn.mongodb.com",
    category: "tech",
    duration: "Self-Paced",
    tags: ["NoSQL", "Database", "Developer"],
    description: "Free MongoDB courses covering database administration, application development, and data modeling.",
    free: "100% Free",
  },
  {
    name: "Salesforce Administrator Cert Prep",
    provider: "Salesforce Trailhead",
    url: "https://trailhead.salesforce.com/en/content/learn/trails/force_com_admin_beginner",
    category: "business",
    duration: "20 hours",
    tags: ["CRM", "Salesforce", "Admin"],
    description: "Free training to prepare for Salesforce Administrator certification. Hands-on projects with badges.",
    free: "100% Free",
  },
  {
    name: "Python for Everybody",
    provider: "University of Michigan (Coursera)",
    url: "https://www.coursera.org/specializations/python",
    category: "tech",
    duration: "8 months",
    tags: ["Python", "Web Scraping", "Databases"],
    description: "Learn Python programming from scratch. Cover data structures, web scraping, databases, and data visualization.",
    free: "Free Audit",
  },
  {
    name: "Stanford Machine Learning",
    provider: "Stanford (Coursera)",
    url: "https://www.coursera.org/specializations/machine-learning-introduction",
    category: "data",
    duration: "3 months",
    tags: ["ML", "Andrew Ng", "Deep Learning"],
    description: "Andrew Ng's legendary machine learning course. Learn supervised/unsupervised learning, neural networks.",
    free: "Free Audit",
  },
  {
    name: "CompTIA ITF+ Self-Study",
    provider: "CompTIA",
    url: "https://www.comptia.org/certifications/it-fundamentals",
    category: "tech",
    duration: "Self-Paced",
    tags: ["IT Fundamentals", "Entry Level", "Resources"],
    description: "Free study resources for IT fundamentals. Understanding hardware, software, networking and security basics.",
    free: "Free Resources",
  },
  {
    name: "Scrum.org Open Assessments",
    provider: "Scrum.org",
    url: "https://www.scrum.org/open-assessments",
    category: "pm",
    duration: "Self-Paced",
    tags: ["Scrum", "Agile", "Practice Tests"],
    description: "Free Scrum assessments and learning resources. Practice for Professional Scrum Master certification.",
    free: "100% Free",
  },
];

export default function FreeCertifications() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = certifications.filter((c) => {
    const matchesCat = activeCategory === "all" || c.category === activeCategory;
    const matchesSearch = !searchQuery ||
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.provider.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 mb-4">
          <Award className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-certifications-title">
          Free Professional Certifications
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Earn industry-recognized certifications from Google, IBM, AWS, Microsoft, HubSpot and more -- all free or with
          financial aid. Boost your resume and stand out to employers worldwide.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Award className="h-4 w-4" />
            <span>{certifications.length} Certifications</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Shield className="h-4 w-4" />
            <span>Industry Recognized</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Briefcase className="h-4 w-4" />
            <span>Career Boosting</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search certifications, providers, or skills..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-certs-search"
          />
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {categories.map((cat) => (
            <Button
              key={cat.id}
              variant={activeCategory === cat.id ? "secondary" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`button-certs-filter-${cat.id}`}
              className="toggle-elevate"
            >
              {cat.label}
            </Button>
          ))}
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} certification{filtered.length !== 1 ? "s" : ""}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((cert) => (
          <Card key={cert.name} className="p-5 flex flex-col gap-3 hover-elevate" data-testid={`card-cert-${cert.name.toLowerCase().replace(/[\s()]/g, "-").substring(0, 40)}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <h3 className="font-semibold text-sm leading-snug">{cert.name}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">{cert.provider}</p>
              </div>
              <Badge variant="secondary" className="shrink-0 text-[10px]">
                {cert.free}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed flex-1">{cert.description}</p>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{cert.duration}</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {cert.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-[10px] font-normal">
                  {tag}
                </Badge>
              ))}
            </div>
            <a href={cert.url} target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline" className="w-full" data-testid={`button-cert-visit-${cert.name.toLowerCase().replace(/[\s()]/g, "-").substring(0, 30)}`}>
                <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                Get Certified
              </Button>
            </a>
          </Card>
        ))}
      </div>

      <Card className="mt-8 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
            <Sparkles className="h-5 w-5 text-amber-600" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">Pro Tip: Financial Aid</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Many Coursera certificates offer full financial aid -- simply apply when enrolling and explain your situation.
              Approval typically takes 2 weeks. Google, HubSpot, and Salesforce certifications are completely free with no application needed.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
