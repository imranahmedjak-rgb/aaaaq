import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Globe, LayoutDashboard, Briefcase, PlusCircle, Users,
  LogOut, Search, Trash2, RefreshCw, Star, TrendingUp,
  Database, Mail, ChevronLeft, ChevronRight, CheckCircle,
  AlertCircle, Clock, Filter, Download, Eye, Building2,
  Zap, Activity, MenuIcon, X, FileText, PenSquare, BookOpen, Info
} from "lucide-react";

const CATEGORIES = [
  "un","ngo","remote","international","technology","healthcare",
  "business","education","engineering","creative","sales","gig","youth"
];

const COUNTRIES = [
  { code: "AF", name: "Afghanistan" }, { code: "AL", name: "Albania" }, { code: "DZ", name: "Algeria" },
  { code: "AR", name: "Argentina" }, { code: "AU", name: "Australia" }, { code: "AT", name: "Austria" },
  { code: "AZ", name: "Azerbaijan" }, { code: "BH", name: "Bahrain" }, { code: "BD", name: "Bangladesh" },
  { code: "BE", name: "Belgium" }, { code: "BR", name: "Brazil" }, { code: "BG", name: "Bulgaria" },
  { code: "CA", name: "Canada" }, { code: "CL", name: "Chile" }, { code: "CN", name: "China" },
  { code: "CO", name: "Colombia" }, { code: "HR", name: "Croatia" }, { code: "CZ", name: "Czech Republic" },
  { code: "DK", name: "Denmark" }, { code: "EG", name: "Egypt" }, { code: "ET", name: "Ethiopia" },
  { code: "FI", name: "Finland" }, { code: "FR", name: "France" }, { code: "DE", name: "Germany" },
  { code: "GH", name: "Ghana" }, { code: "GR", name: "Greece" }, { code: "HK", name: "Hong Kong" },
  { code: "HU", name: "Hungary" }, { code: "IN", name: "India" }, { code: "ID", name: "Indonesia" },
  { code: "IE", name: "Ireland" }, { code: "IL", name: "Israel" }, { code: "IT", name: "Italy" },
  { code: "JP", name: "Japan" }, { code: "JO", name: "Jordan" }, { code: "KZ", name: "Kazakhstan" },
  { code: "KE", name: "Kenya" }, { code: "KW", name: "Kuwait" }, { code: "LB", name: "Lebanon" },
  { code: "MY", name: "Malaysia" }, { code: "MX", name: "Mexico" }, { code: "MA", name: "Morocco" },
  { code: "NL", name: "Netherlands" }, { code: "NZ", name: "New Zealand" }, { code: "NG", name: "Nigeria" },
  { code: "NO", name: "Norway" }, { code: "OM", name: "Oman" }, { code: "PK", name: "Pakistan" },
  { code: "PE", name: "Peru" }, { code: "PH", name: "Philippines" }, { code: "PL", name: "Poland" },
  { code: "PT", name: "Portugal" }, { code: "QA", name: "Qatar" }, { code: "RO", name: "Romania" },
  { code: "RU", name: "Russia" }, { code: "SA", name: "Saudi Arabia" }, { code: "SN", name: "Senegal" },
  { code: "SG", name: "Singapore" }, { code: "ZA", name: "South Africa" }, { code: "KR", name: "South Korea" },
  { code: "ES", name: "Spain" }, { code: "LK", name: "Sri Lanka" }, { code: "SE", name: "Sweden" },
  { code: "CH", name: "Switzerland" }, { code: "TW", name: "Taiwan" }, { code: "TZ", name: "Tanzania" },
  { code: "TH", name: "Thailand" }, { code: "TN", name: "Tunisia" }, { code: "TR", name: "Turkey" },
  { code: "UG", name: "Uganda" }, { code: "UA", name: "Ukraine" }, { code: "AE", name: "United Arab Emirates" },
  { code: "GB", name: "United Kingdom" }, { code: "US", name: "United States" }, { code: "UY", name: "Uruguay" },
  { code: "VN", name: "Vietnam" }, { code: "ZM", name: "Zambia" }, { code: "ZW", name: "Zimbabwe" },
  { code: "REMOTE", name: "Remote / Worldwide" },
];

const JOB_TYPES = ["Full-time","Part-time","Contract","Freelance","Internship","Volunteer","Remote"];

function formatDate(d: string | null | undefined) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString("en-GB", { day:"2-digit", month:"short", year:"numeric" });
}

function StatCard({ icon: Icon, label, value, color }: { icon: any; label: string; value: number | string; color: string }) {
  return (
    <Card className="p-5 bg-slate-800/60 border-slate-700">
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="h-6 w-6" />
        </div>
        <div>
          <p className="text-2xl font-bold text-white">{typeof value === "number" ? value.toLocaleString() : value}</p>
          <p className="text-xs text-slate-400">{label}</p>
        </div>
      </div>
    </Card>
  );
}

// ─── Overview Tab ─────────────────────────────────────────────────────────────
function OverviewTab() {
  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
    queryFn: () => apiRequest("GET", "/api/admin/stats").then(r => r.json()),
  });
  const { data: sources } = useQuery({
    queryKey: ["/api/admin/sources"],
    queryFn: () => apiRequest("GET", "/api/admin/sources").then(r => r.json()),
  });
  const { data: recentJobs } = useQuery({
    queryKey: ["/api/admin/jobs", "recent"],
    queryFn: () => apiRequest("GET", "/api/admin/jobs?page=1&limit=10").then(r => r.json()),
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-white mb-4">Dashboard Overview</h2>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard icon={Briefcase} label="Total Jobs" value={stats?.total ?? "—"} color="bg-blue-500/20 text-blue-400" />
          <StatCard icon={Activity} label="Added Today" value={stats?.today ?? "—"} color="bg-emerald-500/20 text-emerald-400" />
          <StatCard icon={Database} label="Sources" value={stats?.sources ?? "—"} color="bg-violet-500/20 text-violet-400" />
          <StatCard icon={Building2} label="Employer Posts" value={stats?.employer ?? "—"} color="bg-amber-500/20 text-amber-400" />
          <StatCard icon={Star} label="Featured Jobs" value={stats?.featured ?? "—"} color="bg-orange-500/20 text-orange-400" />
          <StatCard icon={Mail} label="Subscribers" value={stats?.subscribers ?? "—"} color="bg-rose-500/20 text-rose-400" />
        </div>
      </div>

      {sources && sources.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-slate-300 mb-3">Jobs by Source</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
            {sources.map((s: any) => (
              <div key={s.source} className="bg-slate-800/60 border border-slate-700 rounded-lg p-3 flex items-center justify-between">
                <span className="text-xs text-slate-300 font-medium truncate">{s.source}</span>
                <span className="text-xs font-bold text-white ml-2">{Number(s.count).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {recentJobs?.jobs && (
        <div>
          <h3 className="text-sm font-semibold text-slate-300 mb-3">Recent Jobs (Latest 10)</h3>
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700 bg-slate-900/40">
                    <th className="text-left p-3 text-xs text-slate-400 font-semibold">ID</th>
                    <th className="text-left p-3 text-xs text-slate-400 font-semibold">Title</th>
                    <th className="text-left p-3 text-xs text-slate-400 font-semibold">Source</th>
                    <th className="text-left p-3 text-xs text-slate-400 font-semibold">Category</th>
                    <th className="text-left p-3 text-xs text-slate-400 font-semibold">Posted</th>
                  </tr>
                </thead>
                <tbody>
                  {recentJobs.jobs.map((job: any) => (
                    <tr key={job.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                      <td className="p-3 text-slate-400 font-mono text-xs">#{job.id}</td>
                      <td className="p-3 text-white max-w-xs truncate">{job.title}</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded text-xs bg-blue-500/20 text-blue-300">{job.source}</span></td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded text-xs bg-slate-600 text-slate-300 capitalize">{job.category}</span></td>
                      <td className="p-3 text-slate-400 text-xs">{formatDate(job.postedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Jobs Tab ─────────────────────────────────────────────────────────────────
function JobsTab() {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [filterSource, setFilterSource] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const LIMIT = 50;

  const { data: sources } = useQuery({
    queryKey: ["/api/admin/sources"],
    queryFn: () => apiRequest("GET", "/api/admin/sources").then(r => r.json()),
  });

  const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
  if (search) params.set("search", search);
  if (filterSource) params.set("source", filterSource);
  if (filterCategory) params.set("category", filterCategory);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/jobs", page, search, filterSource, filterCategory],
    queryFn: () => apiRequest("GET", `/api/admin/jobs?${params}`).then(r => r.json()),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/jobs/${id}`).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      setDeletingId(null);
    },
    onError: () => setDeletingId(null),
  });

  const handleSearch = () => {
    setSearch(searchInput);
    setPage(1);
  };

  const handleClear = () => {
    setSearch("");
    setSearchInput("");
    setFilterSource("");
    setFilterCategory("");
    setPage(1);
  };

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <h2 className="text-lg font-bold text-white">All Jobs</h2>
        <div className="flex items-center gap-2">
          {data && <span className="text-xs text-slate-400">{data.total.toLocaleString()} total</span>}
          <Button size="sm" variant="outline" className="border-slate-600 text-slate-300 hover:text-white" onClick={() => refetch()}>
            <RefreshCw className="h-3.5 w-3.5 mr-1" />Refresh
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSearch()}
            placeholder="Search title, organization, location..."
            className="pl-9 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
          />
        </div>
        <Select value={filterSource || "all"} onValueChange={v => { setFilterSource(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-slate-700/50 border-slate-600 text-white">
            <SelectValue placeholder="All Sources" />
          </SelectTrigger>
          <SelectContent className="bg-slate-800 border-slate-600">
            <SelectItem value="all" className="text-slate-300">All Sources</SelectItem>
            {sources?.map((s: any) => (
              <SelectItem key={s.source} value={s.source} className="text-slate-300">{s.source} ({s.count})</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterCategory || "all"} onValueChange={v => { setFilterCategory(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-slate-700/50 border-slate-600 text-white">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent className="bg-slate-800 border-slate-600">
            <SelectItem value="all" className="text-slate-300">All Categories</SelectItem>
            {CATEGORIES.map(c => (
              <SelectItem key={c} value={c} className="text-slate-300 capitalize">{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-500">
          <Search className="h-4 w-4 mr-1" />Search
        </Button>
        {(search || filterSource || filterCategory) && (
          <Button onClick={handleClear} variant="outline" className="border-slate-600 text-slate-300">
            <X className="h-4 w-4 mr-1" />Clear
          </Button>
        )}
      </div>

      <div className="bg-slate-800/60 border border-slate-700 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center p-16">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700 bg-slate-900/40">
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold w-16">ID</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Title / Org</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Source</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Source ID</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Category</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Location</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Posted</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Flags</th>
                  <th className="p-3 w-16" />
                </tr>
              </thead>
              <tbody>
                {data?.jobs?.map((job: any) => (
                  <tr key={job.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors group">
                    <td className="p-3 text-slate-400 font-mono text-xs">#{job.id}</td>
                    <td className="p-3 max-w-[200px]">
                      <p className="text-white text-xs font-medium truncate">{job.title}</p>
                      <p className="text-slate-400 text-xs truncate">{job.organization}</p>
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-xs bg-blue-500/20 text-blue-300 whitespace-nowrap">{job.source}</span>
                    </td>
                    <td className="p-3 text-slate-500 font-mono text-xs max-w-[120px]">
                      <span className="truncate block">{job.sourceId || "—"}</span>
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-xs bg-slate-600 text-slate-300 capitalize">{job.category}</span>
                    </td>
                    <td className="p-3 text-slate-400 text-xs max-w-[100px]">
                      <span className="truncate block">{job.location || "—"}</span>
                    </td>
                    <td className="p-3 text-slate-400 text-xs whitespace-nowrap">{formatDate(job.postedAt)}</td>
                    <td className="p-3">
                      <div className="flex gap-1">
                        {job.featured && <span className="px-1.5 py-0.5 rounded text-xs bg-amber-500/20 text-amber-400">★</span>}
                        {job.isEmployerPosted && <span className="px-1.5 py-0.5 rounded text-xs bg-emerald-500/20 text-emerald-400">E</span>}
                      </div>
                    </td>
                    <td className="p-3">
                      {deletingId === job.id ? (
                        <div className="flex gap-1">
                          <button
                            onClick={() => { deleteMutation.mutate(job.id); }}
                            className="text-xs px-2 py-1 rounded bg-red-500 text-white hover:bg-red-600"
                            disabled={deleteMutation.isPending}
                          >
                            {deleteMutation.isPending ? "..." : "Yes"}
                          </button>
                          <button
                            onClick={() => setDeletingId(null)}
                            className="text-xs px-2 py-1 rounded bg-slate-600 text-slate-300 hover:bg-slate-500"
                          >
                            No
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeletingId(job.id)}
                          className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-400 transition-all"
                          title="Delete job"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-xs text-slate-400">
            Page {page} of {totalPages} · {data?.total?.toLocaleString()} total jobs
          </p>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="border-slate-600 text-slate-300">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const p = page <= 3 ? i + 1 : page - 2 + i;
              if (p < 1 || p > totalPages) return null;
              return (
                <Button key={p} size="sm" onClick={() => setPage(p)} className={p === page ? "bg-blue-600" : "border-slate-600 text-slate-300"} variant={p === page ? "default" : "outline"}>
                  {p}
                </Button>
              );
            })}
            <Button size="sm" variant="outline" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="border-slate-600 text-slate-300">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Post Job Tab ─────────────────────────────────────────────────────────────
function PostJobTab() {
  const queryClient = useQueryClient();
  const [form, setForm] = useState({
    title: "", organization: "", location: "", category: "",
    description: "", url: "", jobType: "", salary: "", country: "",
    applyEmail: "", source: "Admin", featured: false,
  });
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const postMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/admin/jobs", data).then(r => r.json()),
    onSuccess: (data) => {
      if (data.success) {
        setSuccess(true);
        setError("");
        setForm({ title:"",organization:"",location:"",category:"",description:"",url:"",jobType:"",salary:"",country:"",applyEmail:"",source:"Admin",featured:false });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/jobs"] });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
        setTimeout(() => setSuccess(false), 4000);
      } else {
        setError(data.message || "Failed to post job");
      }
    },
    onError: (err: any) => setError(err.message || "Failed to post job"),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!form.title || !form.organization || !form.category) {
      setError("Title, organization and category are required.");
      return;
    }
    if (!form.description || form.description.length < 20) {
      setError("Description must be at least 20 characters.");
      return;
    }
    postMutation.mutate(form);
  };

  const set = (field: string, value: any) => setForm(f => ({ ...f, [field]: value }));

  return (
    <div className="max-w-2xl">
      <h2 className="text-lg font-bold text-white mb-6">Post New Job</h2>

      {success && (
        <div className="mb-4 p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3">
          <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
          <p className="text-emerald-300 text-sm font-medium">Job posted successfully and is now live!</p>
        </div>
      )}
      {error && (
        <div className="mb-4 p-4 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-red-400 shrink-0" />
          <p className="text-red-300 text-sm">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Job Title *</Label>
            <Input value={form.title} onChange={e => set("title", e.target.value)} placeholder="e.g. Senior Software Engineer" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Organization *</Label>
            <Input value={form.organization} onChange={e => set("organization", e.target.value)} placeholder="e.g. UNICEF, Google" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Category *</Label>
            <Select value={form.category} onValueChange={v => set("category", v)}>
              <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-600">
                {CATEGORIES.map(c => (
                  <SelectItem key={c} value={c} className="text-slate-300 capitalize">{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Job Type</Label>
            <Select value={form.jobType} onValueChange={v => set("jobType", v)}>
              <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-600">
                {JOB_TYPES.map(t => (
                  <SelectItem key={t} value={t} className="text-slate-300">{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Location</Label>
            <Input value={form.location} onChange={e => set("location", e.target.value)} placeholder="e.g. New York, Remote" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Country</Label>
            <Select value={form.country} onValueChange={v => set("country", v)}>
              <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-600 max-h-64 overflow-y-auto">
                {COUNTRIES.map(c => (
                  <SelectItem key={c.code} value={c.code} className="text-slate-300">{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Application URL</Label>
            <Input value={form.url} onChange={e => set("url", e.target.value)} placeholder="https://..." className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Apply Email</Label>
            <Input value={form.applyEmail} onChange={e => set("applyEmail", e.target.value)} placeholder="hr@company.com" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Salary / Compensation</Label>
            <Input value={form.salary} onChange={e => set("salary", e.target.value)} placeholder="e.g. $60,000-$90,000 / year" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
          </div>
          <div>
            <Label className="text-slate-300 text-xs mb-1.5 block">Source Label</Label>
            <Input value={form.source} onChange={e => set("source", e.target.value)} placeholder="Admin" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
          </div>
        </div>

        <div>
          <Label className="text-slate-300 text-xs mb-1.5 block">Job Description *</Label>
          <Textarea
            value={form.description}
            onChange={e => set("description", e.target.value)}
            placeholder="Full job description including responsibilities, requirements, qualifications..."
            rows={8}
            className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 resize-none"
          />
          <p className="text-xs text-slate-500 mt-1">{form.description.length} characters</p>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
          <input
            type="checkbox"
            id="featured"
            checked={form.featured}
            onChange={e => set("featured", e.target.checked)}
            className="w-4 h-4 accent-amber-500"
          />
          <label htmlFor="featured" className="text-sm text-amber-300 font-medium cursor-pointer flex items-center gap-2">
            <Star className="h-4 w-4" />
            Feature this job (pinned at top, highlighted)
          </label>
        </div>

        <Button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold h-11"
          disabled={postMutation.isPending}
        >
          {postMutation.isPending ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Posting Job...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <PlusCircle className="h-4 w-4" />
              Post Job Now
            </span>
          )}
        </Button>
      </form>
    </div>
  );
}

// ─── Subscribers Tab ──────────────────────────────────────────────────────────
function SubscribersTab() {
  const [search, setSearch] = useState("");
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const { data: subscribers, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/newsletter"],
    queryFn: () => apiRequest("GET", "/api/admin/newsletter").then(r => r.json()),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/newsletter/${id}`).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/newsletter"] });
      setDeletingId(null);
    },
    onError: () => setDeletingId(null),
  });

  const handleDelete = (id: number, email: string) => {
    if (!window.confirm(`Delete subscriber: ${email}?\nThis cannot be undone.`)) return;
    setDeletingId(id);
    deleteMutation.mutate(id);
  };

  const filtered = (Array.isArray(subscribers) ? subscribers : []).filter((s: any) =>
    !search || s.email?.toLowerCase().includes(search.toLowerCase()) || (s.name || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-bold text-white">Newsletter Subscribers</h2>
          <p className="text-xs text-slate-400 mt-0.5">{Array.isArray(subscribers) ? subscribers.length : 0} total subscribers</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()} className="text-slate-300 border-slate-600 hover:bg-slate-700 text-xs">
          <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
          Refresh
        </Button>
      </div>

      <div className="relative max-w-xs">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search email or name..."
          className="pl-9 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500"
        />
      </div>

      <div className="bg-slate-800/60 border border-slate-700 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center p-12">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700 bg-slate-900/40">
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">ID</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Email</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Name</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Type</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Status</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Subscribed</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s: any) => (
                  <tr key={s.id} className="border-b border-slate-700/50 hover:bg-slate-700/30">
                    <td className="p-3 text-slate-400 font-mono text-xs">#{s.id}</td>
                    <td className="p-3 text-white text-xs font-medium">{s.email}</td>
                    <td className="p-3 text-slate-300 text-xs">{s.name || "—"}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${s.type === "employer" ? "bg-amber-500/20 text-amber-300" : "bg-blue-500/20 text-blue-300"}`}>
                        {s.type === "employer" ? "Employer" : "Job Seeker"}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${s.active ? "bg-emerald-500/20 text-emerald-300" : "bg-slate-600 text-slate-400"}`}>
                        {s.active ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td className="p-3 text-slate-400 text-xs">{formatDate(s.subscribedAt)}</td>
                    <td className="p-3">
                      <button
                        onClick={() => handleDelete(s.id, s.email)}
                        disabled={deletingId === s.id}
                        className="flex items-center gap-1 px-2 py-1 rounded text-xs text-red-400 hover:bg-red-500/10 hover:text-red-300 border border-red-500/20 hover:border-red-500/40 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {deletingId === s.id ? (
                          <div className="w-3 h-3 border border-red-400/50 border-t-red-400 rounded-full animate-spin" />
                        ) : (
                          <Trash2 className="h-3 w-3" />
                        )}
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-10 text-center text-slate-500 text-sm">
                      {search ? "No subscribers match your search." : isLoading ? "Loading..." : "No subscribers yet. Subscribers will appear here when users sign up for job alerts."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Fetcher Tab ──────────────────────────────────────────────────────────────
function FetcherTab() {
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");

  const { data: sources } = useQuery({
    queryKey: ["/api/admin/sources"],
    queryFn: () => apiRequest("GET", "/api/admin/sources").then(r => r.json()),
  });

  const triggerFetch = useMutation({
    mutationFn: () => apiRequest("POST", "/api/admin/fetch-jobs").then(r => r.json()),
    onSuccess: () => {
      setMessage("Job fetch triggered! New jobs will appear in a few minutes.");
      setTimeout(() => setMessage(""), 6000);
      setTimeout(() => queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] }), 30000);
    },
  });

  return (
    <div className="space-y-6 max-w-2xl">
      <h2 className="text-lg font-bold text-white">Job Fetcher & Sources</h2>

      {message && (
        <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3">
          <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
          <p className="text-emerald-300 text-sm">{message}</p>
        </div>
      )}

      <Card className="bg-slate-800/60 border-slate-700 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
            <Zap className="h-5 w-5 text-blue-400" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Manual Job Fetch</h3>
            <p className="text-xs text-slate-400">Triggers a fresh fetch from all 11+ job sources</p>
          </div>
        </div>
        <p className="text-sm text-slate-400 mb-5 leading-relaxed">
          The system automatically fetches new jobs every 4 hours. Use this button to trigger a manual fetch immediately.
          New jobs will be deduplicated and categorized automatically.
        </p>
        <Button
          onClick={() => triggerFetch.mutate()}
          disabled={triggerFetch.isPending}
          className="bg-blue-600 hover:bg-blue-500"
        >
          {triggerFetch.isPending ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Triggering Fetch...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Fetch All Jobs Now
            </span>
          )}
        </Button>
      </Card>

      {sources && (
        <Card className="bg-slate-800/60 border-slate-700 p-6">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
            <Database className="h-4 w-4 text-slate-400" />
            Active Sources ({sources.length})
          </h3>
          <div className="space-y-2">
            {sources.map((s: any, i: number) => (
              <div key={s.source} className="flex items-center justify-between p-2 rounded-lg bg-slate-700/40">
                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-500 w-5 text-right">{i + 1}</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="text-sm text-slate-200 font-medium">{s.source}</span>
                </div>
                <span className="text-sm font-bold text-white">{Number(s.count).toLocaleString()} jobs</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card className="bg-slate-800/60 border-slate-700 p-6">
        <h3 className="font-semibold text-white mb-3 flex items-center gap-2">
          <Clock className="h-4 w-4 text-slate-400" />
          Schedule Info
        </h3>
        <div className="space-y-2 text-sm text-slate-400">
          <p>• Auto-fetch: Every <strong className="text-slate-200">4 hours</strong></p>
          <p>• Job expiry: Aggregated jobs after <strong className="text-slate-200">30 days</strong>, Featured after <strong className="text-slate-200">45 days</strong></p>
          <p>• Deduplication: Runs automatically on every fetch cycle</p>
          <p>• Sources: ReliefWeb, RemoteOK, Remotive, Jobicy, Arbeitnow, The Muse, Himalayas, WorkingNomads, Adzuna, USAJobs, FindWork</p>
        </div>
      </Card>
    </div>
  );
}

// ─── SEO Score Helpers ────────────────────────────────────────────────────────
function seoCheck(label: string, pass: boolean, tip?: string) {
  return { label, pass, tip };
}

function getSeoChecks(form: any, wordCount: number) {
  const kw = (form.focusKeyword || "").toLowerCase().trim();
  return [
    seoCheck("Title 50–70 chars", form.title.length >= 50 && form.title.length <= 70,
      `Current: ${form.title.length} chars. Ideal: 50–70`),
    seoCheck("Meta title 50–60 chars", (form.metaTitle || "").length >= 50 && (form.metaTitle || "").length <= 60,
      `Current: ${(form.metaTitle || "").length} chars. Ideal: 50–60`),
    seoCheck("Meta desc 150–160 chars", (form.metaDescription || "").length >= 150 && (form.metaDescription || "").length <= 160,
      `Current: ${(form.metaDescription || "").length} chars. Ideal: 150–160`),
    seoCheck("Focus keyword in title", kw.length > 0 && form.title.toLowerCase().includes(kw),
      "Focus keyword must appear in the article title"),
    seoCheck("Focus keyword in meta desc", kw.length > 0 && (form.metaDescription || "").toLowerCase().includes(kw),
      "Focus keyword must appear in meta description"),
    seoCheck("Focus keyword in content (first 100 words)", kw.length > 0 && (form.content || "").toLowerCase().split(/\s+/).slice(0, 100).join(" ").includes(kw),
      "Focus keyword should appear in the opening paragraph"),
    seoCheck("Content 600+ words", wordCount >= 600,
      `Current: ${wordCount} words. Minimum 600 recommended`),
    seoCheck("Featured image alt text", (form.featuredImageAlt || "").trim().length > 0,
      "Alt text is required for accessibility and image SEO"),
    seoCheck("Slug contains keyword or is descriptive", (form.slug || "").length >= 5 && (kw.length === 0 || (form.slug || "").toLowerCase().includes(kw.split(" ")[0])),
      "Slug should include primary keyword and be hyphen-separated"),
  ];
}

// ─── Write Blog Tab ───────────────────────────────────────────────────────────
function WriteBlogTab({ editPost, onSaved }: { editPost?: any; onSaved?: () => void }) {
  const queryClient = useQueryClient();
  const emptyForm = {
    title: "", slug: "", metaTitle: "", metaDescription: "", focusKeyword: "",
    secondaryKeywords: "", content: "", excerpt: "", featuredImageUrl: "",
    featuredImageAlt: "", author: "Dev Global Jobs", category: "", tags: "",
    status: "draft", canonicalUrl: "", ogTitle: "", ogDescription: "",
    schemaType: "BlogPosting",
  };
  const [form, setForm] = useState<any>(editPost ? {
    title: editPost.title || "", slug: editPost.slug || "",
    metaTitle: editPost.metaTitle || "", metaDescription: editPost.metaDescription || "",
    focusKeyword: editPost.focusKeyword || "", secondaryKeywords: editPost.secondaryKeywords || "",
    content: editPost.content || "", excerpt: editPost.excerpt || "",
    featuredImageUrl: editPost.featuredImageUrl || "", featuredImageAlt: editPost.featuredImageAlt || "",
    author: editPost.author || "Dev Global Jobs", category: editPost.category || "",
    tags: editPost.tags || "", status: editPost.status || "draft",
    canonicalUrl: editPost.canonicalUrl || "", ogTitle: editPost.ogTitle || "",
    ogDescription: editPost.ogDescription || "", schemaType: editPost.schemaType || "BlogPosting",
  } : emptyForm);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [autoSlug, setAutoSlug] = useState(!editPost);

  const wordCount = (form.content || "").trim().split(/\s+/).filter(Boolean).length;
  const readingTime = Math.ceil(wordCount / 200);
  const seoChecks = getSeoChecks(form, wordCount);
  const passedChecks = seoChecks.filter(c => c.pass).length;
  const seoScore = Math.round((passedChecks / seoChecks.length) * 100);
  const seoColor = seoScore >= 80 ? "text-emerald-400" : seoScore >= 50 ? "text-amber-400" : "text-red-400";
  const seoBg = seoScore >= 80 ? "bg-emerald-500/10 border-emerald-500/30" : seoScore >= 50 ? "bg-amber-500/10 border-amber-500/30" : "bg-red-500/10 border-red-500/30";
  const seoLabel = seoScore >= 80 ? "Good" : seoScore >= 50 ? "Needs Work" : "Poor";

  function set(key: string, val: string) {
    setForm((f: any) => {
      const next = { ...f, [key]: val };
      if (key === "title" && autoSlug) {
        next.slug = val.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").slice(0, 80);
      }
      return next;
    });
  }

  const mutation = useMutation({
    mutationFn: (data: any) => {
      if (editPost) {
        return apiRequest("PUT", `/api/admin/blog/${editPost.id}`, data).then(r => r.json());
      }
      return apiRequest("POST", "/api/admin/blog", data).then(r => r.json());
    },
    onSuccess: (data) => {
      if (data.success) {
        queryClient.invalidateQueries({ queryKey: ["/api/admin/blog"] });
        setSuccess(true);
        setTimeout(() => setSuccess(false), 4000);
        if (!editPost) { setForm(emptyForm); setAutoSlug(true); }
        if (onSaved) onSaved();
      } else {
        setError(data.message || "Failed to save");
      }
    },
    onError: (e: any) => setError(e.message || "Failed to save"),
  });

  function handleSave(publish: boolean) {
    setError(null); setSuccess(false);
    const data = { ...form, wordCount, readingTimeMinutes: readingTime };
    if (publish) data.status = "published";
    mutation.mutate(data);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-bold text-white">{editPost ? "Edit Blog Post" : "Write Blog Post"}</h2>
          <p className="text-xs text-slate-400 mt-0.5">SEO-optimized blog publishing</p>
        </div>
        <div className="flex items-center gap-2">
          <div className={`px-3 py-1.5 rounded-lg border text-sm font-bold ${seoBg} ${seoColor}`}>
            SEO: {seoScore}% — {seoLabel}
          </div>
        </div>
      </div>

      {success && (
        <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-emerald-300 text-sm">
          <CheckCircle className="h-4 w-4 shrink-0" />
          Blog post {editPost ? "updated" : "saved"} successfully!
        </div>
      )}
      {error && (
        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center gap-2 text-red-300 text-sm">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* ── Main Form ── */}
        <div className="xl:col-span-2 space-y-5">

          {/* Core fields */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2"><FileText className="h-4 w-4" />Content</h3>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="text-slate-300 text-xs">Title *</Label>
                <span className={`text-xs font-medium ${form.title.length >= 50 && form.title.length <= 70 ? "text-emerald-400" : "text-amber-400"}`}>{form.title.length}/70</span>
              </div>
              <Input value={form.title} onChange={e => set("title", e.target.value)} placeholder="How to Land an International Job in 2025" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
              <p className="text-xs text-slate-500 mt-1">Aim for 50–70 characters for best display in search results</p>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="text-slate-300 text-xs">URL Slug *</Label>
                <button onClick={() => setAutoSlug(!autoSlug)} className={`text-xs px-2 py-0.5 rounded ${autoSlug ? "bg-blue-500/20 text-blue-300" : "bg-slate-600 text-slate-400"}`}>{autoSlug ? "Auto" : "Manual"}</button>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 whitespace-nowrap">devglobaljobs.com/blog/</span>
                <Input value={form.slug} onChange={e => { setAutoSlug(false); set("slug", e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-")); }} placeholder="how-to-land-international-job" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 font-mono text-xs" />
              </div>
            </div>
            <div>
              <Label className="text-slate-300 text-xs mb-1.5 block">Excerpt (short summary shown on blog listing)</Label>
              <Textarea value={form.excerpt} onChange={e => set("excerpt", e.target.value)} placeholder="A concise 2-3 sentence summary of the article..." rows={2} className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-sm resize-none" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="text-slate-300 text-xs">Article Content *</Label>
                <span className="text-xs text-slate-400">{wordCount} words · ~{readingTime} min read</span>
              </div>
              <Textarea value={form.content} onChange={e => set("content", e.target.value)} placeholder="Write your full article here. Use double line breaks for paragraphs. You can include HTML tags for formatting..." rows={16} className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-sm font-mono resize-y" />
              <div className={`flex items-center gap-1.5 mt-1.5 text-xs ${wordCount >= 600 ? "text-emerald-400" : wordCount >= 300 ? "text-amber-400" : "text-red-400"}`}>
                <div className={`w-full h-1.5 rounded-full bg-slate-700 overflow-hidden`}>
                  <div className={`h-full rounded-full transition-all ${wordCount >= 600 ? "bg-emerald-500" : wordCount >= 300 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${Math.min((wordCount / 600) * 100, 100)}%` }} />
                </div>
                <span className="shrink-0">{wordCount}/600 words</span>
              </div>
            </div>
          </div>

          {/* SEO fields */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2"><Globe className="h-4 w-4" />SEO Settings</h3>
            <div>
              <Label className="text-slate-300 text-xs mb-1.5 block">Focus Keyword (Primary Keyword)</Label>
              <Input value={form.focusKeyword} onChange={e => set("focusKeyword", e.target.value)} placeholder="e.g. international jobs, remote jobs abroad" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
            </div>
            <div>
              <Label className="text-slate-300 text-xs mb-1.5 block">Secondary Keywords (comma-separated)</Label>
              <Input value={form.secondaryKeywords} onChange={e => set("secondaryKeywords", e.target.value)} placeholder="e.g. global jobs, overseas employment, expat jobs" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="text-slate-300 text-xs">Meta Title (for Google search results)</Label>
                <span className={`text-xs font-medium ${(form.metaTitle || "").length >= 50 && (form.metaTitle || "").length <= 60 ? "text-emerald-400" : "text-amber-400"}`}>{(form.metaTitle || "").length}/60</span>
              </div>
              <Input value={form.metaTitle} onChange={e => set("metaTitle", e.target.value)} placeholder="How to Land an International Job in 2025 | Dev Global Jobs" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
              <p className="text-xs text-slate-500 mt-1">Appears as the blue clickable title in Google. 50–60 chars ideal.</p>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="text-slate-300 text-xs">Meta Description (for Google snippet)</Label>
                <span className={`text-xs font-medium ${(form.metaDescription || "").length >= 150 && (form.metaDescription || "").length <= 160 ? "text-emerald-400" : "text-amber-400"}`}>{(form.metaDescription || "").length}/160</span>
              </div>
              <Textarea value={form.metaDescription} onChange={e => set("metaDescription", e.target.value)} placeholder="Discover proven strategies to find international jobs and work abroad in 2025. Learn how to apply, get hired, and build a global career." rows={3} className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-sm resize-none" />
              <div className={`w-full h-1 rounded-full bg-slate-700 overflow-hidden mt-2`}>
                <div className={`h-full rounded-full transition-all ${(form.metaDescription || "").length >= 150 && (form.metaDescription || "").length <= 160 ? "bg-emerald-500" : (form.metaDescription || "").length > 160 ? "bg-red-500" : "bg-amber-500"}`} style={{ width: `${Math.min(((form.metaDescription || "").length / 160) * 100, 100)}%` }} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300 text-xs mb-1.5 block">Canonical URL (optional)</Label>
                <Input value={form.canonicalUrl} onChange={e => set("canonicalUrl", e.target.value)} placeholder="https://devglobaljobs.com/blog/slug" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-xs" />
              </div>
              <div>
                <Label className="text-slate-300 text-xs mb-1.5 block">Schema Type</Label>
                <Select value={form.schemaType} onValueChange={v => set("schemaType", v)}>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-600">
                    {["BlogPosting", "Article", "NewsArticle"].map(t => <SelectItem key={t} value={t} className="text-slate-300">{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Open Graph */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2"><Star className="h-4 w-4" />Social / Open Graph</h3>
            <div>
              <Label className="text-slate-300 text-xs mb-1.5 block">OG Title (for Facebook / LinkedIn shares)</Label>
              <Input value={form.ogTitle} onChange={e => set("ogTitle", e.target.value)} placeholder="Same as meta title or a catchier variant" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
            </div>
            <div>
              <Label className="text-slate-300 text-xs mb-1.5 block">OG Description</Label>
              <Textarea value={form.ogDescription} onChange={e => set("ogDescription", e.target.value)} placeholder="Compelling description for social shares..." rows={2} className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-sm resize-none" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300 text-xs mb-1.5 block">Featured Image URL</Label>
                <Input value={form.featuredImageUrl} onChange={e => set("featuredImageUrl", e.target.value)} placeholder="https://..." className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-xs" />
              </div>
              <div>
                <Label className="text-slate-300 text-xs mb-1.5 block">Image Alt Text *</Label>
                <Input value={form.featuredImageAlt} onChange={e => set("featuredImageAlt", e.target.value)} placeholder="e.g. Person working remotely abroad" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-xs" />
              </div>
            </div>
          </div>

          {/* Meta / Taxonomy */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2"><Filter className="h-4 w-4" />Publishing Details</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-300 text-xs mb-1.5 block">Author</Label>
                <Input value={form.author} onChange={e => set("author", e.target.value)} className="bg-slate-700/50 border-slate-600 text-white" />
              </div>
              <div>
                <Label className="text-slate-300 text-xs mb-1.5 block">Category</Label>
                <Input value={form.category} onChange={e => set("category", e.target.value)} placeholder="e.g. Career Advice, Remote Work" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
              </div>
              <div className="sm:col-span-2">
                <Label className="text-slate-300 text-xs mb-1.5 block">Tags (comma-separated)</Label>
                <Input value={form.tags} onChange={e => set("tags", e.target.value)} placeholder="international jobs, remote work, career tips" className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-3 flex-wrap">
            <Button onClick={() => handleSave(false)} disabled={mutation.isPending} variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
              {mutation.isPending ? <div className="w-4 h-4 border border-slate-400/30 border-t-slate-400 rounded-full animate-spin mr-2" /> : <Clock className="h-4 w-4 mr-2" />}
              Save as Draft
            </Button>
            <Button onClick={() => handleSave(true)} disabled={mutation.isPending} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              {mutation.isPending ? <div className="w-4 h-4 border border-white/30 border-t-white rounded-full animate-spin mr-2" /> : <Globe className="h-4 w-4 mr-2" />}
              {editPost ? "Update & Publish" : "Publish Now"}
            </Button>
          </div>
        </div>

        {/* ── SEO Score Panel ── */}
        <div className="space-y-4">
          <div className={`rounded-xl border p-4 ${seoBg}`}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-bold text-white">SEO Score</span>
              <span className={`text-2xl font-black ${seoColor}`}>{seoScore}%</span>
            </div>
            <div className="w-full h-3 bg-slate-700/50 rounded-full overflow-hidden mb-4">
              <div className={`h-full rounded-full transition-all duration-500 ${seoScore >= 80 ? "bg-emerald-500" : seoScore >= 50 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${seoScore}%` }} />
            </div>
            <div className="space-y-2">
              {seoChecks.map((c, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div className={`w-4 h-4 rounded-full shrink-0 mt-0.5 flex items-center justify-center ${c.pass ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/10 text-red-400"}`}>
                    {c.pass ? <CheckCircle className="h-3 w-3" /> : <AlertCircle className="h-3 w-3" />}
                  </div>
                  <div>
                    <p className={`text-xs font-medium ${c.pass ? "text-slate-200" : "text-slate-400"}`}>{c.label}</p>
                    {!c.pass && c.tip && <p className="text-xs text-slate-500 mt-0.5">{c.tip}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live preview */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4 space-y-3">
            <p className="text-xs font-semibold text-slate-400">Google Preview</p>
            <div className="bg-white/5 rounded-lg p-3 space-y-1">
              <p className="text-blue-400 text-sm font-medium truncate">{form.metaTitle || form.title || "Your article title"}</p>
              <p className="text-emerald-400 text-xs">devglobaljobs.com/blog/{form.slug || "your-article-slug"}</p>
              <p className="text-slate-300 text-xs leading-relaxed line-clamp-2">{form.metaDescription || "Your meta description will appear here in Google search results..."}</p>
            </div>
          </div>

          {/* Article stats */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4 space-y-2">
            <p className="text-xs font-semibold text-slate-400">Article Stats</p>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-slate-700/50 rounded-lg p-2">
                <p className="text-lg font-bold text-white">{wordCount}</p>
                <p className="text-xs text-slate-400">Words</p>
              </div>
              <div className="bg-slate-700/50 rounded-lg p-2">
                <p className="text-lg font-bold text-white">{readingTime}</p>
                <p className="text-xs text-slate-400">Min Read</p>
              </div>
              <div className="bg-slate-700/50 rounded-lg p-2">
                <p className="text-lg font-bold text-white">{form.title.length}</p>
                <p className="text-xs text-slate-400">Title Chars</p>
              </div>
              <div className="bg-slate-700/50 rounded-lg p-2">
                <p className="text-lg font-bold text-white">{passedChecks}/{seoChecks.length}</p>
                <p className="text-xs text-slate-400">SEO Passed</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Blog Posts Tab ───────────────────────────────────────────────────────────
function BlogPostsTab({ onEdit }: { onEdit: (post: any) => void }) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["/api/admin/blog", statusFilter],
    queryFn: () => {
      const qs = statusFilter !== "all" ? `?status=${statusFilter}` : "";
      return apiRequest("GET", `/api/admin/blog${qs}`).then(r => r.json());
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/blog/${id}`).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/blog"] });
      setDeletingId(null);
    },
    onError: () => setDeletingId(null),
  });

  const posts = (data?.posts || []).filter((p: any) =>
    !search || p.title.toLowerCase().includes(search.toLowerCase()) || (p.slug || "").includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-bold text-white">Blog Posts</h2>
          <p className="text-xs text-slate-400 mt-0.5">{data?.total || 0} total · {(data?.posts || []).filter((p: any) => p.status === "published").length} published</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()} className="text-slate-300 border-slate-600 hover:bg-slate-700 text-xs">
          <RefreshCw className="h-3.5 w-3.5 mr-1.5" />Refresh
        </Button>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search posts..." className="pl-9 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white w-36"><SelectValue /></SelectTrigger>
          <SelectContent className="bg-slate-800 border-slate-600">
            <SelectItem value="all" className="text-slate-300">All Status</SelectItem>
            <SelectItem value="published" className="text-slate-300">Published</SelectItem>
            <SelectItem value="draft" className="text-slate-300">Draft</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="bg-slate-800/60 border border-slate-700 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center p-12">
            <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700 bg-slate-900/40">
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Title / Slug</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Status</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Words</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Category</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Published</th>
                  <th className="text-left p-3 text-xs text-slate-400 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {posts.map((p: any) => (
                  <tr key={p.id} className="border-b border-slate-700/50 hover:bg-slate-700/30">
                    <td className="p-3 max-w-xs">
                      <p className="text-white text-xs font-medium truncate">{p.title}</p>
                      <p className="text-slate-500 text-xs font-mono truncate mt-0.5">/blog/{p.slug}</p>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${p.status === "published" ? "bg-emerald-500/20 text-emerald-300" : "bg-slate-600 text-slate-400"}`}>
                        {p.status === "published" ? "Published" : "Draft"}
                      </span>
                    </td>
                    <td className="p-3 text-slate-300 text-xs">{p.wordCount ? p.wordCount.toLocaleString() : "—"}</td>
                    <td className="p-3 text-slate-300 text-xs">{p.category || "—"}</td>
                    <td className="p-3 text-slate-400 text-xs">{p.publishedAt ? formatDate(p.publishedAt) : "—"}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <button onClick={() => onEdit(p)} className="flex items-center gap-1 px-2 py-1 rounded text-xs text-blue-400 hover:bg-blue-500/10 border border-blue-500/20 hover:border-blue-500/40 transition-colors">
                          <PenSquare className="h-3 w-3" />Edit
                        </button>
                        {p.status === "published" && (
                          <a href={`/blog/${p.slug}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 px-2 py-1 rounded text-xs text-slate-400 hover:bg-slate-600/50 border border-slate-600 transition-colors">
                            <Eye className="h-3 w-3" />View
                          </a>
                        )}
                        <button
                          onClick={() => {
                            if (!window.confirm(`Delete "${p.title}"? This cannot be undone.`)) return;
                            setDeletingId(p.id);
                            deleteMutation.mutate(p.id);
                          }}
                          disabled={deletingId === p.id}
                          className="flex items-center gap-1 px-2 py-1 rounded text-xs text-red-400 hover:bg-red-500/10 border border-red-500/20 hover:border-red-500/40 transition-colors disabled:opacity-50"
                        >
                          {deletingId === p.id ? <div className="w-3 h-3 border border-red-400/50 border-t-red-400 rounded-full animate-spin" /> : <Trash2 className="h-3 w-3" />}
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {posts.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-10 text-center text-slate-500 text-sm">
                      {search ? "No posts match your search." : "No blog posts yet. Write your first post!"}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Revenue Metrics Tab ──────────────────────────────────────────────────────
const REGULAR_PRICE = 29;
const FEATURED_PRICE = 79;

function fmt$(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(1)}K`;
  return `$${n.toLocaleString()}`;
}

function RevenueTab() {
  const { data, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ["/api/admin/revenue-metrics"],
    queryFn: () => apiRequest("GET", "/api/admin/revenue-metrics").then(r => r.json()),
    staleTime: 60_000,
  });

  const PERIODS: { key: "today" | "week" | "month" | "year" | "total"; label: string }[] = [
    { key: "today",  label: "Today" },
    { key: "week",   label: "Last 7 Days" },
    { key: "month",  label: "Last 30 Days" },
    { key: "year",   label: "Last 365 Days" },
    { key: "total",  label: "All Time" },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-emerald-400" />
            Revenue Metrics
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Based on employer postings · Regular <span className="text-white font-medium">${REGULAR_PRICE}/30d</span> · Featured <span className="text-amber-300 font-medium">${FEATURED_PRICE}/45d</span>
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => refetch()}
          disabled={isRefetching}
          className="text-slate-300 border-slate-600 hover:bg-slate-700 text-xs"
        >
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${isRefetching ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-24">
          <div className="w-10 h-10 border-2 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {/* Top Summary Cards — Today */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Card className="p-5 bg-slate-800/60 border-slate-700">
              <p className="text-xs text-slate-400 mb-1">Regular Posts (Total)</p>
              <p className="text-2xl font-bold text-white">{(data?.regular?.total ?? 0).toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-1">@ ${REGULAR_PRICE} each</p>
            </Card>
            <Card className="p-5 bg-slate-800/60 border-slate-700">
              <p className="text-xs text-slate-400 mb-1">Featured Posts (Total)</p>
              <p className="text-2xl font-bold text-amber-300">{(data?.featured?.total ?? 0).toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-1">@ ${FEATURED_PRICE} each</p>
            </Card>
            <Card className="p-5 bg-slate-800/60 border-slate-700 sm:col-span-2">
              <p className="text-xs text-slate-400 mb-1">All-Time Revenue</p>
              <p className="text-2xl font-bold text-emerald-400">{fmt$(data?.revenue?.total ?? 0)}</p>
              <p className="text-xs text-slate-500 mt-1">
                {(data?.regular?.total ?? 0)} regular + {(data?.featured?.total ?? 0)} featured listings
              </p>
            </Card>
          </div>

          {/* Period Breakdown Table */}
          <Card className="bg-slate-800/60 border-slate-700 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-700">
              <h3 className="text-sm font-semibold text-white">Posting Activity &amp; Revenue by Period</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700 bg-slate-900/40">
                    <th className="text-left p-3 text-xs text-slate-400 font-semibold w-36">Period</th>
                    <th className="text-right p-3 text-xs text-slate-400 font-semibold">Regular Posts</th>
                    <th className="text-right p-3 text-xs text-slate-400 font-semibold">Reg. Revenue</th>
                    <th className="text-right p-3 text-xs text-amber-400 font-semibold">Featured Posts</th>
                    <th className="text-right p-3 text-xs text-amber-400 font-semibold">Feat. Revenue</th>
                    <th className="text-right p-3 text-xs text-emerald-400 font-semibold">Total Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  {PERIODS.map(({ key, label }) => {
                    const reg = data?.regular?.[key] ?? 0;
                    const feat = data?.featured?.[key] ?? 0;
                    const rev = data?.revenue?.[key] ?? 0;
                    const regRev = reg * REGULAR_PRICE;
                    const featRev = feat * FEATURED_PRICE;
                    return (
                      <tr key={key} className={`border-b border-slate-700/50 hover:bg-slate-700/20 ${key === "total" ? "bg-slate-900/30 font-semibold" : ""}`}>
                        <td className="p-3 text-slate-200 text-xs">{label}</td>
                        <td className="p-3 text-right text-slate-300 text-xs">{reg.toLocaleString()}</td>
                        <td className="p-3 text-right text-slate-300 text-xs">${regRev.toLocaleString()}</td>
                        <td className="p-3 text-right text-amber-300 text-xs">{feat.toLocaleString()}</td>
                        <td className="p-3 text-right text-amber-300 text-xs">${featRev.toLocaleString()}</td>
                        <td className="p-3 text-right font-bold text-emerald-400 text-xs">{fmt$(rev)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Revenue Projections */}
          <Card className="bg-slate-800/60 border-slate-700 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-700">
              <h3 className="text-sm font-semibold text-white">Revenue Projections</h3>
              <p className="text-xs text-slate-400 mt-0.5">Extrapolated from last 30-day posting rate</p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-y sm:divide-y-0 divide-slate-700/50">
              {[
                { label: "Daily",   key: "daily" as const,   icon: "📅" },
                { label: "Weekly",  key: "weekly" as const,  icon: "📆" },
                { label: "Monthly", key: "monthly" as const, icon: "🗓️" },
                { label: "Yearly",  key: "yearly" as const,  icon: "📈" },
              ].map(({ label, key, icon }) => (
                <div key={key} className="p-5 text-center">
                  <p className="text-2xl mb-1">{icon}</p>
                  <p className="text-xl font-bold text-emerald-400">{fmt$(data?.projections?.[key] ?? 0)}</p>
                  <p className="text-xs text-slate-400 mt-1">{label}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* Pricing Info */}
          <Card className="bg-slate-800/40 border-slate-700/50 p-5">
            <div className="flex items-start gap-3">
              <Info className="h-4 w-4 text-blue-400 mt-0.5 shrink-0" />
              <div className="space-y-1 text-xs text-slate-400">
                <p><span className="text-white font-medium">Regular Posting</span> — ${REGULAR_PRICE} per job · active for 30 days · appears in standard listings</p>
                <p><span className="text-amber-300 font-medium">Featured Posting</span> — ${FEATURED_PRICE} per job · active for 45 days · pinned to top with ★ badge · priority placement</p>
                <p className="text-slate-500">Payment via Wise to Trend Nova World Limited. Revenue figures reflect historical posting counts at current prices.</p>
              </div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
const TABS = [
  { id: "overview",  label: "Overview",    icon: LayoutDashboard },
  { id: "revenue",   label: "Revenue",     icon: TrendingUp },
  { id: "jobs",      label: "All Jobs",    icon: Briefcase },
  { id: "post",      label: "Post Job",    icon: PlusCircle },
  { id: "subscribers", label: "Subscribers", icon: Users },
  { id: "fetcher",   label: "Job Fetcher", icon: Zap },
  { id: "blog-posts", label: "Blog Posts", icon: BookOpen },
  { id: "blog-write", label: "Write Blog", icon: PenSquare },
];

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [editingBlogPost, setEditingBlogPost] = useState<any>(null);
  const queryClient = useQueryClient();

  const { data: me, isLoading } = useQuery({
    queryKey: ["/api/admin/me"],
    queryFn: () => apiRequest("GET", "/api/admin/me").then(r => {
      if (!r.ok) throw new Error("Unauthorized");
      return r.json();
    }),
    retry: false,
  });

  const logoutMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/admin/logout").then(r => r.json()),
    onSuccess: () => {
      queryClient.clear();
      setLocation("/admin");
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="w-10 h-10 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!me) {
    setLocation("/admin");
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-900 flex">
      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-56 bg-slate-950 border-r border-slate-800 flex flex-col
        transform transition-transform duration-200 ease-in-out
        ${mobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
      `}>
        <div className="p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
              <Globe className="h-5 w-5 text-white" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white leading-tight">Dev Global Jobs</p>
              <p className="text-[10px] text-slate-500">Admin Panel</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); setMobileMenuOpen(false); if (tab.id === "blog-write") setEditingBlogPost(null); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-left
                ${activeTab === tab.id
                  ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
                }`}
            >
              <tab.icon className="h-4 w-4 shrink-0" />
              {tab.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="mb-3 px-1">
            <p className="text-xs font-medium text-white truncate">{me.username}</p>
            <p className="text-[10px] text-slate-500">Administrator</p>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            className="w-full border-slate-700 text-slate-400 hover:text-white hover:border-slate-500 text-xs"
          >
            <LogOut className="h-3.5 w-3.5 mr-2" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setMobileMenuOpen(false)} />
      )}

      {/* Main content */}
      <main className="flex-1 lg:ml-56 min-h-screen flex flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-slate-900/90 backdrop-blur border-b border-slate-800 px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="lg:hidden text-slate-400 hover:text-white" onClick={() => setMobileMenuOpen(v => !v)}>
              <MenuIcon className="h-5 w-5" />
            </button>
            <div>
              <h1 className="text-sm font-semibold text-white">
                {TABS.find(t => t.id === activeTab)?.label}
              </h1>
              <p className="text-[10px] text-slate-500 hidden sm:block">devglobaljobs.com · Admin Control Panel</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a href="/" target="_blank" rel="noopener noreferrer" className="text-xs text-slate-400 hover:text-white flex items-center gap-1">
              <Eye className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">View Site</span>
            </a>
          </div>
        </header>

        {/* Page content */}
        <div className="flex-1 p-4 sm:p-6">
          {activeTab === "overview" && <OverviewTab />}
          {activeTab === "revenue" && <RevenueTab />}
          {activeTab === "jobs" && <JobsTab />}
          {activeTab === "post" && <PostJobTab />}
          {activeTab === "subscribers" && <SubscribersTab />}
          {activeTab === "fetcher" && <FetcherTab />}
          {activeTab === "blog-posts" && (
            <BlogPostsTab onEdit={(post) => { setEditingBlogPost(post); setActiveTab("blog-write"); }} />
          )}
          {activeTab === "blog-write" && (
            <WriteBlogTab
              key={editingBlogPost?.id || "new"}
              editPost={editingBlogPost}
              onSaved={() => { setEditingBlogPost(null); setActiveTab("blog-posts"); }}
            />
          )}
        </div>
      </main>
    </div>
  );
}
