import { Card } from "@/components/ui/card";
import { Link } from "wouter";

export default function Privacy() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold mb-6" data-testid="text-privacy-title">Privacy Policy</h1>
      <Card className="p-6 sm:p-8">
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <p className="text-muted-foreground mb-4">Last updated: {new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })}</p>

          <h2>1. Introduction</h2>
          <p>Dev Global Jobs ("we", "us", or "our"), operated by Trend Nova World Limited (Company No. 16709289, registered in the United Kingdom at 27 Old Gloucester Street, London, WC1N 3AX), is committed to protecting your privacy in compliance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.</p>

          <h2>2. Data Controller</h2>
          <p>The data controller responsible for your personal data is:</p>
          <ul>
            <li><strong>Company:</strong> Trend Nova World Limited</li>
            <li><strong>Address:</strong> 27 Old Gloucester Street, London, WC1N 3AX, United Kingdom</li>
            <li><strong>Email:</strong> <a href="mailto:info@devglobaljobs.com">info@devglobaljobs.com</a></li>
            <li><strong>Phone:</strong> <a href="tel:+447473863903">+44 7473 863903</a></li>
          </ul>

          <h2>3. Information We Collect</h2>
          <p>We may collect information about you in a variety of ways:</p>
          <ul>
            <li><strong>Personal Data (Employers):</strong> When you post a job ($10 Regular or $25 Featured), we collect your company name, job details, contact email, and payment information processed securely through Stripe.</li>
            <li><strong>Usage Data:</strong> We automatically collect certain information when you visit our website, including your IP address, browser type, operating system, referring URLs, pages visited, and time spent on pages.</li>
            <li><strong>Cookies:</strong> We use cookies and similar tracking technologies to enhance your browsing experience and analyze site traffic.</li>
            <li><strong>Analytics:</strong> We use Google Analytics to understand how visitors interact with our website. This data is anonymized and used solely for improving our service.</li>
          </ul>

          <h2>4. Legal Basis for Processing</h2>
          <p>We process your personal data under the following legal bases:</p>
          <ul>
            <li><strong>Contract:</strong> Processing necessary for the performance of a contract (e.g., processing your job posting payment)</li>
            <li><strong>Legitimate Interest:</strong> Processing necessary for our legitimate interests (e.g., improving our service, preventing fraud)</li>
            <li><strong>Consent:</strong> Where you have given consent (e.g., cookies, marketing communications)</li>
            <li><strong>Legal Obligation:</strong> Where processing is necessary to comply with legal obligations</li>
          </ul>

          <h2>5. How We Use Your Information</h2>
          <p>We use the information we collect to:</p>
          <ul>
            <li>Provide and maintain our job listing service</li>
            <li>Process job posting payments ($10 Regular or $25 Featured listings)</li>
            <li>Send administrative information related to your job posting</li>
            <li>Improve our website and user experience</li>
            <li>Protect against fraudulent activity</li>
            <li>Comply with legal obligations</li>
          </ul>

          <h2>6. Sharing Your Information</h2>
          <p>We do not sell, trade, or otherwise transfer your personal information to third parties except:</p>
          <ul>
            <li>To trusted service providers who assist us in operating our website (e.g., Stripe for payment processing, Google Analytics for website analytics)</li>
            <li>When required by law, court order, or governmental authority</li>
            <li>In connection with a merger, acquisition, or sale of assets</li>
            <li>To protect the rights, property, or safety of our users or others</li>
          </ul>

          <h2>7. Data Retention</h2>
          <ul>
            <li><strong>Job listings (aggregated):</strong> Retained for 30 days, then automatically removed</li>
            <li><strong>Regular employer postings:</strong> Retained for 30 days from publication</li>
            <li><strong>Featured employer postings:</strong> Retained for 60 days from publication</li>
            <li><strong>Payment records:</strong> Retained as required by UK financial regulations (minimum 6 years)</li>
            <li><strong>Usage data:</strong> Anonymized and retained for analytical purposes</li>
          </ul>

          <h2>8. Data Security</h2>
          <p>We implement appropriate technical and organizational security measures to protect your personal information, including:</p>
          <ul>
            <li>SSL/TLS encryption for all data transmission</li>
            <li>Payment processing through Stripe (PCI-DSS Level 1 compliant)</li>
            <li>Regular security assessments</li>
            <li>Access controls for personal data</li>
          </ul>

          <h2>9. Your Rights (UK GDPR)</h2>
          <p>Under the UK GDPR, you have the following rights:</p>
          <ul>
            <li><strong>Right of Access:</strong> Request a copy of your personal data</li>
            <li><strong>Right to Rectification:</strong> Request correction of inaccurate data</li>
            <li><strong>Right to Erasure:</strong> Request deletion of your personal data</li>
            <li><strong>Right to Restrict Processing:</strong> Request limitation of processing</li>
            <li><strong>Right to Data Portability:</strong> Request transfer of your data</li>
            <li><strong>Right to Object:</strong> Object to processing based on legitimate interests</li>
            <li><strong>Right to Withdraw Consent:</strong> Withdraw consent at any time</li>
          </ul>
          <p>To exercise any of these rights, contact us at <a href="mailto:info@devglobaljobs.com">info@devglobaljobs.com</a>. We will respond within 30 days.</p>

          <h2>10. International Data Transfers</h2>
          <p>Your data may be transferred to and processed in countries outside the UK. When this occurs, we ensure appropriate safeguards are in place, such as Standard Contractual Clauses approved by the ICO.</p>

          <h2>11. Third-Party Links</h2>
          <p>Our website contains links to external job postings and employer websites. We are not responsible for the privacy practices of these external sites. We encourage you to read their privacy policies.</p>

          <h2>12. Children's Privacy</h2>
          <p>Our Service is not intended for individuals under the age of 16. We do not knowingly collect personal data from children.</p>

          <h2>13. Changes to This Policy</h2>
          <p>We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on this page with a revised "Last updated" date.</p>

          <h2>14. Complaints</h2>
          <p>If you are not satisfied with how we handle your personal data, you have the right to lodge a complaint with the Information Commissioner's Office (ICO):</p>
          <ul>
            <li>Website: <a href="https://ico.org.uk" target="_blank" rel="noopener noreferrer">ico.org.uk</a></li>
            <li>Phone: 0303 123 1113</li>
          </ul>

          <h2>15. Contact Us</h2>
          <p>If you have any questions about this Privacy Policy, please contact us:</p>
          <ul>
            <li>Email: <a href="mailto:info@devglobaljobs.com">info@devglobaljobs.com</a></li>
            <li>Phone: <a href="tel:+447473863903">+44 7473 863903</a> (UK)</li>
            <li>WhatsApp: <a href="https://wa.me/994518673521" target="_blank" rel="noopener noreferrer">+994 51 867 35 21</a></li>
            <li>Address: 27 Old Gloucester Street, London, WC1N 3AX, United Kingdom</li>
            <li>Company: <a href="https://trendnovaworld.com/" target="_blank" rel="noopener noreferrer">Trend Nova World Limited</a></li>
          </ul>
        </div>
      </Card>
    </div>
  );
}
