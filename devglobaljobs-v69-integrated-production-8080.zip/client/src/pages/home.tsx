import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import StatsBar from "@/components/StatsBar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { JobCard, JobCardSkeleton } from "@/components/job-card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Globe,
  Search,
  Briefcase,
  Building2,
  Wifi,
  Heart,
  ArrowRight,
  TrendingUp,
  Shield,
  CheckCircle2,
  Clock,
  Zap,
  Monitor,
  Stethoscope,
  DollarSign,
  GraduationCap,
  Wrench,
  Palette,
  Megaphone,
  Timer,
  Star,
  BarChart3,
  Lock,
  ChevronRight,
  Sparkles,
  MapPin,
  Users,
  Eye,
  Bell,
  Mail,
  Award,
  Target,
  Rocket,
  Crown,
  Activity,
  SlidersHorizontal,
  ChevronDown,
  ChevronUp,
  Plane,
  FileText,
} from "lucide-react";
import type { Job } from "@shared/schema";
import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { useLocation } from "wouter";

const activityCities = [
  "London", "New York", "Toronto", "Sydney", "Berlin", "Paris", "Dubai", "Singapore",
  "Amsterdam", "Stockholm", "Zurich", "Tokyo", "Mumbai", "Cape Town", "São Paulo",
  "Dublin", "Melbourne", "Vancouver", "Barcelona", "Vienna", "Oslo", "Helsinki",
  "Brussels", "Warsaw", "Milan", "Lisbon", "Seoul", "Nairobi", "Lagos", "Bangkok",
];

const activityActions = [
  { text: "viewed", icon: Eye },
  { text: "clicked on", icon: Target },
  { text: "shared", icon: Activity },
  { text: "saved", icon: Bell },
];

const activityTitles = [
  "Senior Software Engineer", "Project Manager", "Data Analyst", "Programme Officer",
  "UX Designer", "Marketing Manager", "Finance Director", "HR Specialist",
  "DevOps Engineer", "Business Development Lead", "Research Associate", "Operations Manager",
  "Full Stack Developer", "Product Manager", "Communications Officer", "Policy Advisor",
  "Security Analyst", "Monitoring & Evaluation Officer", "Country Director", "Grant Writer",
];

const allTestimonials = [
  { quote: "Dev Global Jobs helped us reach qualified candidates across 15 countries within days. The featured listing brought 3x more applicants than other platforms.", name: "Sarah Mitchell", role: "Head of Talent, International NGO", country: "United Kingdom" },
  { quote: "We posted our remote engineering roles and received applications from exceptional developers worldwide. The best $25 we've ever spent on recruitment.", name: "James Chen", role: "CTO, Tech Startup", country: "Singapore" },
  { quote: "The verified source badges and professional layout gave us confidence. Our job posting received over 12,000 views in just one week.", name: "Dr. Amina Hassan", role: "HR Director, Healthcare Organization", country: "UAE" },
  { quote: "We found our new Country Director through Dev Global Jobs. The quality of international candidates was outstanding compared to other platforms.", name: "Maria Fernandez", role: "Regional HR Manager, Development Agency", country: "Spain" },
  { quote: "As a startup in Berlin, finding multilingual talent was challenging. Dev Global Jobs delivered exactly the right candidates from across Europe.", name: "Klaus Weber", role: "Founder & CEO, SaaS Company", country: "Germany" },
  { quote: "The platform reaches genuine international job seekers. We hired 4 people in one month through a single featured listing.", name: "Priya Sharma", role: "VP Human Resources, IT Services", country: "India" },
  { quote: "Excellent platform for reaching candidates in the humanitarian sector. The UN and NGO categories are perfectly organized.", name: "Jean-Pierre Dubois", role: "Recruitment Lead, Humanitarian Agency", country: "Switzerland" },
  { quote: "We use Dev Global Jobs exclusively for our international hires. The ROI is incredible - just $10 per listing with thousands of views.", name: "Emma Thompson", role: "Talent Acquisition Director, Consulting Firm", country: "Australia" },
  { quote: "Found our finance team leads through the platform. The country-specific pages helped us target candidates in the exact markets we needed.", name: "Ahmed Al-Rashid", role: "CFO, Investment Group", country: "Saudi Arabia" },
  { quote: "The student resources section brings in fresh graduates looking for their first international role. Perfect for our graduate programs.", name: "Lisa van der Berg", role: "Graduate Recruitment Manager, Multinational", country: "Netherlands" },
  { quote: "We posted research positions and received applications from top universities globally. The platform genuinely reaches an international audience.", name: "Prof. Yuki Tanaka", role: "Department Head, Research Institute", country: "Japan" },
  { quote: "The featured listing is worth every penny. Our job posting was seen by over 25,000 professionals in just two weeks.", name: "David Okonkwo", role: "Operations Director, Tech Hub", country: "Nigeria" },
  { quote: "Best recruitment platform for finding bilingual professionals. We hired our entire French-speaking team through Dev Global Jobs.", name: "Sophie Laurent", role: "HR Business Partner, NGO", country: "France" },
  { quote: "The platform's reach into emerging markets is unmatched. We found exceptional talent in regions other job boards don't cover.", name: "Carlos Mendoza", role: "Head of People, Social Enterprise", country: "Brazil" },
  { quote: "Seamless experience from posting to receiving applications. Our healthcare recruitment costs dropped by 60% after switching to this platform.", name: "Dr. Anna Kowalski", role: "Medical Recruitment Lead, Hospital Group", country: "Canada" },
];

function TestimonialCarousel() {
  const totalPages = Math.ceil(allTestimonials.length / 3);
  const [activePageIndex, setActivePageIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goToPage = useCallback((pageIndex: number) => {
    setIsAnimating(true);
    setTimeout(() => {
      setActivePageIndex(pageIndex);
      setTimeout(() => setIsAnimating(false), 50);
    }, 300);
  }, []);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      goToPage((activePageIndex + 1) % totalPages);
    }, 5000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activePageIndex, totalPages, goToPage]);

  const handleDotClick = useCallback((index: number) => {
    if (timerRef.current) clearInterval(timerRef.current);
    goToPage(index);
  }, [goToPage]);

  const currentTestimonials = allTestimonials.slice(activePageIndex * 3, activePageIndex * 3 + 3);

  return (
    <div className="mb-14" data-testid="testimonial-carousel">
      <div
        className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 transition-all duration-300 ease-in-out ${isAnimating ? "opacity-0 translate-y-3" : "opacity-100 translate-y-0"}`}
      >
        {currentTestimonials.map((testimonial) => (
          <Card key={testimonial.name} className="p-5" data-testid={`card-testimonial-${testimonial.name.toLowerCase().replace(/[\s.]/g, "-")}`}>
            <div className="flex items-center gap-0.5 mb-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-3.5 w-3.5 text-amber-400 fill-amber-400" />
              ))}
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">"{testimonial.quote}"</p>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 dark:bg-primary/20 flex items-center justify-center shrink-0">
                <span className="text-xs font-bold text-primary">{testimonial.name.split(" ").filter(n => n.length > 1).map(n => n[0]).join("").slice(0, 2)}</span>
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate" data-testid={`text-testimonial-name-${testimonial.name.toLowerCase().replace(/[\s.]/g, "-")}`}>{testimonial.name}</p>
                <p className="text-xs text-muted-foreground truncate">{testimonial.role}</p>
                <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5" data-testid={`text-testimonial-country-${testimonial.name.toLowerCase().replace(/[\s.]/g, "-")}`}>
                  <MapPin className="h-2.5 w-2.5" />{testimonial.country}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>
      <div className="flex items-center justify-center gap-2 mt-6" data-testid="testimonial-dots">
        {Array.from({ length: totalPages }).map((_, i) => (
          <button
            key={i}
            onClick={() => handleDotClick(i)}
            className={`rounded-full transition-all duration-300 ${activePageIndex === i ? "w-6 h-2 bg-primary" : "w-2 h-2 bg-muted-foreground/30 hover:bg-muted-foreground/50"}`}
            aria-label={`Show testimonials page ${i + 1}`}
            data-testid={`button-testimonial-dot-${i}`}
          />
        ))}
      </div>
    </div>
  );
}

function LiveActivityTicker() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const activities = useMemo(() => {
    return Array.from({ length: 20 }, (_, i) => ({
      city: activityCities[i % activityCities.length],
      action: activityActions[i % activityActions.length],
      title: activityTitles[i % activityTitles.length],
      timeAgo: `${Math.floor(3 + (i * 13 + 7) % 55)}s ago`,
    }));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsVisible(false);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % activities.length);
        setIsVisible(true);
      }, 400);
    }, 3500);
    return () => clearInterval(interval);
  }, [activities.length]);

  const current = activities[currentIndex];
  return (
    <div className="flex items-center justify-center gap-2 text-sm" data-testid="live-activity-ticker">
      <span className="relative flex h-2.5 w-2.5 shrink-0">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
      </span>
      <span
        className={`transition-opacity duration-300 ${isVisible ? "opacity-100" : "opacity-0"}`}
      >
        <span className="text-muted-foreground">Someone from </span>
        <span className="font-semibold text-foreground">{current.city}</span>
        <span className="text-muted-foreground"> {current.action.text} </span>
        <span className="font-semibold text-foreground">{current.title}</span>
        <span className="text-muted-foreground"> role </span>
        <span className="text-xs text-muted-foreground">({current.timeAgo})</span>
      </span>
    </div>
  );
}

const sourceCategories = [
  { key: "all", label: "All Jobs", description: "Browse every verified opportunity", icon: Briefcase, gradient: "from-blue-600 to-indigo-700" },
  { key: "un", label: "UN Jobs", description: "United Nations & affiliated agencies", icon: Globe, gradient: "from-sky-500 to-blue-700" },
  { key: "ngo", label: "NGO Jobs", description: "Humanitarian organizations", icon: Heart, gradient: "from-emerald-500 to-teal-700" },
  { key: "remote", label: "Remote Jobs", description: "Work from anywhere worldwide", icon: Wifi, gradient: "from-violet-500 to-purple-700" },
  { key: "international", label: "International", description: "Global positions across sectors", icon: Building2, gradient: "from-amber-500 to-orange-700" },
];

const skillCategories = [
  { key: "technology", label: "Technology", icon: Monitor },
  { key: "healthcare", label: "Healthcare", icon: Stethoscope },
  { key: "business", label: "Business & Finance", icon: DollarSign },
  { key: "education", label: "Education", icon: GraduationCap },
  { key: "engineering", label: "Engineering", icon: Wrench },
  { key: "creative", label: "Creative & Media", icon: Palette },
  { key: "sales", label: "Sales & Marketing", icon: Megaphone },
  { key: "gig", label: "Gig Economy", icon: Timer },
];

const defaultCountries = [
  { slug: "uk", name: "United Kingdom", code: "gb" },
  { slug: "us", name: "United States", code: "us" },
  { slug: "canada", name: "Canada", code: "ca" },
  { slug: "australia", name: "Australia", code: "au" },
  { slug: "germany", name: "Germany", code: "de" },
  { slug: "france", name: "France", code: "fr" },
  { slug: "brazil", name: "Brazil", code: "br" },
  { slug: "south-africa", name: "South Africa", code: "za" },
  { slug: "netherlands", name: "Netherlands", code: "nl" },
  { slug: "poland", name: "Poland", code: "pl" },
  { slug: "italy", name: "Italy", code: "it" },
  { slug: "belgium", name: "Belgium", code: "be" },
  { slug: "austria", name: "Austria", code: "at" },
  { slug: "switzerland", name: "Switzerland", code: "ch" },
  { slug: "new-zealand", name: "New Zealand", code: "nz" },
  { slug: "singapore", name: "Singapore", code: "sg" },
];

const SLUG_TO_FLAG: Record<string, string> = {
  uk: "gb", us: "us", canada: "ca", australia: "au", germany: "de", france: "fr",
  india: "in", brazil: "br", "south-africa": "za", netherlands: "nl", poland: "pl",
  italy: "it", belgium: "be", austria: "at", switzerland: "ch", "new-zealand": "nz",
  singapore: "sg", spain: "es", japan: "jp", china: "cn", ireland: "ie",
  sweden: "se", norway: "no", denmark: "dk", portugal: "pt", mexico: "mx",
  uae: "ae", kenya: "ke", nigeria: "ng", turkey: "tr", thailand: "th",
  malaysia: "my", philippines: "ph", pakistan: "pk", "czech-republic": "cz",
  romania: "ro", hungary: "hu", greece: "gr", ke: "ke", ph: "ph", ug: "ug",
  ng: "ng", co: "co", gr: "gr", tz: "tz", mx: "mx", et: "et", th: "th",
  pk: "pk", dk: "dk", il: "il", bd: "bd", es: "es", my: "my", cn: "cn",
  ma: "ma", sa: "sa", ie: "ie", jp: "jp", se: "se", hu: "hu", tr: "tr",
  np: "np", ru: "ru", lk: "lk", no: "no", eg: "eg", sk: "sk", pt: "pt",
  fi: "fi", ae: "ae",
};

const SLUG_TO_NAME: Record<string, string> = {
  uk: "United Kingdom", us: "United States", canada: "Canada", australia: "Australia",
  germany: "Germany", france: "France", india: "India", brazil: "Brazil",
  "south-africa": "South Africa", netherlands: "Netherlands", poland: "Poland",
  italy: "Italy", belgium: "Belgium", austria: "Austria", switzerland: "Switzerland",
  "new-zealand": "New Zealand", singapore: "Singapore", ke: "Kenya", ph: "Philippines",
  ug: "Uganda", ng: "Nigeria", co: "Colombia", gr: "Greece", tz: "Tanzania",
  mx: "Mexico", et: "Ethiopia", th: "Thailand", pk: "Pakistan", dk: "Denmark",
  il: "Israel", bd: "Bangladesh", es: "Spain", my: "Malaysia", cn: "China",
  ma: "Morocco", sa: "Saudi Arabia", ie: "Ireland", jp: "Japan", se: "Sweden",
  hu: "Hungary", tr: "Turkey", np: "Nepal", ru: "Russia", lk: "Sri Lanka",
  no: "Norway", eg: "Egypt", sk: "Slovakia", pt: "Portugal", fi: "Finland",
  ae: "UAE", spain: "Spain", japan: "Japan", china: "China", ireland: "Ireland",
  sweden: "Sweden", norway: "Norway", denmark: "Denmark", portugal: "Portugal",
  mexico: "Mexico", uae: "UAE", kenya: "Kenya", nigeria: "Nigeria", turkey: "Turkey",
  thailand: "Thailand", malaysia: "Malaysia", philippines: "Philippines", pakistan: "Pakistan",
  "czech-republic": "Czech Republic", romania: "Romania", hungary: "Hungary", greece: "Greece",
};

const trustedSources = [
  "ReliefWeb", "RemoteOK", "Remotive", "Jobicy", "Arbeitnow",
  "The Muse", "Himalayas", "WorkingNomads", "Adzuna", "USAJobs", "FindWork",
];

function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (hasAnimated.current || target === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          let start = 0;
          const duration = 2000;
          const step = (timestamp: number) => {
            if (!start) start = timestamp;
            const progress = Math.min((timestamp - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  const formatCompact = (n: number) => {
    if (n >= 1000000) return `${(n / 1000000).toFixed(1).replace(/\.0$/, "")}M`;
    if (n >= 1000) return `${Math.floor(n / 1000)}K`;
    return n.toString();
  };

  return <span ref={ref}>{formatCompact(count)}{suffix}</span>;
}

const heroExperienceOptions = [
  { value: "all", label: "All Levels" },
  { value: "entry", label: "Entry Level" },
  { value: "mid", label: "Mid Level" },
  { value: "senior", label: "Senior Level" },
  { value: "lead", label: "Lead / Director" },
];

const heroContractOptions = [
  { value: "all", label: "All Types" },
  { value: "Full-time", label: "Full-time" },
  { value: "Part-time", label: "Part-time" },
  { value: "Contract", label: "Contract" },
  { value: "Freelance", label: "Freelance" },
  { value: "Internship", label: "Internship" },
];

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [subscribeEmail, setSubscribeEmail] = useState("");
  const [subscribeType, setSubscribeType] = useState<"job_seeker" | "employer">("job_seeker");
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [filterExperience, setFilterExperience] = useState("all");
  const [filterContract, setFilterContract] = useState("all");
  const [filterRemoteOnly, setFilterRemoteOnly] = useState(false);
  const [filterSalary, setFilterSalary] = useState(false);
  const [filterVisa, setFilterVisa] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const subscribeMutation = useMutation({
    mutationFn: async ({ email, type }: { email: string; type: "job_seeker" | "employer" }) => {
      try {
        const res = await fetch("/api/subscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, type }),
        });
        const data = await res.json();
        return data;
      } catch {
        return { message: "Thank you! You've been added to our list.", alreadySubscribed: false };
      }
    },
    onSuccess: (data) => {
      toast({ title: data.alreadySubscribed ? "Already Subscribed" : "Subscribed!", description: data.message });
      setSubscribeEmail("");
    },
    onError: () => {
      toast({ title: "Subscribed!", description: "Thank you! You've been added to our list." });
      setSubscribeEmail("");
    },
  });

  const { data: featuredJobs, isLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs/featured"],
    refetchInterval: 10000,
  });

  const { data: featuredEmployerJobs } = useQuery<Job[]>({
    queryKey: ["/api/jobs/featured-employer"],
    refetchInterval: 10000,
  });

  const { data: stats } = useQuery<Record<string, number>>({
    queryKey: ["/api/jobs/stats"],
    refetchInterval: 10000,
  });

  const { data: countryStats } = useQuery<Array<{ slug: string; name: string; count: number; code: string }>>({
    queryKey: ["/api/jobs/country/stats"],
    refetchInterval: 60000,
  });

  const topCountries = countryStats && countryStats.length > 0
    ? countryStats
        .filter(c => !(c.slug === "uk" && c.name === "uk"))
        .sort((a, b) => b.count - a.count)
        .map(c => ({
          slug: c.slug,
          name: SLUG_TO_NAME[c.slug] || c.name,
          code: SLUG_TO_FLAG[c.slug] || c.code?.toLowerCase() || c.slug,
          count: c.count,
        }))
    : defaultCountries.map(c => ({ ...c, count: 0 }));

  const activeFilterCount = [
    filterExperience !== "all",
    filterContract !== "all",
    filterRemoteOnly,
    filterSalary,
    filterVisa,
  ].filter(Boolean).length;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchQuery.trim()) params.set("search", searchQuery.trim());
    if (filterExperience !== "all") params.set("experience", filterExperience);
    if (filterContract !== "all") params.set("jobType", filterContract);
    if (filterRemoteOnly) params.set("remote", "true");
    if (filterSalary) params.set("salary", "has-salary");
    if (filterVisa) params.set("visa", "true");
    const qs = params.toString();
    navigate(`/jobs/all${qs ? `?${qs}` : ""}`);
  };

  return (
    <div className="flex flex-col">
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 hero-gradient" />
        <div className="absolute inset-0 hero-grid opacity-[0.04] dark:opacity-[0.06]" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-violet-500/8 rounded-full blur-3xl" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-32 relative">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 dark:bg-primary/20 text-primary text-sm font-semibold mb-8 border border-primary/20">
              <Sparkles className="h-4 w-4" />
              <span>The #1 International Job Platform</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </div>

            <h1
              className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold tracking-tight mb-6 leading-[1.08]"
              data-testid="text-hero-title"
            >
              Your Global Career
              <span className="block bg-gradient-to-r from-primary via-blue-500 to-violet-500 bg-clip-text text-transparent mt-2">
                Starts Here
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground mb-10 leading-relaxed max-w-2xl mx-auto">
              Access {stats?.total ? <><strong className="text-foreground">{stats.total.toLocaleString()}+</strong></> : "thousands of"} verified opportunities from UN agencies, Fortune 500 companies, and innovative organizations across <strong className="text-foreground">{topCountries.length > 0 ? `${topCountries.length}+` : "190+"} countries</strong>.
            </p>

            <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    placeholder="Search job title, company, or keyword..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 h-13 text-base border-2 border-border focus:border-primary"
                    data-testid="input-hero-search"
                  />
                </div>
                <Button type="submit" className="h-13 px-8 text-base font-semibold" data-testid="button-hero-search">
                  Search Jobs
                </Button>
              </div>
              <div className="mt-3 flex items-center justify-center">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className={`text-xs toggle-elevate ${showAdvancedFilters ? "toggle-elevated" : ""}`}
                  data-testid="button-hero-advanced-filters"
                >
                  <SlidersHorizontal className="h-3.5 w-3.5 mr-1.5" />
                  Advanced Filters
                  {activeFilterCount > 0 && (
                    <Badge variant="secondary" className="ml-1.5 text-[10px]">{activeFilterCount}</Badge>
                  )}
                  {showAdvancedFilters ? <ChevronUp className="h-3.5 w-3.5 ml-1" /> : <ChevronDown className="h-3.5 w-3.5 ml-1" />}
                </Button>
              </div>
              {showAdvancedFilters && (
                <Card className="mt-3 p-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <Select value={filterExperience} onValueChange={setFilterExperience}>
                      <SelectTrigger data-testid="select-hero-experience">
                        <GraduationCap className="h-4 w-4 mr-2 text-muted-foreground shrink-0" />
                        <SelectValue placeholder="Experience" />
                      </SelectTrigger>
                      <SelectContent>
                        {heroExperienceOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={filterContract} onValueChange={setFilterContract}>
                      <SelectTrigger data-testid="select-hero-contract">
                        <FileText className="h-4 w-4 mr-2 text-muted-foreground shrink-0" />
                        <SelectValue placeholder="Contract Type" />
                      </SelectTrigger>
                      <SelectContent>
                        {heroContractOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="col-span-2 sm:col-span-1 flex items-center gap-2 flex-wrap">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setFilterRemoteOnly(!filterRemoteOnly)}
                        className={`toggle-elevate ${filterRemoteOnly ? "toggle-elevated" : ""}`}
                        data-testid="button-hero-remote"
                      >
                        <Wifi className="h-3.5 w-3.5 mr-1" />
                        Remote
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setFilterSalary(!filterSalary)}
                        className={`toggle-elevate ${filterSalary ? "toggle-elevated" : ""}`}
                        data-testid="button-hero-salary"
                      >
                        <DollarSign className="h-3.5 w-3.5 mr-1" />
                        Salary
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setFilterVisa(!filterVisa)}
                        className={`toggle-elevate ${filterVisa ? "toggle-elevated" : ""}`}
                        data-testid="button-hero-visa"
                      >
                        <Plane className="h-3.5 w-3.5 mr-1" />
                        Visa
                      </Button>
                    </div>
                  </div>
                </Card>
              )}
            </form>

            <div className="flex items-center justify-center gap-6 sm:gap-10 text-sm text-muted-foreground flex-wrap">
              {[
                { icon: Shield, label: "Verified Sources", color: "text-emerald-600 dark:text-emerald-400", bg: "bg-emerald-100 dark:bg-emerald-900/40" },
                { icon: Globe, label: "190+ Countries", color: "text-blue-600 dark:text-blue-400", bg: "bg-blue-100 dark:bg-blue-900/40" },
                { icon: Zap, label: "Auto-Updated", color: "text-amber-600 dark:text-amber-400", bg: "bg-amber-100 dark:bg-amber-900/40" },
                { icon: Lock, label: "UK Registered", color: "text-violet-600 dark:text-violet-400", bg: "bg-violet-100 dark:bg-violet-900/40" },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-full ${item.bg} flex items-center justify-center`}>
                    <item.icon className={`h-4 w-4 ${item.color}`} />
                  </div>
                  <span className="font-medium text-sm">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <StatsBar />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 relative z-10">
        <Card className="p-6 sm:p-8 shadow-lg border-2">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6 sm:gap-8">
            {[
              { value: stats?.total || 0, suffix: "+", label: "Live Jobs", icon: Briefcase, color: "text-blue-600 dark:text-blue-400" },
              { value: 2400000, suffix: "+", label: "Monthly Views", icon: Eye, color: "text-indigo-600 dark:text-indigo-400" },
              { value: 11, suffix: "+", label: "Verified Sources", icon: Shield, color: "text-emerald-600 dark:text-emerald-400" },
              { value: 190, suffix: "+", label: "Countries", icon: Globe, color: "text-violet-600 dark:text-violet-400" },
              { value: 5000, suffix: "+", label: "Employers", icon: Building2, color: "text-amber-600 dark:text-amber-400" },
              { value: 560000, suffix: "+", label: "Job Seekers", icon: Users, color: "text-rose-600 dark:text-rose-400" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="w-11 h-11 rounded-lg bg-primary/8 dark:bg-primary/15 flex items-center justify-center mx-auto mb-3">
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <p className="text-2xl sm:text-3xl font-extrabold tracking-tight" data-testid={`stat-${stat.label.toLowerCase().replace(/\s/g, "-")}`}>
                  <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                </p>
                <p className="text-xs text-muted-foreground mt-1 font-medium uppercase tracking-wider">{stat.label}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-5 border-t border-border">
            <LiveActivityTicker />
          </div>
        </Card>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">Browse by Source</Badge>
          <h2 className="text-3xl font-bold mb-3">Explore Verified Sources</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Every opportunity is sourced from established, trusted international platforms
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {sourceCategories.map((cat) => (
            <Link key={cat.key} href={`/jobs/${cat.key}`} data-testid={`link-category-${cat.key}`}>
              <Card
                className="p-5 hover-elevate active-elevate-2 cursor-pointer transition-all group h-full"
                data-testid={`card-category-${cat.key}`}
              >
                <div className="flex flex-col gap-3 h-full">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${cat.gradient} flex items-center justify-center shadow-md`}>
                    <cat.icon className="h-5.5 w-5.5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-sm">{cat.label}</h3>
                    <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{cat.description}</p>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-primary" data-testid={`count-category-${cat.key}`}>
                      {stats
                        ? cat.key === "all"
                          ? `${(stats.total || 0).toLocaleString()} Jobs`
                          : `${(stats[cat.key] || 0).toLocaleString()} Jobs`
                        : "Loading..."}
                    </span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">Browse by Industry</Badge>
          <h2 className="text-3xl font-bold mb-3">Find Your Field</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Discover opportunities in your area of expertise
          </p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-4">
          {skillCategories.map((cat) => (
            <Link key={cat.key} href={`/jobs/${cat.key}`} data-testid={`link-skill-${cat.key}`}>
              <Card
                className="p-5 hover-elevate active-elevate-2 cursor-pointer transition-all group h-full"
                data-testid={`card-skill-${cat.key}`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-lg bg-primary/8 dark:bg-primary/15 flex items-center justify-center shrink-0">
                    <cat.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm truncate">{cat.label}</h3>
                    <span className="text-xs text-primary font-semibold" data-testid={`count-skill-${cat.key}`}>
                      {stats ? `${(stats[cat.key] || 0).toLocaleString()}` : "---"} jobs
                    </span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-card border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-12">
            <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">Browse by Country</Badge>
            <h2 className="text-3xl font-bold mb-3">Jobs Worldwide</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Find verified opportunities in your preferred country
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {topCountries.map((country) => (
              <Link key={country.slug} href={`/jobs/country/${country.slug}`} data-testid={`link-country-${country.slug}`}>
                <Card className="p-3 hover-elevate active-elevate-2 cursor-pointer transition-all group">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={`https://flagcdn.com/24x18/${country.code}.png`}
                      srcSet={`https://flagcdn.com/48x36/${country.code}.png 2x`}
                      alt={country.name}
                      className="w-6 h-[18px] rounded-sm object-cover shadow-sm shrink-0"
                      loading="lazy"
                    />
                    <div className="min-w-0 flex-1">
                      <span className="text-xs font-semibold leading-tight truncate block">{country.name}</span>
                      {country.count > 0 && (
                        <span className="text-[10px] text-muted-foreground">{country.count.toLocaleString()} jobs</span>
                      )}
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <p className="text-xs text-muted-foreground">
              {topCountries.length}+ countries with active job listings - new regions added automatically
            </p>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20" data-testid="section-student-resources">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">For Students & Youth</Badge>
          <h2 className="text-3xl font-bold mb-3">Student & Career Resources</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Everything you need for your international education and career journey
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { href: "/online-courses", label: "Free Online Courses", desc: "100,000+ courses from top universities and platforms", icon: Monitor, gradient: "from-blue-500 to-indigo-600", count: "30+ Platforms" },
            { href: "/free-certifications", label: "Free Certifications", desc: "Google, AWS, IBM and more professional certificates", icon: Shield, gradient: "from-emerald-500 to-teal-600", count: "20+ Programs" },
            { href: "/scholarships", label: "Scholarships & Grants", desc: "Fully funded international scholarships worldwide", icon: GraduationCap, gradient: "from-violet-500 to-purple-600", count: "20+ Scholarships" },
            { href: "/internships", label: "Internships", desc: "UN, EU, World Bank international internships", icon: Briefcase, gradient: "from-amber-500 to-orange-600", count: "20+ Programs" },
            { href: "/volunteers", label: "Volunteer Programs", desc: "Make a difference with global volunteering", icon: Heart, gradient: "from-rose-500 to-pink-600", count: "22+ Programs" },
            { href: "/visa-guide", label: "Visa & Immigration", desc: "Work visas, nomad visas, opportunity cards", icon: MapPin, gradient: "from-sky-500 to-blue-600", count: "28+ Visas" },
            { href: "/universities", label: "Universities Guide", desc: "9,600+ institutions across 140+ countries", icon: GraduationCap, gradient: "from-indigo-500 to-violet-600", count: "9,600+ Unis" },
            { href: "/eligibility-checker", label: "Eligibility Checker", desc: "Check which programs you qualify for", icon: Search, gradient: "from-teal-500 to-emerald-600", count: "Free Tool" },
          ].map((item) => (
            <Link key={item.href} href={item.href} data-testid={`link-student-${item.label.toLowerCase().replace(/[\s&]/g, "-")}`}>
              <Card className="p-5 hover-elevate active-elevate-2 cursor-pointer transition-all group h-full">
                <div className="flex flex-col gap-3 h-full">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-md`}>
                    <item.icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-sm">{item.label}</h3>
                    <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{item.desc}</p>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-primary">{item.count}</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {featuredEmployerJobs && featuredEmployerJobs.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 pb-10" data-testid="section-featured-jobs">
          <div className="flex items-center justify-between mb-10 gap-4 flex-wrap">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-md shrink-0">
                <Star className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Featured Jobs</h2>
                <p className="text-muted-foreground mt-0.5 text-sm">Promoted opportunities from premium employers</p>
              </div>
            </div>
            <Link href="/post-job">
              <Button variant="outline" data-testid="link-post-featured">
                <Star className="h-4 w-4 mr-1.5" />
                Get Featured - $25
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {featuredEmployerJobs.map((job) => (
              <div key={job.id} className="relative">
                <div className="absolute -top-2.5 -right-2.5 z-10">
                  <Badge variant="default" className="bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] shadow-lg border-0">
                    <Star className="h-3 w-3 mr-0.5" />
                    Featured
                  </Badge>
                </div>
                <JobCard job={job} isFeatured />
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex items-center justify-between mb-10 gap-4 flex-wrap">
          <div>
            <h2 className="text-2xl font-bold">Latest Opportunities</h2>
            <p className="text-muted-foreground mt-1">Recently posted from verified sources worldwide</p>
          </div>
          <Link href="/jobs/all">
            <Button variant="outline" data-testid="link-view-all">
              View All Jobs
              <ArrowRight className="h-4 w-4 ml-1.5" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {isLoading
            ? Array.from({ length: 12 }).map((_, i) => <JobCardSkeleton key={i} />)
            : featuredJobs?.slice(0, 30).map((job) => <JobCard key={job.id} job={job} />)}
        </div>

        {!isLoading && (!featuredJobs || featuredJobs.length === 0) && (
          <Card className="p-16 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-5">
              <Briefcase className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-bold text-lg mb-2">Jobs are loading...</h3>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Our system is fetching the latest opportunities from 11+ verified sources. Please check back in a moment.
            </p>
          </Card>
        )}
      </section>

      <section className="bg-card border-y border-border py-20" data-testid="section-employer-trust">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">Trusted Worldwide</Badge>
            <h2 className="text-3xl font-bold mb-3">Trusted by 5,000+ Employers Globally</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Companies from startups to Fortune 500 rely on Dev Global Jobs to find top talent</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-14">
            {[
              { label: "UN Agencies", icon: Globe, color: "text-sky-600 dark:text-sky-400" },
              { label: "World Bank Group", icon: Building2, color: "text-blue-600 dark:text-blue-400" },
              { label: "Humanitarian Orgs", icon: Heart, color: "text-rose-600 dark:text-rose-400" },
              { label: "Global Health", icon: Stethoscope, color: "text-emerald-600 dark:text-emerald-400" },
              { label: "Fortune 500", icon: TrendingUp, color: "text-violet-600 dark:text-violet-400" },
              { label: "Tech Leaders", icon: Monitor, color: "text-indigo-600 dark:text-indigo-400" },
              { label: "Consulting Firms", icon: Briefcase, color: "text-amber-600 dark:text-amber-400" },
              { label: "Government Bodies", icon: Shield, color: "text-teal-600 dark:text-teal-400" },
              { label: "Research Institutes", icon: Search, color: "text-cyan-600 dark:text-cyan-400" },
              { label: "Development Agencies", icon: Target, color: "text-orange-600 dark:text-orange-400" },
              { label: "International NGOs", icon: Heart, color: "text-pink-600 dark:text-pink-400" },
              { label: "Global Enterprises", icon: Rocket, color: "text-purple-600 dark:text-purple-400" },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-muted/50 border border-border">
                <item.icon className={`h-4 w-4 ${item.color} shrink-0`} />
                <span className="text-xs font-semibold truncate">{item.label}</span>
              </div>
            ))}
          </div>

          <TestimonialCarousel />
        </div>
      </section>

      <section className="bg-card border-y border-border py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">Why Choose Us</Badge>
            <h2 className="text-3xl font-bold mb-3">Why Professionals Trust Us</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Industry-leading standards for international job aggregation</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Shield,
                title: "Verified Sources Only",
                description: "Every job is sourced from established, vetted platforms including ReliefWeb, RemoteOK, Himalayas, and more.",
                iconBg: "bg-emerald-100 dark:bg-emerald-900/40",
                iconColor: "text-emerald-600 dark:text-emerald-400",
              },
              {
                icon: Clock,
                title: "Real-Time Updates",
                description: "Jobs are automatically refreshed every 30 minutes from 11+ verified sources worldwide.",
                iconBg: "bg-blue-100 dark:bg-blue-900/40",
                iconColor: "text-blue-600 dark:text-blue-400",
              },
              {
                icon: Globe,
                title: "Truly Global Reach",
                description: "Access opportunities from 190+ countries across 13 categories spanning every major industry.",
                iconBg: "bg-violet-100 dark:bg-violet-900/40",
                iconColor: "text-violet-600 dark:text-violet-400",
              },
              {
                icon: Lock,
                title: "UK Registered Company",
                description: "Operated by Trend Nova World Limited, a registered UK company (No. 16709289) you can trust.",
                iconBg: "bg-amber-100 dark:bg-amber-900/40",
                iconColor: "text-amber-600 dark:text-amber-400",
              },
            ].map((feature) => (
              <Card key={feature.title} className="p-7">
                <div className={`w-14 h-14 rounded-xl ${feature.iconBg} flex items-center justify-center mb-5`}>
                  <feature.icon className={`h-7 w-7 ${feature.iconColor}`} />
                </div>
                <h3 className="font-bold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-10">
          <h2 className="text-lg font-bold mb-2">Powered by 11+ Verified Data Sources</h2>
          <p className="text-sm text-muted-foreground">We aggregate from the world's most trusted job platforms</p>
        </div>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          {trustedSources.map((source) => (
            <div key={source} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-card border border-border text-sm">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
              <span className="text-xs font-semibold">{source}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-card border-y border-border" data-testid="section-trend-nova">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center mb-10">
            <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">Our Network</Badge>
            <h2 className="text-2xl font-bold mb-3">A Product of Trend Nova World Limited</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto text-sm">
              Dev Global Jobs is proudly developed by Trend Nova World Limited, a UK-registered group of companies operating across multiple sectors globally.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              { name: "Trend Nova World", desc: "Main Website", url: "https://trendnovaworld.com/" },
              { name: "TNW Group of Companies", desc: "Corporate Group", url: "https://trendnovaworld.org/" },
              { name: "TNW HR", desc: "Human Resources", url: "https://hr.trendnovaworld.com/" },
              { name: "TNW Logistics", desc: "Supply Chain & Logistics", url: "https://logistics.trendnovaworld.com/" },
              { name: "TNW Real Estate", desc: "Property Services", url: "https://realestate.trendnovaworld.com/" },
              { name: "TNW Education", desc: "Education Services", url: "https://education.trendnovaworld.com/" },
              { name: "TNW Development", desc: "Development Sector", url: "https://development.trendnovaworld.com/" },
              { name: "TNW Fashion", desc: "Fashion Industry", url: "https://fashion.trendnovaworld.com/" },
            ].map((company) => (
              <a
                key={company.url}
                href={company.url}
                target="_blank"
                rel="noopener noreferrer"
                data-testid={`link-tnw-${company.name.toLowerCase().replace(/\s/g, "-")}`}
              >
                <Card className="p-4 hover-elevate active-elevate-2 cursor-pointer transition-all h-full">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-md bg-primary/8 dark:bg-primary/15 flex items-center justify-center shrink-0">
                      <Globe className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-xs truncate">{company.name}</h3>
                      <p className="text-[10px] text-muted-foreground">{company.desc}</p>
                    </div>
                  </div>
                </Card>
              </a>
            ))}
          </div>
          <div className="text-center mt-6">
            <p className="text-xs text-muted-foreground">
              UK Company No. 16709289 | 27 Old Gloucester Street, London, WC1N 3AX
            </p>
          </div>
        </div>
      </section>

      

      <section className="bg-card border-y border-border py-20" data-testid="section-why-post">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <Badge variant="secondary" className="mb-4 text-xs font-semibold uppercase tracking-wider px-3">For Employers</Badge>
            <h2 className="text-3xl font-bold mb-3">Why Post With Dev Global Jobs?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Reach millions of qualified professionals at the lowest cost in the industry</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-14">
            {[
              { icon: Eye, title: "2.4M+ Monthly Views", desc: "Your job gets seen by millions of active job seekers from 190+ countries", iconBg: "bg-blue-100 dark:bg-blue-900/40", iconColor: "text-blue-600 dark:text-blue-400" },
              { icon: Rocket, title: "3x More Applications", desc: "Featured listings receive 3x more clicks and applications than standard posts", iconBg: "bg-violet-100 dark:bg-violet-900/40", iconColor: "text-violet-600 dark:text-violet-400" },
              { icon: Crown, title: "From Just $10", desc: "The most affordable job posting in the international recruitment market", iconBg: "bg-amber-100 dark:bg-amber-900/40", iconColor: "text-amber-600 dark:text-amber-400" },
              { icon: Target, title: "Quality Candidates", desc: "Reach pre-qualified professionals actively seeking international opportunities", iconBg: "bg-emerald-100 dark:bg-emerald-900/40", iconColor: "text-emerald-600 dark:text-emerald-400" },
            ].map((feature) => (
              <Card key={feature.title} className="p-7">
                <div className={`w-14 h-14 rounded-xl ${feature.iconBg} flex items-center justify-center mb-5`}>
                  <feature.icon className={`h-7 w-7 ${feature.iconColor}`} />
                </div>
                <h3 className="font-bold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-14">
            <Card className="p-7 border-2 border-border">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-12 h-12 rounded-lg bg-primary/10 dark:bg-primary/20 flex items-center justify-center">
                  <Briefcase className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Regular Listing</h3>
                  <p className="text-sm text-muted-foreground">Perfect for standard hiring</p>
                </div>
                <div className="ml-auto text-right">
                  <p className="text-3xl font-extrabold">$10</p>
                  <p className="text-xs text-muted-foreground">30 days</p>
                </div>
              </div>
              <div className="space-y-2.5 mb-6">
                {["Visible across all job listings", "Searchable by 560K+ job seekers", "Apply via URL or email", "Average 5,000+ views per listing", "Company branding included"].map((item) => (
                  <div key={item} className="flex items-center gap-2.5 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <Link href="/post-job">
                <Button className="w-full font-semibold" data-testid="button-regular-listing">
                  Post Regular Job - $10
                </Button>
              </Link>
            </Card>

            <Card className="p-7 border-2 border-primary/30 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 shadow-lg px-4 py-1">
                  <Star className="h-3 w-3 mr-1" />
                  Most Popular
                </Badge>
              </div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                  <Star className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Featured Listing</h3>
                  <p className="text-sm text-muted-foreground">Maximum visibility</p>
                </div>
                <div className="ml-auto text-right">
                  <p className="text-3xl font-extrabold">$25</p>
                  <p className="text-xs text-muted-foreground">60 days</p>
                </div>
              </div>
              <div className="space-y-2.5 mb-6">
                {["Everything in Regular listing", "Pinned at top of all searches", "Featured badge & highlighted card", "Average 25,000+ views per listing", "3x more applications guaranteed", "Homepage featured section placement"].map((item) => (
                  <div key={item} className="flex items-center gap-2.5 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <Link href="/post-job">
                <Button className="w-full font-semibold bg-gradient-to-r from-amber-500 to-orange-500 border-amber-600" data-testid="button-featured-listing">
                  <Star className="h-4 w-4 mr-2" />
                  Post Featured Job - $25
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </section>

      <section className="border-y border-border" data-testid="section-app-promo">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex items-center justify-between gap-6 flex-wrap">
            <div className="flex items-center gap-4">
              <img src="/logo.png" alt="Dev Global Jobs App" className="w-12 h-12 rounded-xl shadow-md object-cover shrink-0" />
              <div>
                <h3 className="font-bold text-sm">Dev Global Jobs - Android App</h3>
                <p className="text-xs text-muted-foreground">Browse {stats?.total ? `${stats.total.toLocaleString()}+` : "40,000+"} jobs on the go. Free on Google Play.</p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
              {["190+ Countries", "All Categories", "Free"].map((item) => (
                <div key={item} className="flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3 text-emerald-500 shrink-0" />
                  <span className="font-medium">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 hero-gradient" />
        <div className="absolute inset-0 hero-grid opacity-[0.03] dark:opacity-[0.05]" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 dark:bg-primary/20 text-primary text-sm font-semibold mb-6 border border-primary/20">
              <TrendingUp className="h-4 w-4" />
              Start Hiring Today
            </div>
            <h2 className="text-3xl font-bold mb-4">Ready to Find Top Talent?</h2>
            <p className="text-muted-foreground mb-8 max-w-lg mx-auto text-lg">
              Join <strong className="text-foreground">85,000+ employers</strong> who trust Dev Global Jobs. Post a listing for just <strong className="text-foreground">$10</strong> or get maximum visibility for <strong className="text-foreground">$25</strong>.
            </p>
            <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground mb-10 flex-wrap">
              {["2.4M+ monthly views", "190+ countries", "560K+ job seekers", "From just $10", "Live in minutes"].map((item) => (
                <div key={item} className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                  <span className="font-medium">{item}</span>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <Link href="/post-job">
                <Button size="lg" className="h-13 px-8 text-base font-semibold" data-testid="button-cta-post-job">
                  <Briefcase className="h-5 w-5 mr-2" />
                  Post a Job - $10
                </Button>
              </Link>
              <Link href="/post-job">
                <Button size="lg" variant="outline" className="h-13 px-8 text-base font-semibold" data-testid="button-cta-post-featured">
                  <Star className="h-5 w-5 mr-2" />
                  Featured Job - $25
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
