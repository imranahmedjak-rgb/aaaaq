import { useInfiniteQuery, useQueryClient } from "@tanstack/react-query";
import { JobCard, JobCardSkeleton } from "@/components/job-card";
import JobAlertBox from "@/components/JobAlertBox";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  MapPin, Loader2, ArrowUp, Search, RefreshCw, Briefcase, Globe,
} from "lucide-react";
import type { Job } from "@shared/schema";
import { useState, useEffect, useRef } from "react";

const JOBS_PER_PAGE = 30;

interface PaginatedResponse {
  jobs: Job[];
  total: number;
  limit: number;
  offset: number;
  hasMore: boolean;
  country: { code: string; name: string; slug: string };
}

export default function CountryJobs({ slug }: { slug: string }) {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const queryClient = useQueryClient();
  const sentinelRef = useRef<HTMLDivElement>(null);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await fetch("/api/jobs/refresh", { method: "POST" });
      await new Promise((r) => setTimeout(r, 3000));
      await queryClient.invalidateQueries({ predicate: (query) => {
        const key = query.queryKey[0] as string;
        return key.includes("/api/jobs");
      }});
    } catch (err) {
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
    }, 400);
    return () => clearTimeout(timer);
  }, [search]);

  const {
    data,
    isLoading,
    isFetchingNextPage,
    fetchNextPage,
    hasNextPage,
  } = useInfiniteQuery<PaginatedResponse>({
    queryKey: ["/api/jobs/country", slug, debouncedSearch],
    queryFn: async ({ pageParam }) => {
      const offset = pageParam as number;
      const params = new URLSearchParams({
        limit: String(JOBS_PER_PAGE),
        offset: String(offset),
      });
      if (debouncedSearch.trim()) {
        params.set("search", debouncedSearch.trim());
      }
      const res = await fetch(`/api/jobs/country/${slug}?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage) => {
      if (lastPage.hasMore) {
        return lastPage.offset + lastPage.limit;
      }
      return undefined;
    },
    refetchInterval: 10000,
  });

  const allJobs = data?.pages.flatMap((page) => page.jobs) || [];
  const totalJobs = data?.pages[0]?.total || 0;
  const countryName = data?.pages[0]?.country?.name || slug.replace(/-/g, " ").replace(/\b\w/g, l => l.toUpperCase());
  const countryCode = data?.pages[0]?.country?.code?.toLowerCase() || slug;
  const loadedCount = allJobs.length;
  const progressPercent = totalJobs > 0 ? Math.round((loadedCount / totalJobs) * 100) : 0;
  const clampedProgress = Math.min(progressPercent, 100);
  const batchNumber = data?.pages.length || 0;
  const totalBatches = totalJobs > 0 ? Math.ceil(totalJobs / JOBS_PER_PAGE) : 0;

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { rootMargin: "400px" }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 600);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center shrink-0 shadow-md">
            <img
              src={`https://flagcdn.com/32x24/${countryCode}.png`}
              srcSet={`https://flagcdn.com/64x48/${countryCode}.png 2x`}
              alt={countryName}
              className="w-8 h-6 rounded-sm"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold" data-testid="text-country-title">
              Jobs in {countryName}
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Browse verified job opportunities in {countryName} from international employers
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Badge variant="secondary" className="font-semibold" data-testid="badge-country-total">
            {totalJobs.toLocaleString()} jobs found
          </Badge>
          {!isLoading && totalJobs > 0 && (
            <span className="text-xs text-muted-foreground" data-testid="text-country-showing">
              Showing {loadedCount.toLocaleString()} of {totalJobs.toLocaleString()}
            </span>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={handleRefresh}
            disabled={isRefreshing}
            data-testid="button-country-refresh"
          >
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${isRefreshing ? "animate-spin" : ""}`} />
            {isRefreshing ? "Refreshing..." : "Refresh"}
          </Button>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search jobs in ${countryName}...`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
            data-testid="input-country-search"
          />
        </div>
      </Card>

      {!isLoading && totalJobs > JOBS_PER_PAGE && (
        <div className="mb-6">
          <div className="flex items-center justify-between gap-4 mb-1.5">
            <span className="text-xs text-muted-foreground">
              Page {batchNumber} of {totalBatches}
            </span>
            <span className="text-xs text-muted-foreground">{clampedProgress}% loaded</span>
          </div>
          <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500 ease-out"
              style={{ width: `${clampedProgress}%` }}
              data-testid="progress-bar-country"
            />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading
          ? Array.from({ length: 12 }).map((_, i) => <JobCardSkeleton key={i} />)
          : allJobs.map((job) => <JobCard key={job.id} job={job} />)}
      </div>

      {!isLoading && allJobs.length === 0 && (
        <Card className="p-16 text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-5">
            <Briefcase className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="font-bold text-lg mb-2">No jobs found</h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">
            {search ? "Try adjusting your search terms." : `Jobs in ${countryName} are being fetched. Please check back shortly.`}
          </p>
        </Card>
      )}

      {(hasNextPage || isFetchingNextPage) && (
        <div ref={sentinelRef} className="flex flex-col items-center justify-center py-10 gap-3" data-testid="sentinel-country">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <span className="text-sm text-muted-foreground">Loading more jobs...</span>
        </div>
      )}

      {!isLoading && !hasNextPage && allJobs.length > 0 && (
        <div className="text-center py-10">
          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-muted/50">
            <Briefcase className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground font-medium">
              You've viewed all {totalJobs.toLocaleString()} jobs in {countryName}
            </span>
          </div>
        </div>
      )}

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 mb-4">
        <JobAlertBox country={slug} />
      </div>

      <div
        className={`fixed bottom-6 right-6 z-40 transition-all duration-300 ${showScrollTop ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"}`}
      >
        <Button
          size="icon"
          variant="secondary"
          onClick={scrollToTop}
          className="shadow-lg"
          data-testid="button-country-scroll-top"
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
