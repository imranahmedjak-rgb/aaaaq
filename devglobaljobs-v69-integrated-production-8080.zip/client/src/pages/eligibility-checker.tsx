import { useState } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CheckCircle2, Globe, Briefcase, GraduationCap, Laptop,
  ArrowRight, Search, Sparkles, Shield, TrendingUp,
  Building2, Users,
} from "lucide-react";

interface VisaProgram {
  name: string;
  country: string;
  countryCode: string;
  category: string;
  typeBadge: string;
  description: string;
  benefits: string[];
}

const visaPrograms: VisaProgram[] = [
  {
    name: "Germany Opportunity Card (Chancenkarte)",
    country: "Germany",
    countryCode: "de",
    category: "opportunity",
    typeBadge: "Opportunity Card",
    description: "Points-based visa for skilled workers to enter Germany and search for employment.",
    benefits: ["No job offer needed", "12-month stay", "Points-based system", "Path to residence"],
  },
  {
    name: "Portugal Digital Nomad Visa (D8)",
    country: "Portugal",
    countryCode: "pt",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Remote work visa for non-EU nationals earning at least 4x Portugal's minimum wage.",
    benefits: ["Remote work friendly", "EU access", "Tax benefits", "Warm climate"],
  },
  {
    name: "Spain Digital Nomad Visa",
    country: "Spain",
    countryCode: "es",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Live in Spain for up to 5 years while working remotely for non-Spanish companies.",
    benefits: ["Up to 5 years", "EU access", "No local employer needed", "Tax advantages"],
  },
  {
    name: "Estonia Digital Nomad Visa",
    country: "Estonia",
    countryCode: "ee",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "One of Europe's first digital nomad visas for location-independent workers.",
    benefits: ["E-Residency available", "Tech-friendly", "EU access", "Fast processing"],
  },
  {
    name: "Croatia Digital Nomad Visa",
    country: "Croatia",
    countryCode: "hr",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Tax-exempt remote work visa for digital nomads for up to 1 year.",
    benefits: ["Tax exempt", "1 year stay", "EU country", "Low cost of living"],
  },
  {
    name: "UAE Golden Visa",
    country: "United Arab Emirates",
    countryCode: "ae",
    category: "golden",
    typeBadge: "Golden Visa",
    description: "Long-term residence visa (5 or 10 years) for investors, entrepreneurs, and skilled professionals.",
    benefits: ["10-year residence", "100% business ownership", "No sponsor needed", "Tax-free income"],
  },
  {
    name: "Canada Express Entry",
    country: "Canada",
    countryCode: "ca",
    category: "work",
    typeBadge: "Work Visa",
    description: "Points-based immigration system for skilled workers seeking permanent residence.",
    benefits: ["Permanent residence", "Universal healthcare", "Family sponsorship", "Path to citizenship"],
  },
  {
    name: "Australia Skilled Worker Visa (Subclass 482)",
    country: "Australia",
    countryCode: "au",
    category: "work",
    typeBadge: "Work Visa",
    description: "Temporary skill shortage visa for employer-sponsored skilled workers.",
    benefits: ["Employer sponsored", "Up to 4 years", "Path to PR", "High quality of life"],
  },
  {
    name: "UK Skilled Worker Visa",
    country: "United Kingdom",
    countryCode: "gb",
    category: "work",
    typeBadge: "Work Visa",
    description: "For workers with a job offer from a UK employer with a valid sponsor licence.",
    benefits: ["Up to 5 years", "Path to settlement", "NHS access", "Bring family"],
  },
  {
    name: "USA H-1B Visa",
    country: "United States",
    countryCode: "us",
    category: "work",
    typeBadge: "Work Visa",
    description: "Specialty occupation visa for highly skilled professionals in specific fields.",
    benefits: ["Specialty occupations", "Up to 6 years", "Dual intent", "Path to green card"],
  },
  {
    name: "USA J-1 Exchange Visitor Visa",
    country: "United States",
    countryCode: "us",
    category: "student",
    typeBadge: "Student Visa",
    description: "Cultural exchange visa for students, interns, trainees, and research scholars.",
    benefits: ["Cultural exchange", "Work experience", "Training programs", "Networking"],
  },
  {
    name: "USA OPT (Optional Practical Training)",
    country: "United States",
    countryCode: "us",
    category: "student",
    typeBadge: "Student Visa",
    description: "Work authorization for F-1 students to gain practical experience in their field.",
    benefits: ["12-month work permit", "STEM 24-month extension", "Career launch", "US experience"],
  },
  {
    name: "Japan Highly Skilled Professional Visa",
    country: "Japan",
    countryCode: "jp",
    category: "work",
    typeBadge: "Work Visa",
    description: "Points-based visa for highly skilled foreign professionals with fast-track PR.",
    benefits: ["Fast-track PR (1-3 years)", "Points-based", "Preferential treatment", "Family benefits"],
  },
  {
    name: "South Korea D-10 Job Seeker Visa",
    country: "South Korea",
    countryCode: "kr",
    category: "opportunity",
    typeBadge: "Opportunity Card",
    description: "Stay in South Korea for up to 6 months to seek employment.",
    benefits: ["Job search period", "6 months", "No employer needed", "Tech hub access"],
  },
  {
    name: "Netherlands Orientation Year Visa",
    country: "Netherlands",
    countryCode: "nl",
    category: "opportunity",
    typeBadge: "Opportunity Card",
    description: "One-year residence permit for graduates from top-200 universities worldwide.",
    benefits: ["1 year permit", "Top-200 grads", "Start a business", "EU access"],
  },
  {
    name: "France Talent Passport",
    country: "France",
    countryCode: "fr",
    category: "work",
    typeBadge: "Work Visa",
    description: "Multi-year residence permit for highly qualified workers and entrepreneurs.",
    benefits: ["Up to 4 years", "Family permits", "Renewable", "EU mobility"],
  },
  {
    name: "Singapore Employment Pass",
    country: "Singapore",
    countryCode: "sg",
    category: "work",
    typeBadge: "Work Visa",
    description: "Work visa for foreign professionals using the COMPASS points-based framework.",
    benefits: ["Points-based", "Business hub", "Low taxes", "High quality of life"],
  },
  {
    name: "New Zealand Skilled Migrant Category",
    country: "New Zealand",
    countryCode: "nz",
    category: "work",
    typeBadge: "Work Visa",
    description: "Points-based resident visa for skilled workers with 160+ points.",
    benefits: ["Permanent residence", "Points-based", "Quality of life", "Path to citizenship"],
  },
  {
    name: "Czech Republic Zivno Visa",
    country: "Czech Republic",
    countryCode: "cz",
    category: "startup",
    typeBadge: "Startup Visa",
    description: "Long-term business visa based on trade license, popular among freelancers.",
    benefits: ["Freelancer friendly", "Schengen access", "Low cost", "Business license"],
  },
  {
    name: "Barbados Welcome Stamp",
    country: "Barbados",
    countryCode: "bb",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "12-month remote work visa to live and work remotely from Barbados.",
    benefits: ["12 months", "Caribbean lifestyle", "Fast processing", "Tax benefits"],
  },
  {
    name: "Malta Nomad Residence Permit",
    country: "Malta",
    countryCode: "mt",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Residence permit for remote workers to live in Malta for up to 1 year.",
    benefits: ["EU access", "Mediterranean lifestyle", "English speaking", "Renewable"],
  },
  {
    name: "Greece Digital Nomad Visa",
    country: "Greece",
    countryCode: "gr",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Residence permit with 50% tax reduction for remote workers.",
    benefits: ["50% tax reduction", "Up to 2 years", "EU access", "Low cost of living"],
  },
  {
    name: "Thailand Long-Term Resident Visa",
    country: "Thailand",
    countryCode: "th",
    category: "golden",
    typeBadge: "Golden Visa",
    description: "10-year visa for wealthy global citizens and highly skilled professionals.",
    benefits: ["10-year visa", "17% flat tax", "Work permit included", "Fast-track services"],
  },
  {
    name: "Mexico Temporary Resident Visa",
    country: "Mexico",
    countryCode: "mx",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Temporary residence for up to 4 years, popular with remote workers.",
    benefits: ["Up to 4 years", "Low cost of living", "No minimum income at visa stage", "Cultural richness"],
  },
  {
    name: "Colombia Digital Nomad Visa",
    country: "Colombia",
    countryCode: "co",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "2-year visa for remote workers with no local income tax obligations.",
    benefits: ["2 years", "No local tax", "Low cost", "Fast processing"],
  },
  {
    name: "Brazil Digital Nomad Visa",
    country: "Brazil",
    countryCode: "br",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "1-year renewable visa for remote workers earning from foreign sources.",
    benefits: ["1 year renewable", "Low income threshold", "Diverse culture", "Natural beauty"],
  },
];

const educationLevels = ["High School", "Bachelor's", "Master's", "PhD", "Professional Degree"];
const languages = ["English", "French", "German", "Spanish", "Arabic", "Chinese", "Japanese", "Portuguese", "Other"];
const expertiseFields = ["Technology/IT", "Engineering", "Healthcare", "Business/Finance", "Education", "Creative/Media", "Law", "Science/Research", "Other"];
const salaryRanges = ["Under $20K", "$20K-$40K", "$40K-$60K", "$60K-$80K", "$80K-$100K", "$100K+"];

function getFlagUrl(countryCode: string) {
  return `https://flagcdn.com/24x18/${countryCode}.png`;
}

function calculateMatch(
  program: VisaProgram,
  form: {
    age: number;
    education: string;
    experience: number;
    selectedLanguages: string[];
    expertise: string;
    salary: string;
    hasJobOffer: boolean;
    isStudent: boolean;
  }
): number {
  let score = 30;

  const { age, education, experience, selectedLanguages, expertise, salary, hasJobOffer, isStudent } = form;

  const isHighEd = education === "PhD" || education === "Master's" || education === "Professional Degree";
  const isTechField = expertise === "Technology/IT" || expertise === "Engineering" || expertise === "Science/Research";
  const salaryIndex = salaryRanges.indexOf(salary);
  const isHighSalary = salaryIndex >= 4;
  const isYoung = age > 0 && age < 35;

  if (program.category === "work") {
    if (isHighEd) score += 25;
    else if (education === "Bachelor's") score += 15;
    if (experience >= 5) score += 15;
    else if (experience >= 2) score += 10;
    if (hasJobOffer) score += 20;
    if (selectedLanguages.length >= 2) score += 5;
    if (isTechField) score += 5;
  }

  if (program.category === "nomad") {
    if (isTechField) score += 20;
    if (!hasJobOffer) score += 15;
    if (salaryIndex >= 3) score += 15;
    if (experience >= 2) score += 10;
    if (selectedLanguages.includes("English")) score += 5;
    if (education === "Bachelor's" || isHighEd) score += 5;
  }

  if (program.category === "student") {
    if (isStudent) score += 30;
    if (isYoung) score += 15;
    if (education === "Bachelor's") score += 10;
    else if (education === "High School") score += 15;
    if (selectedLanguages.includes("English")) score += 5;
  }

  if (program.category === "opportunity") {
    if (isHighEd) score += 20;
    else if (education === "Bachelor's") score += 15;
    if (isYoung) score += 15;
    if (experience >= 1) score += 10;
    if (selectedLanguages.length >= 2) score += 10;
  }

  if (program.category === "golden") {
    if (isHighSalary) score += 25;
    else if (salaryIndex >= 3) score += 15;
    if (experience >= 5) score += 15;
    if (isHighEd) score += 10;
    if (isTechField) score += 5;
  }

  if (program.category === "startup") {
    if (isTechField) score += 15;
    if (experience >= 3) score += 15;
    if (!hasJobOffer) score += 10;
    if (isHighEd) score += 10;
    if (expertise === "Business/Finance") score += 10;
  }

  if (program.name.includes("Germany") && selectedLanguages.includes("German")) score += 10;
  if (program.name.includes("France") && selectedLanguages.includes("French")) score += 10;
  if (program.name.includes("Spain") && selectedLanguages.includes("Spanish")) score += 10;
  if (program.name.includes("Japan") && selectedLanguages.includes("Japanese")) score += 10;
  if (program.name.includes("Brazil") && selectedLanguages.includes("Portuguese")) score += 10;
  if (program.name.includes("Colombia") && selectedLanguages.includes("Spanish")) score += 10;

  return Math.min(score, 98);
}

function getMatchColor(percentage: number) {
  if (percentage >= 80) return "text-green-600 dark:text-green-400";
  if (percentage >= 50) return "text-yellow-600 dark:text-yellow-400";
  return "text-orange-600 dark:text-orange-400";
}

function getMatchBadgeVariant(percentage: number): "default" | "secondary" | "outline" {
  if (percentage >= 80) return "default";
  if (percentage >= 50) return "secondary";
  return "outline";
}

export default function EligibilityChecker() {
  const [age, setAge] = useState<number>(0);
  const [nationality, setNationality] = useState("");
  const [education, setEducation] = useState("");
  const [experience, setExperience] = useState<number>(0);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [expertise, setExpertise] = useState("");
  const [salary, setSalary] = useState("");
  const [hasJobOffer, setHasJobOffer] = useState(false);
  const [isStudent, setIsStudent] = useState(false);
  const [results, setResults] = useState<Array<{ program: VisaProgram; match: number }> | null>(null);

  const toggleLanguage = (lang: string) => {
    setSelectedLanguages((prev) =>
      prev.includes(lang) ? prev.filter((l) => l !== lang) : [...prev, lang]
    );
  };

  const handleCheck = () => {
    const form = { age, education, experience, selectedLanguages, expertise, salary, hasJobOffer, isStudent };
    const scored = visaPrograms
      .map((program) => ({ program, match: calculateMatch(program, form) }))
      .filter((r) => r.match >= 30)
      .sort((a, b) => b.match - a.match);
    setResults(scored);
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
      { "@type": "ListItem", position: 2, name: "Eligibility Checker", item: "https://devglobaljobs.com/eligibility-checker" },
    ],
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />

      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 mb-4">
          <Shield className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-eligibility-title">
          Eligibility Checker
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Check which visa programs and career opportunities you qualify for
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>{visaPrograms.length} Programs</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Briefcase className="h-4 w-4" />
            <span>Work & Study Visas</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Laptop className="h-4 w-4" />
            <span>Digital Nomad</span>
          </div>
          <div className="flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            <span>Golden Visas</span>
          </div>
        </div>
      </div>

      <Card className="p-6 mb-8">
        <h2 className="text-lg font-semibold mb-6 flex items-center gap-2">
          <Search className="h-5 w-5" />
          Your Profile
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="age">Age</Label>
            <Input
              id="age"
              type="number"
              min={0}
              max={100}
              placeholder="Enter your age"
              value={age || ""}
              onChange={(e) => setAge(parseInt(e.target.value) || 0)}
              data-testid="input-age"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="nationality">Nationality / Country of Origin</Label>
            <Input
              id="nationality"
              type="text"
              placeholder="e.g. Pakistan, India, Nigeria"
              value={nationality}
              onChange={(e) => setNationality(e.target.value)}
              data-testid="input-nationality"
            />
          </div>

          <div className="space-y-2">
            <Label>Highest Education Level</Label>
            <Select value={education} onValueChange={setEducation}>
              <SelectTrigger data-testid="select-education">
                <SelectValue placeholder="Select education level" />
              </SelectTrigger>
              <SelectContent>
                {educationLevels.map((level) => (
                  <SelectItem key={level} value={level} data-testid={`option-education-${level.toLowerCase().replace(/['\s]/g, "-")}`}>
                    {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="experience">Years of Work Experience</Label>
            <Input
              id="experience"
              type="number"
              min={0}
              max={50}
              placeholder="Enter years of experience"
              value={experience || ""}
              onChange={(e) => setExperience(parseInt(e.target.value) || 0)}
              data-testid="input-experience"
            />
          </div>

          <div className="space-y-2">
            <Label>Field of Expertise</Label>
            <Select value={expertise} onValueChange={setExpertise}>
              <SelectTrigger data-testid="select-expertise">
                <SelectValue placeholder="Select your field" />
              </SelectTrigger>
              <SelectContent>
                {expertiseFields.map((field) => (
                  <SelectItem key={field} value={field} data-testid={`option-expertise-${field.toLowerCase().replace(/[/\s]/g, "-")}`}>
                    {field}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Current Annual Salary Range</Label>
            <Select value={salary} onValueChange={setSalary}>
              <SelectTrigger data-testid="select-salary">
                <SelectValue placeholder="Select salary range" />
              </SelectTrigger>
              <SelectContent>
                {salaryRanges.map((range) => (
                  <SelectItem key={range} value={range} data-testid={`option-salary-${range.toLowerCase().replace(/[\s$+]/g, "-")}`}>
                    {range}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3 md:col-span-2">
            <Label>Language Skills</Label>
            <div className="flex flex-wrap gap-3">
              {languages.map((lang) => (
                <label
                  key={lang}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <Checkbox
                    checked={selectedLanguages.includes(lang)}
                    onCheckedChange={() => toggleLanguage(lang)}
                    data-testid={`checkbox-lang-${lang.toLowerCase()}`}
                  />
                  <span className="text-sm">{lang}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="job-offer" className="cursor-pointer">Do you have a job offer?</Label>
            <Switch
              id="job-offer"
              checked={hasJobOffer}
              onCheckedChange={setHasJobOffer}
              data-testid="switch-job-offer"
            />
          </div>

          <div className="flex items-center justify-between gap-4">
            <Label htmlFor="student" className="cursor-pointer">Are you a student?</Label>
            <Switch
              id="student"
              checked={isStudent}
              onCheckedChange={setIsStudent}
              data-testid="switch-student"
            />
          </div>
        </div>

        <div className="mt-6">
          <Button
            onClick={handleCheck}
            className="w-full sm:w-auto"
            data-testid="button-check-eligibility"
          >
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Check My Eligibility
          </Button>
        </div>
      </Card>

      {results !== null && (
        <div>
          <div className="flex items-center justify-between gap-4 mb-4 flex-wrap">
            <h2 className="text-lg font-semibold flex items-center gap-2" data-testid="text-results-heading">
              <Sparkles className="h-5 w-5" />
              Your Matching Programs
            </h2>
            <span className="text-sm text-muted-foreground">
              {results.length} program{results.length !== 1 ? "s" : ""} found
            </span>
          </div>

          {results.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground mb-2">No matching programs found with your current profile.</p>
              <p className="text-sm text-muted-foreground">Try adjusting your education, experience, or other fields to see more results.</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.map(({ program, match }) => (
                <Card
                  key={program.name}
                  className="p-5 flex flex-col gap-3 hover-elevate"
                  data-testid={`card-result-${program.countryCode}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={getFlagUrl(program.countryCode)}
                        alt={`${program.country} flag`}
                        className="w-6 h-[18px] rounded-sm object-cover shrink-0"
                      />
                      <div className="min-w-0">
                        <h3 className="font-semibold text-sm leading-tight">{program.name}</h3>
                        <span className="text-xs text-muted-foreground">{program.country}</span>
                      </div>
                    </div>
                    <div className={`text-lg font-bold shrink-0 ${getMatchColor(match)}`} data-testid={`text-match-${program.countryCode}`}>
                      {match}%
                    </div>
                  </div>

                  <Badge variant={getMatchBadgeVariant(match)} className="self-start text-[10px]">
                    {program.typeBadge}
                  </Badge>

                  <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                    {program.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5">
                    {program.benefits.map((benefit) => (
                      <Badge key={benefit} variant="outline" className="text-[10px] font-normal">
                        {benefit}
                      </Badge>
                    ))}
                  </div>

                  <Link href="/visa-guide">
                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full"
                      data-testid={`button-view-${program.countryCode}`}
                    >
                      <ArrowRight className="h-3.5 w-3.5 mr-1.5" />
                      View in Visa Guide
                    </Button>
                  </Link>
                </Card>
              ))}
            </div>
          )}

          <Card className="mt-8 p-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
                <Building2 className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">How Matching Works</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Our eligibility checker uses your profile to estimate compatibility with international visa programs.
                  Match percentages are based on general criteria such as education, work experience, language skills,
                  salary range, and field of expertise. Always verify requirements on official immigration websites
                  before applying.
                </p>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
