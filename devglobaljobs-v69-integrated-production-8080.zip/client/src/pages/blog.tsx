import { Link } from "wouter";
import { blogArticles, getAllCategories } from "@/data/blog-articles";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Clock, ArrowRight, BookOpen, Search } from "lucide-react";
import { useState, useMemo, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { AdUnit } from "@/components/ad-unit";

function normalizeApiPost(post: any) {
  return {
    id: post.id ?? post.slug,
    title: post.title || "Untitled Article",
    slug: post.slug,
    excerpt: post.excerpt || post.metaDescription || post.description || "",
    content: post.content || "",
    category: post.category || "Career Advice",
    readTime: post.readTime || post.read_time || 6,
    keywords: Array.isArray(post.keywords)
      ? post.keywords
      : typeof post.focusKeyword === "string"
        ? [post.focusKeyword]
        : [],
    updatedAt: post.updatedAt || post.updated_at || post.createdAt || post.created_at || new Date().toISOString(),
    metaTitle: post.metaTitle || post.title || "",
    metaDescription: post.metaDescription || post.excerpt || "",
    focusKeyword: post.focusKeyword || "",
  };
}

export default function Blog() {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [apiArticles, setApiArticles] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [apiFailed, setApiFailed] = useState(false);

  useEffect(() => {
    document.title = "Career Blog - International Jobs, Remote Work & Career Advice | Dev Global Jobs";

    let active = true;

    fetch("/api/blog", {
      method: "GET",
      headers: { Accept: "application/json" },
      cache: "no-store",
    })
      .then((res) => {
        if (!res.ok) throw new Error("Blog API failed");
        return res.json();
      })
      .then((data) => {
        if (!active) return;
        const posts = Array.isArray(data?.posts) ? data.posts : Array.isArray(data) ? data : [];
        setApiArticles(posts.filter((post: any) => post?.slug).map(normalizeApiPost));
        setApiFailed(false);
      })
      .catch(() => {
        if (!active) return;
        setApiFailed(true);
      })
      .finally(() => {
        if (!active) return;
        setIsLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const articlesSource = apiFailed ? blogArticles : apiArticles;

  const categories = useMemo(() => {
    const sourceCategories = Array.from(
      new Set(articlesSource.map((article: any) => article.category).filter(Boolean))
    );

    return ["All", ...(sourceCategories.length ? sourceCategories : getAllCategories())];
  }, [articlesSource]);

  const filteredArticles = useMemo(() => {
    let articles = isLoading ? [] : articlesSource;
    if (selectedCategory !== "All") {
      articles = articles.filter(a => a.category === selectedCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      articles = articles.filter(a =>
        a.title.toLowerCase().includes(q) ||
        a.excerpt.toLowerCase().includes(q) ||
        (a.keywords || []).some((k: string) => k.toLowerCase().includes(q))
      );
    }
    return articles;
  }, [articlesSource, isLoading, selectedCategory, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="text-center mb-10">
        <div className="flex items-center justify-center gap-2 mb-3">
          <BookOpen className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold" data-testid="text-blog-title">Career Blog</h1>
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="text-blog-subtitle">
          Expert guides and insights for international job seekers, remote workers, and career changers.
          Actionable strategies to advance your global career.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search articles..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-blog-search"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <Badge
              key={cat}
              variant={selectedCategory === cat ? "default" : "secondary"}
              className="cursor-pointer text-xs"
              onClick={() => setSelectedCategory(cat)}
              data-testid={`badge-category-${cat.toLowerCase().replace(/\s+/g, "-")}`}
            >
              {cat}
            </Badge>
          ))}
        </div>
      </div>

      <div className="text-sm text-muted-foreground mb-6" data-testid="text-article-count">
        {isLoading ? "Loading articles..." : `${filteredArticles.length} article${filteredArticles.length !== 1 ? "s" : ""}`}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArticles.map(article => (
          <Link key={article.slug} href={`/blog/${article.slug}`}>
            <Card className="h-full hover-elevate cursor-pointer p-5 flex flex-col" data-testid={`card-blog-${article.slug}`}>
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <Badge variant="secondary" className="text-[10px]">{article.category}</Badge>
                <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {article.readTime} min read
                </span>
              </div>
              <h2 className="font-semibold text-sm mb-2 line-clamp-2" data-testid={`text-title-${article.slug}`}>
                {article.title}
              </h2>
              <p className="text-xs text-muted-foreground mb-4 flex-1 line-clamp-3">
                {article.excerpt}
              </p>
              <div className="flex items-center justify-between mt-auto">
                <span className="text-[10px] text-muted-foreground">
                  {new Date(article.updatedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                </span>
                <span className="flex items-center gap-1 text-xs text-primary font-medium">
                  Read <ArrowRight className="h-3 w-3" />
                </span>
              </div>
            </Card>
          </Link>
        ))}
      </div>

      {!isLoading && filteredArticles.length === 0 && (
        <div className="text-center py-16 text-muted-foreground" data-testid="text-no-articles">
          No articles found matching your criteria.
        </div>
      )}

      {filteredArticles.length > 0 && (
        <div className="py-6">
          <AdUnit format="horizontal" className="text-center" />
        </div>
      )}
    </div>
  );
}
