import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Briefcase,
  CreditCard,
  CheckCircle2,
  ArrowRight,
  Shield,
  Globe,
  DollarSign,
  Star,
  Zap,
} from "lucide-react";
import { postJobSchema, type PostJobInput } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function PostJob() {
  const [step, setStep] = useState<"form" | "payment" | "success">("form");
  const [jobData, setJobData] = useState<PostJobInput | null>(null);
  const { toast } = useToast();

  const form = useForm<PostJobInput>({
    resolver: zodResolver(postJobSchema),
    defaultValues: {
      title: "",
      organization: "",
      location: "",
      category: "international",
      description: "",
      url: "",
      jobType: "",
      salary: "",
      country: "",
      applyEmail: "",
      adminCode: "",
      listingType: "regular",
    },
  });

  const listingType = form.watch("listingType");
  const isFeatured = listingType === "featured";
  const price = isFeatured ? 25 : 10;

  const createPaymentMutation = useMutation({
    mutationFn: async (data: PostJobInput) => {
      const res = await apiRequest("POST", "/api/create-payment-intent", data);
      return res.json();
    },
    onSuccess: (data) => {
      window.location.href = data.url;
    },
    onError: (error: Error) => {
      toast({
        title: "Payment Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const adminPostMutation = useMutation({
    mutationFn: async (data: PostJobInput) => {
      const res = await apiRequest("POST", "/api/admin-post-job", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs/featured"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs/featured-employer"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs/stats"] });
      setStep("success");
      toast({
        title: "Job Posted",
        description: "Your job listing is now live.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PostJobInput) => {
    setJobData(data);
    if (data.adminCode && data.adminCode.trim() !== "") {
      adminPostMutation.mutate(data);
    } else {
      createPaymentMutation.mutate(data);
    }
  };

  if (step === "success") {
    return (
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
        </div>
        <h1 className="text-2xl font-bold mb-3" data-testid="text-success-title">Job Posted Successfully!</h1>
        <p className="text-muted-foreground mb-6">
          Your job listing is now live on Dev Global Jobs and will be visible to thousands of job seekers worldwide.
        </p>
        <Button onClick={() => { setStep("form"); form.reset(); }} data-testid="button-post-another">
          Post Another Job
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold mb-2" data-testid="text-post-title">Post a Job</h1>
        <p className="text-sm text-muted-foreground mb-4">
          Reach thousands of qualified professionals worldwide
        </p>
        <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <DollarSign className="h-4 w-4" />
            <span>From $10 per posting</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>Global reach</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Shield className="h-4 w-4" />
            <span>Secure payment</span>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h2 className="font-semibold text-sm mb-3">Choose Your Listing Type</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card
            className={`p-5 cursor-pointer transition-all ${
              !isFeatured
                ? "ring-2 ring-primary"
                : ""
            }`}
            onClick={() => form.setValue("listingType", "regular")}
            data-testid="card-listing-regular"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center shrink-0">
                <Briefcase className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <h3 className="font-semibold text-sm">Regular Posting</h3>
                  <span className="font-bold text-lg" data-testid="text-price-regular">$10</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Standard job listing visible across all categories and search results.
                  Active for 30 days.
                </p>
              </div>
            </div>
          </Card>

          <Card
            className={`p-5 cursor-pointer transition-all ${
              isFeatured
                ? "ring-2 ring-primary"
                : ""
            }`}
            onClick={() => form.setValue("listingType", "featured")}
            data-testid="card-listing-featured"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-md bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
                <Star className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-sm">Featured Posting</h3>
                    <Badge variant="secondary" className="text-[10px]">
                      <Zap className="h-3 w-3 mr-0.5" />
                      Premium
                    </Badge>
                  </div>
                  <span className="font-bold text-lg" data-testid="text-price-featured">$25</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Highlighted at the top of all pages in the Featured Jobs section. Active for 60 days.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Card className="p-4 sm:p-6 md:p-8 w-full min-w-0">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5 w-full min-w-0">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Job Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Senior Software Engineer" {...field} data-testid="input-job-title" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="organization"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company / Organization</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. Acme Corp" {...field} data-testid="input-organization" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. London, UK or Remote" {...field} data-testid="input-location" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="un">UN Jobs</SelectItem>
                        <SelectItem value="ngo">NGO Jobs</SelectItem>
                        <SelectItem value="remote">Remote Jobs</SelectItem>
                        <SelectItem value="international">International Jobs</SelectItem>
                        <SelectItem value="technology">Technology & Software</SelectItem>
                        <SelectItem value="healthcare">Healthcare & Life Sciences</SelectItem>
                        <SelectItem value="business">Business & Finance</SelectItem>
                        <SelectItem value="education">Education & Training</SelectItem>
                        <SelectItem value="engineering">Engineering</SelectItem>
                        <SelectItem value="creative">Creative & Media</SelectItem>
                        <SelectItem value="sales">Sales & Marketing</SelectItem>
                        <SelectItem value="gig">Gig Economy</SelectItem>
                        <SelectItem value="youth">Youth Opportunities</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="jobType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Job Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-job-type">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Full-time">Full-time</SelectItem>
                        <SelectItem value="Part-time">Part-time</SelectItem>
                        <SelectItem value="Contract">Contract</SelectItem>
                        <SelectItem value="Internship">Internship</SelectItem>
                        <SelectItem value="Consultant">Consultant</SelectItem>
                        <SelectItem value="Fellowship">Fellowship</SelectItem>
                        <SelectItem value="Scholarship">Scholarship</SelectItem>
                        <SelectItem value="Volunteer">Volunteer</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="salary"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Salary (optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. $80,000 - $120,000" {...field} data-testid="input-salary" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Country (optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. United Kingdom" {...field} data-testid="input-country" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Job Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Provide a detailed description of the role, responsibilities, and requirements..."
                      className="min-h-[200px] resize-y"
                      {...field}
                      data-testid="textarea-description"
                    />
                  </FormControl>
                  <FormDescription>Minimum 50 characters</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="border-t border-border pt-5">
              <h3 className="font-medium text-sm mb-1">How should candidates apply?</h3>
              <p className="text-xs text-muted-foreground mb-4">Provide at least one method for candidates to apply. You can add both an external link and an email address.</p>

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Application URL</FormLabel>
                      <FormControl>
                        <Input placeholder="https://yourcompany.com/careers/job-123" {...field} data-testid="input-apply-url" />
                      </FormControl>
                      <FormDescription>Link to your careers page or job listing where candidates can apply directly</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="applyEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Application Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="hr@yourcompany.com" {...field} data-testid="input-apply-email" />
                      </FormControl>
                      <FormDescription>Email address where candidates can send their CV/resume and cover letter</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="border-t border-border pt-5">
              <FormField
                control={form.control}
                name="adminCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Admin Code (optional)</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="Enter admin code to post without payment" {...field} data-testid="input-admin-code" />
                    </FormControl>
                    <FormDescription>If you have an admin code, your job will be posted instantly without payment</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="border-t border-border pt-5 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 min-w-0">
                <CreditCard className="h-5 w-5 text-muted-foreground shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-medium" data-testid="text-total-price">
                    Total: ${price}.00
                    {isFeatured && (
                      <Badge variant="secondary" className="ml-2 text-[10px]">
                        <Star className="h-3 w-3 mr-0.5" />
                        Featured
                      </Badge>
                    )}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {form.watch("adminCode")
                      ? "Free with admin code"
                      : `One-time payment via Stripe \u00B7 Active for ${isFeatured ? "90" : "30"} days`}
                  </p>
                </div>
              </div>
              <Button
                type="submit"
                className="w-full sm:w-auto shrink-0"
                disabled={createPaymentMutation.isPending || adminPostMutation.isPending}
                data-testid="button-submit-job"
              >
                {createPaymentMutation.isPending || adminPostMutation.isPending ? (
                  "Processing..."
                ) : form.watch("adminCode") ? (
                  <>
                    Post Job Now
                    <ArrowRight className="h-4 w-4 ml-1.5" />
                  </>
                ) : (
                  <>
                    Proceed to Payment - ${price}
                    <ArrowRight className="h-4 w-4 ml-1.5" />
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </Card>
    </div>
  );
}
