import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Globe, Shield, Users, TrendingUp, Briefcase, Heart, Mail, Phone, MapPin, Clock, Star, Award } from "lucide-react";
import { SiLinkedin, SiInstagram, SiX, SiFacebook, SiWhatsapp } from "react-icons/si";
import { Link } from "wouter";

const jobSources = [
  "ReliefWeb", "RemoteOK", "Remotive", "Jobicy", "Arbeitnow",
  "The Muse", "Himalayas", "WorkingNomads", "Adzuna", "USAJobs", "FindWork",
];

export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold mb-6" data-testid="text-about-title">About Dev Global Jobs</h1>

      <Card className="p-6 sm:p-8 mb-6">
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <p className="text-base leading-relaxed">
            Dev Global Jobs is a trusted international job platform connecting professionals with career opportunities worldwide. We aggregate positions from 11+ verified sources including United Nations agencies, non-governmental organizations, remote-first companies, and global employers across all industries and 17+ countries.
          </p>
          <p className="text-sm leading-relaxed text-muted-foreground">
            Our platform is updated automatically every 30 minutes, ensuring you always have access to the latest opportunities. Whether you're looking for a UN position, remote work, or international careers, Dev Global Jobs brings them all to one place.
          </p>
        </div>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <Card className="p-5">
          <Globe className="h-8 w-8 text-primary mb-3" />
          <h3 className="font-semibold text-sm mb-1">Global Reach</h3>
          <p className="text-xs text-muted-foreground">
            Jobs from 11+ verified API sources across every continent and major industry sector.
          </p>
        </Card>
        <Card className="p-5">
          <Shield className="h-8 w-8 text-primary mb-3" />
          <h3 className="font-semibold text-sm mb-1">Verified Sources</h3>
          <p className="text-xs text-muted-foreground">
            Every job listing comes from authenticated, trusted API sources with automatic deduplication.
          </p>
        </Card>
        <Card className="p-5">
          <Clock className="h-8 w-8 text-primary mb-3" />
          <h3 className="font-semibold text-sm mb-1">Real-time Updates</h3>
          <p className="text-xs text-muted-foreground">
            Our automated system refreshes job listings every 30 minutes from all sources.
          </p>
        </Card>
        <Card className="p-5">
          <Users className="h-8 w-8 text-primary mb-3" />
          <h3 className="font-semibold text-sm mb-1">For Job Seekers</h3>
          <p className="text-xs text-muted-foreground">
            Free access to browse, search, and apply for international positions across 17+ countries.
          </p>
        </Card>
        <Card className="p-5">
          <Briefcase className="h-8 w-8 text-primary mb-3" />
          <h3 className="font-semibold text-sm mb-1">For Employers</h3>
          <p className="text-xs text-muted-foreground">
            Post jobs from $10 (Regular, 30 days) or $25 (Featured, 60 days) and reach qualified candidates globally.
          </p>
        </Card>
        <Card className="p-5">
          <Heart className="h-8 w-8 text-primary mb-3" />
          <h3 className="font-semibold text-sm mb-1">Our Mission</h3>
          <p className="text-xs text-muted-foreground">
            Making international career opportunities accessible to professionals everywhere.
          </p>
        </Card>
      </div>

      <Card className="p-6 sm:p-8 mb-6">
        <h2 className="font-semibold text-lg mb-4">Employer Pricing</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <div className="p-4 rounded-md bg-muted/50">
            <div className="flex items-center gap-2 mb-2">
              <Briefcase className="h-5 w-5 text-muted-foreground" />
              <h3 className="font-semibold text-sm">Regular Posting</h3>
            </div>
            <p className="text-2xl font-bold mb-1">$10 <span className="text-sm font-normal text-muted-foreground">USD</span></p>
            <p className="text-xs text-muted-foreground">Active for 30 days. Listed across all categories and search results.</p>
          </div>
          <div className="p-4 rounded-md bg-amber-50 dark:bg-amber-900/10">
            <div className="flex items-center gap-2 mb-2">
              <Star className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              <h3 className="font-semibold text-sm">Featured Posting</h3>
            </div>
            <p className="text-2xl font-bold mb-1">$25 <span className="text-sm font-normal text-muted-foreground">USD</span></p>
            <p className="text-xs text-muted-foreground">Active for 60 days. Highlighted at the top of homepage and all category pages.</p>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          All payments are one-time, processed securely via Stripe. View our full <Link href="/pricing" className="text-primary underline">Pricing page</Link> for more details.
        </p>
      </Card>

      <Card className="p-6 sm:p-8 mb-6">
        <h2 className="font-semibold text-lg mb-4">Verified Job Sources</h2>
        <p className="text-sm text-muted-foreground mb-4">
          We aggregate jobs from the following trusted sources, ensuring quality and authenticity:
        </p>
        <div className="flex gap-2 flex-wrap">
          {jobSources.map((source) => (
            <Badge key={source} variant="secondary">{source}</Badge>
          ))}
        </div>
      </Card>

      <Card className="p-6 sm:p-8 mb-6">
        <h2 className="font-semibold text-lg mb-4">Company Information</h2>
        <div className="space-y-3 text-sm">
          <div className="flex items-start gap-3">
            <span className="text-muted-foreground min-w-[120px]">Platform:</span>
            <span>Dev Global Jobs</span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-muted-foreground min-w-[120px]">Operated by:</span>
            <span>
              <a href="https://trendnovaworld.com/" target="_blank" rel="noopener noreferrer" className="text-primary underline" data-testid="link-about-trendnova">
                Trend Nova World Limited
              </a>
            </span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-muted-foreground min-w-[120px]">Registration:</span>
            <span>United Kingdom (Company No. 16709289)</span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-muted-foreground min-w-[120px]">Headquarters:</span>
            <span>London, United Kingdom</span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-muted-foreground min-w-[120px]">Address:</span>
            <span>27 Old Gloucester Street, London, WC1N 3AX, United Kingdom</span>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-muted-foreground min-w-[120px]">Categories:</span>
            <div className="flex gap-2 flex-wrap">
              <Badge variant="secondary">UN Jobs</Badge>
              <Badge variant="secondary">NGO Jobs</Badge>
              <Badge variant="secondary">Remote Jobs</Badge>
              <Badge variant="secondary">International</Badge>
              <Badge variant="secondary">Technology</Badge>
              <Badge variant="secondary">Healthcare</Badge>
              <Badge variant="secondary">Business</Badge>
              <Badge variant="secondary">Education</Badge>
              <Badge variant="secondary">Engineering</Badge>
              <Badge variant="secondary">Creative</Badge>
              <Badge variant="secondary">Sales</Badge>
              <Badge variant="secondary">Gig Economy</Badge>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-muted-foreground min-w-[120px]">Countries:</span>
            <span>17+ countries including UK, US, Canada, Australia, Germany, France, India, and more</span>
          </div>
        </div>
      </Card>

      <Card className="p-6 sm:p-8 mb-6">
        <h2 className="font-semibold text-lg mb-4">Contact Us</h2>
        <div className="space-y-4">
          <a
            href="mailto:info@devglobaljobs.com"
            className="flex items-center gap-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-about-email"
          >
            <Mail className="h-4 w-4 shrink-0" />
            info@devglobaljobs.com
          </a>
          <a
            href="tel:+447473863903"
            className="flex items-center gap-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-about-phone"
          >
            <Phone className="h-4 w-4 shrink-0" />
            +44 7473 863903 (UK)
          </a>
          <a
            href="https://wa.me/994518673521"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-about-whatsapp"
          >
            <SiWhatsapp className="h-4 w-4 shrink-0" />
            +994 51 867 35 21 (WhatsApp)
          </a>
          <div className="flex items-start gap-3 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 shrink-0 mt-0.5" />
            <span>
              27 Old Gloucester Street,<br />
              London, WC1N 3AX, United Kingdom
            </span>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-border">
          <h3 className="font-medium text-sm mb-3">Follow Us</h3>
          <div className="flex items-center gap-4">
            <a href="https://www.linkedin.com/company/trendnovaworld/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about-linkedin">
              <SiLinkedin className="h-4 w-4" />
              <span className="hidden sm:inline">LinkedIn</span>
            </a>
            <a href="https://x.com/trendnovaworld" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about-x">
              <SiX className="h-4 w-4" />
              <span className="hidden sm:inline">X</span>
            </a>
            <a href="https://www.facebook.com/trendnovaworld" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about-facebook">
              <SiFacebook className="h-4 w-4" />
              <span className="hidden sm:inline">Facebook</span>
            </a>
            <a href="https://www.instagram.com/trendnovaworld/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-about-instagram">
              <SiInstagram className="h-4 w-4" />
              <span className="hidden sm:inline">Instagram</span>
            </a>
          </div>
        </div>
      </Card>
    </div>
  );
}
