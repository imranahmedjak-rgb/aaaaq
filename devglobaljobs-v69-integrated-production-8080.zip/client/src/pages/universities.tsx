import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  GraduationCap,
  Search,
  Globe,
  ExternalLink,
  MapPin,
  BookOpen,
  Building2,
  Sparkles,
} from "lucide-react";

interface University {
  name: string;
  country: string;
  code: string;
  domains: string[];
  webPages: string[];
  stateProvince: string | null;
}

const popularCountries = [
  "United Kingdom", "United States", "Canada", "Australia",
  "Germany", "France", "Netherlands", "Switzerland",
  "Sweden", "Japan", "Singapore", "India",
  "Italy", "Spain", "Belgium", "Austria",
  "New Zealand", "Ireland", "Denmark", "Norway",
  "South Korea", "China", "Brazil", "South Africa",
];

export default function Universities() {
  const [country, setCountry] = useState("United Kingdom");
  const [searchName, setSearchName] = useState("");
  const [activeSearch, setActiveSearch] = useState({ country: "United Kingdom", name: "" });

  const { data: universities, isLoading } = useQuery<University[]>({
    queryKey: ["/api/universities", activeSearch.country, activeSearch.name],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (activeSearch.country) params.set("country", activeSearch.country);
      if (activeSearch.name) params.set("name", activeSearch.name);
      const res = await fetch(`/api/universities?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const handleSearch = () => {
    setActiveSearch({ country, name: searchName });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 mb-4">
          <GraduationCap className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-universities-title">
          World Universities Guide
        </h1>
        <p className="text-sm text-muted-foreground max-w-xl mx-auto mb-4">
          Explore 9,600+ universities across 140+ countries. Find the right institution for your academic journey.
        </p>
        <div className="flex items-center justify-center gap-3 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Building2 className="h-4 w-4" />
            <span>9,600+ Universities</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>140+ Countries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <BookOpen className="h-4 w-4" />
            <span>Free Access</span>
          </div>
        </div>
      </div>

      <Card className="p-4 sm:p-6 mb-8">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 min-w-0">
            <Select value={country} onValueChange={setCountry}>
              <SelectTrigger data-testid="select-university-country">
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent>
                {popularCountries.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1 min-w-0">
            <Input
              placeholder="Search by university name..."
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              data-testid="input-university-search"
            />
          </div>
          <Button onClick={handleSearch} className="shrink-0" data-testid="button-university-search">
            <Search className="h-4 w-4 mr-1.5" />
            Search
          </Button>
        </div>
      </Card>

      <div className="mb-4 flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <MapPin className="h-5 w-5 text-muted-foreground" />
          Universities in {activeSearch.country || "All Countries"}
          {activeSearch.name && <span className="text-muted-foreground font-normal">matching "{activeSearch.name}"</span>}
        </h2>
        {universities && (
          <Badge variant="secondary" data-testid="text-university-count">
            {universities.length} found
          </Badge>
        )}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 9 }).map((_, i) => (
            <Card key={i} className="p-4 animate-pulse">
              <div className="h-5 bg-muted rounded w-3/4 mb-2" />
              <div className="h-4 bg-muted rounded w-1/2 mb-3" />
              <div className="h-3 bg-muted rounded w-2/3" />
            </Card>
          ))}
        </div>
      ) : universities && universities.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {universities.map((uni, idx) => (
            <Card key={idx} className="p-4 hover-elevate group" data-testid={`card-university-${idx}`}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/30 dark:to-purple-900/30 flex items-center justify-center shrink-0">
                  <GraduationCap className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm leading-snug line-clamp-2 mb-1" data-testid={`text-university-name-${idx}`}>
                    {uni.name}
                  </h3>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                    <img
                      src={`https://flagcdn.com/16x12/${uni.code.toLowerCase()}.png`}
                      alt={uni.country}
                      className="w-4 h-3 rounded-sm"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                    />
                    <span>{uni.country}</span>
                    {uni.stateProvince && (
                      <span className="text-muted-foreground/70">- {uni.stateProvince}</span>
                    )}
                  </div>
                  {uni.domains.length > 0 && (
                    <p className="text-xs text-muted-foreground truncate mb-2">
                      {uni.domains[0]}
                    </p>
                  )}
                  {uni.webPages.length > 0 && (
                    <a
                      href={uni.webPages[0]}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                      data-testid={`link-university-${idx}`}
                    >
                      <ExternalLink className="h-3 w-3" />
                      Visit Website
                    </a>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-12 text-center">
          <Sparkles className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="font-semibold mb-2">No universities found</h3>
          <p className="text-sm text-muted-foreground">Try a different country or search term</p>
        </Card>
      )}

      <Card className="p-6 mt-8 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/20 dark:to-purple-950/20 border-indigo-200/50 dark:border-indigo-800/30">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shrink-0">
            <BookOpen className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">Youth Guidance</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Looking for scholarships, fellowships, or training programs? Check out our Youth Opportunities section
              for fully funded programs, internships, and career development resources worldwide.
            </p>
            <a href="/jobs/youth">
              <Button size="sm" data-testid="link-youth-from-universities">
                <Sparkles className="h-4 w-4 mr-1.5" />
                Browse Youth Opportunities
              </Button>
            </a>
          </div>
        </div>
      </Card>
    </div>
  );
}
