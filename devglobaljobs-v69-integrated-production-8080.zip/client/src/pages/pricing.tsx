import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  CheckCircle2,
  Star,
  Briefcase,
  Globe,
  Shield,
  Clock,
  Users,
  Zap,
  ArrowRight,
  CreditCard,
  Mail,
  Phone,
} from "lucide-react";
import { SiWhatsapp } from "react-icons/si";

const regularFeatures = [
  "Listed across all job categories",
  "Visible in country-specific pages",
  "Full job description with formatting",
  "Application via URL or email",
  "Searchable by job seekers worldwide",
  "Active for 30 days",
  "Standard placement in listings",
  "SEO-optimized job page",
];

const featuredFeatures = [
  "Everything in Regular, plus:",
  "Highlighted at the top of homepage",
  "Displayed on ALL category pages",
  "Premium star badge for visibility",
  "Active for 60 days (2x longer)",
  "Priority placement above all jobs",
  "Maximum employer brand exposure",
  "Higher click-through rate",
];

const faqItems = [
  {
    q: "How long will my job listing be active?",
    a: "Regular job postings are active for 30 days. Featured job postings get premium visibility for 60 days, giving you 2x more exposure time.",
  },
  {
    q: "What payment methods do you accept?",
    a: "We accept all major credit and debit cards (Visa, Mastercard, American Express) through our secure Stripe payment gateway. All transactions are encrypted and PCI-compliant.",
  },
  {
    q: "Can I edit my job listing after posting?",
    a: "Please contact our support team at info@devglobaljobs.com if you need to make changes to your listing. We'll be happy to assist you.",
  },
  {
    q: "Where will my job appear?",
    a: "Regular listings appear in relevant category pages and search results. Featured listings appear prominently at the top of the homepage AND across all category pages, maximizing your visibility to job seekers from every category.",
  },
  {
    q: "Is there a refund policy?",
    a: "Once a job listing is published, payments are non-refundable. However, if you experience any issues, please contact our support team and we will work to resolve them.",
  },
  {
    q: "Do you offer bulk posting discounts?",
    a: "Yes, for organizations looking to post multiple positions, please contact us at info@devglobaljobs.com for custom pricing packages.",
  },
];

export default function Pricing() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold mb-3" data-testid="text-pricing-title">
          Simple, Transparent Pricing
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Reach thousands of qualified professionals worldwide. Choose the plan that best fits your hiring needs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <Card className="p-6 sm:p-8 flex flex-col" data-testid="card-pricing-regular">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-md bg-muted flex items-center justify-center shrink-0">
              <Briefcase className="h-6 w-6 text-muted-foreground" />
            </div>
            <div>
              <h2 className="font-bold text-lg">Regular Posting</h2>
              <p className="text-xs text-muted-foreground">Standard job listing</p>
            </div>
          </div>

          <div className="flex items-baseline gap-1 mb-1">
            <span className="text-4xl font-bold">$10</span>
            <span className="text-muted-foreground text-sm">USD</span>
          </div>
          <p className="text-xs text-muted-foreground mb-6">One-time payment, no subscription</p>

          <div className="flex items-center gap-2 mb-4 p-3 rounded-md bg-muted/50">
            <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
            <span className="text-sm font-medium">Active for 30 days</span>
          </div>

          <ul className="space-y-3 mb-8 flex-1">
            {regularFeatures.map((feature, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span className="text-sm text-muted-foreground">{feature}</span>
              </li>
            ))}
          </ul>

          <Link href="/post-job">
            <Button variant="outline" className="w-full" data-testid="button-get-regular">
              Get Started
              <ArrowRight className="h-4 w-4 ml-1.5" />
            </Button>
          </Link>
        </Card>

        <Card className="p-6 sm:p-8 flex flex-col ring-2 ring-primary relative" data-testid="card-pricing-featured">
          <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">
            <Zap className="h-3 w-3 mr-1" />
            Most Popular
          </Badge>

          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-md bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
              <Star className="h-6 w-6 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <h2 className="font-bold text-lg">Featured Posting</h2>
              <p className="text-xs text-muted-foreground">Premium visibility</p>
            </div>
          </div>

          <div className="flex items-baseline gap-1 mb-1">
            <span className="text-4xl font-bold">$25</span>
            <span className="text-muted-foreground text-sm">USD</span>
          </div>
          <p className="text-xs text-muted-foreground mb-6">One-time payment, no subscription</p>

          <div className="flex items-center gap-2 mb-4 p-3 rounded-md bg-amber-50 dark:bg-amber-900/10">
            <Clock className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
            <span className="text-sm font-medium">Active for 60 days</span>
          </div>

          <ul className="space-y-3 mb-8 flex-1">
            {featuredFeatures.map((feature, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <CheckCircle2 className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                <span className="text-sm text-muted-foreground">{feature}</span>
              </li>
            ))}
          </ul>

          <Link href="/post-job">
            <Button className="w-full" data-testid="button-get-featured">
              <Star className="h-4 w-4 mr-1.5" />
              Get Featured
              <ArrowRight className="h-4 w-4 ml-1.5" />
            </Button>
          </Link>
        </Card>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-12">
        <Card className="p-5 text-center">
          <Shield className="h-8 w-8 mx-auto mb-3 text-primary" />
          <h3 className="font-semibold text-sm mb-1">Secure Payments</h3>
          <p className="text-xs text-muted-foreground">
            All payments processed securely via Stripe. PCI-DSS compliant.
          </p>
        </Card>
        <Card className="p-5 text-center">
          <Globe className="h-8 w-8 mx-auto mb-3 text-primary" />
          <h3 className="font-semibold text-sm mb-1">Global Reach</h3>
          <p className="text-xs text-muted-foreground">
            Your listing reaches job seekers across 190+ countries worldwide.
          </p>
        </Card>
        <Card className="p-5 text-center">
          <Users className="h-8 w-8 mx-auto mb-3 text-primary" />
          <h3 className="font-semibold text-sm mb-1">Qualified Candidates</h3>
          <p className="text-xs text-muted-foreground">
            Access professionals from UN, NGO, tech, and international sectors.
          </p>
        </Card>
      </div>

      <Card className="p-6 sm:p-8 mb-12">
        <h2 className="font-bold text-xl mb-6 text-center" data-testid="text-faq-title">Frequently Asked Questions</h2>
        <div className="space-y-6 max-w-3xl mx-auto">
          {faqItems.map((item, i) => (
            <div key={i} className="border-b border-border pb-5 last:border-0 last:pb-0">
              <h3 className="font-semibold text-sm mb-2">{item.q}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.a}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6 sm:p-8 text-center">
        <h2 className="font-bold text-lg mb-2">Need Help or Custom Pricing?</h2>
        <p className="text-sm text-muted-foreground mb-5 max-w-lg mx-auto">
          For bulk posting packages, enterprise solutions, or any questions about our services, get in touch with our team.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-sm">
          <a href="mailto:info@devglobaljobs.com" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="link-pricing-email">
            <Mail className="h-4 w-4" />
            info@devglobaljobs.com
          </a>
          <a href="tel:+447473863903" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="link-pricing-phone">
            <Phone className="h-4 w-4" />
            +44 7473 863903
          </a>
          <a href="https://wa.me/994518673521" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors" data-testid="link-pricing-whatsapp">
            <SiWhatsapp className="h-4 w-4" />
            WhatsApp
          </a>
        </div>
      </Card>
    </div>
  );
}
