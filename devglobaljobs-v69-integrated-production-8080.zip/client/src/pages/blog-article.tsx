import { useParams, Link } from "wouter";
import { getArticleBySlug, blogArticles } from "@/data/blog-articles";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Clock, ArrowLeft, Calendar, ArrowRight, BookOpen, Share2, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdUnit } from "@/components/ad-unit";
import { useState, useEffect } from "react";

export default function BlogArticle() {
  const params = useParams<{ slug: string }>();
  const article = getArticleBySlug(params.slug);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  useEffect(() => {
    if (article) {
      document.title = article.metaTitle;
    }
  }, [article]);

  if (!article) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Article Not Found</h1>
        <p className="text-muted-foreground mb-6">The article you're looking for doesn't exist.</p>
        <Link href="/blog">
          <Button data-testid="button-back-blog">Back to Blog</Button>
        </Link>
      </div>
    );
  }

  const relatedArticles = blogArticles
    .filter(a => a.slug !== article.slug && a.category === article.category)
    .slice(0, 3);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ title: article.title, url: window.location.href });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  return (
    <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link href="/blog">
        <Button variant="ghost" size="sm" className="mb-6" data-testid="button-back-blog">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Blog
        </Button>
      </Link>

      <header className="mb-10">
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <Badge variant="secondary">{article.category}</Badge>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            {article.readTime} min read
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-4 leading-tight" data-testid="text-article-title">
          {article.title}
        </h1>
        <p className="text-muted-foreground text-sm mb-4" data-testid="text-article-excerpt">
          {article.excerpt}
        </p>
        <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            Published: {new Date(article.publishedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
          </span>
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            Updated: {new Date(article.updatedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
          </span>
          <Button variant="ghost" size="sm" onClick={handleShare} data-testid="button-share">
            <Share2 className="h-3 w-3 mr-1" />
            Share
          </Button>
        </div>
      </header>

      <nav className="mb-10 p-5 border border-border rounded-md bg-card" data-testid="section-toc">
        <h2 className="font-semibold text-sm mb-3 flex items-center gap-2">
          <BookOpen className="h-4 w-4" />
          Table of Contents
        </h2>
        <ol className="space-y-1.5">
          {article.sections.map((section, i) => (
            <li key={i}>
              <a
                href={`#section-${i}`}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                data-testid={`link-toc-${i}`}
              >
                {i + 1}. {section.heading}
              </a>
            </li>
          ))}
          {article.faqs.length > 0 && (
            <li>
              <a href="#faqs" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                FAQ
              </a>
            </li>
          )}
        </ol>
      </nav>

      <div className="space-y-10">
        {article.sections.map((section, i) => (
          <section key={i} id={`section-${i}`} data-testid={`section-content-${i}`}>
            <h2 className="text-xl font-bold mb-4">{section.heading}</h2>
            <div className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
              {section.content}
            </div>
          </section>
        ))}
      </div>

      {article.faqs.length > 0 && (
        <section id="faqs" className="mt-14" data-testid="section-faqs">
          <h2 className="text-xl font-bold mb-6">Frequently Asked Questions</h2>
          <div className="space-y-3">
            {article.faqs.map((faq, i) => (
              <Card
                key={i}
                className="cursor-pointer p-4"
                onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                data-testid={`faq-${i}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-medium text-sm">{faq.question}</h3>
                  {expandedFaq === i ? (
                    <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                  )}
                </div>
                {expandedFaq === i && (
                  <p className="text-sm text-muted-foreground mt-3 leading-relaxed">
                    {faq.answer}
                  </p>
                )}
              </Card>
            ))}
          </div>
        </section>
      )}

      <div className="mt-10">
        <AdUnit format="horizontal" className="text-center" />
      </div>

      {relatedArticles.length > 0 && (
        <section className="mt-14" data-testid="section-related">
          <h2 className="text-xl font-bold mb-6">Related Articles</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {relatedArticles.map(related => (
              <Link key={related.slug} href={`/blog/${related.slug}`}>
                <Card className="hover-elevate cursor-pointer p-4 h-full flex flex-col" data-testid={`card-related-${related.slug}`}>
                  <Badge variant="secondary" className="text-[10px] w-fit mb-2">{related.category}</Badge>
                  <h3 className="font-semibold text-sm mb-2 line-clamp-2">{related.title}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2 flex-1">{related.excerpt}</p>
                  <span className="flex items-center gap-1 text-xs text-primary font-medium mt-3">
                    Read <ArrowRight className="h-3 w-3" />
                  </span>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      )}

      <div className="mt-14 text-center border-t border-border pt-8">
        <p className="text-sm text-muted-foreground mb-4">
          Looking for your next international opportunity?
        </p>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <Link href="/jobs/all">
            <Button data-testid="button-browse-jobs">Browse All Jobs</Button>
          </Link>
          <Link href="/blog">
            <Button variant="outline" data-testid="button-more-articles">More Articles</Button>
          </Link>
        </div>
      </div>
    </article>
  );
}
