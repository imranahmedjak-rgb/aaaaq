import { useInfiniteQuery, useQuery, useQueryClient } from "@tanstack/react-query";
import { JobCard, JobCardSkeleton } from "@/components/job-card";
import JobAlertBox from "@/components/JobAlertBox";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getJobEngagement } from "@/lib/engagement";
import {
  Globe, Heart, Wifi, Building2, Briefcase, Loader2,
  Monitor, Stethoscope, DollarSign, GraduationCap,
  Wrench, Palette, Megaphone, Timer, ArrowUp, Search, RefreshCw, Star,
  SlidersHorizontal, X, Sparkles, Flame, Eye, Clock, ChevronDown, ChevronUp, Plane,
} from "lucide-react";
import type { Job } from "@shared/schema";
import { useState, useEffect, useRef } from "react";
import { useSearch } from "wouter";
import { Link } from "wouter";
import { AdUnit } from "@/components/ad-unit";

const categoryMeta: Record<string, { label: string; description: string; icon: any; gradient: string }> = {
  all: { label: "All Jobs", description: "Browse all verified job opportunities across every category", icon: Briefcase, gradient: "from-blue-600 to-indigo-700" },
  un: { label: "UN Jobs", description: "Careers at United Nations agencies and affiliated organizations", icon: Globe, gradient: "from-sky-500 to-blue-700" },
  ngo: { label: "NGO Jobs", description: "Opportunities at non-governmental and humanitarian organizations", icon: Heart, gradient: "from-emerald-500 to-teal-700" },
  remote: { label: "Remote Jobs", description: "Work-from-anywhere positions at global companies", icon: Wifi, gradient: "from-violet-500 to-purple-700" },
  international: { label: "International Jobs", description: "Global career opportunities across all sectors and industries", icon: Building2, gradient: "from-amber-500 to-orange-700" },
  technology: { label: "Technology & Software", description: "IT, software engineering, data science, and development roles", icon: Monitor, gradient: "from-cyan-500 to-blue-700" },
  healthcare: { label: "Healthcare & Life Sciences", description: "Medical, pharmaceutical, and public health positions", icon: Stethoscope, gradient: "from-rose-500 to-pink-700" },
  business: { label: "Business, Finance & Operations", description: "Finance, consulting, management, and operations careers", icon: DollarSign, gradient: "from-green-500 to-emerald-700" },
  education: { label: "Education & Training", description: "Teaching, academic, and professional training positions", icon: GraduationCap, gradient: "from-indigo-500 to-violet-700" },
  engineering: { label: "Engineering & Manufacturing", description: "Mechanical, civil, electrical, and industrial engineering", icon: Wrench, gradient: "from-orange-500 to-amber-700" },
  creative: { label: "Creative & Digital Media", description: "Design, content, communications, and media roles", icon: Palette, gradient: "from-pink-500 to-rose-700" },
  sales: { label: "Sales, Marketing & Customer Success", description: "Sales, growth marketing, and customer-facing roles", icon: Megaphone, gradient: "from-teal-500 to-cyan-700" },
  gig: { label: "Remote & Gig Economy", description: "Freelance, contract, part-time, and flexible positions", icon: Timer, gradient: "from-slate-500 to-gray-700" },
  youth: { label: "Youth Opportunities", description: "Fellowships, scholarships, trainings, workshops, and youth development programs worldwide", icon: Sparkles, gradient: "from-fuchsia-500 to-pink-700" },
};

const JOBS_PER_PAGE = 30;

const jobTypeOptions = [
  { value: "all", label: "All Types" },
  { value: "Full-time", label: "Full-time" },
  { value: "Part-time", label: "Part-time" },
  { value: "Contract", label: "Contract" },
  { value: "Freelance", label: "Freelance" },
  { value: "Internship", label: "Internship" },
  { value: "Fellowship", label: "Fellowship" },
  { value: "Temporary", label: "Temporary" },
];

const sortOptions = [
  { value: "newest", label: "Newest First" },
  { value: "oldest", label: "Oldest First" },
  { value: "trending", label: "Trending" },
  { value: "most-applied", label: "Most Applied" },
];

const experienceLevelOptions = [
  { value: "all", label: "All Levels" },
  { value: "entry", label: "Entry Level" },
  { value: "mid", label: "Mid Level" },
  { value: "senior", label: "Senior Level" },
  { value: "lead", label: "Lead/Director" },
];

const salaryFilterOptions = [
  { value: "all", label: "All Salaries" },
  { value: "has-salary", label: "Has Salary Info" },
];

const experienceKeywords: Record<string, string[]> = {
  entry: ["junior", "entry", "intern", "graduate", "trainee"],
  mid: ["mid", "intermediate", "associate"],
  senior: ["senior", "lead", "principal", "staff"],
  lead: ["director", "manager", "head", "vp", "chief", "executive"],
};


function matchesExperienceLevel(job: Job, level: string): boolean {
  const keywords = experienceKeywords[level];
  if (!keywords) return true;
  const text = `${job.title} ${job.description || ""}`.toLowerCase();
  return keywords.some(kw => text.includes(kw));
}

function isJobNew(postedAt: Date | string | null): boolean {
  if (!postedAt) return false;
  const date = new Date(postedAt);
  const now = new Date();
  const hoursAgo = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
  return hoursAgo <= 24;
}

interface PaginatedResponse {
  jobs: Job[];
  total: number;
  limit: number;
  offset: number;
  hasMore: boolean;
}

export default function JobListing({ category }: { category: string }) {
  const searchParams = useSearch();
  const urlParams = new URLSearchParams(searchParams);
  const urlSearch = urlParams.get("search") || "";
  const urlExperience = urlParams.get("experience") || "all";
  const urlJobType = urlParams.get("jobType") || "all";
  const urlRemote = urlParams.get("remote") === "true";
  const urlSalary = urlParams.get("salary") || "all";
  const urlVisa = urlParams.get("visa") === "true";

  const hasUrlFilters = urlExperience !== "all" || urlJobType !== "all" || urlRemote || urlSalary !== "all" || urlVisa;

  const [search, setSearch] = useState(urlSearch);
  const [debouncedSearch, setDebouncedSearch] = useState(urlSearch);
  const [jobType, setJobType] = useState(urlJobType);
  const [sortBy, setSortBy] = useState("newest");
  const [experienceLevel, setExperienceLevel] = useState(urlExperience);
  const [remoteOnly, setRemoteOnly] = useState(urlRemote);
  const [newIn24h, setNewIn24h] = useState(false);
  const [salaryFilter, setSalaryFilter] = useState(urlSalary);
  const [visaSponsorship, setVisaSponsorship] = useState(urlVisa);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(hasUrlFilters);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const queryClient = useQueryClient();
  const meta = categoryMeta[category] || categoryMeta.all;
  const Icon = meta.icon;
  const sentinelRef = useRef<HTMLDivElement>(null);

  const { data: featuredEmployerJobs } = useQuery<Job[]>({
    queryKey: ["/api/jobs/featured-employer", category],
    queryFn: async () => {
      const params = category && category !== "all" ? `?category=${category}` : "";
      const res = await fetch(`/api/jobs/featured-employer${params}`);
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    refetchInterval: 10000,
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await fetch("/api/jobs/refresh", { method: "POST" });
      await new Promise((r) => setTimeout(r, 3000));
      await queryClient.invalidateQueries({ predicate: (query) => {
        const key = query.queryKey[0] as string;
        return key === "/api/jobs" || key === "/api/jobs/stats" || key === "/api/jobs/featured";
      }});
    } catch (err) {
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
    }, 400);
    return () => clearTimeout(timer);
  }, [search]);

  const {
    data,
    isLoading,
    isFetchingNextPage,
    fetchNextPage,
    hasNextPage,
  } = useInfiniteQuery<PaginatedResponse>({
    queryKey: ["/api/jobs", category, debouncedSearch],
    queryFn: async ({ pageParam }) => {
      const offset = pageParam as number;
      const params = new URLSearchParams({
        limit: String(JOBS_PER_PAGE),
        offset: String(offset),
      });
      if (debouncedSearch.trim()) {
        params.set("search", debouncedSearch.trim());
      }
      const res = await fetch(`/api/jobs/${category}?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch jobs");
      return res.json();
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage) => {
      if (lastPage.hasMore) {
        return lastPage.offset + lastPage.limit;
      }
      return undefined;
    },
    refetchInterval: 10000,
    refetchOnWindowFocus: true,
  });

  let allJobs = data?.pages.flatMap((page) => page.jobs) || [];
  const totalJobs = data?.pages[0]?.total || 0;

  if (jobType !== "all") {
    allJobs = allJobs.filter(j => j.jobType?.toLowerCase().includes(jobType.toLowerCase()));
  }

  if (experienceLevel !== "all") {
    allJobs = allJobs.filter(j => matchesExperienceLevel(j, experienceLevel));
  }

  if (remoteOnly) {
    allJobs = allJobs.filter(j =>
      j.category === "remote" || (j.location && j.location.toLowerCase().includes("remote"))
    );
  }

  if (newIn24h) {
    allJobs = allJobs.filter(j => isJobNew(j.postedAt));
  }

  if (salaryFilter === "has-salary") {
    allJobs = allJobs.filter(j => j.salary && j.salary.trim() !== "");
  }

  if (visaSponsorship) {
    allJobs = allJobs.filter(j => {
      const text = `${j.title || ""} ${j.description || ""} ${j.location || ""}`.toLowerCase();
      return text.includes("visa") || text.includes("sponsorship") || text.includes("sponsor") || text.includes("relocation") || text.includes("work permit");
    });
  }

  if (sortBy === "trending") {
    allJobs = [...allJobs].sort((a, b) => {
      const va = getJobEngagement(a.id, !!a.featured).views;
      const vb = getJobEngagement(b.id, !!b.featured).views;
      return vb - va;
    });
  } else if (sortBy === "most-applied") {
    allJobs = [...allJobs].sort((a, b) => {
      const aa = getJobEngagement(a.id, !!a.featured).applies;
      const ab = getJobEngagement(b.id, !!b.featured).applies;
      return ab - aa;
    });
  } else if (sortBy === "oldest") {
    allJobs = [...allJobs].sort((a, b) => {
      const da = a.postedAt ? new Date(a.postedAt).getTime() : 0;
      const db = b.postedAt ? new Date(b.postedAt).getTime() : 0;
      return da - db;
    });
  }

  const loadedCount = allJobs.length;
  const rawLoaded = data?.pages.flatMap((page) => page.jobs).length || 0;
  const progressPercent = totalJobs > 0 ? Math.round((rawLoaded / totalJobs) * 100) : 0;
  const clampedProgress = Math.min(progressPercent, 100);
  const batchNumber = data?.pages.length || 0;
  const totalBatches = totalJobs > 0 ? Math.ceil(totalJobs / JOBS_PER_PAGE) : 0;

  const hasActiveFilters = jobType !== "all" || experienceLevel !== "all" || remoteOnly || newIn24h || salaryFilter !== "all" || visaSponsorship || sortBy !== "newest";

  const clearFilters = () => {
    setJobType("all");
    setSearch("");
    setExperienceLevel("all");
    setRemoteOnly(false);
    setNewIn24h(false);
    setSalaryFilter("all");
    setVisaSponsorship(false);
    setSortBy("newest");
  };

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { rootMargin: "400px" }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 600);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const advancedFilterCount = [
    experienceLevel !== "all",
    remoteOnly,
    newIn24h,
    salaryFilter !== "all",
    visaSponsorship,
    sortBy !== "newest",
  ].filter(Boolean).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-4 mb-4">
          <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${meta.gradient} flex items-center justify-center shrink-0 shadow-md`}>
            <Icon className="h-7 w-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold" data-testid="text-category-title">{meta.label}</h1>
            <p className="text-sm text-muted-foreground mt-0.5">{meta.description}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Badge variant="secondary" className="font-semibold" data-testid="badge-total-jobs">
            {totalJobs.toLocaleString()} jobs found
          </Badge>
          {!isLoading && totalJobs > 0 && (
            <span className="text-xs text-muted-foreground" data-testid="text-showing-count">
              Showing {loadedCount.toLocaleString()} of {totalJobs.toLocaleString()}
            </span>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={handleRefresh}
            disabled={isRefreshing}
            data-testid="button-refresh-jobs"
          >
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${isRefreshing ? "animate-spin" : ""}`} />
            {isRefreshing ? "Refreshing..." : "Refresh"}
          </Button>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by title, company, or location..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
              data-testid="input-search-jobs"
            />
          </div>
          <Select value={jobType} onValueChange={setJobType}>
            <SelectTrigger className="w-[160px]" data-testid="select-job-type">
              <Briefcase className="h-4 w-4 mr-2 text-muted-foreground" />
              <SelectValue placeholder="Job Type" />
            </SelectTrigger>
            <SelectContent>
              {jobTypeOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[160px]" data-testid="select-sort-by">
              <SlidersHorizontal className="h-4 w-4 mr-2 text-muted-foreground" />
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            className={`toggle-elevate ${showAdvancedFilters ? "toggle-elevated" : ""}`}
            data-testid="button-more-filters"
          >
            {showAdvancedFilters ? <ChevronUp className="h-3.5 w-3.5 mr-1.5" /> : <ChevronDown className="h-3.5 w-3.5 mr-1.5" />}
            More Filters
            {advancedFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1.5 text-[10px]">{advancedFilterCount}</Badge>
            )}
          </Button>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} data-testid="button-clear-filters">
              <X className="h-3.5 w-3.5 mr-1" />
              Clear
            </Button>
          )}
        </div>

        {showAdvancedFilters && (
          <div className="flex items-center gap-3 flex-wrap mt-4 pt-4 border-t border-border">
            <Select value={experienceLevel} onValueChange={setExperienceLevel}>
              <SelectTrigger className="w-[160px]" data-testid="select-experience-level">
                <GraduationCap className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="Experience" />
              </SelectTrigger>
              <SelectContent>
                {experienceLevelOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={salaryFilter} onValueChange={setSalaryFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-salary-filter">
                <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="Salary" />
              </SelectTrigger>
              <SelectContent>
                {salaryFilterOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setRemoteOnly(!remoteOnly)}
              className={`toggle-elevate ${remoteOnly ? "toggle-elevated" : ""}`}
              data-testid="button-remote-only"
            >
              <Wifi className="h-3.5 w-3.5 mr-1.5" />
              Remote Only
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setNewIn24h(!newIn24h)}
              className={`toggle-elevate ${newIn24h ? "toggle-elevated" : ""}`}
              data-testid="button-new-24h"
            >
              <Clock className="h-3.5 w-3.5 mr-1.5" />
              New in 24h
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setVisaSponsorship(!visaSponsorship)}
              className={`toggle-elevate ${visaSponsorship ? "toggle-elevated" : ""}`}
              data-testid="button-visa-sponsorship"
            >
              <Plane className="h-3.5 w-3.5 mr-1.5" />
              Visa Sponsorship
            </Button>
          </div>
        )}
      </Card>

      {!isLoading && totalJobs > JOBS_PER_PAGE && (
        <div className="mb-6">
          <div className="flex items-center justify-between gap-4 mb-1.5">
            <span className="text-xs text-muted-foreground">
              Page {batchNumber} of {totalBatches}
            </span>
            <span className="text-xs text-muted-foreground">{clampedProgress}% loaded</span>
          </div>
          <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500 ease-out"
              style={{ width: `${clampedProgress}%` }}
              data-testid="progress-bar"
            />
          </div>
        </div>
      )}

      {featuredEmployerJobs && featuredEmployerJobs.length > 0 && !debouncedSearch && (
        <div className="mb-8" data-testid="section-listing-featured">
          <div className="flex items-center gap-2 mb-4">
            <Star className="h-4 w-4 text-amber-500" />
            <h2 className="font-bold text-sm">Featured Jobs</h2>
            <Badge variant="secondary" className="text-[10px]">{featuredEmployerJobs.length}</Badge>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {featuredEmployerJobs.map((job) => (
              <div key={`featured-${job.id}`} className="relative">
                <div className="absolute -top-2.5 -right-2.5 z-10">
                  <Badge variant="default" className="bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] shadow-lg border-0">
                    <Star className="h-3 w-3 mr-0.5" />
                    Featured
                  </Badge>
                </div>
                <JobCard job={job} isFeatured />
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading
          ? Array.from({ length: 12 }).map((_, i) => <JobCardSkeleton key={i} />)
          : allJobs.map((job) => <JobCard key={job.id} job={job} />)}
      </div>

      {!isLoading && allJobs.length === 0 && (
        <Card className="p-16 text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-5">
            <Briefcase className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="font-bold text-lg mb-2">No jobs found</h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto">
            {search || hasActiveFilters
              ? "Try adjusting your search terms or filters."
              : "Jobs are being fetched from verified sources. Please check back shortly."}
          </p>
          {(search || hasActiveFilters) && (
            <Button variant="outline" className="mt-4" onClick={clearFilters} data-testid="button-clear-search">
              Clear all filters
            </Button>
          )}
        </Card>
      )}

      {allJobs.length > 0 && (
        <div className="py-4">
          <AdUnit format="horizontal" className="text-center" />
        </div>
      )}

      {(hasNextPage || isFetchingNextPage) && (
        <div ref={sentinelRef} className="flex flex-col items-center justify-center py-10 gap-3" data-testid="infinite-scroll-sentinel">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <span className="text-sm text-muted-foreground">Loading more jobs...</span>
        </div>
      )}

      {!isLoading && !hasNextPage && allJobs.length > 0 && (
        <div className="text-center py-10">
          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-muted/50">
            <Briefcase className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground font-medium">
              You've viewed all {totalJobs.toLocaleString()} jobs
            </span>
          </div>
        </div>
      )}

      <div
        className={`fixed bottom-6 right-6 z-40 transition-all duration-300 ${showScrollTop ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"}`}
      >
        <Button
          size="icon"
          variant="secondary"
          onClick={scrollToTop}
          className="shadow-lg"
          data-testid="button-scroll-top"
        >
          <ArrowUp className="h-4 w-4" />
        </Button>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 mb-4">
        <JobAlertBox category={category} />
      </div>

      <div
        className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-40 hidden md:flex transition-all duration-300 ${showScrollTop ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"}`}
        data-testid="sticky-cta-bar"
      >
        <Card className="px-4 py-3 flex items-center gap-3 shadow-xl backdrop-blur-md bg-card/90 border border-border">
          <Link href="/post-job">
            <Button size="sm" data-testid="button-cta-post-job">
              <Briefcase className="h-3.5 w-3.5 mr-1.5" />
              Post a Job - $10
            </Button>
          </Link>
          <Link href="/post-job">
            <Button size="sm" variant="outline" className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0" data-testid="button-cta-featured-job">
              <Star className="h-3.5 w-3.5 mr-1.5" />
              Featured Job - $25
            </Button>
          </Link>
        </Card>
      </div>
    </div>
  );
}
