import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Globe, ExternalLink, Search, Clock, CheckCircle2,
  Plane, FileText, Briefcase, GraduationCap, Sparkles,
  Building2, Laptop, Rocket,
} from "lucide-react";

const visaCategories = [
  { id: "all", label: "All" },
  { id: "work", label: "Work Visas" },
  { id: "nomad", label: "Digital Nomad Visas" },
  { id: "student", label: "Student Visas" },
  { id: "opportunity", label: "Opportunity Cards" },
  { id: "startup", label: "Startup Visas" },
];

interface VisaProgram {
  name: string;
  country: string;
  countryCode: string;
  category: string;
  typeBadge: string;
  description: string;
  requirements: string[];
  processingTime: string;
  officialUrl: string;
  embassyUrl: string;
}

const visaPrograms: VisaProgram[] = [
  {
    name: "Germany Opportunity Card (Chancenkarte)",
    country: "Germany",
    countryCode: "de",
    category: "opportunity",
    typeBadge: "Opportunity Card",
    description: "Points-based visa for skilled workers to enter Germany and search for employment. Requires a recognized degree or vocational qualification and scores based on language skills, experience, age, and German connection.",
    requirements: ["Recognized degree or vocational qualification", "Minimum 6 points from criteria (language, experience, age)", "Proof of financial means for 12 months", "Basic German (A1) or English (B2)"],
    processingTime: "4-8 weeks",
    officialUrl: "https://www.make-it-in-germany.com/en/visa-residence/types/chance-card",
    embassyUrl: "https://www.auswaertiges-amt.de/en",
  },
  {
    name: "Portugal Digital Nomad Visa (D8)",
    country: "Portugal",
    countryCode: "pt",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Remote work visa for non-EU nationals earning at least 4x Portugal's minimum wage from foreign employers or clients. Allows living in Portugal while working remotely.",
    requirements: ["Proof of remote employment or freelance contracts", "Monthly income of at least 4x Portuguese minimum wage", "Health insurance valid in Portugal", "Clean criminal record"],
    processingTime: "2-3 months",
    officialUrl: "https://www.sef.pt/en/pages/conteudo-detalhe.aspx?nID=72",
    embassyUrl: "https://www.portaldascomunidades.mne.gov.pt/en/",
  },
  {
    name: "Spain Digital Nomad Visa",
    country: "Spain",
    countryCode: "es",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Allows remote workers and freelancers to live in Spain for up to 5 years. Must earn income from companies outside Spain with no more than 20% of income from Spanish sources.",
    requirements: ["Minimum 1 year of relationship with non-Spanish employer", "Income at least 200% of Spanish minimum wage", "University degree or 3+ years professional experience", "No criminal record in last 5 years"],
    processingTime: "1-3 months",
    officialUrl: "https://www.exteriores.gob.es/en/Paginas/index.aspx",
    embassyUrl: "https://www.exteriores.gob.es/en/EmbajadasConsulados/Paginas/index.aspx",
  },
  {
    name: "Estonia Digital Nomad Visa",
    country: "Estonia",
    countryCode: "ee",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "One of Europe's first digital nomad visas. Allows location-independent workers to live in Estonia for up to 1 year while working for a foreign employer or running a foreign business.",
    requirements: ["Work remotely for a company registered outside Estonia", "Minimum monthly income of EUR 4,500 (before tax)", "Ability to work remotely via telecom tools", "Valid travel insurance"],
    processingTime: "2-4 weeks",
    officialUrl: "https://www.e-resident.gov.ee/nomadvisa/",
    embassyUrl: "https://www.vm.ee/en",
  },
  {
    name: "Croatia Digital Nomad Visa",
    country: "Croatia",
    countryCode: "hr",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Temporary stay permit for digital nomads to live in Croatia for up to 1 year. Tax-exempt on foreign income during the stay period.",
    requirements: ["Proof of remote work for foreign company", "Monthly income of at least EUR 2,539", "Health insurance covering Croatia", "Proof of accommodation in Croatia"],
    processingTime: "2-4 weeks",
    officialUrl: "https://mup.gov.hr/en",
    embassyUrl: "https://mvep.gov.hr/en",
  },
  {
    name: "UAE Golden Visa",
    country: "United Arab Emirates",
    countryCode: "ae",
    category: "work",
    typeBadge: "Work Visa",
    description: "Long-term residence visa (5 or 10 years) for investors, entrepreneurs, scientists, outstanding students, and skilled professionals. Offers 100% business ownership and no sponsor required.",
    requirements: ["Skilled professionals: valid employment contract with salary of AED 30,000+", "Investors: investment of AED 2 million+", "Entrepreneurs: project approved by accredited incubator", "Outstanding students: GPA 3.75+ from top universities"],
    processingTime: "2-4 weeks",
    officialUrl: "https://u.ae/en/information-and-services/visa-and-emirates-id/golden-visa",
    embassyUrl: "https://www.mofaic.gov.ae/en",
  },
  {
    name: "Canada Express Entry",
    country: "Canada",
    countryCode: "ca",
    category: "work",
    typeBadge: "Work Visa",
    description: "Points-based immigration system managing applications for permanent residence under Federal Skilled Worker, Canadian Experience Class, and Federal Skilled Trades programs.",
    requirements: ["Skilled work experience (NOC TEER 0, 1, 2, or 3)", "Language test results (CLB 7+ for FSW)", "Education credential assessment for foreign degrees", "Minimum 67 points on selection grid (FSW)"],
    processingTime: "6-8 months",
    officialUrl: "https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/express-entry.html",
    embassyUrl: "https://www.international.gc.ca/country-pays/index.aspx",
  },
  {
    name: "Australia Skilled Worker Visa (Subclass 482)",
    country: "Australia",
    countryCode: "au",
    category: "work",
    typeBadge: "Work Visa",
    description: "Temporary Skill Shortage visa allowing employers to sponsor skilled workers. Available for short-term (2 years) or medium-term (4 years) occupations on the skilled occupation lists.",
    requirements: ["Nomination by an approved sponsor", "Occupation on skilled occupation list", "Minimum 2 years relevant work experience", "English language proficiency (IELTS 5.0+)"],
    processingTime: "1-4 months",
    officialUrl: "https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/temporary-skill-shortage-482",
    embassyUrl: "https://www.dfat.gov.au/embassies",
  },
  {
    name: "UK Skilled Worker Visa",
    country: "United Kingdom",
    countryCode: "gb",
    category: "work",
    typeBadge: "Work Visa",
    description: "For workers with a job offer from a UK employer who holds a valid sponsor licence. Replaced the Tier 2 General visa and allows stay up to 5 years, with path to settlement.",
    requirements: ["Job offer from a licensed UK sponsor", "Certificate of Sponsorship (CoS)", "Minimum salary threshold (generally GBP 38,700+)", "English language requirement (B1 CEFR)"],
    processingTime: "3-8 weeks",
    officialUrl: "https://www.gov.uk/skilled-worker-visa",
    embassyUrl: "https://www.gov.uk/world/embassies",
  },
  {
    name: "USA H-1B Visa",
    country: "United States",
    countryCode: "us",
    category: "work",
    typeBadge: "Work Visa",
    description: "Specialty occupation visa for workers in fields requiring theoretical or technical expertise. Subject to annual cap of 65,000 (plus 20,000 for US master's degree holders) with lottery selection.",
    requirements: ["Bachelor's degree or equivalent in specialty occupation", "Job offer from a US employer for specialty occupation", "Employer must file Labor Condition Application", "Selected in annual H-1B lottery (April)"],
    processingTime: "3-6 months (regular), 15 days (premium)",
    officialUrl: "https://www.uscis.gov/working-in-the-united-states/h-1b-specialty-occupations",
    embassyUrl: "https://www.usembassy.gov/",
  },
  {
    name: "USA J-1 Exchange Visitor Visa",
    country: "United States",
    countryCode: "us",
    category: "student",
    typeBadge: "Student Visa",
    description: "Cultural exchange visa for students, interns, trainees, teachers, professors, and research scholars. Allows participants to gain experience in the US through designated exchange programs.",
    requirements: ["Acceptance into a designated exchange program", "DS-2019 form from program sponsor", "Proof of English proficiency", "Sufficient funding for living expenses"],
    processingTime: "3-5 weeks",
    officialUrl: "https://j1visa.state.gov/",
    embassyUrl: "https://www.usembassy.gov/",
  },
  {
    name: "USA OPT (Optional Practical Training)",
    country: "United States",
    countryCode: "us",
    category: "student",
    typeBadge: "Student Visa",
    description: "Work authorization for F-1 students to gain practical experience in their field of study. Standard OPT is 12 months; STEM graduates may extend for an additional 24 months.",
    requirements: ["Active F-1 student status", "Completed or pursuing a degree at a SEVP-certified school", "Employment directly related to major area of study", "Apply within 60 days before/after program completion"],
    processingTime: "3-5 months",
    officialUrl: "https://www.uscis.gov/working-in-the-united-states/students-and-exchange-visitors/optional-practical-training-opt-for-f-1-students",
    embassyUrl: "https://www.usembassy.gov/",
  },
  {
    name: "Japan Highly Skilled Professional Visa",
    country: "Japan",
    countryCode: "jp",
    category: "work",
    typeBadge: "Work Visa",
    description: "Points-based visa for highly skilled foreign professionals in academic research, specialized technology, or business management. Offers preferential immigration treatment and path to permanent residence in 1-3 years.",
    requirements: ["Minimum 70 points on points-based system", "Qualified in academic, technical, or business management field", "Salary comparable to Japanese nationals", "No criminal record"],
    processingTime: "1-3 months",
    officialUrl: "https://www.moj.go.jp/isa/publications/materials/newimmiact_3_system_index.html",
    embassyUrl: "https://www.mofa.go.jp/about/emb_cons/mofaserv.html",
  },
  {
    name: "South Korea D-10 Job Seeker Visa",
    country: "South Korea",
    countryCode: "kr",
    category: "opportunity",
    typeBadge: "Opportunity Card",
    description: "Allows qualified foreign nationals to stay in South Korea for up to 6 months to seek employment. Available to graduates of Korean universities or holders of specific qualifications.",
    requirements: ["Bachelor's degree or higher", "Graduate from a Korean university or equivalent foreign qualification", "Sufficient funds for stay duration", "No criminal record"],
    processingTime: "2-4 weeks",
    officialUrl: "https://www.visa.go.kr/",
    embassyUrl: "https://overseas.mofa.go.kr/eng/index.do",
  },
  {
    name: "Netherlands Orientation Year Visa (Zoekjaar)",
    country: "Netherlands",
    countryCode: "nl",
    category: "opportunity",
    typeBadge: "Opportunity Card",
    description: "One-year residence permit for recent graduates from top-200 universities worldwide or Dutch institutions. Allows searching for work or starting a business in the Netherlands.",
    requirements: ["Graduated from top-200 ranked university within last 3 years", "OR graduated from any Dutch higher education institution", "Sufficient means of support", "Apply within 3 years of graduation"],
    processingTime: "2-3 months",
    officialUrl: "https://ind.nl/en/residence-permits/work/residence-permit-for-orientation-year",
    embassyUrl: "https://www.netherlandsworldwide.nl/",
  },
  {
    name: "Ireland Stamp 1G (Graduate Permission)",
    country: "Ireland",
    countryCode: "ie",
    category: "opportunity",
    typeBadge: "Opportunity Card",
    description: "Post-study work permission for graduates of Irish higher education institutions. Allows non-EEA graduates to remain in Ireland and seek employment for up to 24 months.",
    requirements: ["Graduated from an Irish higher education institution", "Honours degree (Level 8) or above on NFQ", "Applied within 6 months of exam results", "Private health insurance"],
    processingTime: "2-4 weeks",
    officialUrl: "https://www.irishimmigration.ie/coming-to-study-in-ireland/what-are-my-study-options/third-level-graduate-programme/",
    embassyUrl: "https://www.ireland.ie/en/dfa/embassies/",
  },
  {
    name: "France Talent Passport (Passeport Talent)",
    country: "France",
    countryCode: "fr",
    category: "work",
    typeBadge: "Work Visa",
    description: "Multi-year residence permit for highly qualified workers, researchers, artists, and entrepreneurs. Valid up to 4 years and renewable. Family members receive matching permits.",
    requirements: ["Relevant qualifications (Master's degree or 5+ years experience)", "Employment contract or business plan", "Salary at least 1.5x average gross salary for employees", "Proof of accommodation in France"],
    processingTime: "1-3 months",
    officialUrl: "https://france-visas.gouv.fr/en/web/france-visas/talent-passport",
    embassyUrl: "https://www.diplomatie.gouv.fr/en/french-foreign-policy/",
  },
  {
    name: "Singapore Employment Pass",
    country: "Singapore",
    countryCode: "sg",
    category: "work",
    typeBadge: "Work Visa",
    description: "Work visa for foreign professionals, managers, and executives earning at least SGD 5,000/month. Uses the COMPASS points-based framework evaluating salary, qualifications, diversity, and skills.",
    requirements: ["Minimum monthly salary of SGD 5,000 (higher for older candidates)", "Acceptable qualifications (degree from reputable institution)", "Pass COMPASS framework assessment", "Job offer from a Singapore-registered company"],
    processingTime: "3-8 weeks",
    officialUrl: "https://www.mom.gov.sg/passes-and-permits/employment-pass",
    embassyUrl: "https://www.mfa.gov.sg/Overseas-Missions",
  },
  {
    name: "New Zealand Skilled Migrant Category",
    country: "New Zealand",
    countryCode: "nz",
    category: "work",
    typeBadge: "Work Visa",
    description: "Points-based resident visa for skilled workers. Points awarded for age, skilled employment, qualifications, and work experience. Requires Expression of Interest with 160+ points.",
    requirements: ["Minimum 160 points on points scale", "Age under 56 years", "Skilled employment or job offer in NZ", "Minimum IELTS 6.5 (or equivalent)"],
    processingTime: "6-12 months",
    officialUrl: "https://www.immigration.govt.nz/new-zealand-visas/visas/visa/skilled-migrant-category-resident-visa",
    embassyUrl: "https://www.mfat.govt.nz/en/embassies/",
  },
  {
    name: "Czech Republic Zivno Visa (Trade License)",
    country: "Czech Republic",
    countryCode: "cz",
    category: "startup",
    typeBadge: "Startup Visa",
    description: "Long-term business visa based on a trade license (Zivnostensky list). Popular among freelancers and digital nomads for its relatively easy requirements and access to the Schengen area.",
    requirements: ["Valid trade license (Zivnostensky list) application", "Proof of accommodation in Czech Republic", "Financial means (approx. EUR 6,000 in bank)", "Clean criminal record"],
    processingTime: "2-3 months",
    officialUrl: "https://www.mvcr.cz/mvcren/article/third-country-nationals-long-term-visa.aspx",
    embassyUrl: "https://www.mzv.cz/jnp/en/",
  },
  {
    name: "Barbados Welcome Stamp",
    country: "Barbados",
    countryCode: "bb",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "12-month remote work visa allowing professionals to live and work remotely from Barbados. One of the first Caribbean digital nomad visas with a straightforward application process.",
    requirements: ["Annual income of at least USD 50,000", "Employed or self-employed with clients outside Barbados", "Valid health insurance", "Clean criminal record"],
    processingTime: "1-2 weeks",
    officialUrl: "https://www.visitbarbados.org/barbados-welcome-stamp",
    embassyUrl: "https://www.foreign.gov.bb/",
  },
  {
    name: "Malta Nomad Residence Permit",
    country: "Malta",
    countryCode: "mt",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Residence permit for remote workers to live in Malta for up to 1 year (renewable). Offers access to the EU and Mediterranean lifestyle while working for a foreign employer.",
    requirements: ["Monthly income of at least EUR 2,700", "Remote work for employer/clients outside Malta", "Valid health insurance covering Malta", "Proof of accommodation in Malta"],
    processingTime: "2-4 weeks",
    officialUrl: "https://nomad.residencymalta.gov.mt/",
    embassyUrl: "https://foreignandeu.gov.mt/",
  },
  {
    name: "Greece Digital Nomad Visa",
    country: "Greece",
    countryCode: "gr",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Residence permit for non-EU remote workers to live in Greece for up to 2 years. Offers 50% tax reduction on income earned from foreign sources during the first 7 years.",
    requirements: ["Remote employment with company outside Greece", "Monthly income of at least EUR 3,500", "Health insurance valid in Greece", "No criminal record"],
    processingTime: "1-2 months",
    officialUrl: "https://www.migration.gov.gr/en/",
    embassyUrl: "https://www.mfa.gr/en/appendix/greece-abroad/",
  },
  {
    name: "Thailand Long-Term Resident (LTR) Visa",
    country: "Thailand",
    countryCode: "th",
    category: "work",
    typeBadge: "Work Visa",
    description: "10-year visa for wealthy global citizens, wealthy pensioners, remote workers, and highly skilled professionals. Offers work permit, reduced tax rate of 17%, and fast-track airport services.",
    requirements: ["Remote workers: personal income of USD 80,000+/year", "OR USD 40,000+/year with master's degree or IP/funding", "Health insurance with USD 50,000+ coverage", "No criminal record"],
    processingTime: "1-3 months",
    officialUrl: "https://ltr.boi.go.th/",
    embassyUrl: "https://www.mfa.go.th/en/page/diplomatic-missions-abroad",
  },
  {
    name: "Mexico Temporary Resident Visa",
    country: "Mexico",
    countryCode: "mx",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "Temporary residence for up to 4 years. Popular with remote workers and freelancers. No minimum income requirement at the visa stage, but need to show financial solvency.",
    requirements: ["Monthly income of approx. USD 2,500+ (varies by consulate)", "OR savings of USD 42,000+ in past 12 months", "Valid passport with 6+ months validity", "Completed online application and interview"],
    processingTime: "2-4 weeks",
    officialUrl: "https://www.gob.mx/tramites/ficha/visa-de-residencia-temporal/SRE187",
    embassyUrl: "https://www.gob.mx/sre/acciones-y-programas/embassies-and-consulates",
  },
  {
    name: "Colombia Digital Nomad Visa (V-Nomada Digital)",
    country: "Colombia",
    countryCode: "co",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "2-year digital nomad visa for remote workers earning at least 3x Colombian minimum wage. Allows working remotely from Colombia with no local income tax obligations.",
    requirements: ["Remote work for foreign company or as freelancer", "Monthly income of at least 3x Colombian minimum wage (~USD 900)", "Health insurance valid in Colombia", "Clean criminal record from home country"],
    processingTime: "1-2 weeks",
    officialUrl: "https://www.cancilleria.gov.co/en/procedures_services/visas",
    embassyUrl: "https://www.cancilleria.gov.co/en/",
  },
  {
    name: "Brazil Digital Nomad Visa",
    country: "Brazil",
    countryCode: "br",
    category: "nomad",
    typeBadge: "Nomad Visa",
    description: "1-year renewable visa for remote workers to live in Brazil. Must earn income from foreign sources with a minimum monthly income of USD 1,500 or equivalent savings.",
    requirements: ["Remote employment with foreign company or clients", "Monthly income of at least USD 1,500", "Health insurance valid in Brazil", "No criminal record"],
    processingTime: "2-4 weeks",
    officialUrl: "https://www.gov.br/mre/en",
    embassyUrl: "https://www.gov.br/mre/en/subjects/embassies-consulates-and-honorary-consulates",
  },
  {
    name: "Australia Subclass 494 Skilled Employer Sponsored Regional",
    country: "Australia",
    countryCode: "au",
    category: "work",
    typeBadge: "Work Visa",
    description: "5-year provisional visa for skilled workers sponsored by an employer in regional Australia. Pathway to permanent residence after 3 years of working in a designated regional area.",
    requirements: ["Nomination by an approved regional employer", "Occupation on relevant skilled occupation list", "Skills assessment for nominated occupation", "English proficiency (IELTS 6.0+) and under 45 years old"],
    processingTime: "3-6 months",
    officialUrl: "https://immi.homeaffairs.gov.au/visas/getting-a-visa/visa-listing/skilled-employer-sponsored-regional-494",
    embassyUrl: "https://www.dfat.gov.au/embassies",
  },
];

export default function VisaGuide() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = visaPrograms.filter((v) => {
    const matchesCat = activeCategory === "all" || v.category === activeCategory;
    const matchesSearch = !searchQuery ||
      v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.typeBadge.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 mb-4">
          <Globe className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-visa-guide-title">
          Visa & Immigration Guide
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Navigate international visa requirements with confidence. Comprehensive guide for students,
          skilled workers, digital nomads, and entrepreneurs seeking opportunities abroad.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <FileText className="h-4 w-4" />
            <span>{visaPrograms.length} Visa Programs</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>25+ Countries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Briefcase className="h-4 w-4" />
            <span>Work & Study Options</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Laptop className="h-4 w-4" />
            <span>Digital Nomad Visas</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by country, visa type, or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-visa-search"
          />
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {visaCategories.map((cat) => (
            <Button
              key={cat.id}
              variant={activeCategory === cat.id ? "secondary" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`button-visa-filter-${cat.id}`}
              className="toggle-elevate"
            >
              {cat.label}
            </Button>
          ))}
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} visa program{filtered.length !== 1 ? "s" : ""}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((visa) => (
          <Card
            key={visa.name}
            className="p-5 flex flex-col gap-3 hover-elevate"
            data-testid={`card-visa-${visa.name.toLowerCase().replace(/[\s()\/]/g, "-").substring(0, 50)}`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <img
                  src={`https://flagcdn.com/w40/${visa.countryCode}.png`}
                  srcSet={`https://flagcdn.com/w80/${visa.countryCode}.png 2x`}
                  width="40"
                  height="30"
                  alt={`${visa.country} flag`}
                  className="rounded-sm shrink-0 object-cover"
                  loading="lazy"
                />
                <div>
                  <h3 className="font-semibold text-sm leading-snug">{visa.name}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{visa.country}</p>
                </div>
              </div>
              <Badge variant="secondary" className="shrink-0 text-[10px]">
                {visa.typeBadge}
              </Badge>
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed">{visa.description}</p>

            <div className="space-y-1.5">
              <p className="text-xs font-medium flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-green-600 dark:text-green-400 shrink-0" />
                Key Requirements
              </p>
              <ul className="space-y-1 pl-5">
                {visa.requirements.map((req, i) => (
                  <li key={i} className="text-xs text-muted-foreground list-disc">{req}</li>
                ))}
              </ul>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="h-3.5 w-3.5 shrink-0" />
              <span>Processing: {visa.processingTime}</span>
            </div>

            <div className="flex flex-wrap gap-2 mt-auto">
              <a href={visa.officialUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                <Button size="sm" variant="outline" className="w-full" data-testid={`button-visa-learn-${visa.countryCode}`}>
                  <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                  Learn More
                </Button>
              </a>
              <a href={visa.embassyUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                <Button size="sm" variant="outline" className="w-full" data-testid={`button-visa-embassy-${visa.countryCode}`}>
                  <Building2 className="h-3.5 w-3.5 mr-1.5" />
                  Embassy Info
                </Button>
              </a>
            </div>
          </Card>
        ))}
      </div>

      <Card className="mt-8 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-teal-500/10 flex items-center justify-center shrink-0">
            <Sparkles className="h-5 w-5 text-teal-600" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">Visa Application Tips</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Start your visa application well in advance -- processing times can vary significantly. Always check the
              official embassy or consulate website for the most current requirements and fees. Prepare all documents in the
              required format, get certified translations where needed, and keep copies of everything you submit. Consider
              consulting an immigration lawyer for complex cases.
            </p>
          </div>
        </div>
      </Card>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              {
                "@type": "ListItem",
                position: 1,
                name: "Home",
                item: "https://devglobaljobs.com",
              },
              {
                "@type": "ListItem",
                position: 2,
                name: "Visa & Immigration Guide",
                item: "https://devglobaljobs.com/visa-guide",
              },
            ],
          }),
        }}
      />
    </div>
  );
}
