import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Users, ExternalLink, Search, Globe, Building2,
  Sparkles, MapPin, Heart, CheckCircle2, Briefcase, Shield,
} from "lucide-react";

const categories = [
  { id: "all", label: "All" },
  { id: "internship", label: "Internships" },
  { id: "volunteer", label: "Volunteering" },
  { id: "fellowship", label: "Fellowships" },
  { id: "exchange", label: "Exchange Programs" },
];

const opportunities = [
  {
    name: "UN Volunteers (UNV)",
    org: "United Nations",
    url: "https://www.unv.org",
    category: "volunteer",
    location: "Global",
    tags: ["UN System", "Paid", "6-12 Months"],
    description: "Serve with the United Nations as an international or online volunteer. Assignments across 150+ countries in peace, development and humanitarian work.",
    highlight: true,
  },
  {
    name: "UN Internship Programme",
    org: "United Nations",
    url: "https://careers.un.org/lbw/home.aspx?viewtype=IP",
    category: "internship",
    location: "Global (NY, Geneva, Vienna, Nairobi)",
    tags: ["UN", "2-6 Months", "Students"],
    description: "Intern at UN headquarters and duty stations worldwide. Open to graduate and postgraduate students in international relations, law, economics and more.",
    highlight: true,
  },
  {
    name: "World Bank Internship",
    org: "World Bank Group",
    url: "https://www.worldbank.org/en/about/careers/programs-and-internships/internship",
    category: "internship",
    location: "Washington DC & Global",
    tags: ["Paid", "Summer/Winter", "Graduate"],
    description: "Paid internships at the World Bank for graduate students. Work on development projects in economics, finance, HR, IT, and more.",
    highlight: true,
  },
  {
    name: "UNICEF Internship",
    org: "UNICEF",
    url: "https://www.unicef.org/careers/internships",
    category: "internship",
    location: "Global",
    tags: ["Children's Rights", "Stipend", "6 Months Max"],
    description: "Support UNICEF's work for children worldwide. Internships in programme, communication, supply, finance and IT.",
  },
  {
    name: "European Commission Traineeships (Blue Book)",
    org: "European Union",
    url: "https://traineeships.ec.europa.eu",
    category: "internship",
    location: "Brussels, Luxembourg",
    tags: ["EU", "Paid (~1,400/month)", "5 Months"],
    description: "Prestigious paid traineeships at the European Commission. Two intakes per year (March and October). Open to recent graduates.",
    highlight: true,
  },
  {
    name: "AIESEC Global Volunteer",
    org: "AIESEC",
    url: "https://aiesec.org/global-volunteer",
    category: "volunteer",
    location: "126+ Countries",
    tags: ["Youth-Led", "6-8 Weeks", "SDGs"],
    description: "Short-term volunteering projects aligned with UN SDGs. Cross-cultural leadership experience for 18-30 year olds.",
  },
  {
    name: "Peace Corps",
    org: "US Government",
    url: "https://www.peacecorps.gov",
    category: "volunteer",
    location: "60+ Countries",
    tags: ["US Citizens", "27 Months", "Living Allowance"],
    description: "Serve abroad in education, health, agriculture, environment. Full support including training, housing, and student loan benefits.",
  },
  {
    name: "VSO (Voluntary Service Overseas)",
    org: "VSO International",
    url: "https://www.vsointernational.org/volunteering",
    category: "volunteer",
    location: "Africa & Asia",
    tags: ["Professional", "Expenses Paid", "Skilled"],
    description: "Professional volunteering placements for experienced individuals. Focus on education, health, and livelihoods in developing countries.",
  },
  {
    name: "ICRC Internships & Traineeships",
    org: "International Committee of the Red Cross",
    url: "https://careers.icrc.org/content/Internship/",
    category: "internship",
    location: "Geneva & Field",
    tags: ["Humanitarian", "Law", "3-12 Months"],
    description: "Intern with the ICRC in Geneva or field delegations. Focus on humanitarian law, protection, communication and operations.",
  },
  {
    name: "WHO Internship Programme",
    org: "World Health Organization",
    url: "https://www.who.int/careers/internships",
    category: "internship",
    location: "Geneva & Regional Offices",
    tags: ["Health", "Graduate Students", "6-24 Weeks"],
    description: "Gain experience in global health policy and programmes. Open to enrolled graduate students in public health, medicine, and related fields.",
  },
  {
    name: "Erasmus+ Youth Exchanges",
    org: "European Union",
    url: "https://erasmus-plus.ec.europa.eu/opportunities/opportunities-for-individuals/young-people",
    category: "exchange",
    location: "Europe & Partner Countries",
    tags: ["Funded", "Youth 13-30", "Cultural"],
    description: "Fully funded youth exchanges, volunteering (European Solidarity Corps), and training courses across Europe and partner countries.",
    highlight: true,
  },
  {
    name: "Fulbright Program",
    org: "US Department of State",
    url: "https://foreign.fulbrightonline.org",
    category: "exchange",
    location: "160+ Countries",
    tags: ["Fully Funded", "Research", "Teaching"],
    description: "Prestigious fully funded international exchange program for students, scholars, and professionals. Grants for study, research, and teaching.",
  },
  {
    name: "DAAD Scholarships & Internships",
    org: "German Academic Exchange Service",
    url: "https://www.daad.de/en/study-and-research-in-germany/",
    category: "exchange",
    location: "Germany",
    tags: ["Funded", "Study/Research", "All Levels"],
    description: "Study, research, and intern in Germany with DAAD funding. Programs for undergrads, graduates, and postdocs from all countries.",
  },
  {
    name: "Doctors Without Borders (MSF) Field Work",
    org: "MSF",
    url: "https://www.msf.org/work-msf",
    category: "volunteer",
    location: "70+ Countries",
    tags: ["Medical", "Professional", "Salaried"],
    description: "Join MSF field teams as a doctor, nurse, logistician, or administrator. Competitive salary and full support for experienced professionals.",
  },
  {
    name: "Workaway",
    org: "Workaway",
    url: "https://www.workaway.info",
    category: "volunteer",
    location: "170+ Countries",
    tags: ["Cultural Exchange", "Host Families", "Low Cost"],
    description: "Volunteer a few hours daily in exchange for accommodation and food. Teaching, farming, hostel work, and creative projects worldwide.",
  },
  {
    name: "WWOOF (World Wide Opportunities on Organic Farms)",
    org: "WWOOF",
    url: "https://wwoof.net",
    category: "volunteer",
    location: "130+ Countries",
    tags: ["Organic Farming", "Free Stay", "Learn Skills"],
    description: "Live and learn on organic farms worldwide. Work 4-6 hours daily in exchange for meals and accommodation. Great for gap years.",
  },
  {
    name: "Teach For All Network",
    org: "Teach For All",
    url: "https://teachforall.org",
    category: "fellowship",
    location: "60+ Countries",
    tags: ["Teaching", "2 Years", "Leadership"],
    description: "Join a two-year teaching fellowship to address educational inequity. Programs in 60+ countries including Teach First (UK), TFA (US).",
  },
  {
    name: "Atlas Corps Fellowship",
    org: "Atlas Corps",
    url: "https://atlascorps.org",
    category: "fellowship",
    location: "United States & Colombia",
    tags: ["Nonprofit", "12-18 Months", "J-1 Visa"],
    description: "Professional fellowship for social change leaders. Work at leading US nonprofits with full visa sponsorship and stipend.",
  },
  {
    name: "Ashoka Changemaker Fellowship",
    org: "Ashoka",
    url: "https://www.ashoka.org/en/program/ashoka-young-changemakers",
    category: "fellowship",
    location: "Global",
    tags: ["Social Innovation", "Lifetime", "Network"],
    description: "Join a global network of social entrepreneurs. Ashoka identifies and supports leading social innovators worldwide.",
  },
  {
    name: "OECD Internship Programme",
    org: "OECD",
    url: "https://www.oecd.org/careers/internship-programme/",
    category: "internship",
    location: "Paris, France",
    tags: ["Economics", "Policy", "Paid"],
    description: "Paid internships at the OECD in Paris. Work on economic policy, trade, education, environment and governance research.",
  },
];

export default function Internships() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = opportunities.filter((o) => {
    const matchesCat = activeCategory === "all" || o.category === activeCategory;
    const matchesSearch = !searchQuery ||
      o.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.org.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 mb-4">
          <Users className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-internships-title">
          Internships & Volunteering
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Gain international experience through internships at the UN, EU, World Bank, and top organizations.
          Volunteer worldwide and build your career while making a difference.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Building2 className="h-4 w-4" />
            <span>{opportunities.length} Opportunities</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>170+ Countries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Heart className="h-4 w-4" />
            <span>Paid & Volunteer</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search internships, organizations, or locations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-internships-search"
          />
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {categories.map((cat) => (
            <Button
              key={cat.id}
              variant={activeCategory === cat.id ? "secondary" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`button-internships-filter-${cat.id}`}
              className="toggle-elevate"
            >
              {cat.label}
            </Button>
          ))}
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} opportunit{filtered.length !== 1 ? "ies" : "y"}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((opp) => (
          <Card key={opp.name} className={`p-5 flex flex-col gap-3 hover-elevate ${opp.highlight ? "border-primary/30" : ""}`} data-testid={`card-internship-${opp.name.toLowerCase().replace(/[\s()]/g, "-").substring(0, 40)}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <h3 className="font-semibold text-sm leading-snug">{opp.name}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">{opp.org}</p>
              </div>
              {opp.highlight && (
                <Badge variant="secondary" className="shrink-0 text-[10px]">
                  <Sparkles className="h-3 w-3 mr-1" />
                  Featured
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed flex-1">{opp.description}</p>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" />
              <span>{opp.location}</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {opp.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-[10px] font-normal">
                  {tag}
                </Badge>
              ))}
            </div>
            <a href={opp.url} target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline" className="w-full" data-testid={`button-internship-visit-${opp.name.toLowerCase().replace(/[\s()]/g, "-").substring(0, 30)}`}>
                <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                Learn More
              </Button>
            </a>
          </Card>
        ))}
      </div>

      <Card className="mt-8 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center shrink-0">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">Getting Started</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Most UN and international organization internships require you to be enrolled in or recently graduated from a
              university program. Volunteering opportunities are often more flexible. Start with AIESEC or UNV for your first
              international experience, then apply to more competitive programs.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
