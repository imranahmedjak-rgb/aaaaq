import { useEffect } from "react";
import { useSearch, Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle2, Briefcase, ArrowRight } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function PaymentSuccess() {
  const searchParams = useSearch();
  const sessionId = new URLSearchParams(searchParams).get("session_id");

  const confirmMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/confirm-payment", { sessionId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs/featured"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs/stats"] });
    },
  });

  useEffect(() => {
    if (sessionId) {
      confirmMutation.mutate();
    }
  }, [sessionId]);

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <Card className="p-8 sm:p-12 text-center">
        <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />
        </div>
        <h1 className="text-2xl font-bold mb-3" data-testid="text-payment-success">
          Payment Successful!
        </h1>
        <p className="text-muted-foreground mb-2">
          Your job posting has been published on Dev Global Jobs.
        </p>
        <p className="text-sm text-muted-foreground mb-8">
          It is now visible to thousands of job seekers worldwide.
        </p>
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <Link href="/">
            <Button variant="outline" data-testid="button-go-home">
              <Briefcase className="h-4 w-4 mr-1.5" />
              Browse Jobs
            </Button>
          </Link>
          <Link href="/post-job">
            <Button data-testid="button-post-another">
              Post Another
              <ArrowRight className="h-4 w-4 ml-1.5" />
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  );
}
