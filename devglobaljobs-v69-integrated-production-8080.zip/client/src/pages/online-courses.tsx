import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  BookOpen, ExternalLink, Search, Monitor, Code, Palette,
  TrendingUp, Stethoscope, Calculator, Globe, GraduationCap,
  Sparkles, Users, Award, Clock, CheckCircle2,
} from "lucide-react";

const platformCategories = [
  { id: "all", label: "All Platforms" },
  { id: "mooc", label: "MOOC Platforms" },
  { id: "tech", label: "Tech & Coding" },
  { id: "business", label: "Business" },
  { id: "creative", label: "Creative & Design" },
  { id: "science", label: "Science & Data" },
  { id: "language", label: "Languages" },
];

const platforms = [
  {
    name: "Coursera",
    description: "Access 7,000+ courses from top universities including Stanford, Yale, and Google. Many courses offer free audit mode.",
    url: "https://www.coursera.org/courses?query=free",
    category: "mooc",
    tags: ["University Partners", "Certificates Available", "Financial Aid"],
    courses: "7,000+",
    icon: GraduationCap,
    highlight: true,
  },
  {
    name: "edX",
    description: "Free courses from Harvard, MIT, Berkeley and 160+ institutions. Earn MicroMasters and Professional Certificates.",
    url: "https://www.edx.org/search?tab=course",
    category: "mooc",
    tags: ["Harvard", "MIT", "MicroMasters"],
    courses: "4,000+",
    icon: GraduationCap,
    highlight: true,
  },
  {
    name: "Khan Academy",
    description: "Completely free education platform covering math, science, computing, economics, arts and humanities for all levels.",
    url: "https://www.khanacademy.org",
    category: "mooc",
    tags: ["100% Free", "K-12 to College", "Practice Exercises"],
    courses: "10,000+",
    icon: BookOpen,
    highlight: true,
  },
  {
    name: "MIT OpenCourseWare",
    description: "Free lecture notes, exams, and videos from MIT. Access virtually all MIT course content at no cost.",
    url: "https://ocw.mit.edu",
    category: "mooc",
    tags: ["100% Free", "MIT Quality", "Full Syllabi"],
    courses: "2,500+",
    icon: GraduationCap,
  },
  {
    name: "Stanford Online",
    description: "Free courses from Stanford University covering AI, machine learning, cryptography, and more.",
    url: "https://online.stanford.edu/free-courses",
    category: "mooc",
    tags: ["Stanford", "AI/ML", "Free Courses"],
    courses: "200+",
    icon: GraduationCap,
  },
  {
    name: "Harvard Online",
    description: "Free online courses from Harvard University across computer science, data science, business, health and humanities.",
    url: "https://pll.harvard.edu/catalog/free",
    category: "mooc",
    tags: ["Harvard", "CS50", "Free Certificates"],
    courses: "150+",
    icon: GraduationCap,
  },
  {
    name: "freeCodeCamp",
    description: "Learn to code for free. Full stack web development, data science, machine learning with hands-on projects and certifications.",
    url: "https://www.freecodecamp.org",
    category: "tech",
    tags: ["100% Free", "Certifications", "Projects"],
    courses: "3,000+ hrs",
    icon: Code,
  },
  {
    name: "The Odin Project",
    description: "Full stack curriculum: HTML, CSS, JavaScript, Ruby, NodeJS. Project-based learning with a supportive community.",
    url: "https://www.theodinproject.com",
    category: "tech",
    tags: ["100% Free", "Full Stack", "Open Source"],
    courses: "Full Curriculum",
    icon: Code,
  },
  {
    name: "Codecademy (Free Tier)",
    description: "Interactive coding lessons in Python, JavaScript, SQL, HTML/CSS and more. Free basic courses available.",
    url: "https://www.codecademy.com/catalog",
    category: "tech",
    tags: ["Interactive", "Beginner Friendly", "Multiple Languages"],
    courses: "200+ Free",
    icon: Code,
  },
  {
    name: "Google Digital Garage",
    description: "Free courses from Google on digital marketing, data analytics, career development, and AI fundamentals.",
    url: "https://learndigital.withgoogle.com/digitalgarage",
    category: "tech",
    tags: ["Google Certified", "Career Skills", "Free Certificates"],
    courses: "150+",
    icon: Monitor,
  },
  {
    name: "Microsoft Learn",
    description: "Free technical training on Azure, Microsoft 365, Power Platform, and developer tools with hands-on exercises.",
    url: "https://learn.microsoft.com/en-us/training/",
    category: "tech",
    tags: ["Microsoft", "Azure", "Free Certifications"],
    courses: "5,000+",
    icon: Monitor,
  },
  {
    name: "IBM SkillsBuild",
    description: "Free courses in AI, cybersecurity, data science, cloud computing and professional skills with digital credentials.",
    url: "https://skillsbuild.org",
    category: "tech",
    tags: ["IBM", "AI/Cyber", "Digital Credentials"],
    courses: "1,000+",
    icon: Monitor,
  },
  {
    name: "AWS Skill Builder (Free)",
    description: "Amazon Web Services free digital training on cloud computing, machine learning, security and more.",
    url: "https://explore.skillbuilder.aws/learn",
    category: "tech",
    tags: ["AWS", "Cloud", "Free Tier"],
    courses: "600+",
    icon: Monitor,
  },
  {
    name: "Udemy (Free Courses)",
    description: "Thousands of free courses across programming, business, design, marketing, photography and personal development.",
    url: "https://www.udemy.com/courses/free/",
    category: "mooc",
    tags: ["Free Selection", "Wide Range", "Self-Paced"],
    courses: "10,000+ Free",
    icon: BookOpen,
  },
  {
    name: "Alison",
    description: "Free online courses and diplomas in IT, health, business, languages and more with 30+ million learners worldwide.",
    url: "https://alison.com",
    category: "mooc",
    tags: ["Free Diplomas", "30M+ Learners", "Career Paths"],
    courses: "4,000+",
    icon: BookOpen,
  },
  {
    name: "FutureLearn",
    description: "Free short courses from top universities and institutions. Topics include healthcare, teaching, nature and technology.",
    url: "https://www.futurelearn.com/courses",
    category: "mooc",
    tags: ["UK Universities", "Short Courses", "Social Learning"],
    courses: "2,000+",
    icon: BookOpen,
  },
  {
    name: "Swayam (India Gov)",
    description: "India's national MOOC platform offering free courses from IITs, IIMs and top Indian universities across all disciplines.",
    url: "https://swayam.gov.in",
    category: "mooc",
    tags: ["Government", "IIT/IIM", "Credits Available"],
    courses: "3,000+",
    icon: Globe,
  },
  {
    name: "OpenLearn (Open University)",
    description: "Free courses from The Open University (UK) covering science, arts, business, technology, health and education.",
    url: "https://www.open.edu/openlearn/free-courses",
    category: "mooc",
    tags: ["Open University UK", "Statements", "All Levels"],
    courses: "1,000+",
    icon: GraduationCap,
  },
  {
    name: "HubSpot Academy",
    description: "Free courses and certifications in digital marketing, sales, customer service, content marketing and web design.",
    url: "https://academy.hubspot.com",
    category: "business",
    tags: ["Free Certs", "Marketing", "Industry Recognized"],
    courses: "500+",
    icon: TrendingUp,
  },
  {
    name: "Google Skillshop",
    description: "Free training on Google products: Google Ads, Analytics, Marketing Platform, and more with official certifications.",
    url: "https://skillshop.withgoogle.com",
    category: "business",
    tags: ["Google Certified", "Ads/Analytics", "Free"],
    courses: "100+",
    icon: TrendingUp,
  },
  {
    name: "Salesforce Trailhead",
    description: "Free gamified learning platform for Salesforce, business analysis, and tech skills with badges and superbadges.",
    url: "https://trailhead.salesforce.com",
    category: "business",
    tags: ["Salesforce", "Gamified", "Career Boost"],
    courses: "900+",
    icon: TrendingUp,
  },
  {
    name: "Canva Design School",
    description: "Free design courses covering graphic design, branding, social media design, presentations and photo editing.",
    url: "https://www.canva.com/designschool/",
    category: "creative",
    tags: ["Free", "Design Skills", "Practical"],
    courses: "100+",
    icon: Palette,
  },
  {
    name: "Drawspace",
    description: "Free and premium drawing and art lessons. Learn fundamentals of sketching, illustration and fine art techniques.",
    url: "https://www.drawspace.com",
    category: "creative",
    tags: ["Art", "Drawing", "Free Lessons"],
    courses: "200+",
    icon: Palette,
  },
  {
    name: "Kaggle Learn",
    description: "Free micro-courses in data science: Python, machine learning, deep learning, SQL, data visualization and AI.",
    url: "https://www.kaggle.com/learn",
    category: "science",
    tags: ["Data Science", "ML/AI", "Hands-on"],
    courses: "20+",
    icon: Calculator,
  },
  {
    name: "fast.ai",
    description: "Free practical deep learning courses making neural networks accessible. No PhD required, learn from world-class researchers.",
    url: "https://www.fast.ai",
    category: "science",
    tags: ["Deep Learning", "Free", "Practical"],
    courses: "7 Courses",
    icon: Calculator,
  },
  {
    name: "Duolingo",
    description: "Learn 40+ languages for free with gamified lessons. The world's most popular language learning app.",
    url: "https://www.duolingo.com",
    category: "language",
    tags: ["40+ Languages", "Gamified", "Free"],
    courses: "40+",
    icon: Globe,
  },
  {
    name: "Open Culture",
    description: "Curated collection of 1,700+ free online courses from top universities including audio books, textbooks and movies.",
    url: "https://www.openculture.com/freeonlinecourses",
    category: "mooc",
    tags: ["Curated", "University Courses", "Multimedia"],
    courses: "1,700+",
    icon: BookOpen,
  },
  {
    name: "Saylor Academy",
    description: "Free college-level courses with the option to earn college credit through partner institutions.",
    url: "https://www.saylor.org",
    category: "mooc",
    tags: ["College Credit", "Free", "Self-Paced"],
    courses: "100+",
    icon: GraduationCap,
  },
  {
    name: "Class Central",
    description: "Search engine for free online courses aggregating from Coursera, edX, FutureLearn, Udacity and 70+ providers.",
    url: "https://www.classcentral.com/collection/free-certificates",
    category: "mooc",
    tags: ["Aggregator", "Free Certs", "Reviews"],
    courses: "100,000+",
    icon: Search,
  },
  {
    name: "OpenStax (Rice University)",
    description: "Free, peer-reviewed textbooks for college and AP courses in math, science, social sciences, and humanities.",
    url: "https://openstax.org",
    category: "science",
    tags: ["Free Textbooks", "Peer-Reviewed", "Rice University"],
    courses: "50+ Books",
    icon: BookOpen,
  },
];

export default function OnlineCourses() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = platforms.filter((p) => {
    const matchesCat = activeCategory === "all" || p.category === activeCategory;
    const matchesSearch = !searchQuery ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 mb-4">
          <BookOpen className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-courses-title">
          Free Online Courses
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Access world-class education for free. Learn from Harvard, MIT, Stanford, Google, IBM and hundreds of top
          institutions. No fees, no barriers -- just quality education available to everyone worldwide.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Monitor className="h-4 w-4" />
            <span>{platforms.length} Platforms</span>
          </div>
          <div className="flex items-center gap-1.5">
            <BookOpen className="h-4 w-4" />
            <span>100,000+ Courses</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Award className="h-4 w-4" />
            <span>Free Certificates</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>Learn Anywhere</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search platforms, topics, or skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              data-testid="input-courses-search"
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {platformCategories.map((cat) => (
            <Button
              key={cat.id}
              variant={activeCategory === cat.id ? "secondary" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`button-courses-filter-${cat.id}`}
              className="toggle-elevate"
            >
              {cat.label}
            </Button>
          ))}
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} platform{filtered.length !== 1 ? "s" : ""}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((platform) => {
          const Icon = platform.icon;
          return (
            <Card
              key={platform.name}
              className={`p-5 flex flex-col gap-3 hover-elevate ${platform.highlight ? "border-primary/30" : ""}`}
              data-testid={`card-course-${platform.name.toLowerCase().replace(/[\s()]/g, "-")}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
                    <Icon className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">{platform.name}</h3>
                    <span className="text-xs text-muted-foreground">{platform.courses} courses</span>
                  </div>
                </div>
                {platform.highlight && (
                  <Badge variant="secondary" className="shrink-0 text-[10px]">
                    <Sparkles className="h-3 w-3 mr-1" />
                    Top Pick
                  </Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed flex-1">{platform.description}</p>
              <div className="flex flex-wrap gap-1.5">
                {platform.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="text-[10px] font-normal">
                    {tag}
                  </Badge>
                ))}
              </div>
              <a href={platform.url} target="_blank" rel="noopener noreferrer">
                <Button size="sm" variant="outline" className="w-full" data-testid={`button-visit-${platform.name.toLowerCase().replace(/[\s()]/g, "-")}`}>
                  <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                  Visit Platform
                </Button>
              </a>
            </Card>
          );
        })}
      </div>

      <Card className="mt-8 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center shrink-0">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">Why Free Online Courses?</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              These platforms are verified and trusted by millions of learners worldwide. Many offer free certificates,
              college credits, and industry-recognized credentials. Whether you're a student, job seeker, or career changer,
              these resources give you access to the same education that costs thousands elsewhere -- completely free.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
