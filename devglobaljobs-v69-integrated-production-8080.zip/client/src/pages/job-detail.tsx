import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import RelatedJobs from "@/components/RelatedJobs";
import MoreFromCompany from "@/components/MoreFromCompany";
import RecentlyViewed, { trackRecentlyViewed } from "@/components/RecentlyViewed";
import ShareJob from "@/components/ShareJob";
import SaveJobButton from "@/components/SaveJobButton";
import EasyApplyDialog from "@/components/EasyApplyDialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  MapPin,
  Building2,
  Clock,
  Briefcase,
  ExternalLink,
  ArrowLeft,
  Calendar,
  Globe,
  Mail,
  DollarSign,
  Shield,
  CheckCircle2,
  Share2,
  BookmarkPlus,
  Users,
  Eye,
  MousePointerClick,
  Flame,
  TrendingUp,
} from "lucide-react";
import type { Job } from "@shared/schema";
import { formatDistanceToNow, format } from "date-fns";
import { getJobEngagement } from "@/lib/engagement";
import { AdUnit } from "@/components/ad-unit";
import { useToast } from "@/hooks/use-toast";
import { formatJobDescription } from "@/lib/formatDescription";
import { useState, useEffect, useCallback } from "react";

const categoryColors: Record<string, string> = {
  un: "bg-blue-600 dark:bg-blue-500 text-white",
  ngo: "bg-emerald-600 dark:bg-emerald-500 text-white",
  remote: "bg-violet-600 dark:bg-violet-500 text-white",
  international: "bg-amber-600 dark:bg-amber-500 text-white",
};

const categoryLabels: Record<string, string> = {
  un: "UN",
  ngo: "NGO",
  remote: "Remote",
  international: "International",
};

function getOrgInitials(name: string): string {
  return name.split(/[\s&]+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase();
}

function getOrgColor(name: string): string {
  const colors = [
    "bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300",
    "bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300",
    "bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300",
    "bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300",
    "bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300",
    "bg-cyan-100 dark:bg-cyan-900/40 text-cyan-700 dark:text-cyan-300",
    "bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300",
    "bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300",
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

function getSavedJobs(): number[] {
  try {
    const saved = localStorage.getItem("devglobaljobs_saved");
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

function toggleSavedJob(jobId: number): boolean {
  const saved = getSavedJobs();
  const index = saved.indexOf(jobId);
  if (index > -1) {
    saved.splice(index, 1);
    localStorage.setItem("devglobaljobs_saved", JSON.stringify(saved));
    return false;
  } else {
    saved.push(jobId);
    localStorage.setItem("devglobaljobs_saved", JSON.stringify(saved));
    return true;
  }
}

export default function JobDetail() {
  const params = useParams<{ id: string }>();
  const { toast } = useToast();
  const [isSaved, setIsSaved] = useState(false);
  const { data: job, isLoading } = useQuery<Job>({
    queryKey: ["/api/jobs/detail", params.id],
  });

  useEffect(() => {
    if (params.id) {
      setIsSaved(getSavedJobs().includes(Number(params.id)));
    }
  }, [params.id]);

  useEffect(() => {
    if (job?.id) {
      fetch(`/api/jobs/${job.id}/view`, { method: "POST" }).catch(() => {});
      trackRecentlyViewed({
        id: job.id,
        title: job.title,
        organization: job.organization,
        location: job.location || "International",
      });
    }
  }, [job?.id]);

  const handleSave = useCallback(() => {
    if (!params.id) return;
    const jobId = Number(params.id);
    const nowSaved = toggleSavedJob(jobId);
    setIsSaved(nowSaved);
    toast({
      title: nowSaved ? "Job saved successfully" : "Job removed from saved",
      description: nowSaved
        ? "You can find your saved jobs anytime from your browser"
        : "This job has been removed from your saved list",
    });
  }, [params.id, toast]);

  const handleShare = () => {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: job?.title, url });
    } else {
      navigator.clipboard.writeText(url);
      toast({ title: "Link copied to clipboard" });
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Skeleton className="h-8 w-48 mb-6" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="space-y-4">
                <Skeleton className="h-8 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-1/3" />
                <div className="space-y-2 pt-4">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </div>
            </Card>
          </div>
          <div>
            <Card className="p-6">
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <Briefcase className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
        <h1 className="text-2xl font-bold mb-2">Job Not Found</h1>
        <p className="text-muted-foreground mb-6">
          This job may have been removed or is no longer available.
        </p>
        <Link href="/" data-testid="link-back-home">
          <Button data-testid="button-back-home">
            <ArrowLeft className="h-4 w-4 mr-1.5" />
            Back to Home
          </Button>
        </Link>
      </div>
    );
  }

  const postedTime = job.postedAt
    ? formatDistanceToNow(new Date(job.postedAt), { addSuffix: true })
    : "Recently";

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link href={`/jobs/${job.category}`}>
        <Button variant="ghost" size="sm" className="mb-6" data-testid="button-back">
          <ArrowLeft className="h-4 w-4 mr-1.5" />
          Back to {categoryLabels[job.category] || "Jobs"}
        </Button>
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Card className="p-6 sm:p-8">
            <div className="flex flex-col gap-5">
              <div className="flex items-center gap-2.5 flex-wrap">
                <Badge
                  className={`no-default-hover-elevate no-default-active-elevate ${categoryColors[job.category] || "bg-muted"}`}
                  data-testid="badge-detail-category"
                >
                  {categoryLabels[job.category] || job.category}
                </Badge>
                {job.isEmployerPosted && (
                  <Badge variant="outline" className="gap-1">
                    <CheckCircle2 className="h-3 w-3" />
                    Verified Employer
                  </Badge>
                )}
                {job.featured && (
                  <Badge variant="secondary">Featured</Badge>
                )}
              </div>

              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 rounded-md flex items-center justify-center shrink-0 text-base font-bold ${getOrgColor(job.organization)}`}>
                  {getOrgInitials(job.organization)}
                </div>
                <div>
                  <h1
                    className="text-xl sm:text-2xl font-bold leading-tight mb-2"
                    data-testid="text-detail-title"
                  >
                    {job.title}
                  </h1>
                  <p className="text-sm text-muted-foreground font-medium" data-testid="text-detail-org">{job.organization}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {job.location && (
                  <div className="flex items-center gap-2.5 text-sm">
                    <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center shrink-0">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span>{job.location}</span>
                  </div>
                )}
                {job.jobType && (
                  <div className="flex items-center gap-2.5 text-sm">
                    <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center shrink-0">
                      <Briefcase className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span>{job.jobType}</span>
                  </div>
                )}
                <div className="flex items-center gap-2.5 text-sm">
                  <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center shrink-0">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <span>Posted {postedTime}</span>
                </div>
                {job.salary && (
                  <div className="flex items-center gap-2.5 text-sm">
                    <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center shrink-0">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span>{job.salary}</span>
                  </div>
                )}
                {job.country && (
                  <div className="flex items-center gap-2.5 text-sm">
                    <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center shrink-0">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span>{job.country}</span>
                  </div>
                )}
                {job.closingDate && (
                  <div className="flex items-center gap-2.5 text-sm">
                    <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center shrink-0">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span>Closing: {format(new Date(job.closingDate), "MMM d, yyyy")}</span>
                  </div>
                )}
              </div>
            </div>
          </Card>

          <Card className="p-6 sm:p-8">
            <h2 className="font-semibold text-lg mb-4" data-testid="text-description-heading">Job Description</h2>
            {job.description ? (
              <div
                className="job-description-content prose prose-sm dark:prose-invert max-w-none text-foreground leading-relaxed"
                dangerouslySetInnerHTML={{ __html: formatJobDescription(job.description) }}
                data-testid="text-description-content"
                data-nosnippet
              />
            ) : (
              <p className="text-sm text-muted-foreground">
                Full job description is available on the employer's website.
                Click the apply button to view the complete details and submit your application.
              </p>
            )}
          </Card>

          <div className="flex gap-2 mt-2">
            <ShareJob title={job.title} jobId={job.id} />
            <SaveJobButton jobId={job.id} />
          </div>
          <RelatedJobs jobId={job.id} />
          <MoreFromCompany jobId={job.id} />
          <RecentlyViewed />
        </div>

        <div className="flex flex-col gap-4">
          <Card className="p-5">
            <h3 className="font-semibold text-sm mb-4">Apply Now - Instant & Free</h3>
            <div className="flex flex-col gap-3">
              {job.url && (
                <a href={job.url} target="_blank" rel="nofollow sponsored noopener noreferrer" className="w-full">
                  <Button className="w-full" data-testid="button-apply-external">
                    <ExternalLink className="h-4 w-4 mr-1.5" />
                    Apply on Employer Site
                  </Button>
                </a>
              )}
              <EasyApplyDialog
                job={{
                  id: job.id,
                  title: job.title,
                  organization: job.organization,
                  location: job.location,
                }}
                showUnavailableMessage={!job.url}
              />
            </div>

            <div className="border-t border-border mt-4 pt-4 flex gap-2">
              <Button variant="outline" size="sm" className="flex-1" onClick={handleShare} data-testid="button-share">
                <Share2 className="h-3.5 w-3.5 mr-1" />
                Share
              </Button>
              <Button variant="outline" size="sm" className={`flex-1 ${isSaved ? "toggle-elevate toggle-elevated" : ""}`} onClick={handleSave} data-testid="button-save">
                <BookmarkPlus className="h-3.5 w-3.5 mr-1" />
                {isSaved ? "Saved" : "Save"}
              </Button>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="font-semibold text-sm mb-4">Job Overview</h3>
            <div className="flex flex-col gap-3.5">
              <div className="flex items-center gap-3 text-sm">
                <div className="w-9 h-9 rounded-md bg-primary/10 dark:bg-primary/20 flex items-center justify-center shrink-0">
                  <Building2 className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Company</p>
                  <p className="text-sm font-medium">{job.organization}</p>
                </div>
              </div>
              {job.location && (
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-9 h-9 rounded-md bg-primary/10 dark:bg-primary/20 flex items-center justify-center shrink-0">
                    <MapPin className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Location</p>
                    <p className="text-sm font-medium">{job.location}</p>
                  </div>
                </div>
              )}
              {job.jobType && (
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-9 h-9 rounded-md bg-primary/10 dark:bg-primary/20 flex items-center justify-center shrink-0">
                    <Briefcase className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Job Type</p>
                    <p className="text-sm font-medium">{job.jobType}</p>
                  </div>
                </div>
              )}
              {job.salary && (
                <div className="flex items-center gap-3 text-sm">
                  <div className="w-9 h-9 rounded-md bg-primary/10 dark:bg-primary/20 flex items-center justify-center shrink-0">
                    <DollarSign className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Salary</p>
                    <p className="text-sm font-medium">{job.salary}</p>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3 text-sm">
                <div className="w-9 h-9 rounded-md bg-primary/10 dark:bg-primary/20 flex items-center justify-center shrink-0">
                  <Globe className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Source</p>
                  <p className="text-sm font-medium">{job.source}</p>
                </div>
              </div>
            </div>
          </Card>

          {(() => {
            const engagement = getJobEngagement(job.id, !!job.featured, job.postedAt);
            return (
              <Card className="p-5" data-testid="card-job-engagement">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  <h3 className="font-semibold text-sm">Job Performance</h3>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <Eye className="h-5 w-5 text-blue-500 mx-auto mb-1" />
                    <p className="text-lg font-bold" data-testid="text-job-views">{engagement.views.toLocaleString()}</p>
                    <p className="text-[10px] text-muted-foreground uppercase font-medium">Views</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <MousePointerClick className="h-5 w-5 text-emerald-500 mx-auto mb-1" />
                    <p className="text-lg font-bold" data-testid="text-job-applies">{engagement.applies.toLocaleString()}</p>
                    <p className="text-[10px] text-muted-foreground uppercase font-medium">Clicks</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <Share2 className="h-5 w-5 text-purple-500 mx-auto mb-1" />
                    <p className="text-lg font-bold" data-testid="text-job-shares">{engagement.shares.toLocaleString()}</p>
                    <p className="text-[10px] text-muted-foreground uppercase font-medium">Shares</p>
                  </div>
                </div>
                {engagement.views > 5000 && (
                  <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-border">
                    <Flame className="h-3.5 w-3.5 text-orange-500" />
                    <span className="text-xs font-semibold text-orange-600 dark:text-orange-400">Trending - High Interest</span>
                  </div>
                )}
              </Card>
            );
          })()}

          <Card className="p-5 bg-primary/5 dark:bg-primary/10 border-primary/20">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-4 w-4 text-primary" />
              <h3 className="font-semibold text-sm">Verified Listing</h3>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              This job was sourced from <span className="font-medium text-foreground">{job.source}</span>, a verified and trusted platform. Dev Global Jobs aggregates opportunities from 11+ verified international sources to ensure authenticity.
            </p>
            <div className="flex items-center gap-3 mt-3 pt-3 border-t border-border">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                <span>Source Verified</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Users className="h-3 w-3 text-blue-500" />
                <span>Auto-Updated</span>
              </div>
            </div>
          </Card>

          <AdUnit format="auto" className="mt-2" />
        </div>
      </div>
    </div>
  );
}
