import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Heart, ExternalLink, Search, Globe, Building2,
  Sparkles, MapPin, CheckCircle2, Clock, Shield,
  Users, Leaf, HandHeart,
} from "lucide-react";

const categories = [
  { id: "all", label: "All" },
  { id: "un", label: "UN Programs" },
  { id: "ngo", label: "NGO Programs" },
  { id: "peacecorps", label: "Peace Corps" },
  { id: "community", label: "Community Service" },
  { id: "environmental", label: "Environmental" },
  { id: "humanitarian", label: "Humanitarian" },
];

const programs = [
  {
    name: "UN Volunteers (UNV) - International",
    org: "United Nations",
    url: "https://www.unv.org",
    category: "un",
    location: "150+ Countries Worldwide",
    duration: "6-12 months",
    description: "Serve with the United Nations as an international volunteer across peace, development and humanitarian assignments in 150+ countries.",
    benefits: ["Living Allowance", "Accommodation", "Insurance", "Travel"],
    eligibility: "25+ years, Bachelor's degree, 2+ years experience",
    highlight: true,
  },
  {
    name: "UN Volunteers (UNV) - Online",
    org: "United Nations",
    url: "https://www.onlinevolunteering.org",
    category: "un",
    location: "Remote / Online",
    duration: "Flexible (part-time)",
    description: "Contribute to sustainable development from anywhere through online volunteering. Support UN agencies and civil society organizations remotely.",
    benefits: ["Flexible Schedule", "Certificate", "UN Experience", "Remote"],
    eligibility: "18+ years, Internet access, relevant skills",
    highlight: false,
  },
  {
    name: "Peace Corps",
    org: "US Government",
    url: "https://www.peacecorps.gov",
    category: "peacecorps",
    location: "60+ Countries",
    duration: "27 months",
    description: "Serve abroad in education, health, agriculture, and environment. Full support including pre-service training, housing, and student loan benefits for US citizens.",
    benefits: ["Living Allowance", "Housing", "Medical/Dental", "Student Loan Benefits"],
    eligibility: "US Citizens, 18+, Bachelor's degree preferred",
    highlight: true,
  },
  {
    name: "VSO (Voluntary Service Overseas)",
    org: "VSO International",
    url: "https://www.vsointernational.org/volunteering",
    category: "ngo",
    location: "Africa & Asia",
    duration: "6-24 months",
    description: "Professional volunteering placements for experienced individuals. Focus on education, health, and livelihoods in developing countries.",
    benefits: ["Expenses Paid", "Accommodation", "Insurance", "Training"],
    eligibility: "Professional experience, relevant skills, 18+",
    highlight: true,
  },
  {
    name: "AIESEC Global Volunteer",
    org: "AIESEC",
    url: "https://aiesec.org/global-volunteer",
    category: "community",
    location: "126+ Countries",
    duration: "6-8 weeks",
    description: "Short-term cross-cultural volunteering projects aligned with UN Sustainable Development Goals. Youth-led leadership experience worldwide.",
    benefits: ["Accommodation", "Cultural Immersion", "Leadership Training", "Certificate"],
    eligibility: "18-30 years, any nationality, passion for SDGs",
    highlight: false,
  },
  {
    name: "European Solidarity Corps",
    org: "European Union",
    url: "https://europa.eu/youth/solidarity_en",
    category: "community",
    location: "EU & Partner Countries",
    duration: "2-12 months",
    description: "EU-funded volunteering, traineeships and jobs for young people. Projects in communities across Europe covering social inclusion, environment, and culture.",
    benefits: ["Pocket Money", "Accommodation", "Food", "Travel", "Insurance"],
    eligibility: "18-30 years, EU/partner country residents",
    highlight: true,
  },
  {
    name: "Habitat for Humanity International",
    org: "Habitat for Humanity",
    url: "https://www.habitat.org/volunteer",
    category: "community",
    location: "70+ Countries",
    duration: "1-2 weeks minimum",
    description: "Build homes and communities alongside families in need. Global Village trips offer hands-on construction experience in developing countries.",
    benefits: ["Training", "Cultural Experience", "Certificate", "Team Building"],
    eligibility: "16+ years (18+ for international), no experience needed",
    highlight: false,
  },
  {
    name: "Red Cross / Red Crescent Volunteer",
    org: "International Federation of Red Cross",
    url: "https://www.ifrc.org/volunteering",
    category: "humanitarian",
    location: "192 Countries",
    duration: "Varies (ongoing)",
    description: "Join the world's largest humanitarian network. Respond to disasters, support health initiatives, and build community resilience across 192 countries.",
    benefits: ["Training", "Insurance", "Certificate", "Networking"],
    eligibility: "18+ years, commitment to humanitarian principles",
    highlight: true,
  },
  {
    name: "WWOOF (World Wide Opportunities on Organic Farms)",
    org: "WWOOF",
    url: "https://wwoof.net",
    category: "environmental",
    location: "130+ Countries",
    duration: "2 weeks minimum",
    description: "Live and learn on organic farms worldwide. Work 4-6 hours daily in exchange for meals and accommodation. Perfect for gap years and sustainable living enthusiasts.",
    benefits: ["Free Accommodation", "Meals Provided", "Farming Skills", "Cultural Exchange"],
    eligibility: "18+ years, physically fit, interest in organic farming",
    highlight: false,
  },
  {
    name: "Doctors Without Borders (MSF) Field Support",
    org: "MSF",
    url: "https://www.msf.org/work-msf",
    category: "humanitarian",
    location: "70+ Countries",
    duration: "6-12 months",
    description: "Support MSF field operations as a logistician, administrator, or non-medical professional. Critical humanitarian work in conflict zones and crisis areas.",
    benefits: ["Salary", "Accommodation", "Insurance", "Travel", "Per Diem"],
    eligibility: "2+ years professional experience, language skills, availability",
    highlight: true,
  },
  {
    name: "UNICEF Volunteer Programs",
    org: "UNICEF",
    url: "https://www.unicef.org/get-involved/volunteer",
    category: "un",
    location: "190+ Countries",
    duration: "Varies",
    description: "Support UNICEF's mission for children worldwide. Volunteer in advocacy, fundraising, emergency response, and community-based programs.",
    benefits: ["Training", "Certificate", "UN Network", "Impact"],
    eligibility: "18+ years, passion for children's rights",
    highlight: false,
  },
  {
    name: "World Food Programme Volunteers",
    org: "World Food Programme (WFP)",
    url: "https://www.wfp.org/careers/volunteers",
    category: "un",
    location: "80+ Countries",
    duration: "6-12 months",
    description: "Join WFP in the fight against global hunger. Volunteer in logistics, nutrition, emergency preparedness, and food distribution programs.",
    benefits: ["Living Allowance", "Accommodation", "Insurance", "Travel"],
    eligibility: "25+ years, Bachelor's degree, relevant experience",
    highlight: true,
  },
  {
    name: "International Committee of the Red Cross",
    org: "ICRC",
    url: "https://www.icrc.org/en/careers",
    category: "humanitarian",
    location: "80+ Countries",
    duration: "12-24 months",
    description: "Work with ICRC in armed conflict and violence situations. Protect lives, ensure respect for international humanitarian law, and deliver assistance.",
    benefits: ["Competitive Salary", "Accommodation", "R&R Leave", "Insurance"],
    eligibility: "Minimum 2 years experience, language skills, degree",
    highlight: false,
  },
  {
    name: "Amnesty International Volunteer",
    org: "Amnesty International",
    url: "https://www.amnesty.org/en/get-involved/volunteer/",
    category: "ngo",
    location: "Global (Local Chapters)",
    duration: "Ongoing (flexible)",
    description: "Campaign for human rights worldwide. Volunteer in research, advocacy, letter-writing campaigns, and community organizing through local and international programs.",
    benefits: ["Training", "Advocacy Skills", "Network", "Certificate"],
    eligibility: "16+ years, commitment to human rights",
    highlight: false,
  },
  {
    name: "Greenpeace Volunteer",
    org: "Greenpeace",
    url: "https://www.greenpeace.org/international/act/volunteer/",
    category: "environmental",
    location: "40+ Countries",
    duration: "Ongoing (flexible)",
    description: "Protect the environment through direct action, campaigning, and community mobilization. Join ship expeditions, office volunteering, or local activism.",
    benefits: ["Training", "Campaign Skills", "Network", "Ship Experience"],
    eligibility: "18+ years, environmental commitment, physically fit for field roles",
    highlight: false,
  },
  {
    name: "Conservation Volunteers International",
    org: "Conservation Volunteers",
    url: "https://conservationvolunteers.com.au",
    category: "environmental",
    location: "Australia, Asia Pacific",
    duration: "1-6 weeks",
    description: "Hands-on conservation projects including tree planting, wildlife surveys, habitat restoration, and seed collection across Australia and partner countries.",
    benefits: ["Accommodation", "Meals", "Training", "Conservation Skills"],
    eligibility: "18+ years, physically fit, interest in conservation",
    highlight: false,
  },
  {
    name: "Teaching Abroad - WorldTeach",
    org: "WorldTeach",
    url: "https://www.worldteach.org",
    category: "community",
    location: "Developing Countries",
    duration: "Summer (6 weeks) or Year-Long",
    description: "Teach in underserved communities worldwide. Programs in Pacific Islands, Africa, Asia, and Latin America. No prior teaching experience required.",
    benefits: ["Housing", "Training", "Stipend", "Certificate"],
    eligibility: "18+ years, Bachelor's degree, English proficiency",
    highlight: false,
  },
  {
    name: "Camp Counselor Programs (CCUSA)",
    org: "CCUSA",
    url: "https://www.ccusa.com",
    category: "community",
    location: "United States",
    duration: "9-12 weeks (Summer)",
    description: "Work as a camp counselor at American summer camps. Lead activities, mentor youth, and experience American culture during summer months.",
    benefits: ["Salary", "Accommodation", "Meals", "Visa Sponsorship", "Travel"],
    eligibility: "18-30 years, English proficiency, J-1 visa eligible",
    highlight: false,
  },
  {
    name: "Workaway",
    org: "Workaway",
    url: "https://www.workaway.info",
    category: "community",
    location: "170+ Countries",
    duration: "2 weeks minimum",
    description: "Volunteer a few hours daily in exchange for accommodation and food. Teaching, farming, hostel work, childcare, and creative projects with host families worldwide.",
    benefits: ["Free Accommodation", "Meals", "Cultural Exchange", "Skill Development"],
    eligibility: "18+ years, any nationality, basic communication skills",
    highlight: false,
  },
  {
    name: "SCI (Service Civil International)",
    org: "SCI",
    url: "https://sci.ngo",
    category: "ngo",
    location: "90+ Countries",
    duration: "2-3 weeks (workcamps)",
    description: "International voluntary service promoting peace, sustainable development, and intercultural understanding through workcamps, long-term volunteering, and exchanges.",
    benefits: ["Accommodation", "Meals", "Certificate", "Cultural Exchange"],
    eligibility: "18+ years (16+ for some), any nationality",
    highlight: false,
  },
  {
    name: "Projects Abroad",
    org: "Projects Abroad",
    url: "https://www.projects-abroad.org",
    category: "ngo",
    location: "30+ Countries",
    duration: "1 week minimum",
    description: "Structured volunteer and internship programs in conservation, teaching, medicine, journalism, and community development for students and professionals.",
    benefits: ["Accommodation", "Meals", "Airport Pickup", "24/7 Support", "Training"],
    eligibility: "15+ years, no experience needed, all nationalities",
    highlight: true,
  },
  {
    name: "HelpX",
    org: "HelpX",
    url: "https://www.helpx.net",
    category: "community",
    location: "140+ Countries",
    duration: "Flexible (2+ weeks)",
    description: "Exchange a few hours of help per day for free accommodation and meals. Hosts include farms, homestays, ranches, lodges, and sailing boats worldwide.",
    benefits: ["Free Accommodation", "Meals", "Skill Learning", "Travel Savings"],
    eligibility: "18+ years, any nationality, willingness to work",
    highlight: false,
  },
];

export default function Volunteers() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = programs.filter((p) => {
    const matchesCat = activeCategory === "all" || p.category === activeCategory;
    const matchesSearch = !searchQuery ||
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.org.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.benefits.some((b) => b.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 overflow-x-hidden">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://devglobaljobs.com/" },
              { "@type": "ListItem", position: 2, name: "Volunteers", item: "https://devglobaljobs.com/volunteers" },
            ],
          }),
        }}
      />

      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-rose-500 to-pink-600 mb-4">
          <HandHeart className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" data-testid="text-volunteers-title">
          International Volunteer Programs
        </h1>
        <p className="text-sm text-muted-foreground max-w-2xl mx-auto mb-4">
          Make a difference globally through meaningful volunteer opportunities. Join programs from the UN, NGOs,
          and community organizations across 170+ countries for students and professionals.
        </p>
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-sm text-muted-foreground flex-wrap">
          <div className="flex items-center gap-1.5">
            <Users className="h-4 w-4" />
            <span>{programs.length} Programs</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Globe className="h-4 w-4" />
            <span>170+ Countries</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Heart className="h-4 w-4" />
            <span>Paid & Volunteer</span>
          </div>
        </div>
      </div>

      <Card className="p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search volunteer programs, organizations, or locations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-volunteers-search"
          />
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {categories.map((cat) => (
            <Button
              key={cat.id}
              variant={activeCategory === cat.id ? "secondary" : "outline"}
              size="sm"
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`button-volunteers-filter-${cat.id}`}
              className="toggle-elevate"
            >
              {cat.label}
            </Button>
          ))}
        </div>
      </Card>

      <div className="mb-4 text-sm text-muted-foreground">
        Showing {filtered.length} program{filtered.length !== 1 ? "s" : ""}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((prog) => (
          <Card
            key={prog.name}
            className={`p-5 flex flex-col gap-3 hover-elevate ${prog.highlight ? "border-primary/30" : ""}`}
            data-testid={`card-volunteer-${prog.name.toLowerCase().replace(/[\s()\/]/g, "-").substring(0, 40)}`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <h3 className="font-semibold text-sm leading-snug">{prog.name}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">{prog.org}</p>
              </div>
              <Badge variant="secondary" className="shrink-0 text-[10px]">
                {categories.find((c) => c.id === prog.category)?.label || prog.category}
              </Badge>
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed flex-1">{prog.description}</p>

            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3 shrink-0" />
              <span>{prog.location}</span>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="h-3 w-3 shrink-0" />
              <span>{prog.duration}</span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {prog.benefits.map((benefit) => (
                <Badge key={benefit} variant="outline" className="text-[10px] font-normal">
                  {benefit}
                </Badge>
              ))}
            </div>

            <div className="flex items-start gap-1.5 text-xs text-muted-foreground">
              <Shield className="h-3 w-3 shrink-0 mt-0.5" />
              <span>{prog.eligibility}</span>
            </div>

            <a href={prog.url} target="_blank" rel="noopener noreferrer">
              <Button
                size="sm"
                variant="outline"
                className="w-full"
                data-testid={`button-volunteer-apply-${prog.name.toLowerCase().replace(/[\s()\/]/g, "-").substring(0, 30)}`}
              >
                <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                Apply
              </Button>
            </a>
          </Card>
        ))}
      </div>

      <Card className="mt-8 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-lg bg-rose-500/10 flex items-center justify-center shrink-0">
            <CheckCircle2 className="h-5 w-5 text-rose-600" />
          </div>
          <div>
            <h3 className="font-semibold mb-1">Getting Started with Volunteering</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Start with short-term programs like AIESEC, Workaway, or WWOOF to gain international experience.
              For professional placements, consider UN Volunteers or VSO which offer living allowances and structured support.
              Peace Corps is ideal for US citizens seeking immersive long-term service. Always research visa requirements
              and health precautions before applying.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
