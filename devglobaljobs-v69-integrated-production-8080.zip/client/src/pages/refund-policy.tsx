import { Shield, AlertCircle, CreditCard, Clock, FileText, Mail } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";

export default function RefundPolicy() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Refund Policy</h1>
              <p className="text-sm text-muted-foreground mt-0.5">Dev Global Jobs — Operated by Trend Nova World Limited</p>
            </div>
          </div>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Last updated: January 1, 2025 &nbsp;·&nbsp; Effective for all purchases made on or after this date.
          </p>
        </div>

        <div className="space-y-8 text-sm leading-relaxed">

          <Card className="p-5 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
              <div>
                <h2 className="font-semibold text-amber-900 dark:text-amber-200 mb-1">No-Refund Policy</h2>
                <p className="text-amber-800 dark:text-amber-300 text-sm leading-relaxed">
                  All purchases made on Dev Global Jobs — including job postings, featured listings, and any promotional packages — are <strong>final and non-refundable</strong>. By completing a purchase, you acknowledge and agree to this policy.
                </p>
              </div>
            </div>
          </Card>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <CreditCard className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">1. Scope of This Policy</h2>
            </div>
            <p className="text-muted-foreground mb-3">
              This Refund Policy applies to all services and products offered by Dev Global Jobs (operated by Trend Nova World Limited, a company registered in England and Wales). This includes, but is not limited to:
            </p>
            <ul className="list-disc pl-5 space-y-1.5 text-muted-foreground">
              <li><strong className="text-foreground">Regular Job Listings</strong> — 30-day active job postings</li>
              <li><strong className="text-foreground">Featured Job Listings</strong> — 45-day priority-highlighted job postings</li>
              <li><strong className="text-foreground">Bulk Posting Packages</strong> — custom multi-listing arrangements</li>
              <li>Any promotional or discounted packages offered from time to time</li>
            </ul>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <Clock className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">2. Why All Sales Are Final</h2>
            </div>
            <p className="text-muted-foreground mb-3">
              Job listing services are delivered immediately upon payment confirmation. Once a listing is activated and published on the platform — making it visible to our global audience of job seekers — the service has been rendered in full. Because the advertising value is delivered the moment a listing goes live, we are unable to offer refunds, credits, or exchanges under any circumstances, including:
            </p>
            <ul className="list-disc pl-5 space-y-1.5 text-muted-foreground">
              <li>Change of mind after purchase</li>
              <li>Failure to receive applications or qualified candidates</li>
              <li>Position filled before the listing expires</li>
              <li>Errors in the job listing submitted by the employer</li>
              <li>Duplicate purchases made in error</li>
              <li>Dissatisfaction with the number of views or applications received</li>
            </ul>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <FileText className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">3. Listing Modifications</h2>
            </div>
            <p className="text-muted-foreground">
              While we do not offer refunds, employers may request reasonable modifications to an active listing — such as corrections to job title, description, or contact details — by contacting our team at{" "}
              <a href="mailto:info@devglobaljobs.com" className="text-primary hover:underline">info@devglobaljobs.com</a>{" "}
              within 48 hours of purchase. Modifications are granted at the sole discretion of Dev Global Jobs and do not constitute a right to a refund.
            </p>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">4. Fraudulent or Rejected Listings</h2>
            </div>
            <p className="text-muted-foreground">
              Dev Global Jobs reserves the right to remove any listing that violates our{" "}
              <Link href="/terms" className="text-primary hover:underline">Terms of Service</Link>, contains fraudulent information, or is deemed inappropriate at our discretion. In such cases, no refund will be issued, as payment represents agreement to our terms and the listing review process.
            </p>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <Clock className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">5. Technical Issues</h2>
            </div>
            <p className="text-muted-foreground">
              In the exceptional event that a verified technical error on our platform prevents your listing from being published (e.g., payment confirmed but listing not activated), please contact us within 7 days. We will investigate and, if the error is confirmed on our end, either activate the listing or provide a service credit — not a cash refund.
            </p>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">6. Payment Processing</h2>
            </div>
            <p className="text-muted-foreground">
              Payments are currently processed via <strong>Wise bank transfer</strong> to Trend Nova World Limited. As transfers are manual and reviewed before listing activation, please allow up to 24 business hours for your listing to go live after payment confirmation. Contact us if your listing has not been activated within this period.
            </p>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">7. Governing Law</h2>
            </div>
            <p className="text-muted-foreground">
              This Refund Policy is governed by the laws of England and Wales. Any disputes arising from or relating to this policy shall be subject to the exclusive jurisdiction of the courts of England and Wales.
            </p>
          </section>

          <section>
            <div className="flex items-center gap-2 mb-3">
              <Mail className="h-4 w-4 text-primary" />
              <h2 className="text-base font-semibold">8. Contact Us</h2>
            </div>
            <p className="text-muted-foreground mb-3">
              If you have any questions about this policy or believe you have encountered a qualifying technical issue, please reach out to us:
            </p>
            <Card className="p-4 bg-muted/30">
              <div className="space-y-1.5 text-sm">
                <p><strong>Company:</strong> Trend Nova World Limited</p>
                <p><strong>Registered Address:</strong> 27 Old Gloucester Street, London, WC1N 3AX, United Kingdom</p>
                <p><strong>Email:</strong>{" "}
                  <a href="mailto:info@devglobaljobs.com" className="text-primary hover:underline">
                    info@devglobaljobs.com
                  </a>
                </p>
                <p><strong>Response Time:</strong> Within 2–3 business days</p>
              </div>
            </Card>
          </section>

          <div className="border-t border-border pt-6">
            <p className="text-xs text-muted-foreground">
              By making a purchase on Dev Global Jobs, you confirm that you have read, understood, and agreed to this No-Refund Policy. This policy forms part of our{" "}
              <Link href="/terms" className="text-primary hover:underline">Terms of Service</Link>{" "}
              and{" "}
              <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
