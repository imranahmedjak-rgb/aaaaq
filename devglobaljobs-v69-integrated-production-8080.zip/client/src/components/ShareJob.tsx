interface ShareJobProps {
  title: string;
  jobId: number;
}

export function ShareJob({ title, jobId }: ShareJobProps) {
  const url = `https://devglobaljobs.com/?jobId=${jobId}`;
  const text = encodeURIComponent(`Check out this job: ${title}`);
  const encodedUrl = encodeURIComponent(url);

  // All external share links use rel="nofollow sponsored noopener noreferrer"
  // to prevent passing PageRank to external/sponsored share targets
  const shares = [
    {
      label: "Twitter",
      href: `https://twitter.com/intent/tweet?text=${text}&url=${encodedUrl}`,
      rel: "nofollow sponsored noopener noreferrer",
    },
    {
      label: "LinkedIn",
      href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
      rel: "nofollow sponsored noopener noreferrer",
    },
    {
      label: "WhatsApp",
      href: `https://wa.me/?text=${text}%20${encodedUrl}`,
      rel: "nofollow sponsored noopener noreferrer",
    },
    {
      label: "Facebook",
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      rel: "nofollow sponsored noopener noreferrer",
    },
  ];

  return (
    <div className="flex flex-wrap gap-2 mt-4">
      <span className="text-sm font-medium text-gray-600 self-center">Share:</span>
      {shares.map((s) => (
        <a
          key={s.label}
          href={s.href}
          rel={s.rel}
          target="_blank"
          className="text-xs px-3 py-1 border rounded hover:bg-gray-100 transition"
        >
          {s.label}
        </a>
      ))}
    </div>
  );
}

export default ShareJob;
