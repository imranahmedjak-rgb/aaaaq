import { useState, useRef, useEffect } from "react";
import { Globe, ChevronDown, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n, LANGUAGES, type Language } from "@/lib/i18n";

export function LanguageSwitcher() {
  const { lang, setLang } = useI18n();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const current = LANGUAGES.find(l => l.code === lang) || LANGUAGES[0];

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  function handleSelect(code: Language) {
    setLang(code);
    setOpen(false);
  }

  return (
    <div ref={ref} className="relative">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-2"
        aria-label="Select language"
        data-testid="button-language-switcher"
      >
        <Globe className="h-3.5 w-3.5" />
        <span className="hidden md:inline text-xs font-medium">{current.nativeLabel}</span>
        <ChevronDown className="h-3 w-3" />
      </Button>

      {open && (
        <div className="absolute top-full right-0 mt-1 w-44 bg-popover border border-border rounded-md shadow-lg py-1 z-[1000]">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-3 py-1.5">
            Language / 语言 / Idioma
          </p>
          {LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => handleSelect(l.code)}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-sm hover:bg-accent transition-colors"
              data-testid={`lang-option-${l.code}`}
            >
              <img
                src={`https://flagcdn.com/16x12/${l.flag}.png`}
                alt={l.label}
                className="w-4 h-3 rounded-sm object-cover"
                loading="lazy"
              />
              <span className="flex-1 text-left text-xs">{l.nativeLabel}</span>
              <span className="text-[10px] text-muted-foreground">{l.label}</span>
              {lang === l.code && <Check className="h-3 w-3 text-primary shrink-0" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
