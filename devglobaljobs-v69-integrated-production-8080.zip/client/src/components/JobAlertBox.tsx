import { useState } from "react";

interface JobAlertBoxProps {
  defaultKeywords?: string;
  defaultLocation?: string;
  category?: string;
  country?: string;
}

export function JobAlertBox({ defaultKeywords = "", defaultLocation = "", category = "", country = "" }: JobAlertBoxProps) {
  const [email, setEmail] = useState("");
  const [keywords, setKeywords] = useState(defaultKeywords || category);
  const [location, setLocation] = useState(defaultLocation || country);
  const [frequency, setFrequency] = useState("daily");
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/job-alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, keywords, location, frequency }),
      });
      if (res.ok) {
        setStatus("success");
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    } finally {
      setLoading(false);
    }
  }

  if (status === "success") {
    return (
      <div className="bg-green-50 border border-green-200 rounded p-4 text-center">
        <p className="text-green-800 font-medium">Job alert created!</p>
        <p className="text-sm text-green-600 mt-1">We'll notify you at <strong>{email}</strong> when matching jobs are posted.</p>
      </div>
    );
  }

  return (
    <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
      <h3 className="text-base font-semibold mb-3 text-blue-900">Get Job Alerts</h3>
      <form onSubmit={handleSubmit} className="space-y-2">
        <input
          type="email"
          placeholder="Your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full px-3 py-2 border rounded text-sm"
        />
        <input
          type="text"
          placeholder="Keywords (e.g. React Developer)"
          value={keywords}
          onChange={(e) => setKeywords(e.target.value)}
          className="w-full px-3 py-2 border rounded text-sm"
        />
        <input
          type="text"
          placeholder="Location (optional)"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="w-full px-3 py-2 border rounded text-sm"
        />
        <select
          value={frequency}
          onChange={(e) => setFrequency(e.target.value)}
          className="w-full px-3 py-2 border rounded text-sm"
        >
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="instant">Instant</option>
        </select>
        {status === "error" && <p className="text-red-600 text-xs">Something went wrong. Please try again.</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 rounded text-sm hover:bg-blue-700 transition"
        >
          {loading ? "Creating..." : "Create Alert"}
        </button>
      </form>
    </div>
  );
}

export default JobAlertBox;
