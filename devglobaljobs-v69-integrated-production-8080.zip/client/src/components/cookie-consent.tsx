import { useState, useEffect } from "react";
import { X, Cookie, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useI18n } from "@/lib/i18n";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const { t } = useI18n();

  useEffect(() => {
    const consent = localStorage.getItem("dgj_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 500);
      return () => clearTimeout(timer);
    }
  }, []);

  function accept() {
    localStorage.setItem("dgj_cookie_consent", "accepted");
    setVisible(false);
  }

  function decline() {
    localStorage.setItem("dgj_cookie_consent", "declined");
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-[9999] p-4 md:p-6 animate-in slide-in-from-bottom-4 duration-500"
      role="dialog"
      aria-label="Cookie consent"
    >
      <div className="max-w-4xl mx-auto bg-background border border-border rounded-xl shadow-2xl p-4 md:p-5">
        <div className="flex items-start gap-4">
          <div className="shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mt-0.5">
            <Cookie className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-sm">Cookie Notice</h3>
              <div className="flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                <Shield className="h-3 w-3" />
                GDPR Compliant
              </div>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {t.cookie.message}
            </p>
            <div className="flex flex-wrap gap-1.5 mt-1">
              <Link href="/privacy" className="text-xs text-primary hover:underline">
                {t.common.privacyPolicy}
              </Link>
              <span className="text-xs text-muted-foreground">·</span>
              <Link href="/privacy" className="text-xs text-primary hover:underline">
                {t.cookie.learnMore}
              </Link>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0 mt-0.5">
            <Button
              size="sm"
              variant="outline"
              onClick={decline}
              className="text-xs h-8 px-3"
            >
              {t.cookie.decline}
            </Button>
            <Button
              size="sm"
              onClick={accept}
              className="text-xs h-8 px-3"
            >
              {t.cookie.accept}
            </Button>
            <button
              onClick={decline}
              className="text-muted-foreground hover:text-foreground transition-colors ml-1"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
