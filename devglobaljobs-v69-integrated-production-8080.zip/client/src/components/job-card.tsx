import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Building2, Clock, Briefcase, ArrowUpRight, DollarSign, Globe, Eye, MousePointerClick, Flame, Zap, Share2 } from "lucide-react";
import type { Job } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { getJobEngagement } from "@/lib/engagement";

const categoryColors: Record<string, string> = {
  un: "bg-blue-600 dark:bg-blue-500 text-white",
  ngo: "bg-emerald-600 dark:bg-emerald-500 text-white",
  remote: "bg-violet-600 dark:bg-violet-500 text-white",
  international: "bg-amber-600 dark:bg-amber-500 text-white",
};

const categoryLabels: Record<string, string> = {
  un: "UN",
  ngo: "NGO",
  remote: "Remote",
  international: "International",
};

function getOrgInitials(name: string): string {
  return name.split(/[\s&]+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase();
}

function getOrgColor(name: string): string {
  const colors = [
    "bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300",
    "bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300",
    "bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300",
    "bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300",
    "bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300",
    "bg-cyan-100 dark:bg-cyan-900/40 text-cyan-700 dark:text-cyan-300",
    "bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300",
    "bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300",
  ];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}


function isJobNew(postedAt: Date | string | null): boolean {
  if (!postedAt) return false;
  const date = new Date(postedAt);
  const now = new Date();
  const hoursAgo = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
  return hoursAgo <= 24;
}

export function JobCard({ job, isFeatured }: { job: Job; isFeatured?: boolean }) {
  const postedTime = job.postedAt
    ? formatDistanceToNow(new Date(job.postedAt), { addSuffix: true })
    : "Recently";

  const isNew = isJobNew(job.postedAt);
  const { views, applies, shares } = getJobEngagement(job.id, isFeatured ?? job.featured ?? false, job.postedAt);
  const isTrending = views > 500;

  return (
    <Link href={`/jobs/detail/${job.id}`}>
      <Card
        className="p-5 hover-elevate active-elevate-2 cursor-pointer transition-all duration-200 group h-full relative"
        data-testid={`card-job-${job.id}`}
      >
        <div className="flex flex-col gap-3 h-full">
          <div className="flex items-start gap-3">
            <div className={`w-11 h-11 rounded-lg flex items-center justify-center shrink-0 text-xs font-extrabold ${getOrgColor(job.organization)}`}>
              {getOrgInitials(job.organization)}
            </div>
            <div className="flex-1 min-w-0">
              <h3
                className="font-bold text-sm leading-snug line-clamp-2 group-hover:text-primary transition-colors"
                data-testid={`text-job-title-${job.id}`}
              >
                {job.title}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5 truncate font-medium" data-testid={`text-org-${job.id}`}>
                {job.organization}
              </p>
            </div>
            <div className="flex flex-col gap-1 items-end shrink-0">
              {isNew && (
                <Badge
                  className="shrink-0 text-[10px] bg-blue-600 dark:bg-blue-500 text-white no-default-hover-elevate no-default-active-elevate"
                  data-testid={`badge-new-${job.id}`}
                >
                  <Zap className="h-2.5 w-2.5 mr-1" />
                  New
                </Badge>
              )}
              {isTrending && (
                <Badge
                  className="shrink-0 text-[10px] bg-orange-600 dark:bg-orange-500 text-white no-default-hover-elevate no-default-active-elevate"
                  data-testid={`badge-trending-${job.id}`}
                >
                  <Flame className="h-2.5 w-2.5 mr-1" />
                  Trending
                </Badge>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-1.5 flex-1">
            {job.location && (
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <MapPin className="h-3.5 w-3.5 shrink-0" />
                <span className="text-xs truncate">{job.location}</span>
              </div>
            )}
            <div className="flex items-center gap-3 flex-wrap">
              {job.jobType && (
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Briefcase className="h-3.5 w-3.5 shrink-0" />
                  <span className="text-xs">{job.jobType}</span>
                </div>
              )}
              {job.salary && (
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <DollarSign className="h-3.5 w-3.5 shrink-0" />
                  <span className="text-xs truncate max-w-[120px]">{job.salary}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 pt-3 border-t border-border">
            <div className="flex items-center gap-2 min-w-0">
              <Badge
                className={`shrink-0 text-[10px] no-default-hover-elevate no-default-active-elevate ${categoryColors[job.category] || "bg-muted text-muted-foreground"}`}
                data-testid={`badge-category-${job.id}`}
              >
                {categoryLabels[job.category] || job.category}
              </Badge>
              <div className="flex items-center gap-1 text-muted-foreground min-w-0">
                <Clock className="h-3 w-3 shrink-0" />
                <span className="text-[11px] truncate">{postedTime}</span>
              </div>
            </div>
            <ArrowUpRight className="h-4 w-4 text-muted-foreground shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>

          <div className="flex items-center gap-4 pt-2 px-0 flex-wrap">
            <div className="flex items-center gap-1.5 text-muted-foreground text-[11px]" data-testid={`stat-views-${job.id}`}>
              <Eye className="h-3.5 w-3.5 shrink-0" />
              <span>{views.toLocaleString()} views</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground text-[11px]" data-testid={`stat-applies-${job.id}`}>
              <MousePointerClick className="h-3.5 w-3.5 shrink-0" />
              <span>{applies.toLocaleString()} clicks</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground text-[11px]" data-testid={`stat-shares-${job.id}`}>
              <Share2 className="h-3.5 w-3.5 shrink-0" />
              <span>{shares.toLocaleString()} shares</span>
            </div>
          </div>

          {job.source && (
            <div className="text-[10px] text-muted-foreground pt-1" data-testid={`text-source-${job.id}`}>
              via {job.source}
            </div>
          )}
        </div>
      </Card>
    </Link>
  );
}

export function JobCardSkeleton() {
  return (
    <Card className="p-5">
      <div className="flex flex-col gap-3 animate-pulse">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 bg-muted rounded-lg shrink-0" />
          <div className="flex-1 space-y-2">
            <div className="h-4 bg-muted rounded w-4/5" />
            <div className="h-3 bg-muted rounded w-1/2" />
          </div>
          <div className="flex flex-col gap-1 items-end shrink-0">
            <div className="h-5 w-12 bg-muted rounded-full" />
          </div>
        </div>
        <div className="space-y-1.5">
          <div className="h-3 bg-muted rounded w-2/3" />
          <div className="h-3 bg-muted rounded w-1/3" />
        </div>
        <div className="flex items-center gap-2 pt-3 border-t border-border">
          <div className="h-5 w-14 bg-muted rounded-full" />
          <div className="h-3 bg-muted rounded w-16" />
        </div>
        <div className="flex items-center gap-4 pt-2 px-0">
          <div className="h-3 bg-muted rounded w-16" />
          <div className="h-3 bg-muted rounded w-16" />
          <div className="h-3 bg-muted rounded w-16" />
        </div>
        <div className="h-2.5 bg-muted rounded w-24" />
      </div>
    </Card>
  );
}
