import { Link } from "wouter";
import { Shield, CheckCircle2, Mail, Phone, MapPin, Globe, Award, Clock, CreditCard, GraduationCap, Wrench, Plane } from "lucide-react";
import { SiLinkedin, SiInstagram, SiX, SiFacebook, SiWhatsapp } from "react-icons/si";
import { Logo } from "@/components/logo";

const jobLinks = [
  { href: "/jobs/all", label: "All Jobs", testId: "link-footer-all" },
  { href: "/jobs/un", label: "UN Jobs", testId: "link-footer-un" },
  { href: "/jobs/ngo", label: "NGO Jobs", testId: "link-footer-ngo" },
  { href: "/jobs/remote", label: "Remote Jobs", testId: "link-footer-remote" },
  { href: "/jobs/international", label: "International", testId: "link-footer-international" },
  { href: "/jobs/technology", label: "Technology", testId: "link-footer-technology" },
  { href: "/jobs/healthcare", label: "Healthcare", testId: "link-footer-healthcare" },
  { href: "/jobs/business", label: "Business & Finance", testId: "link-footer-business" },
  { href: "/jobs/education", label: "Education", testId: "link-footer-education" },
  { href: "/jobs/engineering", label: "Engineering", testId: "link-footer-engineering" },
];

const topCountryLinks = [
  { href: "/jobs/country/uk", label: "UK Jobs", testId: "link-footer-country-uk" },
  { href: "/jobs/country/us", label: "US Jobs", testId: "link-footer-country-us" },
  { href: "/jobs/country/canada", label: "Canada Jobs", testId: "link-footer-country-canada" },
  { href: "/jobs/country/australia", label: "Australia Jobs", testId: "link-footer-country-australia" },
  { href: "/jobs/country/germany", label: "Germany Jobs", testId: "link-footer-country-germany" },
  { href: "/jobs/country/france", label: "France Jobs", testId: "link-footer-country-france" },
  { href: "/jobs/country/netherlands", label: "Netherlands Jobs", testId: "link-footer-country-netherlands" },
  { href: "/jobs/country/switzerland", label: "Switzerland Jobs", testId: "link-footer-country-switzerland" },
];

export function Footer() {
  return (
    <footer className="border-t border-border bg-card mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-10 lg:gap-6">
          <div className="lg:col-span-2 text-center md:text-left">
            <div className="flex items-center gap-2.5 mb-5 justify-center md:justify-start">
              <Logo className="w-9 h-9" />
              <div className="flex flex-col">
                <span className="font-bold text-base leading-tight">Dev Global Jobs</span>
                <span className="text-[10px] text-muted-foreground leading-tight tracking-wide uppercase">International Careers</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              The #1 trusted international job platform connecting professionals
              with verified opportunities across 190+ countries. Powered by 11+ verified API sources.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-3 justify-center md:justify-start">
              <Shield className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
              <span>
                <a href="https://trendnovaworld.com/" target="_blank" rel="noopener noreferrer" className="underline font-medium" data-testid="link-trendnova">
                  Trend Nova World Limited
                </a>
                {" "}(UK Company No. 16709289)
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-5 justify-center md:justify-start">
              <MapPin className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              <span>27 Old Gloucester Street, London, WC1N 3AX, UK</span>
            </div>
            <div className="flex items-center gap-3 mb-6 justify-center md:justify-start">
              <a href="https://www.linkedin.com/company/trendnovaworld/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-social-linkedin" aria-label="LinkedIn"><SiLinkedin className="h-4 w-4" /></a>
              <a href="https://x.com/trendnovaworld" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-social-x" aria-label="X"><SiX className="h-4 w-4" /></a>
              <a href="https://www.facebook.com/trendnovaworld" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-social-facebook" aria-label="Facebook"><SiFacebook className="h-4 w-4" /></a>
              <a href="https://www.instagram.com/trendnovaworld/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-social-instagram" aria-label="Instagram"><SiInstagram className="h-4 w-4" /></a>
              <a href="https://wa.me/994518673521" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-social-whatsapp" aria-label="WhatsApp"><SiWhatsapp className="h-4 w-4" /></a>
            </div>
            <div className="space-y-2">
              <a href="mailto:info@devglobaljobs.com" className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors justify-center md:justify-start" data-testid="link-contact-email">
                <Mail className="h-3.5 w-3.5 shrink-0" />
                info@devglobaljobs.com
              </a>
              <a href="tel:+447473863903" className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors justify-center md:justify-start" data-testid="link-contact-phone">
                <Phone className="h-3.5 w-3.5 shrink-0" />
                +44 7473 863903 (UK)
              </a>
              <a href="https://wa.me/994518673521" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors justify-center md:justify-start" data-testid="link-contact-whatsapp">
                <SiWhatsapp className="h-3.5 w-3.5 shrink-0" />
                +994 51 867 35 21 (WhatsApp)
              </a>
            </div>
          </div>

          <div className="text-center md:text-left">
            <h3 className="font-semibold text-sm mb-4">Browse Jobs</h3>
            <ul className="space-y-2.5">
              {jobLinks.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid={link.testId}>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="text-center md:text-left">
            <h3 className="font-semibold text-sm mb-4">Popular Countries</h3>
            <ul className="space-y-2.5">
              {topCountryLinks.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid={link.testId}>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="text-center md:text-left">
            <h3 className="font-semibold text-sm mb-4">Student Resources</h3>
            <ul className="space-y-2.5">
              <li><Link href="/online-courses" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-courses">Free Online Courses</Link></li>
              <li><Link href="/free-certifications" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-certs">Free Certifications</Link></li>
              <li><Link href="/internships" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-internships">Internships & Volunteering</Link></li>
              <li><Link href="/scholarships" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-scholarships">Scholarships & Grants</Link></li>
              <li><Link href="/volunteers" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-volunteers">Volunteer Programs</Link></li>
              <li><Link href="/visa-guide" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-visa">Visa & Immigration</Link></li>
              <li><Link href="/universities" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-universities">Universities Guide</Link></li>
              <li><Link href="/jobs/youth" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-youth">Youth Opportunities</Link></li>
            </ul>
          </div>

          <div className="text-center md:text-left">
            <h3 className="font-semibold text-sm mb-4">Free Tools</h3>
            <ul className="space-y-2.5">
              <li><Link href="/tools/country-salary-calculator" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-country-salary">Country Salary Calculator</Link></li>
              <li><Link href="/tools/salary-calculator" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-salary-calc">UN Salary Calculator</Link></li>
              <li><Link href="/tools/ngo-salary-guide" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-ngo-salary">NGO Salary Guide</Link></li>
              <li><Link href="/tools/cost-of-living" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-col">Cost of Living</Link></li>
              <li><Link href="/tools/resume-checker" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-resume">Resume Checker</Link></li>
              <li><Link href="/tools/interview-prep" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-interview">Interview Prep</Link></li>
              <li><Link href="/tools/ats-keywords" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-ats-keywords">ATS Keywords Scanner</Link></li>
              <li><Link href="/tools/salary-negotiation" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-salary-negotiation">Salary Negotiation</Link></li>
              <li><Link href="/tools/career-path" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-career-path">Career Path Explorer</Link></li>
              <li><Link href="/tools/linkedin-optimizer" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-linkedin-optimizer">LinkedIn Optimizer</Link></li>
              <li><Link href="/eligibility-checker" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-eligibility">Eligibility Checker</Link></li>
            </ul>
          </div>

          <div className="text-center md:text-left">
            <h3 className="font-semibold text-sm mb-4">Company</h3>
            <ul className="space-y-2.5">
              <li><Link href="/about" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-about">About Us</Link></li>
              <li><Link href="/blog" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-blog">Career Blog</Link></li>
              <li><Link href="/pricing" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-pricing">Pricing</Link></li>
              <li><Link href="/post-job" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-post">Post a Job</Link></li>
              <li><Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-privacy">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="link-footer-terms">Terms of Service</Link></li>
            </ul>
            <div className="mt-6 space-y-2">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground justify-center md:justify-start">
                <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                11+ verified job sources
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground justify-center md:justify-start">
                <CreditCard className="h-3 w-3 text-emerald-500" />
                Secure Stripe payments
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground justify-center md:justify-start">
                <Clock className="h-3 w-3 text-emerald-500" />
                Auto-updated every 30 min
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground justify-center md:justify-start">
                <Award className="h-3 w-3 text-emerald-500" />
                GDPR compliant
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-10 pt-8 flex flex-col items-center md:flex-row md:justify-between gap-3 text-center md:text-left">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Dev Global Jobs. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Globe className="h-3 w-3" />
              <span>A product of Trend Nova World Limited (UK Registered)</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
