import { useState, useEffect } from "react";
import { X, Mail, Globe2, Bell, CheckCircle, Loader2 } from "lucide-react";
import { useI18n } from "@/lib/i18n";

const STORAGE_KEY = "dgj_newsletter_dismissed";

export function NewsletterPopup() {
  const [visible, setVisible] = useState(false);
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");
  const { t } = useI18n();

  useEffect(() => {
    const dismissed = localStorage.getItem(STORAGE_KEY);
    if (dismissed) return;
    const timer = setTimeout(() => setVisible(true), 5000);
    return () => clearTimeout(timer);
  }, []);

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, "1");
    setVisible(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setStatus("loading");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), type: "job_seeker" }),
      });
      const data = await res.json();
      setStatus("success");
      setMessage(data.message || "You're subscribed!");
      setTimeout(dismiss, 2800);
    } catch {
      setStatus("error");
      setMessage("Something went wrong. Please try again.");
    }
  };

  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0,0,0,0.55)", backdropFilter: "blur(4px)" }}
      onClick={(e) => { if (e.target === e.currentTarget) dismiss(); }}
    >
      <div
        className="relative w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
        style={{
          animation: "popupSlideIn 0.35s cubic-bezier(0.34,1.56,0.64,1) both",
          background: "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)",
          border: "1px solid rgba(99,102,241,0.25)",
        }}
      >
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(99,102,241,0.18) 0%, transparent 70%)",
          }}
        />

        <button
          onClick={dismiss}
          className="absolute top-4 right-4 z-10 text-slate-400 hover:text-white transition-colors rounded-full p-1 hover:bg-white/10"
        >
          <X size={18} />
        </button>

        <div className="relative p-7 pt-8">
          <div className="flex items-center gap-3 mb-5">
            <div
              className="flex items-center justify-center w-11 h-11 rounded-xl"
              style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)" }}
            >
              <Globe2 size={22} className="text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold text-indigo-400 uppercase tracking-widest mb-0.5">Dev Global Jobs</p>
              <h2 className="text-lg font-bold text-white leading-tight">Never miss a great job</h2>
            </div>
          </div>

          <p className="text-slate-300 text-sm mb-5 leading-relaxed">
            Get the latest international jobs, fellowships & scholarships delivered to your inbox — free, weekly, and curated.
          </p>

          <div className="flex flex-col gap-2.5 mb-6">
            {[
              "Jobs from 50+ countries & 200+ organisations",
              "UN, NGO, Remote & Tech opportunities",
              "No spam — unsubscribe any time",
            ].map((benefit) => (
              <div key={benefit} className="flex items-start gap-2.5">
                <CheckCircle size={15} className="text-indigo-400 mt-0.5 flex-shrink-0" />
                <span className="text-slate-300 text-sm">{benefit}</span>
              </div>
            ))}
          </div>

          {status === "success" ? (
            <div className="flex flex-col items-center gap-2 py-4">
              <CheckCircle size={36} className="text-green-400" />
              <p className="text-white font-semibold text-base">{message}</p>
              <p className="text-slate-400 text-sm">Check your inbox soon!</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  required
                  disabled={status === "loading"}
                  className="w-full pl-10 pr-4 py-3 rounded-xl text-sm text-white placeholder-slate-500 outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-60"
                  style={{
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.12)",
                  }}
                />
              </div>
              {status === "error" && (
                <p className="text-red-400 text-xs">{message}</p>
              )}
              <button
                type="submit"
                disabled={status === "loading" || !email.trim()}
                className="w-full py-3 rounded-xl text-white font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-60"
                style={{
                  background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
                  boxShadow: "0 4px 20px rgba(99,102,241,0.4)",
                }}
              >
                {status === "loading" ? (
                  <><Loader2 size={16} className="animate-spin" /> Subscribing...</>
                ) : (
                  <><Bell size={16} /> Get Job Alerts — It's Free</>
                )}
              </button>
            </form>
          )}

          <button
            onClick={dismiss}
            className="w-full mt-3 text-slate-500 hover:text-slate-300 text-xs text-center transition-colors py-1"
          >
            No thanks, I'll miss out
          </button>
        </div>
      </div>

      <style>{`
        @keyframes popupSlideIn {
          from { opacity: 0; transform: scale(0.88) translateY(20px); }
          to   { opacity: 1; transform: scale(1) translateY(0); }
        }
      `}</style>
    </div>
  );
}
