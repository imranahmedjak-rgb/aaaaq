import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import {
  BriefcaseBusiness,
  CheckCircle2,
  FileText,
  Loader2,
  Send,
  Sparkles,
  Upload,
} from "lucide-react";

type EasyApplyJob = {
  id: number;
  title: string;
  organization: string;
  location?: string | null;
};

type FormState = {
  fullName: string;
  email: string;
  phone: string;
  currentCountry: string;
  nationality: string;
  currentJobTitle: string;
  experienceYears: string;
  qualification: string;
  linkedin: string;
  availability: string;
  workAuthorization: string;
  expectedSalary: string;
  professionalSummary: string;
  coverLetter: string;
};

const initialForm: FormState = {
  fullName: "",
  email: "",
  phone: "",
  currentCountry: "",
  nationality: "",
  currentJobTitle: "",
  experienceYears: "",
  qualification: "",
  linkedin: "",
  availability: "",
  workAuthorization: "",
  expectedSalary: "",
  professionalSummary: "",
  coverLetter: "",
};

function generateCoverLetter(job: EasyApplyJob, form: FormState): string {
  const candidateName = form.fullName || "Applicant";
  const currentRole = form.currentJobTitle || "professional";
  const experience = form.experienceYears
    ? ` with ${form.experienceYears} of relevant experience`
    : "";

  const summary = form.professionalSummary
    ? `\n\nMy background includes ${form.professionalSummary.trim()}`
    : "";

  return `Dear Hiring Manager,

I am writing to apply for the ${job.title} position at ${job.organization}. I am currently working as a ${currentRole}${experience}, and I believe my experience, qualifications and professional background make me a suitable candidate for this opportunity.${summary}

I am particularly interested in this position because it aligns with my professional experience and future career goals. I am confident that I can contribute positively to your organisation through dedication, reliability and a strong commitment to delivering quality work.

I would welcome the opportunity to discuss my application and suitability for the position. My CV is attached for your review.

Thank you for your time and consideration.

Kind regards,
${candidateName}`;
}

export default function EasyApplyDialog({
  job,
  showUnavailableMessage = false,
}: {
  job: EasyApplyJob;
  showUnavailableMessage?: boolean;
}) {
  const { toast } = useToast();
  const [available, setAvailable] = useState<boolean | null>(null);
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [consent, setConsent] = useState(false);
  const [cv, setCv] = useState<File | null>(null);
  const [form, setForm] = useState<FormState>(initialForm);

  useEffect(() => {
    let active = true;

    fetch(`/api/jobs/${job.id}/easy-apply-status`)
      .then((response) => response.json())
      .then((data) => {
        if (active) setAvailable(Boolean(data.available));
      })
      .catch(() => {
        if (active) setAvailable(false);
      });

    return () => {
      active = false;
    };
  }, [job.id]);

  const updateField = (field: keyof FormState, value: string) => {
    setForm((current) => ({
      ...current,
      [field]: value,
    }));
  };

  const handleGenerateCoverLetter = () => {
    setForm((current) => ({
      ...current,
      coverLetter: generateCoverLetter(job, current),
    }));

    toast({
      title: "Cover letter prepared",
      description: "Please review and edit it before submitting.",
    });
  };

  const handleFile = (file: File | null) => {
    if (!file) {
      setCv(null);
      return;
    }

    const allowedExtensions = [".pdf", ".doc", ".docx"];
    const lowerName = file.name.toLowerCase();
    const allowed = allowedExtensions.some((extension) =>
      lowerName.endsWith(extension),
    );

    if (!allowed) {
      toast({
        title: "Invalid CV format",
        description: "Please upload a PDF, DOC or DOCX file.",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "CV is too large",
        description: "The maximum allowed size is 5 MB.",
        variant: "destructive",
      });
      return;
    }

    setCv(file);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!cv) {
      toast({
        title: "CV required",
        description: "Please attach your CV before submitting.",
        variant: "destructive",
      });
      return;
    }

    if (!consent) {
      toast({
        title: "Consent required",
        description: "Please confirm that your information may be sent to the employer.",
        variant: "destructive",
      });
      return;
    }

    if (form.coverLetter.trim().length < 80) {
      toast({
        title: "Cover letter required",
        description: "Please generate or write a complete cover letter.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    try {
      const data = new FormData();

      Object.entries(form).forEach(([key, value]) => {
        data.append(key, value);
      });

      data.append("consent", "true");
      data.append("cv", cv);

      const response = await fetch(`/api/jobs/${job.id}/easy-apply`, {
        method: "POST",
        body: data,
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Application could not be sent.");
      }

      toast({
        title: "Application sent successfully",
        description: result.message,
      });

      setOpen(false);
      setForm(initialForm);
      setCv(null);
      setConsent(false);
    } catch (error) {
      toast({
        title: "Application not sent",
        description:
          error instanceof Error
            ? error.message
            : "Please check your details and try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (available === null) {
    return (
      <Button variant="outline" className="w-full" disabled>
        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
        Checking Easy Apply
      </Button>
    );
  }

  if (!available) {
    return showUnavailableMessage ? (
      <p className="text-sm text-muted-foreground">
        Application instructions are available directly from the employer.
        Please check the job description or employer website.
      </p>
    ) : null;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          className="w-full border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground"
          data-testid="button-easy-apply"
        >
          <BriefcaseBusiness className="h-4 w-4 mr-1.5" />
          Easy Apply
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-3xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-1">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <BriefcaseBusiness className="h-5 w-5 text-primary" />
            </div>
            <div>
              <DialogTitle>Easy Apply</DialogTitle>
              <DialogDescription>
                Apply directly to the employer through Dev Global Jobs.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="rounded-lg border bg-muted/30 p-4">
          <p className="font-semibold text-sm">{job.title}</p>
          <p className="text-sm text-muted-foreground">
            {job.organization}
            {job.location ? ` · ${job.location}` : ""}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              <h3 className="font-semibold">Personal information</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="easy-full-name">Full name *</Label>
                <Input
                  id="easy-full-name"
                  required
                  value={form.fullName}
                  onChange={(event) => updateField("fullName", event.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-email">Email address *</Label>
                <Input
                  id="easy-email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(event) => updateField("email", event.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-phone">Phone with country code *</Label>
                <Input
                  id="easy-phone"
                  required
                  placeholder="+974 0000 0000"
                  value={form.phone}
                  onChange={(event) => updateField("phone", event.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-country">Current country *</Label>
                <Input
                  id="easy-country"
                  required
                  value={form.currentCountry}
                  onChange={(event) =>
                    updateField("currentCountry", event.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-nationality">Nationality *</Label>
                <Input
                  id="easy-nationality"
                  required
                  value={form.nationality}
                  onChange={(event) =>
                    updateField("nationality", event.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-linkedin">LinkedIn profile</Label>
                <Input
                  id="easy-linkedin"
                  type="url"
                  placeholder="https://linkedin.com/in/..."
                  value={form.linkedin}
                  onChange={(event) => updateField("linkedin", event.target.value)}
                />
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" />
              <h3 className="font-semibold">Professional information</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="easy-job-title">Current job title *</Label>
                <Input
                  id="easy-job-title"
                  required
                  value={form.currentJobTitle}
                  onChange={(event) =>
                    updateField("currentJobTitle", event.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-experience">Experience *</Label>
                <Input
                  id="easy-experience"
                  required
                  placeholder="Example: 5 years"
                  value={form.experienceYears}
                  onChange={(event) =>
                    updateField("experienceYears", event.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-qualification">Highest qualification *</Label>
                <Input
                  id="easy-qualification"
                  required
                  value={form.qualification}
                  onChange={(event) =>
                    updateField("qualification", event.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-availability">Availability *</Label>
                <Input
                  id="easy-availability"
                  required
                  placeholder="Immediate / 30 days"
                  value={form.availability}
                  onChange={(event) =>
                    updateField("availability", event.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-authorisation">Work authorisation *</Label>
                <Input
                  id="easy-authorisation"
                  required
                  placeholder="Visa required / Valid work permit"
                  value={form.workAuthorization}
                  onChange={(event) =>
                    updateField("workAuthorization", event.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="easy-salary">Expected salary</Label>
                <Input
                  id="easy-salary"
                  value={form.expectedSalary}
                  onChange={(event) =>
                    updateField("expectedSalary", event.target.value)
                  }
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="easy-summary">Professional summary *</Label>
              <Textarea
                id="easy-summary"
                required
                rows={5}
                placeholder="Briefly describe your experience, skills and achievements."
                value={form.professionalSummary}
                onChange={(event) =>
                  updateField("professionalSummary", event.target.value)
                }
              />
            </div>
          </section>

          <section className="space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                <h3 className="font-semibold">Tailored cover letter</h3>
              </div>

              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleGenerateCoverLetter}
              >
                <Sparkles className="h-4 w-4 mr-1.5" />
                Generate Cover Letter
              </Button>
            </div>

            <Textarea
              required
              rows={12}
              placeholder="Generate a tailored cover letter, then review and edit it."
              value={form.coverLetter}
              onChange={(event) =>
                updateField("coverLetter", event.target.value)
              }
            />
          </section>

          <section className="space-y-3">
            <Label htmlFor="easy-cv">Upload CV *</Label>

            <label
              htmlFor="easy-cv"
              className="flex cursor-pointer items-center justify-center gap-3 rounded-lg border border-dashed border-primary/40 bg-primary/5 px-4 py-6 hover:bg-primary/10 transition-colors"
            >
              <Upload className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm font-medium">
                  {cv ? cv.name : "Choose your CV"}
                </p>
                <p className="text-xs text-muted-foreground">
                  PDF, DOC or DOCX, maximum 5 MB
                </p>
              </div>
            </label>

            <Input
              id="easy-cv"
              type="file"
              className="hidden"
              accept=".pdf,.doc,.docx"
              onChange={(event) =>
                handleFile(event.target.files?.[0] || null)
              }
            />
          </section>

          <div className="flex items-start gap-3 rounded-lg border p-4">
            <Checkbox
              id="easy-consent"
              checked={consent}
              onCheckedChange={(checked) => setConsent(checked === true)}
            />

            <Label
              htmlFor="easy-consent"
              className="text-sm leading-relaxed font-normal cursor-pointer"
            >
              I confirm that the information provided is accurate and I consent
              to Dev Global Jobs sending my application and CV directly to the
              employer.
            </Label>
          </div>

          <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={submitting}
            >
              Cancel
            </Button>

            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Sending Application
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Submit Application
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
