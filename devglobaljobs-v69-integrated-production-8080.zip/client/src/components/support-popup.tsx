import { useState, useEffect } from "react";
import { X, Heart, Coffee, Globe2, Star, ExternalLink } from "lucide-react";

const STORAGE_KEY = "dgj_support_dismissed";
const DELAY_MS = 60000; // 1 minute

export function SupportPopup() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem(STORAGE_KEY);
    if (dismissed) return;
    const timer = setTimeout(() => setVisible(true), DELAY_MS);
    return () => clearTimeout(timer);
  }, []);

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, "1");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0,0,0,0.50)", backdropFilter: "blur(4px)" }}
      onClick={(e) => { if (e.target === e.currentTarget) dismiss(); }}
    >
      <div
        className="relative w-full max-w-md rounded-2xl overflow-hidden shadow-2xl"
        style={{
          animation: "supportSlideIn 0.4s cubic-bezier(0.34,1.56,0.64,1) both",
          background: "linear-gradient(135deg, #0a0f1e 0%, #111827 60%, #0a0f1e 100%)",
          border: "1px solid rgba(251,146,60,0.25)",
        }}
      >
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "radial-gradient(ellipse 90% 55% at 50% 0%, rgba(251,146,60,0.14) 0%, transparent 70%)",
          }}
        />

        <button
          onClick={dismiss}
          className="absolute top-4 right-4 z-10 text-slate-400 hover:text-white transition-colors rounded-full p-1 hover:bg-white/10"
        >
          <X size={18} />
        </button>

        <div className="relative p-7 pt-8">
          <div className="flex items-center gap-3 mb-5">
            <div
              className="flex items-center justify-center w-12 h-12 rounded-xl"
              style={{ background: "linear-gradient(135deg, #f97316, #ef4444)" }}
            >
              <Heart size={24} className="text-white" />
            </div>
            <div>
              <p className="text-xs font-semibold text-orange-400 uppercase tracking-widest mb-0.5">Always Free for Job Seekers</p>
              <h2 className="text-lg font-bold text-white leading-tight">Support Dev Global Jobs</h2>
            </div>
          </div>

          <p className="text-slate-300 text-sm mb-5 leading-relaxed">
            We never charge job seekers — every job is completely free to browse and apply. We're a small independent team building a world-class international job platform.
          </p>

          <div className="rounded-xl p-4 mb-5" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <div className="flex items-center gap-3 mb-3">
              <Globe2 size={16} className="text-orange-400" />
              <span className="text-white text-sm font-semibold">Your support keeps us running:</span>
            </div>
            <div className="flex flex-col gap-2">
              {[
                "Server and infrastructure costs for 30,000+ active listings",
                "Continuous development of new features",
                "Keeping the platform 100% free for job seekers",
              ].map((item) => (
                <div key={item} className="flex items-start gap-2">
                  <Star size={12} className="text-orange-400 mt-1 flex-shrink-0" />
                  <span className="text-slate-400 text-xs">{item}</span>
                </div>
              ))}
            </div>
          </div>

          <a
            href="https://wise.com/pay/business/trendnovaworldlimited"
            target="_blank"
            rel="nofollow noopener noreferrer"
            onClick={dismiss}
            className="w-full py-3.5 rounded-xl text-white font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 no-underline"
            style={{
              background: "linear-gradient(135deg, #f97316 0%, #ef4444 100%)",
              boxShadow: "0 4px 20px rgba(249,115,22,0.35)",
              display: "flex",
            }}
          >
            <Coffee size={17} />
            Support Us via Wise
            <ExternalLink size={14} className="opacity-70" />
          </a>

          <p className="text-slate-600 text-[10px] text-center mt-2">
            Trend Nova World Limited · Any amount is appreciated
          </p>

          <button
            onClick={dismiss}
            className="w-full mt-3 text-slate-600 hover:text-slate-400 text-xs text-center transition-colors py-1"
          >
            Maybe later
          </button>
        </div>
      </div>

      <style>{`
        @keyframes supportSlideIn {
          from { opacity: 0; transform: scale(0.88) translateY(20px); }
          to   { opacity: 1; transform: scale(1) translateY(0); }
        }
      `}</style>
    </div>
  );
}
