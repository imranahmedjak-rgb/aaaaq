import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { MapPin } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function MoreFromCompany({ jobId }: { jobId: number }) {
  const { data } = useQuery({
    queryKey: ["/api/jobs", jobId, "same-company"],
    queryFn: async () => {
      const res = await fetch(`/api/jobs/${jobId}/same-company`);
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!jobId,
    staleTime: 5 * 60 * 1000,
  });

  if (!data?.jobs?.length) return null;

  return (
    <div className="mt-6 border-t pt-6">
      <h3 className="text-lg font-bold mb-3 text-foreground">
        More Jobs from {data.organization} ({data.jobs.length})
      </h3>
      <div className="space-y-2">
        {data.jobs.map((job: any) => (
          <Link key={job.id} href={`/jobs/detail/${job.id}`}>
            <div className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors cursor-pointer">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-foreground truncate">{job.title}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                  {job.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{job.location}</span>}
                  {job.jobType && <span>{job.jobType}</span>}
                </div>
              </div>
              {job.postedAt && (
                <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">
                  {formatDistanceToNow(new Date(job.postedAt), { addSuffix: true })}
                </span>
              )}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
