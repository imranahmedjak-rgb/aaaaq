import { Moon, Sun, Palette, Droplets, Flame, Monitor, Trees, Flower2, Layers, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const colorThemes = [
  { id: "default" as const, label: "Classic Blue", icon: Monitor, color: "text-blue-500" },
  { id: "ocean" as const, label: "Ocean Teal", icon: Droplets, color: "text-teal-500" },
  { id: "sunset" as const, label: "Sunset Amber", icon: Flame, color: "text-amber-500" },
  { id: "forest" as const, label: "Forest Green", icon: Trees, color: "text-emerald-500" },
  { id: "rose" as const, label: "Elegant Rose", icon: Flower2, color: "text-rose-500" },
  { id: "slate" as const, label: "Slate Gray", icon: Layers, color: "text-slate-500" },
  { id: "lavender" as const, label: "Lavender", icon: Sparkles, color: "text-purple-500" },
  { id: "midnight" as const, label: "Midnight", icon: Moon, color: "text-indigo-500" },
];

export function ThemeToggle() {
  const { mode, colorTheme, toggleMode, setColorTheme } = useTheme();

  return (
    <div className="flex items-center gap-1">
      <Button
        size="icon"
        variant="ghost"
        onClick={toggleMode}
        data-testid="button-theme-toggle"
      >
        {mode === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            size="icon"
            variant="ghost"
            data-testid="button-color-theme"
          >
            <Palette className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel className="text-xs">Color Theme</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {colorThemes.map((t) => (
            <DropdownMenuItem
              key={t.id}
              onClick={() => setColorTheme(t.id)}
              className="flex items-center gap-2 cursor-pointer"
              data-testid={`button-theme-${t.id}`}
            >
              <t.icon className={`h-4 w-4 ${t.color}`} />
              <span className="text-sm">{t.label}</span>
              {colorTheme === t.id && (
                <span className="ml-auto text-xs text-primary" data-testid={`text-theme-active-${t.id}`}>Active</span>
              )}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
