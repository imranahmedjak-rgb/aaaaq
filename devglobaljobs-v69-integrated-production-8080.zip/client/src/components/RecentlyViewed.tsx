import { useEffect, useState } from "react";

const STORAGE_KEY = "dgj_recently_viewed_jobs";
const MAX_ITEMS = 5;

interface JobSummary {
  id: number;
  title: string;
  organization: string;
  location: string;
}

export function trackRecentlyViewed(job: JobSummary) {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    const list: JobSummary[] = stored ? JSON.parse(stored) : [];
    const filtered = list.filter((j) => j.id !== job.id);
    filtered.unshift(job);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered.slice(0, MAX_ITEMS)));
  } catch {}
}

export function RecentlyViewed() {
  const [jobs, setJobs] = useState<JobSummary[]>([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) setJobs(JSON.parse(stored));
    } catch {}
  }, []);

  if (jobs.length === 0) return null;

  return (
    <div className="mt-6">
      <h3 className="text-base font-semibold mb-2 text-gray-700">Recently Viewed</h3>
      <ul className="space-y-1">
        {jobs.map((job) => (
          <li key={job.id}>
            <a
              href={`/?jobId=${job.id}`}
              className="flex items-center gap-2 text-sm text-blue-700 hover:underline truncate"
            >
              <svg className="w-4 h-4 flex-shrink-0 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="truncate">{job.title} — {job.organization}</span>
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default RecentlyViewed;
