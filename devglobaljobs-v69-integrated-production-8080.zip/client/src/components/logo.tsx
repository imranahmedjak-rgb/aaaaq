export function Logo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <img
      src="/logo.png"
      alt="Dev Global Jobs"
      className={`${className} rounded-md`}
    />
  );
}
