import { useEffect, useState } from "react";

interface Job {
  id: number;
  title: string;
  organization: string;
  location: string;
  category: string;
}

interface RelatedJobsProps {
  jobId: number;
}

export function RelatedJobs({ jobId }: RelatedJobsProps) {
  const [related, setRelated] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!jobId) return;
    fetch(`/api/jobs/${jobId}/related`)
      .then((r) => r.json())
      .then((data) => {
        setRelated(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [jobId]);

  if (loading) return <div className="text-sm text-gray-500">Loading related jobs...</div>;
  if (related.length === 0) return null;

  return (
    <div className="mt-6">
      <h3 className="text-lg font-semibold mb-3">Related Jobs</h3>
      <ul className="space-y-2">
        {related.map((job) => (
          <li key={job.id} className="border rounded p-3 hover:bg-gray-50 transition">
            <a href={`/?jobId=${job.id}`} className="block">
              <div className="font-medium text-blue-700">{job.title}</div>
              <div className="text-sm text-gray-600">{job.organization} — {job.location}</div>
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default RelatedJobs;
