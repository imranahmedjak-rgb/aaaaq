interface JobDetailProps {
  title: string;
  organization: string;
  location: string;
  description: string;
  applyUrl?: string;
  jobId: number;
  isSponsored?: boolean;
}

export function JobDetail({
  title,
  organization,
  location,
  description,
  applyUrl,
  jobId,
  isSponsored = false,
}: JobDetailProps) {
  return (
    <article className="max-w-3xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-1">{title}</h1>
      <div className="text-gray-600 mb-2">
        {organization} &mdash; {location}
      </div>

      {isSponsored && applyUrl && (
        <a
          href={applyUrl}
          rel="nofollow sponsored noopener noreferrer"
          target="_blank"
          className="inline-block text-xs text-gray-400 mb-3"
        >
          Sponsored Job &rarr;
        </a>
      )}

      {/* data-nosnippet prevents Google from using job description as a snippet */}
      <div
        className="prose max-w-none mt-4"
        data-nosnippet
        dangerouslySetInnerHTML={{ __html: description }}
      />
    </article>
  );
}

export default JobDetail;
