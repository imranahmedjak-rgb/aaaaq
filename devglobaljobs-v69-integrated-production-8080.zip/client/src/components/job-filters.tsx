import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

interface JobFiltersProps {
  search: string;
  onSearchChange: (val: string) => void;
  jobType: string;
  onJobTypeChange: (val: string) => void;
  sortBy: string;
  onSortChange: (val: string) => void;
}

export function JobFilters({
  search,
  onSearchChange,
  jobType,
  onJobTypeChange,
  sortBy,
  onSortChange,
}: JobFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-3">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search jobs by title, organization, or location..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9"
          data-testid="input-search-jobs"
        />
      </div>
      <Select value={jobType} onValueChange={onJobTypeChange}>
        <SelectTrigger className="w-full sm:w-40" data-testid="select-job-type">
          <SelectValue placeholder="Job Type" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Types</SelectItem>
          <SelectItem value="Full-time">Full-time</SelectItem>
          <SelectItem value="Part-time">Part-time</SelectItem>
          <SelectItem value="Contract">Contract</SelectItem>
          <SelectItem value="Internship">Internship</SelectItem>
          <SelectItem value="Consultant">Consultant</SelectItem>
        </SelectContent>
      </Select>
      <Select value={sortBy} onValueChange={onSortChange}>
        <SelectTrigger className="w-full sm:w-40" data-testid="select-sort">
          <SelectValue placeholder="Sort By" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="newest">Newest First</SelectItem>
          <SelectItem value="oldest">Oldest First</SelectItem>
          <SelectItem value="title">By Title</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}
