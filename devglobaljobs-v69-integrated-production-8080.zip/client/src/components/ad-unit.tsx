import { useEffect, useRef } from "react";

declare global {
  interface Window {
    adsbygoogle: any[];
  }
}

interface AdUnitProps {
  format?: "auto" | "fluid" | "rectangle" | "horizontal";
  layout?: string;
  className?: string;
  responsive?: boolean;
}

export function AdUnit({ format = "auto", layout, className = "", responsive = true }: AdUnitProps) {
  const adRef = useRef<HTMLModElement>(null);
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    if (!adRef.current) return;
    const alreadyInitialized = adRef.current.getAttribute("data-adsbygoogle-status");
    if (alreadyInitialized) return;

    try {
      if (typeof window !== "undefined" && window.adsbygoogle) {
        window.adsbygoogle.push({});
        initialized.current = true;
      }
    } catch (e) {
    }
  }, []);

  return (
    <div className={`ad-container overflow-hidden ${className}`} data-testid="ad-unit">
      <ins
        ref={adRef}
        className="adsbygoogle"
        style={{ display: "block", minHeight: "50px" }}
        data-ad-client="ca-pub-3836763018052347"
        data-ad-format={format}
        {...(responsive ? { "data-full-width-responsive": "true" } : {})}
        {...(layout ? { "data-ad-layout": layout } : {})}
      />
    </div>
  );
}
