import { createContext, useContext, useEffect, useState } from "react";

type ColorTheme = "default" | "ocean" | "sunset" | "forest" | "rose" | "slate" | "lavender" | "midnight";
type Mode = "light" | "dark";

interface ThemeContextType {
  mode: Mode;
  colorTheme: ColorTheme;
  toggleMode: () => void;
  setColorTheme: (theme: ColorTheme) => void;
  theme: string;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({
  mode: "light",
  colorTheme: "default",
  toggleMode: () => {},
  setColorTheme: () => {},
  theme: "light",
  toggleTheme: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<Mode>(() => {
    if (typeof window !== "undefined") {
      return (localStorage.getItem("theme") as Mode) || "light";
    }
    return "light";
  });

  const [colorTheme, setColorThemeState] = useState<ColorTheme>(() => {
    if (typeof window !== "undefined") {
      return (localStorage.getItem("colorTheme") as ColorTheme) || "default";
    }
    return "default";
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("dark", "theme-ocean", "theme-sunset", "theme-forest", "theme-rose", "theme-slate", "theme-lavender", "theme-midnight");
    if (mode === "dark") {
      root.classList.add("dark");
    }
    if (colorTheme !== "default") {
      root.classList.add(`theme-${colorTheme}`);
    }
    localStorage.setItem("theme", mode);
    localStorage.setItem("colorTheme", colorTheme);
  }, [mode, colorTheme]);

  const toggleMode = () => {
    setMode((prev) => (prev === "light" ? "dark" : "light"));
  };

  const setColorTheme = (theme: ColorTheme) => {
    setColorThemeState(theme);
  };

  return (
    <ThemeContext.Provider value={{
      mode,
      colorTheme,
      toggleMode,
      setColorTheme,
      theme: mode,
      toggleTheme: toggleMode,
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
