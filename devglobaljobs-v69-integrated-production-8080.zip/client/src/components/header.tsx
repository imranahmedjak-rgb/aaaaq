import { Link, useLocation } from "wouter";
import { Briefcase, Menu, X, ChevronDown, Globe, MapPin, DollarSign, Layers, Building2, GraduationCap, BookOpen, Award, Users, Wrench, Plane, Calculator, Heart, Wifi } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { Logo } from "@/components/logo";
import { useState, useRef, useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";

const jobLinks = [
  { href: "/jobs/all", label: "All Jobs", icon: Briefcase, desc: "Browse every verified opportunity" },
  { href: "/jobs/un", label: "UN Jobs", icon: Globe, desc: "United Nations & affiliated agencies" },
  { href: "/jobs/ngo", label: "NGO Jobs", icon: Heart, desc: "Humanitarian organizations" },
  { href: "/jobs/remote", label: "Remote Jobs", icon: Wifi, desc: "Work from anywhere worldwide" },
  { href: "/jobs/international", label: "International", icon: Building2, desc: "Global positions across sectors" },
  { href: "/jobs/technology", label: "Technology", icon: null, desc: "" },
  { href: "/jobs/healthcare", label: "Healthcare", icon: null, desc: "" },
  { href: "/jobs/business", label: "Business & Finance", icon: null, desc: "" },
  { href: "/jobs/education", label: "Education", icon: null, desc: "" },
  { href: "/jobs/engineering", label: "Engineering", icon: null, desc: "" },
  { href: "/jobs/creative", label: "Creative & Media", icon: null, desc: "" },
  { href: "/jobs/sales", label: "Sales & Marketing", icon: null, desc: "" },
  { href: "/jobs/gig", label: "Gig Economy", icon: null, desc: "" },
];

const studentLinks = [
  { href: "/online-courses", label: "Free Online Courses", icon: BookOpen, desc: "100,000+ courses from top universities" },
  { href: "/free-certifications", label: "Free Certifications", icon: Award, desc: "Google, IBM, AWS & more" },
  { href: "/internships", label: "Internships & Volunteering", icon: Users, desc: "UN, EU, World Bank opportunities" },
  { href: "/scholarships", label: "Scholarships & Grants", icon: GraduationCap, desc: "Fully funded programs worldwide" },
  { href: "/volunteers", label: "Volunteer Programs", icon: Heart, desc: "Global volunteering opportunities" },
  { href: "/visa-guide", label: "Visa & Immigration Guide", icon: Plane, desc: "Work visas, nomad visas & more" },
  { href: "/eligibility-checker", label: "Eligibility Checker", icon: Calculator, desc: "Check your visa & program eligibility" },
  { href: "/universities", label: "World Universities Guide", icon: Building2, desc: "9,600+ institutions in 140+ countries" },
  { href: "/jobs/youth", label: "Youth Opportunities", icon: Award, desc: "Fellowships, trainings & workshops" },
];

const toolLinks = [
  { href: "/tools/country-salary-calculator", label: "Country Salary Calculator", desc: "Compare salaries across 34 countries" },
  { href: "/tools/salary-calculator", label: "UN Salary Calculator", desc: "Calculate UN staff salary scales" },
  { href: "/tools/ngo-salary-guide", label: "NGO Salary Guide", desc: "Non-profit salary benchmarks" },
  { href: "/tools/cost-of-living", label: "Cost of Living Comparison", desc: "Compare living costs worldwide" },
  { href: "/tools/resume-checker", label: "Resume/CV Checker", desc: "AI-powered resume review tips" },
  { href: "/tools/interview-prep", label: "Interview Preparation", desc: "Common interview questions & tips" },
  { href: "/tools/cover-letter", label: "Cover Letter Guide", desc: "Templates and writing tips" },
  { href: "/tools/work-permit-guide", label: "Work Permit Guide", desc: "Country-by-country requirements" },
  { href: "/tools/remote-work-tax", label: "Remote Work Tax Guide", desc: "Tax obligations for remote workers" },
  { href: "/tools/ats-keywords", label: "ATS Keywords Scanner", desc: "Extract resume keywords from job descriptions" },
  { href: "/tools/salary-negotiation", label: "Salary Negotiation Guide", desc: "Calculator, scripts & negotiation tips" },
  { href: "/tools/career-path", label: "Career Path Explorer", desc: "Map your career progression roadmap" },
  { href: "/tools/linkedin-optimizer", label: "LinkedIn Profile Optimizer", desc: "Audit & optimize your LinkedIn profile" },
];

const defaultCountryLinks = [
  { href: "/jobs/country/uk", label: "United Kingdom", code: "gb" },
  { href: "/jobs/country/us", label: "United States", code: "us" },
  { href: "/jobs/country/canada", label: "Canada", code: "ca" },
  { href: "/jobs/country/australia", label: "Australia", code: "au" },
  { href: "/jobs/country/germany", label: "Germany", code: "de" },
  { href: "/jobs/country/france", label: "France", code: "fr" },
  { href: "/jobs/country/india", label: "India", code: "in" },
  { href: "/jobs/country/brazil", label: "Brazil", code: "br" },
  { href: "/jobs/country/south-africa", label: "South Africa", code: "za" },
  { href: "/jobs/country/netherlands", label: "Netherlands", code: "nl" },
  { href: "/jobs/country/poland", label: "Poland", code: "pl" },
  { href: "/jobs/country/italy", label: "Italy", code: "it" },
  { href: "/jobs/country/belgium", label: "Belgium", code: "be" },
  { href: "/jobs/country/austria", label: "Austria", code: "at" },
  { href: "/jobs/country/switzerland", label: "Switzerland", code: "ch" },
  { href: "/jobs/country/new-zealand", label: "New Zealand", code: "nz" },
  { href: "/jobs/country/singapore", label: "Singapore", code: "sg" },
];

const SLUG_TO_FLAG: Record<string, string> = {
  uk: "gb", us: "us", canada: "ca", australia: "au", germany: "de", france: "fr",
  india: "in", brazil: "br", "south-africa": "za", netherlands: "nl", poland: "pl",
  italy: "it", belgium: "be", austria: "at", switzerland: "ch", "new-zealand": "nz",
  singapore: "sg", spain: "es", japan: "jp", china: "cn", "south-korea": "kr",
  ireland: "ie", sweden: "se", norway: "no", denmark: "dk", finland: "fi",
  portugal: "pt", mexico: "mx", argentina: "ar", chile: "cl", colombia: "co",
  uae: "ae", "saudi-arabia": "sa", qatar: "qa", kenya: "ke", nigeria: "ng",
  egypt: "eg", turkey: "tr", thailand: "th", vietnam: "vn", indonesia: "id",
  malaysia: "my", philippines: "ph", taiwan: "tw", pakistan: "pk", bangladesh: "bd",
  "czech-republic": "cz", romania: "ro", hungary: "hu", greece: "gr", croatia: "hr",
};

export function Header() {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [jobsOpen, setJobsOpen] = useState(false);
  const [countryOpen, setCountryOpen] = useState(false);
  const [studentOpen, setStudentOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);

  const jobsRef = useRef<HTMLDivElement>(null);
  const countryRef = useRef<HTMLDivElement>(null);
  const studentRef = useRef<HTMLDivElement>(null);
  const toolsRef = useRef<HTMLDivElement>(null);

  const closeMobile = useCallback(() => setMobileOpen(false), []);

  const { data: countryStats } = useQuery<Array<{ slug: string; name: string; count: number; code: string }>>({
    queryKey: ["/api/jobs/country/stats"],
    refetchInterval: 60000,
  });

  const countryLinks = countryStats && countryStats.length > 0
    ? countryStats
        .sort((a, b) => b.count - a.count)
        .slice(0, 30)
        .map(c => ({
          href: `/jobs/country/${c.slug}`,
          label: c.name,
          code: SLUG_TO_FLAG[c.slug] || c.code?.toLowerCase() || c.slug,
        }))
    : defaultCountryLinks;

  useEffect(() => {
    setMobileOpen(false);
    setJobsOpen(false);
    setCountryOpen(false);
    setStudentOpen(false);
    setToolsOpen(false);
  }, [location]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (jobsRef.current && !jobsRef.current.contains(e.target as Node)) setJobsOpen(false);
      if (countryRef.current && !countryRef.current.contains(e.target as Node)) setCountryOpen(false);
      if (studentRef.current && !studentRef.current.contains(e.target as Node)) setStudentOpen(false);
      if (toolsRef.current && !toolsRef.current.contains(e.target as Node)) setToolsOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-[999] bg-background/85 glass-effect border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          <Link href="/" className="flex items-center gap-2.5 shrink-0" data-testid="link-home">
            <Logo className="w-9 h-9" />
            <div className="hidden sm:flex flex-col">
              <span className="font-extrabold text-base tracking-tight leading-tight">Dev Global Jobs</span>
              <span className="text-[10px] text-muted-foreground leading-tight tracking-widest uppercase font-medium">International Careers</span>
            </div>
          </Link>

          <nav className="hidden lg:flex items-center gap-0.5">
            <div
              ref={jobsRef}
              className="relative"
              onMouseEnter={() => setJobsOpen(true)}
              onMouseLeave={() => setJobsOpen(false)}
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setJobsOpen(!jobsOpen)}
                data-testid="button-nav-jobs"
              >
                <Briefcase className="h-3.5 w-3.5 mr-1" />
                Jobs
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
              <div
                className="absolute top-full left-0 mt-1 w-[520px] bg-popover border border-border rounded-md shadow-lg p-4 z-50"
                style={{ visibility: jobsOpen ? "visible" : "hidden" }}
              >
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">By Source</p>
                <div className="grid grid-cols-1 gap-0.5 mb-3">
                  {jobLinks.filter(l => l.icon).map((link) => {
                    const Icon = link.icon!;
                    return (
                      <Link
                        key={link.href}
                        href={link.href}
                        onClick={() => setJobsOpen(false)}
                        data-testid={`link-nav-job-${link.label.toLowerCase().replace(/[\s&]/g, "-")}`}
                      >
                        <div className="px-3 py-2.5 text-sm hover-elevate active-elevate-2 rounded-md cursor-pointer flex items-start gap-3">
                          <Icon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                          <div>
                            <div className="font-medium text-sm">{link.label}</div>
                            <div className="text-xs text-muted-foreground">{link.desc}</div>
                          </div>
                        </div>
                      </Link>
                    );
                  })}
                </div>
                <div className="border-t border-border pt-3">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-2">By Industry</p>
                  <div className="grid grid-cols-2 gap-0.5">
                    {jobLinks.filter(l => !l.icon).map((link) => (
                      <Link
                        key={link.href}
                        href={link.href}
                        onClick={() => setJobsOpen(false)}
                        data-testid={`link-nav-industry-${link.label.toLowerCase().replace(/[\s&]/g, "-")}`}
                      >
                        <div className="px-3 py-2 text-sm text-muted-foreground hover-elevate active-elevate-2 rounded-sm cursor-pointer">
                          {link.label}
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div
              ref={countryRef}
              className="relative"
              onMouseEnter={() => setCountryOpen(true)}
              onMouseLeave={() => setCountryOpen(false)}
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setCountryOpen(!countryOpen)}
                data-testid="button-nav-countries"
              >
                <Globe className="h-3.5 w-3.5 mr-1" />
                Countries
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
              <div
                className="absolute top-full right-0 mt-1 w-[520px] bg-popover border border-border rounded-md shadow-lg p-4 z-50"
                style={{ visibility: countryOpen ? "visible" : "hidden" }}
              >
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">Browse by Country</p>
                <div className="grid grid-cols-2 gap-0.5">
                  {countryLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setCountryOpen(false)}
                      data-testid={`link-nav-country-${link.label.toLowerCase().replace(/\s/g, "-")}`}
                    >
                      <div className="px-3 py-2.5 text-sm text-muted-foreground hover-elevate active-elevate-2 rounded-md cursor-pointer flex items-center gap-2.5">
                        <img
                          src={`https://flagcdn.com/20x15/${link.code}.png`}
                          alt={link.label}
                          className="w-5 h-[15px] rounded-sm object-cover shadow-sm"
                          loading="lazy"
                        />
                        <span className="font-medium">{link.label}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            <div
              ref={studentRef}
              className="relative"
              onMouseEnter={() => setStudentOpen(true)}
              onMouseLeave={() => setStudentOpen(false)}
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setStudentOpen(!studentOpen)}
                data-testid="button-nav-students"
              >
                <GraduationCap className="h-3.5 w-3.5 mr-1" />
                Students
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
              <div
                className="absolute top-full right-0 mt-1 w-80 bg-popover border border-border rounded-md shadow-lg py-2 z-50"
                style={{ visibility: studentOpen ? "visible" : "hidden" }}
              >
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-4">Student Resources</p>
                {studentLinks.map((link) => {
                  const Icon = link.icon;
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setStudentOpen(false)}
                      data-testid={`link-nav-student-${link.label.toLowerCase().replace(/[\s&]/g, "-")}`}
                    >
                      <div className="px-4 py-2.5 text-sm hover-elevate active-elevate-2 rounded-sm cursor-pointer mx-1 flex items-start gap-3">
                        <Icon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                        <div>
                          <div className="font-medium text-sm">{link.label}</div>
                          <div className="text-xs text-muted-foreground">{link.desc}</div>
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>

            <div
              ref={toolsRef}
              className="relative"
              onMouseEnter={() => setToolsOpen(true)}
              onMouseLeave={() => setToolsOpen(false)}
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setToolsOpen(!toolsOpen)}
                data-testid="button-nav-tools"
              >
                <Wrench className="h-3.5 w-3.5 mr-1" />
                Tools
                <ChevronDown className="h-3 w-3 ml-1" />
              </Button>
              <div
                className="absolute top-full right-0 mt-1 w-72 bg-popover border border-border rounded-md shadow-lg py-2 z-50"
                style={{ visibility: toolsOpen ? "visible" : "hidden" }}
              >
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-4">Free HR & Career Tools</p>
                {toolLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setToolsOpen(false)}
                    data-testid={`link-nav-tool-${link.label.toLowerCase().replace(/[\s&/]/g, "-")}`}
                  >
                    <div className="px-4 py-2.5 text-sm hover-elevate active-elevate-2 rounded-sm cursor-pointer mx-1">
                      <div className="font-medium text-sm">{link.label}</div>
                      <div className="text-xs text-muted-foreground">{link.desc}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </nav>

          <div className="flex items-center gap-2">
            <Link href="/blog" className="hidden sm:block">
              <Button variant="ghost" size="sm" data-testid="link-blog">
                Blog
              </Button>
            </Link>
            <Link href="/pricing" className="hidden sm:block">
              <Button variant="ghost" size="sm" data-testid="link-pricing">
                Pricing
              </Button>
            </Link>
            <Link href="/post-job">
              <Button size="sm" data-testid="link-post-job">
                <Briefcase className="h-4 w-4 mr-1.5" />
                <span className="hidden sm:inline">Post a Job</span>
                <span className="sm:hidden">Post</span>
              </Button>
            </Link>
            <ThemeToggle />
            <Button
              size="icon"
              variant="ghost"
              className="lg:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      <div
        className="lg:hidden border-t border-border bg-background/95 glass-effect max-h-[80vh] overflow-y-auto"
        style={{ display: mobileOpen ? "block" : "none" }}
      >
        <nav className="flex flex-col p-3 gap-0.5">
          <p className="px-3 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Jobs by Source</p>
          {jobLinks.filter(l => l.icon).map((link) => (
            <Link key={link.href} href={link.href} onClick={closeMobile}>
              <Button
                variant={location === link.href ? "secondary" : "ghost"}
                className="w-full justify-start"
                size="sm"
                data-testid={`link-mobile-${link.label.toLowerCase().replace(/\s/g, "-")}`}
              >
                {link.label}
              </Button>
            </Link>
          ))}
          <p className="px-3 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider mt-3">Jobs by Industry</p>
          {jobLinks.filter(l => !l.icon).map((link) => (
            <Link key={link.href} href={link.href} onClick={closeMobile}>
              <Button
                variant={location === link.href ? "secondary" : "ghost"}
                className="w-full justify-start"
                size="sm"
                data-testid={`link-mobile-industry-${link.label.toLowerCase().replace(/[\s&]/g, "-")}`}
              >
                {link.label}
              </Button>
            </Link>
          ))}
          <p className="px-3 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider mt-3">Countries</p>
          <div className="grid grid-cols-2 gap-0.5 px-1">
            {countryLinks.slice(0, 20).map((link) => (
              <Link key={link.href} href={link.href} onClick={closeMobile}>
                <Button
                  variant="ghost"
                  className="w-full justify-start text-xs"
                  size="sm"
                  data-testid={`link-mobile-country-${link.label.toLowerCase().replace(/\s/g, "-")}`}
                >
                  <img
                    src={`https://flagcdn.com/16x12/${link.code}.png`}
                    alt={link.label}
                    className="w-4 h-3 rounded-sm mr-1.5"
                    loading="lazy"
                  />
                  {link.label}
                </Button>
              </Link>
            ))}
          </div>
          <p className="px-3 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider mt-3">Student Resources</p>
          {studentLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Link key={link.href} href={link.href} onClick={closeMobile}>
                <Button
                  variant={location === link.href ? "secondary" : "ghost"}
                  className="w-full justify-start"
                  size="sm"
                  data-testid={`link-mobile-student-${link.label.toLowerCase().replace(/[\s&]/g, "-")}`}
                >
                  <Icon className="h-4 w-4 mr-1.5" />
                  {link.label}
                </Button>
              </Link>
            );
          })}
          <p className="px-3 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider mt-3">Free Tools</p>
          {toolLinks.map((link) => (
            <Link key={link.href} href={link.href} onClick={closeMobile}>
              <Button
                variant={location === link.href ? "secondary" : "ghost"}
                className="w-full justify-start"
                size="sm"
                data-testid={`link-mobile-tool-${link.label.toLowerCase().replace(/[\s&/]/g, "-")}`}
              >
                {link.label}
              </Button>
            </Link>
          ))}
          <div className="border-t border-border mt-3 pt-3">
            <Link href="/blog" onClick={closeMobile}>
              <Button variant="ghost" className="w-full justify-start" size="sm" data-testid="link-mobile-blog">
                <BookOpen className="h-4 w-4 mr-1.5" />
                Career Blog
              </Button>
            </Link>
            <Link href="/pricing" onClick={closeMobile}>
              <Button variant="ghost" className="w-full justify-start" size="sm" data-testid="link-mobile-pricing">
                <DollarSign className="h-4 w-4 mr-1.5" />
                Pricing
              </Button>
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
