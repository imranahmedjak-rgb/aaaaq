import { useState } from "react";

interface SaveJobButtonProps {
  jobId: number;
  accountId?: number;
}

export function SaveJobButton({ jobId, accountId }: SaveJobButtonProps) {
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  async function toggleSave() {
    if (!accountId) {
      alert("Please log in to save jobs.");
      return;
    }
    setLoading(true);
    try {
      if (saved) {
        await fetch(`/api/saved-jobs/${jobId}`, { method: "DELETE" });
        setSaved(false);
      } else {
        await fetch("/api/saved-jobs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ accountId, jobId }),
        });
        setSaved(true);
      }
    } catch {
      alert("Failed to save job. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={toggleSave}
      disabled={loading}
      className={`flex items-center gap-1 px-3 py-1 rounded border text-sm transition ${
        saved ? "bg-blue-600 text-white border-blue-600" : "border-gray-300 hover:bg-gray-50"
      }`}
      aria-label={saved ? "Remove from saved jobs" : "Save job"}
    >
      <svg className="w-4 h-4" fill={saved ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
      </svg>
      {saved ? "Saved" : "Save Job"}
    </button>
  );
}

export default SaveJobButton;
