import { useEffect, useState } from "react";

interface PublicStats {
  totalJobs: number;
  countries: number;
  companies: number;
}

export function StatsBar() {
  const [stats, setStats] = useState<PublicStats | null>(null);

  useEffect(() => {
    fetch("/api/public-stats")
      .then((r) => r.json())
      .then((data) => setStats(data))
      .catch(() => {});
  }, []);

  if (!stats) return null;

  return (
    <div className="bg-blue-600 text-white py-3">
      <div className="max-w-5xl mx-auto flex justify-around text-center">
        <div>
          <div className="text-2xl font-bold">{stats.totalJobs.toLocaleString()}+</div>
          <div className="text-xs opacity-80">Active Jobs</div>
        </div>
        <div>
          <div className="text-2xl font-bold">{stats.countries}+</div>
          <div className="text-xs opacity-80">Countries</div>
        </div>
        <div>
          <div className="text-2xl font-bold">{stats.companies.toLocaleString()}+</div>
          <div className="text-xs opacity-80">Companies</div>
        </div>
      </div>
    </div>
  );
}

export default StatsBar;
