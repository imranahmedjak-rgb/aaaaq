import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type Language = "en" | "es" | "fr" | "ar" | "pt" | "de" | "zh" | "hi" | "ja" | "ru";

export const LANGUAGES: { code: Language; label: string; nativeLabel: string; flag: string; dir?: "rtl" }[] = [
  { code: "en", label: "English", nativeLabel: "English", flag: "gb" },
  { code: "es", label: "Spanish", nativeLabel: "Español", flag: "es" },
  { code: "fr", label: "French", nativeLabel: "Français", flag: "fr" },
  { code: "ar", label: "Arabic", nativeLabel: "العربية", flag: "sa", dir: "rtl" },
  { code: "pt", label: "Portuguese", nativeLabel: "Português", flag: "br" },
  { code: "de", label: "German", nativeLabel: "Deutsch", flag: "de" },
  { code: "zh", label: "Chinese", nativeLabel: "中文", flag: "cn" },
  { code: "hi", label: "Hindi", nativeLabel: "हिंदी", flag: "in" },
  { code: "ja", label: "Japanese", nativeLabel: "日本語", flag: "jp" },
  { code: "ru", label: "Russian", nativeLabel: "Русский", flag: "ru" },
];

type Translations = {
  nav: {
    jobs: string;
    countries: string;
    students: string;
    tools: string;
    blog: string;
    pricing: string;
    postJob: string;
  };
  hero: {
    heading: string;
    subheading: string;
    searchPlaceholder: string;
    browseJobs: string;
    totalJobs: string;
  };
  jobCard: {
    apply: string;
    save: string;
    saved: string;
    featured: string;
    daysLeft: string;
    remote: string;
    fullTime: string;
    partTime: string;
    contract: string;
  };
  common: {
    share: string;
    loadMore: string;
    noResults: string;
    loading: string;
    verified: string;
    newJobs: string;
    privacyPolicy: string;
    termsOfService: string;
    refundPolicy: string;
    cookiePolicy: string;
    contactUs: string;
    aboutUs: string;
  };
  cookie: {
    message: string;
    accept: string;
    decline: string;
    learnMore: string;
  };
};

const translations: Record<Language, Translations> = {
  en: {
    nav: {
      jobs: "Jobs",
      countries: "Countries",
      students: "Students",
      tools: "Tools",
      blog: "Blog",
      pricing: "Pricing",
      postJob: "Post a Job",
    },
    hero: {
      heading: "Find Your Next International Career",
      subheading: "Thousands of verified opportunities from UN agencies, NGOs, remote companies, and global employers worldwide.",
      searchPlaceholder: "Search jobs, companies, locations...",
      browseJobs: "Browse Jobs",
      totalJobs: "international opportunities",
    },
    jobCard: {
      apply: "Apply Now",
      save: "Save",
      saved: "Saved",
      featured: "Featured",
      daysLeft: "days left",
      remote: "Remote",
      fullTime: "Full-time",
      partTime: "Part-time",
      contract: "Contract",
    },
    common: {
      share: "Share",
      loadMore: "Load More",
      noResults: "No jobs found",
      loading: "Loading...",
      verified: "Verified",
      newJobs: "new jobs today",
      privacyPolicy: "Privacy Policy",
      termsOfService: "Terms of Service",
      refundPolicy: "Refund Policy",
      cookiePolicy: "Cookie Policy",
      contactUs: "Contact Us",
      aboutUs: "About Us",
    },
    cookie: {
      message: "We use cookies to improve your experience, analyze site traffic, and serve relevant ads. By continuing, you agree to our cookie policy.",
      accept: "Accept All",
      decline: "Decline",
      learnMore: "Learn More",
    },
  },
  es: {
    nav: {
      jobs: "Empleos",
      countries: "Países",
      students: "Estudiantes",
      tools: "Herramientas",
      blog: "Blog",
      pricing: "Precios",
      postJob: "Publicar Empleo",
    },
    hero: {
      heading: "Encuentra tu Próxima Carrera Internacional",
      subheading: "Miles de oportunidades verificadas de agencias de la ONU, ONG, empresas remotas y empleadores globales.",
      searchPlaceholder: "Buscar empleos, empresas, ubicaciones...",
      browseJobs: "Ver Empleos",
      totalJobs: "oportunidades internacionales",
    },
    jobCard: {
      apply: "Aplicar Ahora",
      save: "Guardar",
      saved: "Guardado",
      featured: "Destacado",
      daysLeft: "días restantes",
      remote: "Remoto",
      fullTime: "Tiempo Completo",
      partTime: "Medio Tiempo",
      contract: "Contrato",
    },
    common: {
      share: "Compartir",
      loadMore: "Cargar Más",
      noResults: "No se encontraron empleos",
      loading: "Cargando...",
      verified: "Verificado",
      newJobs: "nuevos empleos hoy",
      privacyPolicy: "Política de Privacidad",
      termsOfService: "Términos de Servicio",
      refundPolicy: "Política de Reembolso",
      cookiePolicy: "Política de Cookies",
      contactUs: "Contáctenos",
      aboutUs: "Sobre Nosotros",
    },
    cookie: {
      message: "Usamos cookies para mejorar su experiencia, analizar el tráfico del sitio y mostrar anuncios relevantes. Al continuar, acepta nuestra política de cookies.",
      accept: "Aceptar Todo",
      decline: "Rechazar",
      learnMore: "Más Información",
    },
  },
  fr: {
    nav: {
      jobs: "Emplois",
      countries: "Pays",
      students: "Étudiants",
      tools: "Outils",
      blog: "Blog",
      pricing: "Tarifs",
      postJob: "Publier un Emploi",
    },
    hero: {
      heading: "Trouvez Votre Prochaine Carrière Internationale",
      subheading: "Des milliers d'opportunités vérifiées d'agences de l'ONU, d'ONG, d'entreprises à distance et d'employeurs mondiaux.",
      searchPlaceholder: "Rechercher des emplois, entreprises, lieux...",
      browseJobs: "Voir les Emplois",
      totalJobs: "opportunités internationales",
    },
    jobCard: {
      apply: "Postuler",
      save: "Sauvegarder",
      saved: "Sauvegardé",
      featured: "En Vedette",
      daysLeft: "jours restants",
      remote: "Télétravail",
      fullTime: "Temps Plein",
      partTime: "Temps Partiel",
      contract: "Contrat",
    },
    common: {
      share: "Partager",
      loadMore: "Charger Plus",
      noResults: "Aucun emploi trouvé",
      loading: "Chargement...",
      verified: "Vérifié",
      newJobs: "nouveaux emplois aujourd'hui",
      privacyPolicy: "Politique de Confidentialité",
      termsOfService: "Conditions d'Utilisation",
      refundPolicy: "Politique de Remboursement",
      cookiePolicy: "Politique des Cookies",
      contactUs: "Nous Contacter",
      aboutUs: "À Propos",
    },
    cookie: {
      message: "Nous utilisons des cookies pour améliorer votre expérience, analyser le trafic du site et diffuser des annonces pertinentes. En continuant, vous acceptez notre politique de cookies.",
      accept: "Tout Accepter",
      decline: "Refuser",
      learnMore: "En Savoir Plus",
    },
  },
  ar: {
    nav: {
      jobs: "الوظائف",
      countries: "الدول",
      students: "الطلاب",
      tools: "الأدوات",
      blog: "المدونة",
      pricing: "الأسعار",
      postJob: "نشر وظيفة",
    },
    hero: {
      heading: "ابحث عن مسيرتك المهنية الدولية التالية",
      subheading: "آلاف الفرص الموثقة من وكالات الأمم المتحدة والمنظمات غير الحكومية والشركات عن بُعد وأصحاب العمل العالميين.",
      searchPlaceholder: "ابحث عن وظائف، شركات، مواقع...",
      browseJobs: "تصفح الوظائف",
      totalJobs: "فرصة دولية",
    },
    jobCard: {
      apply: "قدّم الآن",
      save: "حفظ",
      saved: "محفوظ",
      featured: "مميز",
      daysLeft: "أيام متبقية",
      remote: "عن بُعد",
      fullTime: "دوام كامل",
      partTime: "دوام جزئي",
      contract: "عقد",
    },
    common: {
      share: "مشاركة",
      loadMore: "تحميل المزيد",
      noResults: "لا توجد وظائف",
      loading: "جاري التحميل...",
      verified: "موثق",
      newJobs: "وظائف جديدة اليوم",
      privacyPolicy: "سياسة الخصوصية",
      termsOfService: "شروط الخدمة",
      refundPolicy: "سياسة الاسترداد",
      cookiePolicy: "سياسة ملفات تعريف الارتباط",
      contactUs: "اتصل بنا",
      aboutUs: "من نحن",
    },
    cookie: {
      message: "نستخدم ملفات تعريف الارتباط لتحسين تجربتك وتحليل حركة الموقع وعرض إعلانات ذات صلة. بالاستمرار، فإنك توافق على سياسة ملفات تعريف الارتباط لدينا.",
      accept: "قبول الكل",
      decline: "رفض",
      learnMore: "معرفة المزيد",
    },
  },
  pt: {
    nav: {
      jobs: "Empregos",
      countries: "Países",
      students: "Estudantes",
      tools: "Ferramentas",
      blog: "Blog",
      pricing: "Preços",
      postJob: "Publicar Vaga",
    },
    hero: {
      heading: "Encontre Sua Próxima Carreira Internacional",
      subheading: "Milhares de oportunidades verificadas de agências da ONU, ONGs, empresas remotas e empregadores globais.",
      searchPlaceholder: "Pesquisar empregos, empresas, locais...",
      browseJobs: "Ver Empregos",
      totalJobs: "oportunidades internacionais",
    },
    jobCard: {
      apply: "Candidatar",
      save: "Salvar",
      saved: "Salvo",
      featured: "Destaque",
      daysLeft: "dias restantes",
      remote: "Remoto",
      fullTime: "Tempo Integral",
      partTime: "Meio Período",
      contract: "Contrato",
    },
    common: {
      share: "Compartilhar",
      loadMore: "Carregar Mais",
      noResults: "Nenhum emprego encontrado",
      loading: "Carregando...",
      verified: "Verificado",
      newJobs: "novos empregos hoje",
      privacyPolicy: "Política de Privacidade",
      termsOfService: "Termos de Serviço",
      refundPolicy: "Política de Reembolso",
      cookiePolicy: "Política de Cookies",
      contactUs: "Contate-nos",
      aboutUs: "Sobre Nós",
    },
    cookie: {
      message: "Usamos cookies para melhorar sua experiência, analisar o tráfego do site e exibir anúncios relevantes. Ao continuar, você concorda com nossa política de cookies.",
      accept: "Aceitar Tudo",
      decline: "Recusar",
      learnMore: "Saiba Mais",
    },
  },
  de: {
    nav: {
      jobs: "Jobs",
      countries: "Länder",
      students: "Studenten",
      tools: "Tools",
      blog: "Blog",
      pricing: "Preise",
      postJob: "Job Inserieren",
    },
    hero: {
      heading: "Finden Sie Ihre Nächste Internationale Karriere",
      subheading: "Tausende verifizierte Möglichkeiten von UN-Agenturen, NGOs, Remote-Unternehmen und globalen Arbeitgebern.",
      searchPlaceholder: "Jobs, Unternehmen, Standorte suchen...",
      browseJobs: "Jobs Durchsuchen",
      totalJobs: "internationale Stellenangebote",
    },
    jobCard: {
      apply: "Jetzt Bewerben",
      save: "Speichern",
      saved: "Gespeichert",
      featured: "Hervorgehoben",
      daysLeft: "Tage verbleibend",
      remote: "Remote",
      fullTime: "Vollzeit",
      partTime: "Teilzeit",
      contract: "Vertrag",
    },
    common: {
      share: "Teilen",
      loadMore: "Mehr Laden",
      noResults: "Keine Jobs gefunden",
      loading: "Laden...",
      verified: "Verifiziert",
      newJobs: "neue Jobs heute",
      privacyPolicy: "Datenschutzrichtlinie",
      termsOfService: "Nutzungsbedingungen",
      refundPolicy: "Rückerstattungsrichtlinie",
      cookiePolicy: "Cookie-Richtlinie",
      contactUs: "Kontaktieren Sie uns",
      aboutUs: "Über Uns",
    },
    cookie: {
      message: "Wir verwenden Cookies, um Ihre Erfahrung zu verbessern, den Website-Traffic zu analysieren und relevante Anzeigen zu schalten. Durch das Fortfahren stimmen Sie unserer Cookie-Richtlinie zu.",
      accept: "Alle Akzeptieren",
      decline: "Ablehnen",
      learnMore: "Mehr Erfahren",
    },
  },
  zh: {
    nav: {
      jobs: "职位",
      countries: "国家",
      students: "学生",
      tools: "工具",
      blog: "博客",
      pricing: "定价",
      postJob: "发布职位",
    },
    hero: {
      heading: "寻找您的下一份国际职业",
      subheading: "来自联合国机构、非政府组织、远程公司和全球雇主的数千个经过验证的机会。",
      searchPlaceholder: "搜索工作、公司、地点...",
      browseJobs: "浏览职位",
      totalJobs: "个国际机会",
    },
    jobCard: {
      apply: "立即申请",
      save: "收藏",
      saved: "已收藏",
      featured: "精选",
      daysLeft: "天剩余",
      remote: "远程",
      fullTime: "全职",
      partTime: "兼职",
      contract: "合同",
    },
    common: {
      share: "分享",
      loadMore: "加载更多",
      noResults: "未找到职位",
      loading: "加载中...",
      verified: "已验证",
      newJobs: "今日新职位",
      privacyPolicy: "隐私政策",
      termsOfService: "服务条款",
      refundPolicy: "退款政策",
      cookiePolicy: "Cookie政策",
      contactUs: "联系我们",
      aboutUs: "关于我们",
    },
    cookie: {
      message: "我们使用Cookie来改善您的体验、分析网站流量并投放相关广告。继续使用即表示您同意我们的Cookie政策。",
      accept: "全部接受",
      decline: "拒绝",
      learnMore: "了解更多",
    },
  },
  hi: {
    nav: {
      jobs: "नौकरियाँ",
      countries: "देश",
      students: "छात्र",
      tools: "उपकरण",
      blog: "ब्लॉग",
      pricing: "मूल्य",
      postJob: "नौकरी पोस्ट करें",
    },
    hero: {
      heading: "अपना अगला अंतर्राष्ट्रीय करियर खोजें",
      subheading: "संयुक्त राष्ट्र एजेंसियों, NGOs, रिमोट कंपनियों और वैश्विक नियोक्ताओं से हजारों सत्यापित अवसर।",
      searchPlaceholder: "नौकरियाँ, कंपनियाँ, स्थान खोजें...",
      browseJobs: "नौकरियाँ देखें",
      totalJobs: "अंतर्राष्ट्रीय अवसर",
    },
    jobCard: {
      apply: "अभी आवेदन करें",
      save: "सहेजें",
      saved: "सहेजा गया",
      featured: "विशेष",
      daysLeft: "दिन शेष",
      remote: "दूरस्थ",
      fullTime: "पूर्णकालिक",
      partTime: "अंशकालिक",
      contract: "अनुबंध",
    },
    common: {
      share: "साझा करें",
      loadMore: "और लोड करें",
      noResults: "कोई नौकरी नहीं मिली",
      loading: "लोड हो रहा है...",
      verified: "सत्यापित",
      newJobs: "आज की नई नौकरियाँ",
      privacyPolicy: "गोपनीयता नीति",
      termsOfService: "सेवा की शर्तें",
      refundPolicy: "वापसी नीति",
      cookiePolicy: "कुकी नीति",
      contactUs: "हमसे संपर्क करें",
      aboutUs: "हमारे बारे में",
    },
    cookie: {
      message: "हम आपके अनुभव को बेहतर बनाने, साइट ट्रैफ़िक का विश्लेषण करने और प्रासंगिक विज्ञापन दिखाने के लिए कुकीज़ का उपयोग करते हैं। जारी रखकर, आप हमारी कुकी नीति से सहमत होते हैं।",
      accept: "सभी स्वीकार करें",
      decline: "अस्वीकार करें",
      learnMore: "और जानें",
    },
  },
  ja: {
    nav: {
      jobs: "求人",
      countries: "国別",
      students: "学生",
      tools: "ツール",
      blog: "ブログ",
      pricing: "料金",
      postJob: "求人掲載",
    },
    hero: {
      heading: "次の国際キャリアを見つけよう",
      subheading: "国連機関、NGO、リモート企業、グローバル雇用主からの数千件の認証済み求人。",
      searchPlaceholder: "求人、企業、場所を検索...",
      browseJobs: "求人を見る",
      totalJobs: "件の国際的な機会",
    },
    jobCard: {
      apply: "今すぐ応募",
      save: "保存",
      saved: "保存済み",
      featured: "注目",
      daysLeft: "日残り",
      remote: "リモート",
      fullTime: "フルタイム",
      partTime: "パートタイム",
      contract: "契約",
    },
    common: {
      share: "シェア",
      loadMore: "さらに読む",
      noResults: "求人が見つかりません",
      loading: "読み込み中...",
      verified: "認証済み",
      newJobs: "本日の新着求人",
      privacyPolicy: "プライバシーポリシー",
      termsOfService: "利用規約",
      refundPolicy: "返金ポリシー",
      cookiePolicy: "Cookieポリシー",
      contactUs: "お問い合わせ",
      aboutUs: "会社概要",
    },
    cookie: {
      message: "当サイトでは、ユーザー体験の向上、トラフィック分析、関連広告の表示のためにCookieを使用しています。続行することで、Cookie ポリシーに同意したことになります。",
      accept: "すべて承諾",
      decline: "辞退",
      learnMore: "詳細",
    },
  },
  ru: {
    nav: {
      jobs: "Вакансии",
      countries: "Страны",
      students: "Студентам",
      tools: "Инструменты",
      blog: "Блог",
      pricing: "Цены",
      postJob: "Разместить Вакансию",
    },
    hero: {
      heading: "Найдите Свою Следующую Международную Карьеру",
      subheading: "Тысячи проверенных возможностей от агентств ООН, НКО, удалённых компаний и глобальных работодателей.",
      searchPlaceholder: "Поиск вакансий, компаний, мест...",
      browseJobs: "Просмотр Вакансий",
      totalJobs: "международных возможностей",
    },
    jobCard: {
      apply: "Откликнуться",
      save: "Сохранить",
      saved: "Сохранено",
      featured: "Рекомендуемое",
      daysLeft: "дней осталось",
      remote: "Удалённо",
      fullTime: "Полная занятость",
      partTime: "Частичная занятость",
      contract: "Контракт",
    },
    common: {
      share: "Поделиться",
      loadMore: "Загрузить Ещё",
      noResults: "Вакансии не найдены",
      loading: "Загрузка...",
      verified: "Проверено",
      newJobs: "новых вакансий сегодня",
      privacyPolicy: "Политика конфиденциальности",
      termsOfService: "Условия использования",
      refundPolicy: "Политика возврата",
      cookiePolicy: "Политика Cookies",
      contactUs: "Связаться с нами",
      aboutUs: "О нас",
    },
    cookie: {
      message: "Мы используем файлы cookie для улучшения вашего опыта, анализа трафика сайта и показа релевантной рекламы. Продолжая, вы соглашаетесь с нашей политикой cookie.",
      accept: "Принять все",
      decline: "Отклонить",
      learnMore: "Узнать больше",
    },
  },
};

type I18nContextType = {
  lang: Language;
  setLang: (lang: Language) => void;
  t: Translations;
  dir: "ltr" | "rtl";
};

const I18nContext = createContext<I18nContextType>({
  lang: "en",
  setLang: () => {},
  t: translations.en,
  dir: "ltr",
});

function detectLanguage(): Language {
  const stored = localStorage.getItem("dgj_lang") as Language | null;
  if (stored && translations[stored]) return stored;
  const urlParam = new URLSearchParams(window.location.search).get("lang") as Language | null;
  if (urlParam && translations[urlParam]) return urlParam;
  const browserLang = navigator.language.split("-")[0] as Language;
  if (translations[browserLang]) return browserLang;
  return "en";
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Language>("en");

  useEffect(() => {
    const detected = detectLanguage();
    setLangState(detected);
    document.documentElement.lang = detected;
    const langDef = LANGUAGES.find(l => l.code === detected);
    document.documentElement.dir = langDef?.dir || "ltr";
  }, []);

  function setLang(newLang: Language) {
    setLangState(newLang);
    localStorage.setItem("dgj_lang", newLang);
    document.documentElement.lang = newLang;
    const langDef = LANGUAGES.find(l => l.code === newLang);
    document.documentElement.dir = langDef?.dir || "ltr";
    const url = new URL(window.location.href);
    if (newLang === "en") {
      url.searchParams.delete("lang");
    } else {
      url.searchParams.set("lang", newLang);
    }
    window.history.replaceState({}, "", url.toString());
  }

  const langDef = LANGUAGES.find(l => l.code === lang);
  const dir = langDef?.dir === "rtl" ? "rtl" : "ltr";

  return (
    <I18nContext.Provider value={{ lang, setLang, t: translations[lang], dir }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}
