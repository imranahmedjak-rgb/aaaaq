export function getJobEngagement(jobId: number, isFeatured: boolean = false, postedAt?: string | Date | null): { views: number; applies: number; shares: number } {
  let hash = jobId * 2654435761;
  hash = ((hash >>> 16) ^ hash) * 0x45d9f3b;
  hash = ((hash >>> 16) ^ hash) * 0x45d9f3b;
  hash = (hash >>> 16) ^ hash;
  const norm1 = (Math.abs(hash) % 10000) / 10000;
  const norm2 = (Math.abs(hash * 31 + 7) % 10000) / 10000;
  const norm3 = (Math.abs(hash * 53 + 13) % 10000) / 10000;

  let ageDays = 14;
  if (postedAt) {
    const posted = new Date(postedAt);
    const now = new Date();
    ageDays = Math.max(0, (now.getTime() - posted.getTime()) / (1000 * 60 * 60 * 24));
  }

  let viewsMin: number, viewsMax: number;
  let appliesMin: number, appliesMax: number;
  let sharesMin: number, sharesMax: number;

  if (isFeatured) {
    if (ageDays < 1) {
      viewsMin = 25; viewsMax = 120;
      appliesMin = 3; appliesMax = 15;
      sharesMin = 2; sharesMax = 10;
    } else if (ageDays < 3) {
      viewsMin = 200; viewsMax = 800;
      appliesMin = 20; appliesMax = 80;
      sharesMin = 10; sharesMax = 50;
    } else if (ageDays < 7) {
      viewsMin = 800; viewsMax = 3500;
      appliesMin = 80; appliesMax = 350;
      sharesMin = 40; sharesMax = 200;
    } else if (ageDays < 14) {
      viewsMin = 3500; viewsMax = 12000;
      appliesMin = 350; appliesMax = 1200;
      sharesMin = 150; sharesMax = 800;
    } else {
      viewsMin = 12000; viewsMax = 45000;
      appliesMin = 1000; appliesMax = 4500;
      sharesMin = 600; sharesMax = 4500;
    }
  } else {
    if (ageDays < 1) {
      viewsMin = 12; viewsMax = 75;
      appliesMin = 1; appliesMax = 8;
      sharesMin = 0; sharesMax = 5;
    } else if (ageDays < 3) {
      viewsMin = 80; viewsMax = 400;
      appliesMin = 8; appliesMax = 45;
      sharesMin = 3; sharesMax = 25;
    } else if (ageDays < 7) {
      viewsMin = 400; viewsMax = 2000;
      appliesMin = 40; appliesMax = 200;
      sharesMin = 15; sharesMax = 100;
    } else if (ageDays < 14) {
      viewsMin = 1500; viewsMax = 6000;
      appliesMin = 120; appliesMax = 600;
      sharesMin = 40; sharesMax = 350;
    } else {
      viewsMin = 2500; viewsMax = 15000;
      appliesMin = 150; appliesMax = 1500;
      sharesMin = 50; sharesMax = 1000;
    }
  }

  return {
    views: Math.floor(viewsMin + norm1 * (viewsMax - viewsMin)),
    applies: Math.floor(appliesMin + norm2 * (appliesMax - appliesMin)),
    shares: Math.floor(sharesMin + norm3 * (sharesMax - sharesMin)),
  };
}
