function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function isHtml(text: string): boolean {
  return /<\/?[a-z][\s\S]*>/i.test(text);
}

function markdownToHtml(text: string): string {
  let html = escapeHtml(text);

  html = html.replace(/^######\s+(.+)$/gm, '<h6>$1</h6>');
  html = html.replace(/^#####\s+(.+)$/gm, '<h5>$1</h5>');
  html = html.replace(/^####\s+(.+)$/gm, '<h4>$1</h4>');
  html = html.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^##\s+(.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^#\s+(.+)$/gm, '<h3>$1</h3>');

  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');

  html = html.replace(/(?<!\*)\*([^*\n]+?)\*(?!\*)/g, '<em>$1</em>');
  html = html.replace(/(?<!_)_([^_\n]+?)_(?!_)/g, '<em>$1</em>');

  html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');

  html = html.replace(/^---+$/gm, '<hr />');

  const lines = html.split('\n');
  const result: string[] = [];
  let inList = false;
  let listType = '';
  let paragraphBuffer: string[] = [];

  const flushParagraph = () => {
    if (paragraphBuffer.length > 0) {
      const content = paragraphBuffer.join(' ').trim();
      if (content) {
        result.push(`<p>${content}</p>`);
      }
      paragraphBuffer = [];
    }
  };

  const flushList = () => {
    if (inList) {
      result.push(listType === 'ul' ? '</ul>' : '</ol>');
      inList = false;
      listType = '';
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    if (trimmed.startsWith('<h') || trimmed.startsWith('<hr')) {
      flushParagraph();
      flushList();
      result.push(trimmed);
      continue;
    }

    const ulMatch = trimmed.match(/^[-*•]\s+(.+)/);
    const olMatch = trimmed.match(/^\d+[.)]\s+(.+)/);

    if (ulMatch) {
      flushParagraph();
      if (!inList || listType !== 'ul') {
        flushList();
        result.push('<ul>');
        inList = true;
        listType = 'ul';
      }
      result.push(`<li>${ulMatch[1]}</li>`);
      continue;
    }

    if (olMatch) {
      flushParagraph();
      if (!inList || listType !== 'ol') {
        flushList();
        result.push('<ol>');
        inList = true;
        listType = 'ol';
      }
      result.push(`<li>${olMatch[1]}</li>`);
      continue;
    }

    flushList();

    if (trimmed === '') {
      flushParagraph();
      continue;
    }

    paragraphBuffer.push(trimmed);
  }

  flushParagraph();
  flushList();

  return result.join('\n');
}

function cleanHtml(html: string): string {
  let cleaned = html;

  cleaned = cleaned.replace(/<br\s*\/?>\s*<br\s*\/?>/gi, '</p><p>');

  cleaned = cleaned.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  cleaned = cleaned.replace(/__(.+?)__/g, '<strong>$1</strong>');

  if (!/<(p|div|h[1-6]|ul|ol|li|br|hr|table|section|article)/i.test(cleaned)) {
    cleaned = cleaned.split(/\n{2,}/).map(p => `<p>${p.trim()}</p>`).join('');
    cleaned = cleaned.replace(/\n/g, '<br />');
  }

  return cleaned;
}

export function formatJobDescription(description: string): string {
  if (!description || !description.trim()) return '';

  const trimmed = description.trim();

  if (isHtml(trimmed)) {
    return cleanHtml(trimmed);
  }

  return markdownToHtml(trimmed);
}
