import { useEffect } from "react";
import { useLocation } from "wouter";

const BASE_URL = "https://devglobaljobs.com";

export function useCanonical(override?: string) {
  const [location] = useLocation();
  useEffect(() => {
    const canonical = override || `${BASE_URL}${location === "/" ? "" : location}`;
    let el = document.querySelector("link[rel='canonical']") as HTMLLinkElement | null;
    if (!el) {
      el = document.createElement("link");
      el.rel = "canonical";
      document.head.appendChild(el);
    }
    el.href = canonical;
  }, [location, override]);
}

export function useSEO({
  title,
  description,
  canonical,
  ogImage,
  noindex,
}: {
  title: string;
  description: string;
  canonical?: string;
  ogImage?: string;
  noindex?: boolean;
}) {
  const [location] = useLocation();

  useEffect(() => {
    document.title = title;

    const setMeta = (selector: string, attr: string, value: string) => {
      let el = document.querySelector(selector) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        const [attrName, attrVal] = selector.replace(/[[\]']/g, "").split("=");
        el.setAttribute(attrName.replace("meta[", ""), attrVal);
        document.head.appendChild(el);
      }
      el.setAttribute(attr, value);
    };

    setMeta("meta[name='description']", "content", description);
    setMeta("meta[property='og:title']", "content", title);
    setMeta("meta[property='og:description']", "content", description);
    setMeta("meta[property='og:url']", "content", canonical || `${BASE_URL}${location}`);
    setMeta("meta[property='og:type']", "content", "website");

    if (ogImage) {
      setMeta("meta[property='og:image']", "content", ogImage);
      setMeta("meta[name='twitter:image']", "content", ogImage);
    }
    setMeta("meta[name='twitter:card']", "content", "summary_large_image");
    setMeta("meta[name='twitter:title']", "content", title);
    setMeta("meta[name='twitter:description']", "content", description);

    if (noindex) {
      setMeta("meta[name='robots']", "content", "noindex, nofollow");
    } else {
      setMeta("meta[name='robots']", "content", "index, follow");
    }

    let canonicalEl = document.querySelector("link[rel='canonical']") as HTMLLinkElement | null;
    if (!canonicalEl) {
      canonicalEl = document.createElement("link");
      canonicalEl.rel = "canonical";
      document.head.appendChild(canonicalEl);
    }
    canonicalEl.href = canonical || `${BASE_URL}${location === "/" ? "" : location}`;
  }, [title, description, canonical, ogImage, noindex, location]);
}
