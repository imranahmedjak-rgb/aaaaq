# Dev Global Jobs — Live V68 Master Package

This package is a source-and-runtime backup of the live Dev Global Jobs website.

## Important release rule

The `dist/` directory is the preserved live V68 runtime. Do not replace it with
a fresh source build until the source has been reconciled with every live V68
route and feature. A successful TypeScript/Vite build alone is not sufficient:
the live runtime contains production patches for Admin, Employer, Profile,
Easy Apply, payments, growth and special routes.

## Contents

- `client/`, `server/`, `shared/`, `script/`: editable application source
- `dashboard-updates/`: latest Employer/Admin/Profile dashboard source and visual system
- `dist/`: preserved live V68 server runtime and public assets
- `package.json` and lockfiles: dependency/build contract
- `server/vendor-types.d.ts`: strict-build declarations for optional mail/upload packages
- `.env.example`: configuration names only; never commit real secrets

## Database

The application expects a PostgreSQL `DATABASE_URL`. The schema definitions
live in `shared/schema.ts`. Database setup must run only after the target
database connection is configured and backed up; never delete or reset the
production database during deployment.

## Deployment safety

1. Keep the current VPS release as a rollback copy.
2. Build and health-check in a temporary release directory.
3. Compare critical routes before switching: `/`, `/admin`, `/employer`,
   `/profile`, `/post-job?employer=1`, Easy Apply and payment callbacks.
4. Reload PM2 gracefully only after the health check passes.

No credentials, private receipts, database files, or `.env` files are included.