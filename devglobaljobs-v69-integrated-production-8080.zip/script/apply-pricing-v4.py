from pathlib import Path
import re
import sys

app = Path(sys.argv[1] if len(sys.argv) > 1 else "/var/www/devglobaljobs")
index_html = app / "dist/public/index.html"
assets_dir = app / "dist/public/assets"

if not index_html.is_file():
    raise SystemExit("ERROR: dist/public/index.html not found. No files changed.")

html = index_html.read_text(errors="ignore")
m = re.search(r'assets/(index-[^"\']+\.js)', html)
if not m:
    raise SystemExit("ERROR: Live JavaScript asset reference not found. No files changed.")

asset = assets_dir / m.group(1)
if not asset.is_file():
    raise SystemExit(f"ERROR: Referenced live asset missing: {asset}. No files changed.")

js = asset.read_text()

def once(old: str, new: str, label: str) -> None:
    global js
    count = js.count(old)
    if count != 1:
        raise SystemExit(f"ERROR: {label} expected once, found {count}. No files changed.")
    js = js.replace(old, new, 1)

# Homepage
once(
    'title:"From Just $29",desc:"Highly competitive pricing with broad international reach - no subscription required"',
    'title:"First 5 Free, Then $29",desc:"Post your first 5 regular jobs free every month. Additional regular listings are $29 and Featured listings remain $79."',
    "home benefit pricing"
)
once(
    'children:"Regular Listing"}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Perfect for standard hiring"})]}),e.jsxs("div",{className:"ml-auto text-right",children:[e.jsx("p",{className:"text-3xl font-extrabold",children:"$29"}),e.jsx("p",{className:"text-xs text-muted-foreground",children:"30 days"})]',
    'children:"Regular Listing"}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"First 5 regular jobs free each month"})]}),e.jsxs("div",{className:"ml-auto text-right",children:[e.jsx("p",{className:"text-3xl font-extrabold",children:"5 FREE"}),e.jsx("p",{className:"text-xs text-muted-foreground",children:"then $29 · 30 days"})]',
    "home regular card"
)
once('children:"Post Regular Job - $29"','children:"Post First 5 Jobs Free"',"home regular button")
once(
    '''children:["Post your job listing on one of the world's fastest-growing international job platforms. Starting at just ",e.jsx("strong",{className:"text-foreground",children:"$29"})," for broad international reach, or ",e.jsx("strong",{className:"text-foreground",children:"$79"})," for featured placement across all pages."]''',
    '''children:["Start with ",e.jsx("strong",{className:"text-foreground",children:"5 free regular job posts every month"}),". Additional regular listings are ",e.jsx("strong",{className:"text-foreground",children:"$29"})," each, while Featured listings remain ",e.jsx("strong",{className:"text-foreground",children:"$79"}),"."]''',
    "home CTA paragraph"
)
once(
    'children:["190+ countries","560K+ job seekers","From just $29","Live in 6 hours","No subscription needed"]',
    'children:["190+ countries","560K+ job seekers","First 5 free monthly","Regular $29 after free quota","Featured $79"]',
    "home CTA badges"
)
count = js.count('"Post a Job - $29"')
if count != 2:
    raise SystemExit(f"ERROR: expected 2 home Post a Job buttons, found {count}. No files changed.")
js = js.replace('"Post a Job - $29"', '"Post First 5 Jobs Free"', 2)

# Post Job page
simple = [
('desc:"First 5 regular jobs free monthly"','desc:"First 5 Free · Then Regular $29 · Featured $79"',"post step summary"),
('children:"Free Regular Posting"','children:"First 5 Regular Jobs Free"',"post plan title"),
('children:"5 FREE / MONTH"','children:"5 FREE · THEN $29"',"post plan price"),
('children:"Your first 5 regular listings per application email are free every month. Active for 30 days."','children:"Your first 5 regular listings per application email are free every month. Additional regular listings are $29 each. Every regular listing stays active for 30 days."',"post plan description"),
('children:"Need more than 5 jobs this month?"','children:"After your 5 free regular jobs"',"post extra heading"),
('children:["Use an admin code for the 6th regular job, Featured jobs, or contact us for custom bulk support."','children:["Additional regular listings are $29 each and Featured listings are $79. After payment verification, use the admin code supplied by our team, or contact us for bulk pricing."',"post extra description"),
('children:"Admin Code (required after 5 free jobs or for Featured)"','children:"Admin Code (after payment for Regular $29 or Featured $79)"',"post admin label"),
('children:f?"Featured listings require a valid admin code.":"The first 5 regular jobs per application email are free every calendar month. The 6th requires an admin code."','children:f?"Featured listing: $79. Enter the admin code supplied after payment verification.":"First 5 regular jobs are free each month. Additional regular listings are $29 and require the admin code supplied after payment verification."',"post helper"),
('const P=j.listingType==="featured"?"Featured - $79":"Regular - $29";','const P=j.listingType==="featured"?"Featured - $79":"First 5 Free / Additional Regular - $29";',"post email plan"),
('${f?"Featured $79":"Regular $29"}','${f?"Featured $79":"First 5 Free or Regular $29"}',"post email subject"),
('children:"• Your chosen plan (Regular $29 or Featured $79)"','children:"• Your chosen plan (First 5 Regular Free, Additional Regular $29, or Featured $79)"',"post email instructions"),
]
for old,new,label in simple:
    once(old,new,label)

# Pricing page
pricing = [
('children:"Post Jobs Free - Simple Global Employer Pricing"','children:"First 5 Free, Then Regular $29 or Featured $79"',"pricing title"),
('children:"Post your first 5 regular jobs free every month. Reach qualified candidates across 190+ countries with no commission per hire."','children:"Post your first 5 regular jobs free every month. After the free quota, additional Regular listings are $29 each and Featured listings are $79."',"pricing intro"),
('children:"Free Monthly Posting"','children:"First 5 Regular Jobs Free"',"pricing free title"),
('children:"First 5 regular jobs every month"','children:"Free monthly quota before paid Regular listings"',"pricing free subtitle"),
('children:"No payment for your first 5 regular listings"','children:"$0 for the first 5 each month · then Regular $29"',"pricing free note"),
('children:"Additional & Bulk Posting"','children:"Additional Regular & Bulk Posting"',"pricing additional title"),
('children:["6th regular job requires an admin code"','children:["6th and later regular jobs are $29 each after payment verification"',"pricing additional bullet"),
]
for old,new,label in pricing:
    once(old,new,label)

# Public/legal text, using only string-content replacements to preserve JSX structure.
public_text = [
('When you post a job ($29 Regular or $79 Featured),','When you post a job (first 5 Regular listings free each month, then $29 Regular or $79 Featured),',"privacy employer data"),
('Process job posting payments ($29 Regular or $79 Featured listings)','Process job posting payments for additional Regular listings ($29) and Featured listings ($79)',"privacy payments"),
('Allows employers to post paid job listings (Regular at $29 USD or Featured at $79 USD)','Allows employers to post the first 5 Regular listings free each month, then additional Regular listings at $29 USD or Featured listings at $79 USD',"terms service description"),
('We offer two posting options:','We offer a free monthly quota followed by two paid posting options:',"terms pricing intro"),
('Regular Posting ($29 USD):','Free Monthly Regular Posting:',"terms regular title"),
('Standard job listing visible across all categories and search results. Active for 30 days from the date of publication.','The first 5 Regular listings per application email are free each calendar month. Additional Regular listings are $29 USD each. Every Regular listing is active for 30 days.',"terms regular description"),
('You transfer the specified amount ($29 Regular or $79 Featured USD equivalent)','For postings beyond the free monthly quota, you transfer the specified amount ($29 Regular or $79 Featured USD equivalent)',"terms payment"),
('Post jobs from $29 (Regular, 30 days) or $79 (Featured, 45 days) and reach a qualified global audience of 560,000+ active professionals.','Post your first 5 Regular jobs free each month, then $29 per additional Regular listing or $79 for Featured, and reach 560,000+ professionals.',"about employer text"),
('children:["$29 ",e.jsx("span",{className:"text-sm font-normal text-muted-foreground",children:"USD"})]','children:["First 5 Free ",e.jsx("span",{className:"text-sm font-normal text-muted-foreground",children:"then $29 USD"})]',"about pricing card"),
('desc:"You pay once - $29 for Regular, $79 for Featured. We charge zero commission per hire, zero subscription, and zero hidden fees. One payment, full global exposure."','desc:"Your first 5 Regular listings are free each month. After that, pay $29 per Regular listing or $79 for Featured. Zero commission, subscription, or hidden fees."',"pricing FAQ fee"),
]
for old,new,label in public_text:
    once(old,new,label)

# SEO descriptions/schema
seo = [
('Post up to five regular jobs free every month on Dev Global Jobs. Reach qualified professionals across 190+ countries with global job distribution and SmartMatch.','Post your first five regular jobs free every month on Dev Global Jobs. Additional Regular listings are $29 and Featured listings are $79. Reach professionals across 190+ countries.',"post meta"),
('description:"First five regular job postings per application email every calendar month"','description:"First five regular job postings free per application email each month; additional Regular listings $29; Featured listings $79"',"post schema"),
('Post five regular jobs free every month on Dev Global Jobs. Compare free, featured and bulk employer posting options for global recruitment.','Post five regular jobs free every month, then pay $29 for additional Regular listings or $79 for Featured listings on Dev Global Jobs.',"pricing meta"),
('description:"First five regular job postings free each month"','description:"First five Regular job postings free each month; additional Regular $29; Featured $79"',"pricing schema"),
]
for old,new,label in seo:
    once(old,new,label)

asset.write_text(js)
print(f"PATCHED_FRONTEND={asset}")
print("PRICING_V4_PATCH_OK")
