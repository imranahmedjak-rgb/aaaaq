import { build } from "esbuild";
import { execSync } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");

// Build client with Vite
console.log("building client...");
execSync("npx vite build", { stdio: "inherit", cwd: root });

// Build server with esbuild
console.log("building server...");
await build({
  entryPoints: [path.join(root, "server/index.ts")],
  bundle: true,
  platform: "node",
  format: "cjs",
  outfile: path.join(root, "dist/index.cjs"),
  packages: "external",
  // Tell esbuild NODE_ENV=production so vite dev-server branch is tree-shaken out
  define: {
    "process.env.NODE_ENV": '"production"',
  },
  sourcemap: false,
  minify: false,
});

console.log("Build complete!");
