from pathlib import Path
import re
import sys

app = Path(sys.argv[1] if len(sys.argv) > 1 else "/var/www/devglobaljobs")
index_html = app / "dist/public/index.html"
assets_dir = app / "dist/public/assets"

if not index_html.is_file():
    raise SystemExit("ERROR: dist/public/index.html not found. No files changed.")

html = index_html.read_text(errors="ignore")

# Preserve the correct PDF CV panel already injected in index.html.
for marker in ["id='dgj-cv-panel'", "Preview or download any format as PDF.", "application/pdf", "dgj-dl-"]:
    if marker not in html:
        raise SystemExit(f"ERROR: Correct PDF CV panel marker missing: {marker}. No files changed.")

m = re.search(r'assets/(index-[^"\']+\.js)', html)
if not m:
    raise SystemExit("ERROR: Live JavaScript asset reference not found. No files changed.")

asset = assets_dir / m.group(1)
if not asset.is_file():
    raise SystemExit(f"ERROR: Referenced live asset missing: {asset}. No files changed.")

js = asset.read_text()

def once(old: str, new: str, label: str) -> None:
    global js
    count = js.count(old)
    if count != 1:
        raise SystemExit(f"ERROR: {label} expected once, found {count}. No files changed.")
    js = js.replace(old, new, 1)

# -------------------------------------------------------------------
# A. PROFILE CV CLEANUP
# -------------------------------------------------------------------

desktop_button = ',e.jsxs(V,{size:"sm",variant:"outline",onClick:P,className:"gap-1.5 hidden sm:flex",children:[e.jsx(Fd,{className:"h-4 w-4"})," Download CV"]})'
mobile_block = 'e.jsxs("div",{className:"sticky bottom-4 flex gap-3 sm:hidden justify-center",children:[e.jsxs(V,{onClick:()=>C.mutate(),disabled:C.isPending,className:"flex-1 max-w-[180px] gap-1.5",children:[e.jsx(Kv,{className:"h-4 w-4"})," ",s?"Saved!":"Save"]}),e.jsxs(V,{variant:"outline",onClick:P,className:"flex-1 max-w-[180px] gap-1.5",children:[e.jsx(Fd,{className:"h-4 w-4"})," Download CV"]})]})'
sidebar_block = ',e.jsxs("div",{className:"mt-auto space-y-2.5",children:[e.jsxs(V,{className:"w-full gap-2",onClick:P,children:[e.jsx(Fd,{className:"h-4 w-4"})," Download CV"]}),e.jsx("p",{className:"text-center text-[11px] text-muted-foreground leading-relaxed",children:"British format · No photo · Internationally accepted"})]})'

once(desktop_button, '', "old desktop profile Download CV button")

start_marker = 'e.jsxs(z,{className:"p-5 sm:p-6 border-primary/20 bg-gradient-to-br from-primary/5 to-blue-600/5 space-y-4",children:[e.jsxs("div",{className:"flex items-center justify-between flex-wrap gap-2",children:[e.jsxs("h2",{className:"text-base font-bold text-foreground flex items-center gap-2",children:[e.jsx(Qe,{className:"h-4 w-4 text-primary"})," My CV Formats"]})'
end_marker = ',e.jsxs("div",{className:"sticky bottom-4 flex gap-3 sm:hidden justify-center"'

start = js.find(start_marker)
end = js.find(end_marker, start)

if start == -1 or end == -1:
    raise SystemExit(f"ERROR: Duplicate CV section boundaries not found (start={start}, end={end}). No files changed.")

duplicate_block = js[start:end]
if duplicate_block.count("My CV Formats") != 1 or "4 Formats Available" not in duplicate_block:
    raise SystemExit("ERROR: Duplicate CV section validation failed. No files changed.")

js = js[:start] + js[end + 1:]

once(
    mobile_block,
    'e.jsx("div",{className:"sticky bottom-4 flex sm:hidden justify-center",children:e.jsxs(V,{onClick:()=>C.mutate(),disabled:C.isPending,className:"w-full max-w-[240px] gap-1.5",children:[e.jsx(Kv,{className:"h-4 w-4"})," ",s?"Saved!":"Save Profile"]})})',
    "old mobile profile Download CV button"
)

once(sidebar_block, '', "old sidebar profile Download CV button")

if "4 Formats Available" in js:
    raise SystemExit("ERROR: Duplicate React CV formats section still present. No files changed.")

for marker in ["Personal Information", "ATS Improvement Tips", "Save Profile"]:
    if marker not in js:
        raise SystemExit(f"ERROR: Profile marker missing after patch: {marker}. No files changed.")

# -------------------------------------------------------------------
# B. PROFESSIONAL BLOG EDITOR WITH H2/H3 PRESERVATION
# -------------------------------------------------------------------

old_component_anchor = 'function L(k,T){l(B=>{const q={...B,[k]:T};return k==="title"&&p&&(q.slug=T.toLowerCase().replace(/[^a-z0-9\\s-]/g,"").replace(/\\s+/g,"-").replace(/-+/g,"-").slice(0,80)),q})}const D='

new_component_anchor = r'''function L(k,T){l(B=>{const q={...B,[k]:T};return k==="title"&&p&&(q.slug=T.toLowerCase().replace(/[^a-z0-9\s-]/g,"").replace(/\s+/g,"-").replace(/-+/g,"-").slice(0,80)),q})}function H(k){const T=k.clipboardData;if(!T)return;const B=T.getData("text/html")||"",q=T.getData("text/plain")||"";if(!B&&!q)return;k.preventDefault();const z=S=>S.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),F=S=>{const Y=S.trim();return Y.length>0&&Y.length<=100&&Y.split(/\s+/).length<=14&&!/[.!]$/.test(Y)},I=S=>{const Y=S.split(/\r?\n/),Z=[];for(let ee=0;ee<Y.length;ee++){const te=Y[ee].trim();if(!te){Z.push("");continue}let ne=te.match(/^#{1,2}\s+(.+)/);if(ne){Z.push(`<h2>${z(ne[1])}</h2>`);continue}ne=te.match(/^#{3,6}\s+(.+)/);if(ne){Z.push(`<h3>${z(ne[1])}</h3>`);continue}const oe=ee===0||!Y[ee-1].trim(),ie=ee===Y.length-1||!Y[ee+1].trim();if(oe&&ie&&F(te)){Z.push(`<h2>${z(te)}</h2>`);continue}if(/^[-*•]\s+/.test(te)){Z.push(`<p>${z(te)}</p>`);continue}Z.push(`<p>${z(te)}</p>`)}return Z.join("\n")};let U="";if(B){const Y=new DOMParser().parseFromString(B,"text/html");Y.querySelectorAll("script,style,iframe,object").forEach(Z=>Z.remove());U=Array.from(Y.body.children).map(Z=>{const ee=Z.tagName.toLowerCase();if(ee==="h1")return `<h2>${z(Z.textContent||"")}</h2>`;if(["h2","h3","p","ul","ol","blockquote"].includes(ee))return Z.outerHTML;return Z.textContent&&Z.textContent.trim()?`<p>${z(Z.textContent.trim())}</p>`:""}).filter(Boolean).join("\n")}else U=I(q);const V=document.getElementById("admin-article-content"),W=V&&typeof V.selectionStart==="number"?V.selectionStart:(o.content||"").length,X=V&&typeof V.selectionEnd==="number"?V.selectionEnd:W,ae=o.content||"",be=ae.slice(0,W),ce=ae.slice(X),de=(be&&U?"\n\n":"")+U;L("content",be+de+ce);setTimeout(()=>{const Y=document.getElementById("admin-article-content");Y&&Y.focus()},0)}function R(k){const T=document.getElementById("admin-article-content");if(!T)return;const B=typeof T.selectionStart==="number"?T.selectionStart:0,q=typeof T.selectionEnd==="number"?T.selectionEnd:B,z=o.content||"",F=q>B?z.slice(B,q):k==="p"?"Paragraph text":"Heading text",I=F.replace(/<[^>]+>/g,""),U=`<${k}>${I}</${k}>`,V=z.slice(0,B)+U+z.slice(q);L("content",V);setTimeout(()=>{const W=document.getElementById("admin-article-content");W&&(W.focus(),W.setSelectionRange(B+U.length,B+U.length))},0)}const D='''

once(old_component_anchor, new_component_anchor, "blog editor paste/format helpers")

old_textarea = 'e.jsx(Xa,{value:o.content,onChange:k=>L("content",k.target.value),placeholder:"Write your full article here. Use double line breaks for paragraphs. You can include HTML tags for formatting...",rows:16,className:"bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-sm font-mono resize-y"})'

new_textarea = 'e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-wrap items-center gap-2 mb-2",children:[e.jsx(V,{type:"button",size:"sm",variant:"outline",onClick:()=>R("h2"),className:"h-8 px-3 text-xs",children:"H2 Section"}),e.jsx(V,{type:"button",size:"sm",variant:"outline",onClick:()=>R("h3"),className:"h-8 px-3 text-xs",children:"H3 Subheading"}),e.jsx(V,{type:"button",size:"sm",variant:"outline",onClick:()=>R("p"),className:"h-8 px-3 text-xs",children:"Paragraph"}),e.jsx("span",{className:"text-[11px] text-slate-400",children:"Paste from Word, Google Docs or ChatGPT: H2/H3 headings are preserved automatically."})]}),e.jsx(Xa,{id:"admin-article-content",value:o.content,onChange:k=>L("content",k.target.value),onPaste:H,placeholder:"Paste or write your full article. Existing H2/H3 headings are preserved. Use the H2 and H3 buttons for manual structure.",rows:16,className:"bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-500 text-sm font-mono resize-y"})]})'

once(old_textarea, new_textarea, "professional Article Content editor")

for marker in [
    "H2 Section",
    "H3 Subheading",
    "Paste from Word, Google Docs or ChatGPT",
    "onPaste:H",
    "admin-article-content",
]:
    if marker not in js:
        raise SystemExit(f"ERROR: Blog editor marker missing after patch: {marker}. No files changed.")

asset.write_text(js)

print(f"PATCHED_FRONTEND={asset}")
print("PROFILE_BLOG_V7_PATCH_OK")
