from pathlib import Path
import re, json
import sys
app = Path(sys.argv[1] if len(sys.argv) > 1 else "/var/www/devglobaljobs")
backend = app / "dist/index.cjs"
assets_dir = app / "dist/public/assets"
index_html = app / "dist/public/index.html"
if not index_html.is_file():
    raise SystemExit("ERROR: Live index.html not found. No files changed.")
html = index_html.read_text(errors="ignore")
match = re.search(r'assets/(index-[^"\']+\.js)', html)
if not match:
    raise SystemExit("ERROR: Live frontend asset reference not found in index.html. No files changed.")
asset = assets_dir / match.group(1)
if not asset.is_file():
    raise SystemExit(f"ERROR: Referenced live frontend asset missing: {asset}. No files changed.")
bs=backend.read_text()
js=asset.read_text()

# Backend admin route
pat=re.compile(r'  app2\.post\("/api/admin-post-job", rateLimit\(5, 6e4\), async \(req, res\) => \{.*?\n  \}\);\n  app2\.post\("/api/create-payment-intent"',re.S)
new='''  app2.post("/api/admin-post-job", rateLimit(10, 6e4), async (req, res) => {
    let quotaClient;
    try {
      const parsed = postJobSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid job data", errors: parsed.error.flatten() });
      }
      const VALID_ADMIN_CODES = [
        "TNW112288899", "TNW1122888910", "TNW112288811", "TNW1122887789",
        "TNW1122888726", "TNW112287625", "TNW11228876829", "TNW112288879",
        "TNW1122809872", "TNW1122887829", "TNW1122880928", "TNW1122888792"
      ];
      const envCodes = process.env.ADMIN_POST_CODES?.split(",").map((c) => c.trim()).filter(Boolean) || [];
      const allCodes = [...VALID_ADMIN_CODES, ...envCodes];
      const submittedCode = parsed.data.adminCode?.trim() || "";
      const hasValidAdminCode = submittedCode.length > 0 && allCodes.includes(submittedCode);
      const isFeatured = parsed.data.listingType === "featured";
      const employerEmail = (parsed.data.applyEmail || "").trim().toLowerCase();

      if (submittedCode && !hasValidAdminCode) {
        return res.status(403).json({ message: "Invalid admin code" });
      }
      if (isFeatured && !hasValidAdminCode) {
        return res.status(403).json({ message: "Featured job postings require a valid admin code." });
      }
      if (!isFeatured && !hasValidAdminCode && !employerEmail) {
        return res.status(400).json({ message: "Application email is required for free monthly job posting." });
      }

      let monthlyCount = 0;
      if (!isFeatured && !hasValidAdminCode) {
        quotaClient = await pool.connect();
        await quotaClient.query("BEGIN");
        await quotaClient.query("SELECT pg_advisory_xact_lock(hashtext($1))", [`dgj-free:${employerEmail}`]);
        const quotaResult = await quotaClient.query(`
          SELECT COUNT(*)::int AS count
          FROM jobs
          WHERE source = 'Employer'
            AND is_employer_posted = true
            AND lower(trim(apply_email)) = $1
            AND posted_at >= date_trunc('month', CURRENT_TIMESTAMP)
            AND posted_at < date_trunc('month', CURRENT_TIMESTAMP) + INTERVAL '1 month'
        `, [employerEmail]);
        monthlyCount = Number(quotaResult.rows?.[0]?.count || 0);
        if (monthlyCount >= 5) {
          await quotaClient.query("ROLLBACK");
          quotaClient.release();
          quotaClient = undefined;
          return res.status(403).json({
            message: "You have used your 5 free job posts for this month. Enter a valid admin code to post additional jobs.",
            code: "MONTHLY_FREE_LIMIT_REACHED",
            freeJobsUsed: monthlyCount,
            freeJobsRemaining: 0
          });
        }
      }

      const skillCat = classifyJobSkillCategory(parsed.data.title, parsed.data.description || "");
      const job = await storage.insertJob({
        title: parsed.data.title,
        organization: parsed.data.organization,
        location: parsed.data.location,
        category: parsed.data.category,
        skillCategory: skillCat || "business",
        description: parsed.data.description,
        url: parsed.data.url || null,
        source: "Employer",
        sourceId: `employer-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        jobType: parsed.data.jobType || null,
        salary: parsed.data.salary || null,
        country: parsed.data.country || null,
        startDate: parsed.data.startDate ? new Date(parsed.data.startDate) : null,
        closingDate: parsed.data.closingDate ? new Date(parsed.data.closingDate) : null,
        isEmployerPosted: true,
        applyEmail: parsed.data.applyEmail || null,
        stripePaymentId: null,
        featured: isFeatured
      });

      if (quotaClient) {
        await quotaClient.query("COMMIT");
        quotaClient.release();
        quotaClient = undefined;
      }
      queueUrlForIndexing(`https://devglobaljobs.com/jobs/detail/${job.id}`);
      queueGoogleIndexingUpdate(job.id);
      res.json({
        success: true,
        job,
        postingType: isFeatured ? "featured-admin" : hasValidAdminCode ? "admin" : "free",
        freeJobsUsed: isFeatured || hasValidAdminCode ? undefined : monthlyCount + 1,
        freeJobsRemaining: isFeatured || hasValidAdminCode ? undefined : Math.max(0, 4 - monthlyCount)
      });
    } catch (err) {
      if (quotaClient) {
        try { await quotaClient.query("ROLLBACK"); } catch {}
        quotaClient.release();
      }
      console.error("Admin post job error:", err);
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/create-payment-intent"'''
bs,n=pat.subn(new,bs)
assert n==1,n

# Blog normalizer injection before POST route
marker='  app2.post("/api/admin/blog", requireAdmin, async (req, res) => {'
normalizer='''  function normalizeBlogForSeo(payload, existing = {}) {
    const title = String(payload.title ?? existing.title ?? "").trim();
    const slugBase = String(payload.slug ?? existing.slug ?? title).trim().toLowerCase()
      .replace(/[^a-z0-9\\s-]/g, "").replace(/\\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    const content = String(payload.content ?? existing.content ?? "");
    const plainText = content.replace(/<[^>]+>/g, " ").replace(/\\s+/g, " ").trim();
    const words = plainText ? plainText.split(/\\s+/).length : 0;
    const status = String(payload.status ?? existing.status ?? "draft");
    const h1Count = (content.match(/<h1\\b/gi) || []).length;
    const h2Count = (content.match(/<h2\\b/gi) || []).length;
    const h3Count = (content.match(/<h3\\b/gi) || []).length;
    if (status === "published") {
      if (words < 600) throw new Error(`Published articles require at least 600 words. Current: ${words}.`);
      if (h1Count > 0) throw new Error("Do not add H1 inside article content. The article title is the single page H1.");
      if (h2Count < 2) throw new Error("Published articles require at least two H2 section headings.");
      if (!String(payload.metaDescription ?? existing.metaDescription ?? "").trim()) throw new Error("Meta description is required before publishing.");
    }
    const metaTitle = String(payload.metaTitle ?? existing.metaTitle ?? title).trim().slice(0, 60);
    const excerpt = String(payload.excerpt ?? existing.excerpt ?? plainText.slice(0, 220)).trim();
    const metaDescription = String(payload.metaDescription ?? existing.metaDescription ?? excerpt.slice(0, 160)).trim().slice(0, 160);
    const canonicalUrl = String(payload.canonicalUrl ?? existing.canonicalUrl ?? `https://devglobaljobs.com/blog/${slugBase}`).trim();
    return {
      ...existing,
      ...payload,
      title,
      slug: slugBase,
      content,
      excerpt: excerpt || null,
      metaTitle: metaTitle || title,
      metaDescription: metaDescription || null,
      canonicalUrl,
      ogTitle: String(payload.ogTitle ?? existing.ogTitle ?? metaTitle ?? title).trim().slice(0, 95),
      ogDescription: String(payload.ogDescription ?? existing.ogDescription ?? metaDescription ?? excerpt).trim().slice(0, 200),
      schemaType: payload.schemaType || existing.schemaType || "BlogPosting",
      wordCount: words,
      readingTimeMinutes: Math.max(1, Math.ceil(words / 220)),
      seoHeadingSummary: { pageH1: 1, contentH1: h1Count, h2: h2Count, h3: h3Count }
    };
  }
'''
assert marker in bs
bs=bs.replace(marker,normalizer+marker,1)
# replace POST body destructuring block by simpler normalization within route
postpat=re.compile(r'  app2\.post\("/api/admin/blog", requireAdmin, async \(req, res\) => \{\n    try \{.*?\n      res\.json\(\{ success: true, post \}\);\n    \} catch \(err\) \{\n      res\.status\(500\)\.json\(\{ message: err\.message \}\);\n    \}\n  \}\);',re.S)
postnew='''  app2.post("/api/admin/blog", requireAdmin, async (req, res) => {
    try {
      const normalized = normalizeBlogForSeo(req.body);
      if (!normalized.title || !normalized.slug) return res.status(400).json({ message: "Title and slug are required" });
      const status = normalized.status || "draft";
      const post = await storage.createBlogPost({
        ...normalized,
        publishedAt: status === "published" ? new Date() : null,
        createdAt: new Date(),
        updatedAt: new Date()
      });
      if (status === "published") {
        queueUrlForIndexing(`${BASE_URL3}/blog/${post.slug}`);
        queueGoogleBlogUpdate(post.slug);
      }
      res.json({ success: true, post });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(400).json({ message });
    }
  });'''
bs,n=postpat.subn(postnew,bs)
assert n==1,n
putpat=re.compile(r'  app2\.put\("/api/admin/blog/:id", requireAdmin, async \(req, res\) => \{\n    try \{.*?\n      res\.json\(\{ success: true, post: updated \}\);\n    \} catch \(err\) \{\n      res\.status\(500\)\.json\(\{ message: err\.message \}\);\n    \}\n  \}\);',re.S)
putnew='''  app2.put("/api/admin/blog/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existing = await storage.getBlogPostById(id);
      if (!existing) return res.status(404).json({ message: "Blog post not found" });
      const normalized = normalizeBlogForSeo(req.body, existing);
      const wasPublished = existing.status === "published";
      const isPublishing = normalized.status === "published" && !wasPublished;
      const updated = await storage.updateBlogPost(id, {
        ...normalized,
        publishedAt: isPublishing ? new Date() : existing.publishedAt,
        updatedAt: new Date()
      });
      if (updated && (isPublishing || normalized.status === "published")) {
        queueUrlForIndexing(`${BASE_URL3}/blog/${updated.slug}`);
        queueGoogleBlogUpdate(updated.slug);
      }
      res.json({ success: true, post: updated });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(400).json({ message });
    }
  });'''
bs,n=putpat.subn(putnew,bs)
assert n==1,n
backend.write_text(bs)

# Frontend submit route
old='w=j=>{j.adminCode&&j.adminCode.trim()!==""?p.mutate(j):v()}'
assert js.count(old)==1,js.count(old)
js=js.replace(old,'w=j=>p.mutate(j)',1)
# submit button block
old='''d.watch("adminCode")?e.jsx(V,{type:"submit",className:"w-full",disabled:p.isPending,"data-testid":"button-submit-job",children:p.isPending?"Posting...":e.jsxs(e.Fragment,{children:["Post Job Now ",e.jsx(vn,{className:"h-4 w-4 ml-1.5"})]})}):e.jsxs(V,{type:"button",className:"w-full",onClick:v,"data-testid":"button-submit-job",children:[e.jsx(bn,{className:"h-4 w-4 mr-1.5"}),"Send Job Details via Email",e.jsx(vn,{className:"h-4 w-4 ml-1.5"})]}),!d.watch("adminCode")&&e.jsx("p",{className:"text-xs text-center text-muted-foreground mt-2",children:"This will open your email client pre-filled with your job details - attach your payment receipt and send."})'''
new='''e.jsx(V,{type:"submit",className:"w-full",disabled:p.isPending,"data-testid":"button-submit-job",children:p.isPending?"Posting...":e.jsxs(e.Fragment,{children:[f?"Post Featured Job with Admin Code":"Post Free Job Now",e.jsx(vn,{className:"h-4 w-4 ml-1.5"})]})}),e.jsx("p",{className:"text-xs text-center text-muted-foreground mt-2",children:f?"Featured listings require a valid admin code.":"The first 5 regular jobs per application email are free every calendar month. The 6th requires an admin code."})'''
assert js.count(old)==1,js.count(old)
js=js.replace(old,new,1)
# post page strings
repls={
'Reach 560,000+ qualified professionals worldwide - fast, simple, no account needed':'Post up to 5 regular jobs free every month and reach 560,000+ professionals across 190+ countries',
'desc:"Regular ($29) or Featured ($79)"':'desc:"First 5 regular jobs free monthly"',
'{num:"2",icon:bn,title:"Email Job Details",desc:"Send details to info@devglobaljobs.com"}':'{num:"2",icon:bn,title:"Add Job Details",desc:"No account or payment for first 5 regular jobs"}',
'{num:"3",icon:Of,title:"Pay via Wise",desc:"Bank transfer - 150+ countries"}':'{num:"3",icon:Of,title:"Publish Free",desc:"6th regular job or Featured requires admin code"}',
'{num:"4",icon:jt,title:"Go Live in 6 Hours",desc:"We verify & publish your listing"}':'{num:"4",icon:jt,title:"Reach Global Talent",desc:"Visible in search, country and category pages"}',
'children:"Step 1 - Choose Your Plan"':'children:"Step 1 - Choose Your Posting Type"',
'children:"Regular Posting"}),e.jsx("span",{className:"font-bold text-lg","data-testid":"text-price-regular",children:"$29"})':'children:"Free Regular Posting"}),e.jsx("span",{className:"font-bold text-lg","data-testid":"text-price-regular",children:"5 FREE / MONTH"})',
'children:"Standard listing visible across all categories and search results. Active for 30 days."':'children:"Your first 5 regular listings per application email are free every month. Active for 30 days."',
'children:"Need to post 5+ jobs?"':'children:"Need more than 5 jobs this month?"',
'children:["We offer custom Bulk Posting packages with volume discounts, dedicated support, and flexible terms."':'children:["Use an admin code for the 6th regular job, Featured jobs, or contact us for custom bulk support."',
'children:"Admin Code (internal use only)"':'children:"Admin Code (required after 5 free jobs or for Featured)"'
}
for a,b in repls.items():
    c=js.count(a)
    assert c>=1,(a,c)
    js=js.replace(a,b,1)
# pricing region edits only
start=js.index('function F7()')
# find next function after F7 using known following marker
end=js.find('function ',start+20)
seg=js[start:end]
pre=seg
pricing_repls={
'children:"Simple, Transparent Pricing"':'children:"Post Jobs Free - Simple Global Employer Pricing"',
'children:"Reach thousands of qualified professionals worldwide. Choose the plan that best fits your hiring needs."':'children:"Post your first 5 regular jobs free every month. Reach qualified candidates across 190+ countries with no commission per hire."',
'children:"Regular Posting"':'children:"Free Monthly Posting"',
'children:"Standard job listing"':'children:"First 5 regular jobs every month"',
'children:"$29"':'children:"$0"',
'children:"One-time payment, no subscription"':'children:"No payment for your first 5 regular listings"',
'children:["Get Started - Post Your Job"':'children:["Post a Free Job"',
'children:"Bulk Posting"':'children:"Additional & Bulk Posting"',
'children:["Post 5+ jobs at discounted rates"':'children:["6th regular job requires an admin code"'
}
for a,b in pricing_repls.items():
    assert a in seg,a
    seg=seg.replace(a,b,1)
assert seg!=pre
js=js[:start]+seg+js[end:]
# Blog dashboard SEO checks
needle='jr("Slug contains keyword or is descriptive",(t.slug||"").length>=5&&(a.length===0||(t.slug||"").toLowerCase().includes(a.split(" ")[0])),"Slug should include primary keyword and be hyphen-separated")'
assert js.count(needle)==1
extra=needle+',jr("Single H1 structure",(t.content.match(/<h1\\b/gi)||[]).length===0,"The article title is the page H1. Do not add another H1 inside content."),jr("At least two H2 sections",(t.content.match(/<h2\\b/gi)||[]).length>=2,"Use at least two H2 headings to structure the article."),jr("H3 supporting headings",(t.content.match(/<h3\\b/gi)||[]).length>=1,"Use H3 headings under relevant H2 sections for detailed subtopics.")'
js=js.replace(needle,extra,1)
# SEO runtime for post page and pricing
post_hook='''function A7(){x.useEffect(()=>{document.title="Post 5 Jobs Free Every Month | Dev Global Jobs";let t=document.querySelector('meta[name="description"]');t&&t.setAttribute("content","Post up to five regular jobs free every month on Dev Global Jobs. Reach qualified professionals across 190+ countries with global job distribution and SmartMatch.");let n=document.querySelector('link[rel="canonical"]');n||(n=document.createElement("link"),n.rel="canonical",document.head.appendChild(n)),n.href="https://devglobaljobs.com/post-job";let a=document.getElementById("post-job-service-schema");a||(a=document.createElement("script"),a.id="post-job-service-schema",a.type="application/ld+json",document.head.appendChild(a)),a.textContent=JSON.stringify({"@context":"https://schema.org","@type":"Service",name:"Free Monthly Job Posting",provider:{"@type":"Organization",name:"Dev Global Jobs"},areaServed:"Worldwide",offers:{"@type":"Offer",price:"0",priceCurrency:"USD",description:"First five regular job postings per application email every calendar month"}});return()=>{a&&a.remove()}},[]);'''
assert js.count('function A7(){const[')==1
js=js.replace('function A7(){const[',post_hook+'const[',1)
pricing_hook='''function F7(){x.useEffect(()=>{document.title="Free Job Posting Pricing | Dev Global Jobs";let t=document.querySelector('meta[name="description"]');t&&t.setAttribute("content","Post five regular jobs free every month on Dev Global Jobs. Compare free, featured and bulk employer posting options for global recruitment.");let n=document.querySelector('link[rel="canonical"]');n||(n=document.createElement("link"),n.rel="canonical",document.head.appendChild(n)),n.href="https://devglobaljobs.com/pricing";let a=document.getElementById("pricing-offer-schema");a||(a=document.createElement("script"),a.id="pricing-offer-schema",a.type="application/ld+json",document.head.appendChild(a)),a.textContent=JSON.stringify({"@context":"https://schema.org","@type":"Product",name:"Dev Global Jobs Employer Posting",brand:{"@type":"Brand",name:"Dev Global Jobs"},offers:{"@type":"Offer",price:"0",priceCurrency:"USD",description:"First five regular job postings free each month"}});return()=>{a&&a.remove()}},[]);return'''
assert js.count('function F7(){return')==1
js=js.replace('function F7(){return',pricing_hook,1)
asset.write_text(js)
print(f"PATCHED_BACKEND={backend}")
print(f"PATCHED_FRONTEND={asset}")
print("LIVE_TARGETED_PATCH_OK")
