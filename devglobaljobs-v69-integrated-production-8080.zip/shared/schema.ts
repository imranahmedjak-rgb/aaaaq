import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  organization: text("organization").notNull(),
  location: text("location"),
  category: text("category").notNull(),
  skillCategory: text("skill_category"),
  description: text("description"),
  url: text("url"),
  source: text("source").notNull(),
  sourceId: text("source_id").unique(),
  postedAt: timestamp("posted_at").defaultNow(),
  startDate: timestamp("start_date"),
  closingDate: timestamp("closing_date"),
  jobType: text("job_type"),
  salary: text("salary"),
  country: text("country"),
  isEmployerPosted: boolean("is_employer_posted").default(false),
  applyEmail: text("apply_email"),
  stripePaymentId: text("stripe_payment_id"),
  featured: boolean("featured").default(false),
  viewCount: integer("view_count").notNull().default(0),
});

export const savedJobs = pgTable("saved_jobs", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").notNull(),
  jobId: integer("job_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobAlerts = pgTable("job_alerts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  keywords: text("keywords").notNull().default(""),
  location: text("location").notNull().default(""),
  frequency: text("frequency").notNull().default("daily"),
  unsubscribeToken: text("unsubscribe_token").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const pendingJobs = pgTable("pending_jobs", {
  id: serial("id").primaryKey(),
  stripeSessionId: text("stripe_session_id").notNull().unique(),
  title: text("title").notNull(),
  organization: text("organization").notNull(),
  location: text("location"),
  category: text("category").notNull(),
  description: text("description"),
  url: text("url"),
  jobType: text("job_type"),
  salary: text("salary"),
  country: text("country"),
  applyEmail: text("apply_email"),
  featured: boolean("featured").default(false),
  startDate: timestamp("start_date"),
  closingDate: timestamp("closing_date"),
  createdAt: timestamp("created_at").defaultNow(),
  published: boolean("published").default(false),
});

export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name"),
  type: text("type").notNull().default("job_seeker"),
  subscribedAt: timestamp("subscribed_at").defaultNow(),
  active: boolean("active").default(true),
});

export const insertSubscriberSchema = createInsertSchema(newsletterSubscribers).omit({
  id: true,
  subscribedAt: true,
  active: true,
});

export const subscribeSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  name: z.string().optional(),
  type: z.enum(["job_seeker", "employer"]).default("job_seeker"),
});

export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;
export type InsertSubscriber = z.infer<typeof insertSubscriberSchema>;

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  postedAt: true,
});

export const postJobSchema = z.object({
  title: z.string().min(3, "Job title must be at least 3 characters"),
  organization: z.string().min(2, "Company name is required"),
  location: z.string().min(2, "Location is required"),
  category: z.enum(["un", "ngo", "remote", "international", "technology", "healthcare", "business", "education", "engineering", "creative", "sales", "gig", "youth", "sponsored"]),
  description: z.string().min(1, "Description required").refine(
    (v) => v.trim().split(/\s+/).filter(Boolean).length >= 600,
    "Description must be at least 600 words. Best: 800\u20131,000 words for quality SEO job postings."
  ),
  url: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  jobType: z.string().optional(),
  salary: z.string().optional(),
  country: z.string().optional(),
  applyEmail: z.string().email("Please enter a valid email").optional().or(z.literal("")),
  adminCode: z.string().optional(),
  listingType: z.enum(["regular", "featured"]).default("regular"),
  startDate: z.string().optional().or(z.literal("")),
  closingDate: z.string().optional().or(z.literal("")),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type PostJobInput = z.infer<typeof postJobSchema>;

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  focusKeyword: text("focus_keyword"),
  secondaryKeywords: text("secondary_keywords"),
  content: text("content").notNull().default(""),
  excerpt: text("excerpt"),
  featuredImageUrl: text("featured_image_url"),
  featuredImageAlt: text("featured_image_alt"),
  author: text("author").notNull().default("Dev Global Jobs"),
  category: text("category"),
  tags: text("tags"),
  status: text("status").notNull().default("draft"),
  canonicalUrl: text("canonical_url"),
  ogTitle: text("og_title"),
  ogDescription: text("og_description"),
  schemaType: text("schema_type").notNull().default("BlogPosting"),
  wordCount: integer("word_count"),
  readingTimeMinutes: integer("reading_time_minutes"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;

// ─── Job Seeker Accounts ──────────────────────────────────────────────────────
export const jobSeekerAccounts = pgTable("job_seeker_accounts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
});

export const jobSeekerProfiles = pgTable("job_seeker_profiles", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").notNull().unique(),
  fullName: text("full_name").notNull().default(""),
  phone: text("phone").default(""),
  city: text("city").default(""),
  country: text("country").default(""),
  linkedin: text("linkedin").default(""),
  website: text("website").default(""),
  jobTitle: text("job_title").default(""),
  summary: text("summary").default(""),
  skills: text("skills").default("[]"),
  languages: text("languages").default("[]"),
  workExperience: text("work_experience").default("[]"),
  education: text("education").default("[]"),
  certifications: text("certifications").default("[]"),
  atsScore: integer("ats_score").default(0),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type JobSeekerAccount = typeof jobSeekerAccounts.$inferSelect;
export type JobSeekerProfile = typeof jobSeekerProfiles.$inferSelect;
export type InsertJobSeekerAccount = typeof jobSeekerAccounts.$inferInsert;
export type InsertJobSeekerProfile = typeof jobSeekerProfiles.$inferInsert;
