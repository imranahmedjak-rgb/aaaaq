import { JSDOM } from "jsdom";
import { readFileSync } from "fs";

const js = readFileSync(process.argv[2], "utf8");
const css = readFileSync(process.argv[3], "utf8");

const REQUESTS = [
  {
    id: 101, request_type: "job_posting", listing_type: "regular", status: "pending",
    organization: "Acme Health NGO", employer_email: "hr@acmehealth.org",
    job_payload: { title: "Program Officer", organization: "Acme Health NGO" },
    amount: 29, currency: "USD", payment_method: "wise", payment_reference: "WISE-88213",
    receipt_original_name: "receipt-101.pdf", reference: "PR-101", created_at: "2026-09-01T10:00:00Z",
  },
  {
    id: 102, request_type: "job_posting", listing_type: "featured", status: "published",
    organization: "Acme Health NGO", live_job_title: "Senior Program Officer", live_job_organization: "Acme Health NGO",
    job_payload: { title: "Senior Program Officer", organization: "Acme Health NGO" },
    amount: 79, currency: "USD", payment_method: "paypal", payment_reference: "PP-991",
    receipt_original_name: "receipt-102.pdf", reference: "PR-102", created_at: "2026-08-20T10:00:00Z",
  },
  {
    id: 103, request_type: "boost", status: "pending", organization: "Northwind Logistics",
    live_job_title: "Logistics Coordinator", live_job_organization: "Northwind Logistics",
    amount: 49, currency: "USD", payment_method: "bank_transfer", payment_reference: "BT-4471",
    receipt_original_name: null, reference: "PR-103", created_at: "2026-09-03T10:00:00Z",
  },
];

async function run() {
  const dom = new JSDOM(`<!doctype html><html><head></head><body><div id="root"></div></body></html>`, {
    url: "https://example.test/admin/premium",
    runScripts: "outside-only",
    pretendToBeVisual: true,
  });
  const { window } = dom;
  window.fetch = async (url) => {
    const u = String(url);
    console.log("[fetch mock] requested:", u);
    if (u.includes("/api/admin/me")) return { ok: true, status: 200, json: async () => ({ username: "test-admin" }) };
    if (u.includes("/api/v45/admin/requests") && !u.includes("/receipt")) return { ok: true, status: 200, json: async () => ({ items: REQUESTS }) };
    if (u.match(/\/api\/v45\/admin\/requests\/101\/receipt/)) {
      console.log("[fetch mock] -> serving fake receipt for 101");
      return { ok: true, status: 200, headers: { get: () => 'attachment; filename="receipt-101.pdf"' }, blob: async () => new window.Blob(["fake-pdf-bytes"]) };
    }
    if (u.match(/\/api\/v45\/admin\/requests\/102\/receipt/)) {
      console.log("[fetch mock] -> serving 404 for 102");
      return { ok: false, status: 404, json: async () => ({ message: "Receipt not found." }) };
    }
    return { ok: true, status: 200, json: async () => ({}) };
  };
  window.URL.createObjectURL = () => "blob:fake";
  window.URL.revokeObjectURL = () => {};

  const styleEl = window.document.createElement("style");
  styleEl.textContent = css;
  window.document.head.appendChild(styleEl);
  window.eval(js);
  await new Promise((r) => setTimeout(r, 80));
  await new Promise((r) => setTimeout(r, 80));

  const root = window.document.getElementById("root");
  console.log("Rendered:", root.children.length > 0, "| location:", window.location.pathname);

  const rows = Array.from(root.querySelectorAll(".divide-y > div")).filter((el) => /Request #/.test(el.textContent || ""));
  console.log("Paid-request rows found:", rows.length);

  for (const row of rows) {
    const text = row.textContent || "";
    const idMatch = text.match(/Request #(\d+)/);
    const id = idMatch ? idMatch[1] : "?";
    console.log(`\n-- Row #${id} --`);
    console.log("full row text:", text.replace(/\s+/g, " ").trim());
  }

  console.log("\n=== Expectations ===");
  const row101 = rows.find((r) => /Request #101/.test(r.textContent || ""));
  const row102 = rows.find((r) => /Request #102/.test(r.textContent || ""));
  const row103 = rows.find((r) => /Request #103/.test(r.textContent || ""));

  console.log("101 (pending job_posting regular) shows 'Paid Job — Regular':", /Paid Job — Regular/.test(row101?.textContent || ""));
  console.log("101 shows job title 'Program Officer':", /Program Officer/.test(row101?.textContent || ""));
  console.log("101 shows organization 'Acme Health NGO':", /Acme Health NGO/.test(row101?.textContent || ""));
  console.log("101 (pending) shows Publish+Reject controls:", /Publish/.test(row101?.textContent || "") && /Reject/.test(row101?.textContent || ""));

  console.log("102 (published job_posting featured) shows 'Paid Job — Featured':", /Paid Job — Featured/.test(row102?.textContent || ""));
  console.log("102 shows live job title 'Senior Program Officer':", /Senior Program Officer/.test(row102?.textContent || ""));
  const has102Publish = row102 ? Array.from(row102.querySelectorAll("button")).some((b) => /^Publish$/.test((b.textContent || "").trim())) : true;
  console.log("102 (already published) does NOT show a Publish button:", !has102Publish);

  console.log("103 (boost) shows 'Premium Boost':", /Premium Boost/.test(row103?.textContent || ""));
  console.log("103 shows boosted job title 'Logistics Coordinator':", /Logistics Coordinator/.test(row103?.textContent || ""));

  console.log("\n=== Receipt link behavior ===");
  const receiptBtn101 = Array.from(row101.querySelectorAll("button")).find((b) => /View receipt/.test(b.textContent || ""));
  console.log("101 has a 'View receipt' button (real receipt_original_name present):", !!receiptBtn101);
  const receiptBtn103 = row103 ? Array.from(row103.querySelectorAll("button")).find((b) => /View receipt/.test(b.textContent || "")) : null;
  console.log("103 (no receipt_original_name) shows no receipt control at all:", !receiptBtn103);

  if (receiptBtn101) {
    receiptBtn101.dispatchEvent(new window.Event("click", { bubbles: true }));
    await new Promise((r) => setTimeout(r, 200));
    console.log("101 after clicking 'View receipt' (real file, mocked 200): button/label text now:", receiptBtn101.textContent, "(expected: back to 'View receipt', re-enabled, since the fetch succeeded and settled)");
  }

  const receiptBtn102 = Array.from(row102.querySelectorAll("button")).find((b) => /View receipt/.test(b.textContent || ""));
  if (receiptBtn102) {
    receiptBtn102.dispatchEvent(new window.Event("click", { bubbles: true }));
    await new Promise((r) => setTimeout(r, 50));
    const nowText = row102.textContent || "";
    console.log("102 after clicking 'View receipt' (mocked 404 — stale file): row now shows 'Receipt unavailable':", /Receipt unavailable/.test(nowText));
  }
}
run();
