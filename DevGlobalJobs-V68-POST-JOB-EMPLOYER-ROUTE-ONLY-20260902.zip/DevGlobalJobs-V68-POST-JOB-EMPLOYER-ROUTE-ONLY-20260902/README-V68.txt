V68 is a minimal two-file hotfix on top of exact V67.

It fixes only the regression where SPA navigation to /post-job could show the old Post a Job page.
The secure Employer Workspace route remains /post-job?employer=1.

Deployment is zero-downtime frontend file replacement. No PM2 restart/reload.
The deploy script SAFE STOPs unless the exact V67 baseline and protected assets are present.
