#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$HERE/payload/dist/public"
BACKUP="/var/backups/devglobaljobs-v68-post-job-route-$(date +%Y%m%d-%H%M%S)"

# Exact V67 baseline hashes from reviewed V67 package.
V67_IDX="dfc39b02aab13180cde86a49d4caf7e52aaffa4cdc1557c62b305e1499a654a6"
V67_EMP="645f804cb5d5abcb3482d4be1f42d655684ee97f979209cdf71c6dc2f0645efc"
V67_COMM="ce203a36e6b721c49085fa8485504dee9143f923c5f06718d4922bc0adec6314"
V67_PREM="8158610dd628ad9749c0e906fccd72aea2933df58798980860350d2553d872ff"
V67_REC="592622150567ef99eae9c46ae61ba4a8a2b57d03d845332f88bd857badfe7840"
REC_CSS="4fd6bc549aa36c3c674404d13c9e0ef0e65de46f23988daf759cce421b021042"
ADMIN_JS="8f463260c08757f95419ea461233315f18f0bbac590b2b287761e7b8e53cc0bf"
SW_DIST="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"

V68_IDX="506b154048b8095284d99e9f2a39ba50e5eb096a9de777b52e496099721cef77"
V68_EMP="01f2175b99f1911a06e055d7a6cca380d19856bbc7e7ef4df79a9beb2bf59715"

H(){ sha256sum "$1" | awk '{print $1}'; }
fail(){
  echo
  echo '============================================================'
  echo "SAFE STOP: $*"
  if [ -d "$BACKUP" ] && [ -f "$BACKUP/index.html" ]; then
    echo 'ROLLBACK: restoring exact pre-V68 two files...'
    cp -af "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -af "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    echo 'ROLLBACK COMPLETE.'
  fi
  echo 'NO PM2 RESTART/RELOAD. NO BACKEND/DATABASE/PWA CHANGE.'
  echo '============================================================'
  exit 1
}

echo '============================================================'
echo 'DEV GLOBAL JOBS V68'
echo 'POST JOB -> SECURE EMPLOYER WORKSPACE ROUTE ONLY'
echo 'ZERO-DOWNTIME TWO-FILE FRONTEND HOTFIX'
echo '============================================================'

echo '1/8 EXACT V67 BASELINE + LIVE HEALTH'
for f in \
 "$APP/dist/public/index.html" \
 "$APP/dist/public/assets/dgj-v51-employer.js" \
 "$APP/dist/public/assets/dgj-v45-commercial.js" \
 "$APP/dist/public/assets/dgj-v49-premium.js" \
 "$APP/dist/public/assets/dgj-v51-recruitment.js" \
 "$APP/dist/public/assets/dgj-v51-recruitment.css" \
 "$APP/dist/public/assets/dgj-v57-admin-enterprise.js" \
 "$APP/dist/public/sw.js"; do [ -f "$f" ] || fail "missing file: $f"; done
[ "$(H "$APP/dist/public/index.html")" = "$V67_IDX" ] || fail 'index is not exact V67 baseline'
[ "$(H "$APP/dist/public/assets/dgj-v51-employer.js")" = "$V67_EMP" ] || fail 'employer JS is not exact V67 baseline'
[ "$(H "$APP/dist/public/assets/dgj-v45-commercial.js")" = "$V67_COMM" ] || fail 'commercial JS differs from V67; refusing unrelated overwrite'
[ "$(H "$APP/dist/public/assets/dgj-v49-premium.js")" = "$V67_PREM" ] || fail 'premium JS differs from V67; refusing unrelated overwrite'
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.js")" = "$V67_REC" ] || fail 'recruitment JS differs from V67; refusing unrelated overwrite'
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.css")" = "$REC_CSS" ] || fail 'recruitment CSS differs; refusing unrelated overwrite'
[ "$(H "$APP/dist/public/assets/dgj-v57-admin-enterprise.js")" = "$ADMIN_JS" ] || fail 'admin JS differs; refusing unrelated overwrite'
[ "$(H "$APP/dist/public/sw.js")" = "$SW_DIST" ] || fail 'service worker differs; refusing unrelated overwrite'
API="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$API" = '200' ] || fail "API health=$API"
[ "$HOME" = '200' ] || fail "homepage health=$HOME"
echo 'PASS: exact V67 + protected assets + health verified.'

echo '2/8 PACKAGE PREFLIGHT'
bash "$HERE/preflight-v68.sh" || fail 'V68 preflight failed'
echo 'PASS: V68 package verified.'

echo '3/8 PRIVATE TWO-FILE BACKUP'
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
echo "Backup: $BACKUP"

echo '4/8 ATOMIC TWO-FILE INSTALL'
install -m 0644 "$PAYLOAD/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v68.tmp"
install -m 0644 "$PAYLOAD/index.html" "$APP/dist/public/index.html.v68.tmp"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v68.tmp" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/index.html.v68.tmp" "$APP/dist/public/index.html"
echo 'PASS: only employer JS + index cache reference installed.'

echo '5/8 EXACT BYTE + PROTECTED-ASSET VERIFICATION'
[ "$(H "$APP/dist/public/index.html")" = "$V68_IDX" ] || fail 'installed V68 index hash mismatch'
[ "$(H "$APP/dist/public/assets/dgj-v51-employer.js")" = "$V68_EMP" ] || fail 'installed V68 employer JS hash mismatch'
[ "$(H "$APP/dist/public/assets/dgj-v45-commercial.js")" = "$V67_COMM" ] || fail 'commercial JS changed unexpectedly'
[ "$(H "$APP/dist/public/assets/dgj-v49-premium.js")" = "$V67_PREM" ] || fail 'premium JS changed unexpectedly'
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.js")" = "$V67_REC" ] || fail 'recruitment JS changed unexpectedly'
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.css")" = "$REC_CSS" ] || fail 'recruitment CSS changed unexpectedly'
[ "$(H "$APP/dist/public/assets/dgj-v57-admin-enterprise.js")" = "$ADMIN_JS" ] || fail 'admin JS changed unexpectedly'
[ "$(H "$APP/dist/public/sw.js")" = "$SW_DIST" ] || fail 'service worker changed unexpectedly'
echo 'PASS: exact V68 two-file bytes; all protected assets unchanged.'

echo '6/8 ORIGIN CONTRACT — NO PM2 RELOAD'
IDX="$(curl -fsS --max-time 15 http://127.0.0.1:8080/)" || fail 'origin homepage fetch failed'
printf '%s' "$IDX" | grep -F 'dgj-v51-employer.js?v=68.0.0' >/dev/null || fail 'origin index missing V68 employer reference'
EMP="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v51-employer.js)" || fail 'origin employer JS fetch failed'
printf '%s' "$EMP" | grep -F '__DGJ_V68_POST_ROUTE_GUARD__' >/dev/null || fail 'origin V68 marker missing'
printf '%s' "$EMP" | grep -F 'installPostJobRouteGuard' >/dev/null || fail 'origin route guard missing'
printf '%s' "$EMP" | grep -F "location.assign('/post-job?employer=1')" >/dev/null || fail 'origin public Post a Job redirect missing'
echo 'PASS: origin serves V68 immediately without backend restart.'

echo '7/8 FINAL HEALTH'
API="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$API" = '200' ] || fail "post-install API health=$API"
[ "$HOME" = '200' ] || fail "post-install homepage health=$HOME"
echo 'PASS: backend + homepage healthy.'

echo '8/8 FINAL SCOPE'
echo '============================================================'
echo 'SUCCESS: V68 POST JOB EMPLOYER ROUTE FIX IS LIVE'
echo '============================================================'
echo '✓ Public/header Post a Job no longer remains on legacy /post-job'
echo '✓ React Router pushState/replaceState /post-job is normalized event-by-event'
echo '✓ Secure Employer Workspace route is /post-job?employer=1'
echo '✓ No polling or MutationObserver added by V68'
echo '✓ V67 Employer layout and main-thread fixes retained'
echo '✓ Commercial/Premium/Recruitment/Easy Apply unchanged from V67'
echo '✓ Admin/backend/database/payment backend/PWA/SEO unchanged'
echo '✓ No PM2 reload/restart performed'
echo "Rollback backup: $BACKUP"
echo '============================================================'
