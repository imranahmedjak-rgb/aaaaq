#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
P="$HERE/payload/dist/public"
[ -f "$P/index.html" ]
[ -f "$P/assets/dgj-v51-employer.js" ]
COUNT="$(find "$P" -type f | wc -l | tr -d ' ')"
[ "$COUNT" = "2" ] || { echo "FAIL: payload file count=$COUNT, expected 2"; exit 1; }
node --check "$P/assets/dgj-v51-employer.js" >/dev/null
grep -F 'dgj-v51-employer.js?v=68.0.0' "$P/index.html" >/dev/null
grep -F '__DGJ_V68_POST_ROUTE_GUARD__' "$P/assets/dgj-v51-employer.js" >/dev/null
grep -F 'installPostJobRouteGuard' "$P/assets/dgj-v51-employer.js" >/dev/null
grep -F "location.replace('/post-job?employer=1')" "$P/assets/dgj-v51-employer.js" >/dev/null
! grep -F "location.replace('/employer/post-job')" "$P/assets/dgj-v51-employer.js" >/dev/null
# V68 must not add new polling/observer mechanisms.
# Existing employer file can contain legacy function definitions, but no V68 guard uses polling.
(cd "$P" && sha256sum -c "$HERE/PAYLOAD-SHA256SUMS.txt")
echo 'PASS: V68 post-job employer-route-only preflight.'
