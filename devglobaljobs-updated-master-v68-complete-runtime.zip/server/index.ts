import express from "express";
import session from "express-session";
import compression from "compression";
import path from "path";
import { registerRoutes } from "./routes";
import { registerEasyApplyRoutes } from "./easyApply";

const app = express();

export function log(message: string, source = "express") {
  const timestamp = new Date().toISOString();
  console.log(`${timestamp} [${source}] ${message}`);
}

// HTTPS redirect in production
if (process.env.NODE_ENV === "production") {
  app.set("trust proxy", 1);
  app.use((req, res, next) => {
    const proto = req.headers["x-forwarded-proto"];
    if (proto && proto !== "https") {
      return res.redirect(301, `https://${req.headers.host}${req.url}`);
    }
    next();
  });
}

// force-https redirect via x-forwarded-proto header check
app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session with secure cookie in production
app.use(session({
  secret: process.env.SESSION_SECRET || (() => { throw new Error("SESSION_SECRET required"); })(),
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000,
  },
}));

// Static files with differentiated cache headers
app.use(express.static(path.join(__dirname, "public"), {
  setHeaders(res, filePath) {
    if (filePath.match(/\.(js|css)$/)) {
      res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    } else if (filePath.match(/\.(png|jpg|jpeg|gif|svg|ico|webp)$/)) {
      res.setHeader("Cache-Control", "public, max-age=2592000");
    } else {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    }
  },
}));

registerEasyApplyRoutes(app);
registerRoutes(app);

const PORT = parseInt(process.env.PORT || "3000", 10);
app.listen(PORT, "0.0.0.0", () => {
  log(`Server running on port ${PORT}`);
});
