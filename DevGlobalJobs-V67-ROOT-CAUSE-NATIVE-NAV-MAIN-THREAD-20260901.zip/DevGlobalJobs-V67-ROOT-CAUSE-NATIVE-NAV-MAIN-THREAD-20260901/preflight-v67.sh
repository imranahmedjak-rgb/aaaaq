#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
P="$HERE/payload/dist/public"
for f in index.html assets/dgj-v51-employer.js assets/dgj-v45-commercial.js assets/dgj-v49-premium.js assets/dgj-v51-recruitment.js; do [ -f "$P/$f" ]; done
node --check "$P/assets/dgj-v51-employer.js" >/dev/null
node --check "$P/assets/dgj-v45-commercial.js" >/dev/null
node --check "$P/assets/dgj-v49-premium.js" >/dev/null
node --check "$P/assets/dgj-v51-recruitment.js" >/dev/null
grep -F 'dgj-v51-employer.js?v=67.0.0' "$P/index.html" >/dev/null
grep -F 'dgj-v45-commercial.js?v=67.0.0' "$P/index.html" >/dev/null
grep -F 'dgj-v49-premium.js?v=67.0.0' "$P/index.html" >/dev/null
grep -F 'dgj-v51-recruitment.js?v=67.0.0' "$P/index.html" >/dev/null
grep -F 'window.__DGJ_V67_NATIVE_ANCHOR_NAV__=true' "$P/assets/dgj-v51-employer.js" >/dev/null
grep -F '<a href="${employerTabHref(x[0])}" data-dgj46-nav=' "$P/assets/dgj-v51-employer.js" >/dev/null
grep -F 'window.__DGJ_V67_BOUNDED_COMMERCIAL__=true' "$P/assets/dgj-v45-commercial.js" >/dev/null
grep -F 'window.__DGJ_V67_BOUNDED_PREMIUM__=true' "$P/assets/dgj-v49-premium.js" >/dev/null
grep -F 'window.__DGJ_V67_BOUNDED_RECRUITMENT__=true' "$P/assets/dgj-v51-recruitment.js" >/dev/null
! grep -F 'new MutationObserver' "$P/assets/dgj-v45-commercial.js" >/dev/null
! grep -F 'new MutationObserver' "$P/assets/dgj-v49-premium.js" >/dev/null
! grep -F 'new MutationObserver' "$P/assets/dgj-v51-recruitment.js" >/dev/null
! grep -F 'setInterval(tick,900)' "$P/assets/dgj-v51-recruitment.js" >/dev/null
! grep -F 'setInterval(()=>{try{enhancePortalPanels()' "$P/assets/dgj-v49-premium.js" >/dev/null
! grep -F 'setInterval(findAndAttach, 5000)' "$P/index.html" >/dev/null
! grep -F 'setInterval(injectRuleBanner, 3000)' "$P/index.html" >/dev/null
echo 'PASS: V67 root-cause/native-navigation preflight.'
