#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$HERE/payload/dist/public"
BACKUP="/var/backups/devglobaljobs-v67-root-cause-$(date +%Y%m%d-%H%M%S)"

# Exact live V66 baseline from the read-only diagnostic.
V66_IDX="fb965e235f264ea2e968908490ef218c263c21a88a8e18250bf7bed82cddaa7c"
V66_EMP="ddd42715591de7cc6abb6f31826f60c9809b194c73ddc0422e50ab791bfb8798"
V66_COMM="0476e5a72a80392919906fb42a9a04cbebdd111cf0a563989b2efde1ee99a1d9"
V55_PREM="9df668535f6876ba727c17cc85eabf33f9004f114b4109cc990b129c810e841d"
V60_REC="25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304"
REC_CSS="4fd6bc549aa36c3c674404d13c9e0ef0e65de46f23988daf759cce421b021042"
ADMIN_JS="8f463260c08757f95419ea461233315f18f0bbac590b2b287761e7b8e53cc0bf"
SW_DIST="7f6986e064891c43437df7f35fd4c2a7050d1ce82bd0120b12afb7e9fa1733f3"

V67_IDX="dfc39b02aab13180cde86a49d4caf7e52aaffa4cdc1557c62b305e1499a654a6"
V67_EMP="645f804cb5d5abcb3482d4be1f42d655684ee97f979209cdf71c6dc2f0645efc"
V67_COMM="ce203a36e6b721c49085fa8485504dee9143f923c5f06718d4922bc0adec6314"
V67_PREM="8158610dd628ad9749c0e906fccd72aea2933df58798980860350d2553d872ff"
V67_REC="592622150567ef99eae9c46ae61ba4a8a2b57d03d845332f88bd857badfe7840"

fail(){
  echo
  echo '============================================================'
  echo "SAFE STOP: $*"
  if [ -d "$BACKUP" ] && [ -f "$BACKUP/index.html" ]; then
    echo 'ROLLBACK: restoring exact pre-V67 frontend files...'
    cp -af "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -af "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    cp -af "$BACKUP/dgj-v45-commercial.js" "$APP/dist/public/assets/dgj-v45-commercial.js" || true
    cp -af "$BACKUP/dgj-v49-premium.js" "$APP/dist/public/assets/dgj-v49-premium.js" || true
    cp -af "$BACKUP/dgj-v51-recruitment.js" "$APP/dist/public/assets/dgj-v51-recruitment.js" || true
    echo 'ROLLBACK COMPLETE.'
  fi
  echo 'NO PM2 RESTART/RELOAD. BACKEND/DATABASE/PWA/SEO PROTECTED.'
  echo '============================================================'
  exit 1
}

H(){ sha256sum "$1"|awk '{print $1}'; }

echo '============================================================'
echo 'DEV GLOBAL JOBS V67'
echo 'ROOT-CAUSE MAIN-THREAD STABILITY + NATIVE EMPLOYER NAV'
echo 'ZERO-DOWNTIME FRONTEND ATOMIC INSTALL'
echo '============================================================'

echo '1/10 EXACT V66 LIVE BASELINE + HEALTH'
for f in \
 "$APP/dist/public/index.html" \
 "$APP/dist/public/assets/dgj-v51-employer.js" \
 "$APP/dist/public/assets/dgj-v45-commercial.js" \
 "$APP/dist/public/assets/dgj-v49-premium.js" \
 "$APP/dist/public/assets/dgj-v51-recruitment.js" \
 "$APP/dist/public/assets/dgj-v51-recruitment.css" \
 "$APP/dist/public/assets/dgj-v57-admin-enterprise.js" \
 "$APP/dist/public/sw.js"; do [ -f "$f" ] || fail "missing live/protected file: $f"; done
[ "$(H "$APP/dist/public/index.html")" = "$V66_IDX" ] || fail 'index is not exact V66 baseline'
[ "$(H "$APP/dist/public/assets/dgj-v51-employer.js")" = "$V66_EMP" ] || fail 'employer JS is not exact V66 baseline'
[ "$(H "$APP/dist/public/assets/dgj-v45-commercial.js")" = "$V66_COMM" ] || fail 'commercial JS is not exact V66 baseline'
[ "$(H "$APP/dist/public/assets/dgj-v49-premium.js")" = "$V55_PREM" ] || fail "premium JS differs from expected V55 live baseline: $(H "$APP/dist/public/assets/dgj-v49-premium.js")"
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.js")" = "$V60_REC" ] || fail 'recruitment JS differs from protected V60 baseline'
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.css")" = "$REC_CSS" ] || fail 'recruitment CSS differs; refusing overwrite'
[ "$(H "$APP/dist/public/assets/dgj-v57-admin-enterprise.js")" = "$ADMIN_JS" ] || fail 'admin enterprise JS differs; refusing overwrite'
[ "$(H "$APP/dist/public/sw.js")" = "$SW_DIST" ] || fail 'service worker differs from diagnostic baseline; refusing unrelated overwrite'
CODE="$(curl -sS -o /tmp/dgj-v67-before.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "homepage health is $HOME"
echo 'PASS: exact V66 + premium/recruitment/service-worker baselines + health verified.'

echo '2/10 PACKAGE PREFLIGHT'
bash "$HERE/preflight-v67.sh" || fail 'V67 preflight failed'
(cd "$PAYLOAD" && sha256sum -c "$HERE/PAYLOAD-SHA256SUMS.txt") || fail 'payload checksum failed'
echo 'PASS: V67 package verified.'

echo '3/10 PRIVATE FIVE-FILE ROLLBACK BACKUP'
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
cp -a "$APP/dist/public/assets/dgj-v45-commercial.js" "$BACKUP/dgj-v45-commercial.js"
cp -a "$APP/dist/public/assets/dgj-v49-premium.js" "$BACKUP/dgj-v49-premium.js"
cp -a "$APP/dist/public/assets/dgj-v51-recruitment.js" "$BACKUP/dgj-v51-recruitment.js"
echo "Backup: $BACKUP"

echo '4/10 ATOMIC FIVE-FILE INSTALL'
install -m 0644 "$PAYLOAD/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v67.tmp"
install -m 0644 "$PAYLOAD/assets/dgj-v45-commercial.js" "$APP/dist/public/assets/dgj-v45-commercial.js.v67.tmp"
install -m 0644 "$PAYLOAD/assets/dgj-v49-premium.js" "$APP/dist/public/assets/dgj-v49-premium.js.v67.tmp"
install -m 0644 "$PAYLOAD/assets/dgj-v51-recruitment.js" "$APP/dist/public/assets/dgj-v51-recruitment.js.v67.tmp"
install -m 0644 "$PAYLOAD/index.html" "$APP/dist/public/index.html.v67.tmp"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v67.tmp" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/assets/dgj-v45-commercial.js.v67.tmp" "$APP/dist/public/assets/dgj-v45-commercial.js"
mv -f "$APP/dist/public/assets/dgj-v49-premium.js.v67.tmp" "$APP/dist/public/assets/dgj-v49-premium.js"
mv -f "$APP/dist/public/assets/dgj-v51-recruitment.js.v67.tmp" "$APP/dist/public/assets/dgj-v51-recruitment.js"
mv -f "$APP/dist/public/index.html.v67.tmp" "$APP/dist/public/index.html"
echo 'PASS: V67 frontend files installed atomically; backend process untouched.'

echo '5/10 EXACT BYTE VERIFICATION'
[ "$(H "$APP/dist/public/index.html")" = "$V67_IDX" ] || fail 'installed index hash mismatch'
[ "$(H "$APP/dist/public/assets/dgj-v51-employer.js")" = "$V67_EMP" ] || fail 'installed employer hash mismatch'
[ "$(H "$APP/dist/public/assets/dgj-v45-commercial.js")" = "$V67_COMM" ] || fail 'installed commercial hash mismatch'
[ "$(H "$APP/dist/public/assets/dgj-v49-premium.js")" = "$V67_PREM" ] || fail 'installed premium hash mismatch'
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.js")" = "$V67_REC" ] || fail 'installed recruitment hash mismatch'
echo 'PASS: exact V67 bytes installed.'

echo '6/10 PROTECTED-ASSET VERIFICATION'
[ "$(H "$APP/dist/public/assets/dgj-v51-recruitment.css")" = "$REC_CSS" ] || fail 'recruitment CSS changed unexpectedly'
[ "$(H "$APP/dist/public/assets/dgj-v57-admin-enterprise.js")" = "$ADMIN_JS" ] || fail 'admin enterprise JS changed unexpectedly'
[ "$(H "$APP/dist/public/sw.js")" = "$SW_DIST" ] || fail 'service worker changed unexpectedly'
echo 'PASS: CSS/Admin/PWA protected bytes unchanged.'

echo '7/10 ORIGIN V67 CONTRACT — NO PM2 RELOAD'
IDX="$(curl -fsS --max-time 15 http://127.0.0.1:8080/)" || fail 'origin homepage fetch failed'
for ref in 'dgj-v51-employer.js?v=67.0.0' 'dgj-v45-commercial.js?v=67.0.0' 'dgj-v49-premium.js?v=67.0.0' 'dgj-v51-recruitment.js?v=67.0.0'; do printf '%s' "$IDX"|grep -F "$ref" >/dev/null || fail "origin index missing $ref"; done
EMP="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v51-employer.js)" || fail 'origin employer JS fetch failed'
printf '%s' "$EMP"|grep -F '__DGJ_V67_NATIVE_ANCHOR_NAV__' >/dev/null || fail 'origin employer marker missing'
printf '%s' "$EMP"|grep -F '<a href="${employerTabHref(x[0])}" data-dgj46-nav=' >/dev/null || fail 'dashboard native anchors missing'
PREM="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v49-premium.js)" || fail 'origin premium JS fetch failed'
REC="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v51-recruitment.js)" || fail 'origin recruitment JS fetch failed'
COMM="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v45-commercial.js)" || fail 'origin commercial JS fetch failed'
for body in "$PREM" "$REC" "$COMM"; do if printf '%s' "$body"|grep -F 'new MutationObserver' >/dev/null; then fail 'unbounded observer still present in patched runtime asset'; fi; done
echo 'PASS: origin serves native anchors + bounded runtime assets immediately.'

echo '8/10 FINAL API + HOME HEALTH'
CODE="$(curl -sS -o /tmp/dgj-v67-after.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "post-install API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "post-install homepage health is $HOME"
echo 'PASS: backend + homepage healthy.'

echo '9/10 PM2 NON-RESTART CONTRACT'
pm2 status | sed -n '1,20p'
echo 'PASS: deploy script issued no PM2 restart/reload command.'

echo '10/10 FINAL SCOPE'
echo '============================================================'
echo 'SUCCESS: V67 ROOT-CAUSE STABILITY + NATIVE NAV IS LIVE'
echo '============================================================'
echo '✓ Employer Dashboard menu is real browser <a href> navigation'
echo '✓ Capture-level Employer navigation interceptor is not installed'
echo '✓ V55 Premium global MutationObserver + recurring loop removed'
echo '✓ V60 Recruitment global MutationObserver + 900ms loop removed'
echo '✓ Commercial MutationObserver removed from runtime'
echo '✓ Post Job description polling changed from perpetual to bounded retries'
echo '✓ Saved/Profile observer is not attached inside Employer/Admin/Post workspace'
echo '✓ Existing Easy Apply business flows retained; recruitment CSS unchanged'
echo '✓ Existing V64 Employer layout retained'
echo '✓ Service worker/PWA unchanged'
echo '✓ Admin enterprise JS unchanged'
echo '✓ Backend/database/payment backend/SEO/Google Jobs unchanged'
echo '✓ Website remained served; no PM2 reload/restart performed'
echo "Rollback backup: $BACKUP"
echo '============================================================'
