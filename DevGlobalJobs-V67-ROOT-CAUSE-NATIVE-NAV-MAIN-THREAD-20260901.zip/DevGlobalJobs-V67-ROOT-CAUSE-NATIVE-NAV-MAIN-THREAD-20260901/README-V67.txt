V67 is based on the live V66 diagnostic evidence from 2026-09-01.

Confirmed by diagnostic before this build:
- PM2 online, CPU low, memory ~356 MB
- API response ~1.4 ms, homepage ~10 ms
- live Employer V66 asset equals disk hash
- service worker navigation is network-first and no-store
- therefore the Chrome Page Unresponsive symptom is frontend/main-thread, not origin latency

Root-cause classes addressed in V67:
- remaining global MutationObserver/polling loops in V55 Premium + V60 Recruitment
- post-job commercial observer running inside React-owned form
- JS-dependent Employer Dashboard buttons + competing capture navigation
- perpetual description UI polling on Post Job/Admin routes

Safety:
- exact V66 baseline required
- protected assets checked
- private rollback backup
- atomic frontend install
- no PM2 restart/reload
- API + homepage health checks before/after
