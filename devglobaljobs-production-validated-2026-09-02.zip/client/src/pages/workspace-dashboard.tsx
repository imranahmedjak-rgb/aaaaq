import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { useLocation } from "wouter";
import {
  Activity,
  ArrowUpRight,
  Bell,
  BriefcaseBusiness,
  Building2,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleDollarSign,
  CircleHelp,
  Clock3,
  Download,
  FileCheck2,
  Filter,
  Globe2,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Menu,
  RefreshCw,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  UsersRound,
  X,
} from "lucide-react";

type Mode = "employer" | "admin";
type AnyRecord = Record<string, any>;

async function requestJson<T = AnyRecord>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { credentials: "include", ...init });
  let data: AnyRecord = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok) {
    const error = new Error(data.message || data.error || `Request failed (${response.status})`);
    (error as Error & { status?: number }).status = response.status;
    throw error;
  }
  return data as T;
}

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function displayDate(value: unknown) {
  if (!value) return "—";
  const date = new Date(String(value));
  return Number.isNaN(date.getTime())
    ? String(value)
    : date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

function displayDateTime(value: unknown) {
  if (!value) return "—";
  const date = new Date(String(value));
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString("en-GB");
}

function displayMoney(value: unknown, currency = "USD") {
  const number = Number(value);
  if (!Number.isFinite(number)) return "—";
  return `${currency} ${number.toFixed(2)}`;
}

function countValue(...values: unknown[]) {
  const value = values.find((item) => item !== undefined && item !== null && item !== "");
  return value === undefined ? "—" : Number(value).toLocaleString();
}

function initials(value: unknown) {
  return String(value || "DG").trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "DG";
}

function StatusPill({ status }: { status: unknown }) {
  const value = String(status || "Unknown");
  const lower = value.toLowerCase();
  const tone = /live|active|healthy|paid|hired|approved|shortlisted/.test(lower)
    ? "bg-emerald-50 text-emerald-700"
    : /pending|review|interview|processing|under review|changes/.test(lower)
      ? "bg-amber-50 text-amber-700"
      : /reject|closed|withdrawn|not selected|failed|revoked/.test(lower)
        ? "bg-rose-50 text-rose-700"
        : "bg-slate-100 text-slate-600";
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ${tone}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{value}</span>;
}

function StatCard({ label, value, note, icon: Icon, accent = "cyan" }: { label: string; value: ReactNode; note: string; icon: typeof Activity; accent?: "cyan" | "amber" | "green" | "navy" }) {
  const colors = {
    cyan: "bg-cyan-50 text-cyan-700",
    amber: "bg-amber-50 text-amber-700",
    green: "bg-emerald-50 text-emerald-700",
    navy: "bg-slate-100 text-slate-700",
  };
  return <article className="workspace-card card-lift p-5">
    <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${colors[accent]}`}><Icon size={19} strokeWidth={1.8} /></div>
    <p className="mt-5 text-[11px] font-bold uppercase tracking-[.13em] text-slate-500">{label}</p>
    <p className="mt-1 font-mono-ui text-[29px] font-bold tracking-[-.06em] text-slate-900">{value}</p>
    <p className="mt-1 text-xs text-slate-500">{note}</p>
  </article>;
}

function SectionHeader({ eyebrow, title, action, onAction }: { eyebrow: string; title: string; action?: string; onAction?: () => void }) {
  return <div className="mb-4 flex items-end justify-between gap-3">
    <div><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">{eyebrow}</p><h2 className="mt-1 text-lg font-bold tracking-[-.02em] text-slate-900">{title}</h2></div>
    {action && <button type="button" onClick={onAction} className="inline-flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-cyan-700">{action}<ChevronRight size={14} /></button>}
  </div>;
}

function PageFrame({ eyebrow, title, description, action, onAction, children }: { eyebrow: string; title: string; description: string; action?: string; onAction?: () => void; children: ReactNode }) {
  return <div className="workspace-grid min-h-[calc(100dvh-72px)] px-4 py-7 sm:px-7 lg:px-10">
    <div className="mx-auto w-full max-w-[1480px]">
      <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
        <div><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.2em] text-cyan-700">{eyebrow}</p><h1 className="mt-2 text-[clamp(28px,4vw,42px)] font-bold tracking-[-.055em] text-[#17263a]">{title}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{description}</p></div>
        {action && <button type="button" onClick={onAction} className="inline-flex h-10 items-center gap-2 self-start rounded-xl bg-[#17263a] px-3.5 text-xs font-bold text-white shadow-lg shadow-slate-900/10 hover:-translate-y-0.5 lg:self-auto"><Sparkles size={15} />{action}</button>}
      </div>
      <div className="mt-7">{children}</div>
    </div>
  </div>;
}

const employerNav = [
  ["Overview", LayoutDashboard, "/employer"],
  ["My Jobs", BriefcaseBusiness, "/employer/jobs"],
  ["Applications", UsersRound, "/employer/applications"],
  ["Post a Job", Sparkles, "/post-job?employer=1"],
  ["Analytics", Activity, "/employer/analytics"],
  ["Premium Boost", ArrowUpRight, "/employer/boosts"],
  ["Billing & Payments", FileCheck2, "/employer/billing"],
  ["Plans & Credits", Sparkles, "/employer/plans"],
  ["Company Profile", Building2, "/employer/profile"],
  ["Settings", Settings2, "/employer/settings"],
] as const;

const adminNav = [
  ["Overview", LayoutDashboard, "/admin"],
  ["Jobs", BriefcaseBusiness, "/admin/jobs"],
  ["Employers", Building2, "/admin/employers"],
  ["Applications", FileCheck2, "/admin/applications"],
  ["Review", CircleHelp, "/admin/review"],
  ["Premium & Boosts", Sparkles, "/admin/premium"],
  ["Revenue", CircleDollarSign, "/admin/revenue"],
  ["Reports", Activity, "/admin/reports"],
  ["Growth", ArrowUpRight, "/admin/growth"],
  ["Requests", CircleHelp, "/admin/requests"],
  ["Settings", Settings2, "/admin/settings"],
] as const;

function routeKey(path: string, mode: Mode) {
  const last = path.split("/").filter(Boolean).pop() || "";
  if (mode === "employer") return ({ employer: "Overview", jobs: "My Jobs", applications: "Applications", analytics: "Analytics", boosts: "Premium Boost", billing: "Billing & Payments", plans: "Plans & Credits", profile: "Company Profile", settings: "Settings", support: "Settings" } as AnyRecord)[last] || "Overview";
  return ({ admin: "Overview", jobs: "Jobs", employers: "Employers", applications: "Applications", review: "Review", premium: "Premium & Boosts", revenue: "Revenue", reports: "Reports", growth: "Growth", requests: "Requests", settings: "Settings" } as AnyRecord)[last] || "Overview";
}

function WorkspaceShell({ mode, account, children, onRefresh }: { mode: Mode; account: AnyRecord; children: ReactNode; onRefresh?: () => void }) {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const active = routeKey(location, mode);
  const nav = mode === "employer" ? employerNav : adminNav;
  const company = account.profile?.company_name || account.companyName || account.username || account.email || "Workspace";
  const logout = async () => {
    await requestJson(mode === "admin" ? "/api/admin/logout" : "/api/seekers/logout", { method: "POST" }).catch(() => undefined);
    window.location.href = mode === "admin" ? "/admin" : "/employer/sign-in";
  };
  const go = (path: string) => { setLocation(path); setMobileOpen(false); };
  const pending = mode === "employer"
    ? Number(account.summary?.pendingReviews || 0)
    : Number(account.pending_requests || 0);

  return <div className="workspace-app min-h-[100dvh] bg-[#eef3f7] text-slate-900">
    <aside className={`workspace-sidebar fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col overflow-y-auto bg-[#17263a] text-slate-300 transition-transform duration-300 md:translate-x-0 ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}>
      <div className="flex h-[88px] shrink-0 items-center border-b border-white/10 px-6"><img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs" className="h-12 w-auto object-contain" /><div className="ml-3"><p className="text-sm font-bold text-white">Dev Global Jobs</p><p className="font-mono-ui text-[9px] uppercase tracking-widest text-cyan-300">{mode === "admin" ? "Operations" : "Employer"}</p></div></div>
      <div className="px-4 pt-7"><p className="px-3 font-mono-ui text-[9px] font-bold uppercase tracking-[.2em] text-slate-500">{mode === "admin" ? "Marketplace control" : "Hiring workspace"}</p><nav className="mt-3 space-y-1">
        {nav.map(([label, Icon, path]) => <button key={label} type="button" onClick={() => go(path)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition-colors ${active === label ? "bg-cyan-400 text-[#17263a] shadow-lg shadow-cyan-950/20" : "text-slate-400 hover:bg-white/10 hover:text-white"}`}><Icon size={17} strokeWidth={1.8} /><span>{label}</span>{mode === "admin" && label === "Requests" && pending > 0 && <span className="ml-auto rounded-full bg-amber-300 px-1.5 py-0.5 font-mono-ui text-[9px] font-bold text-[#17263a]">{pending}</span>}</button>)}
      </nav></div>
      <div className="mt-auto px-4 pb-5"><div className="mb-4 rounded-2xl border border-white/10 bg-white/5 p-3.5"><div className="flex items-center gap-2"><ShieldCheck size={14} className="text-cyan-300" /><span className="text-xs font-bold text-white">Secure workspace</span></div><p className="mt-2 text-xs leading-5 text-slate-400">{mode === "admin" ? "Restricted operations backed by the existing admin session." : "Your jobs, applications and payments stay private to this account."}</p></div><button type="button" onClick={() => go(mode === "admin" ? "/admin/settings" : "/employer/profile")} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold text-slate-400 hover:bg-white/10 hover:text-white"><Settings2 size={16} />Settings</button><button type="button" onClick={() => go("/")} className="mt-1 flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold text-slate-400 hover:bg-white/10 hover:text-white"><Globe2 size={16} />Public site</button></div>
    </aside>
    {mobileOpen && <button type="button" aria-label="Close navigation" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-30 bg-slate-950/40 md:hidden" />}
    <main className="min-h-[100dvh] min-w-0 overflow-x-hidden md:pl-[248px]">
      <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-slate-200/90 bg-[#eef3f7]/90 px-4 backdrop-blur-md sm:px-7 lg:px-10">
        <div className="flex items-center gap-3"><button type="button" onClick={() => setMobileOpen(true)} className="rounded-lg p-2 text-slate-600 hover:bg-white md:hidden" aria-label="Open navigation"><Menu size={21} /></button><div className="hidden items-center gap-2 text-sm text-slate-400 sm:flex"><span className="font-semibold">Workspace</span><ChevronRight size={14} /><span className="font-bold text-slate-800">{mode === "admin" ? "Marketplace operations" : company}</span></div></div>
        <div className="flex items-center gap-1.5 sm:gap-3"><button type="button" onClick={() => { setNotificationsOpen((value) => !value); setProfileOpen(false); }} className="relative rounded-xl p-2.5 text-slate-500 hover:bg-white hover:text-slate-900" aria-label="Notifications"><Bell size={19} strokeWidth={1.8} />{pending > 0 && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full border-2 border-[#eef3f7] bg-amber-400" />}</button>{notificationsOpen && <div className="absolute right-16 top-16 w-[280px] rounded-2xl border border-slate-200 bg-white p-4 shadow-2xl"><p className="font-bold text-slate-900">Workspace signals</p><p className="mt-3 text-xs leading-5 text-slate-500">{pending > 0 ? `${pending} item${pending === 1 ? "" : "s"} need attention.` : "No unread workspace signals."}</p>{pending > 0 && <button type="button" onClick={() => { setNotificationsOpen(false); go(mode === "admin" ? "/admin/requests" : "/employer/applications"); }} className="mt-3 text-xs font-bold text-cyan-700">Open queue <ChevronRight size={13} className="inline" /></button>}</div>}<div className="relative"><button type="button" onClick={() => { setProfileOpen((value) => !value); setNotificationsOpen(false); }} className="flex items-center gap-2 rounded-xl p-1.5 pr-2 hover:bg-white"><span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#17263a] text-xs font-bold text-cyan-300">{initials(company)}</span><span className="hidden max-w-[180px] text-left sm:block"><span className="block truncate text-xs font-bold text-slate-800">{company}</span><span className="block text-[10px] text-slate-400">{mode === "admin" ? "Marketplace admin" : account.account?.email || account.email || "Employer account"}</span></span><ChevronDown size={14} className="hidden text-slate-400 sm:block" /></button>{profileOpen && <div className="absolute right-0 top-12 w-48 rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl"><button type="button" onClick={() => { setProfileOpen(false); go(mode === "admin" ? "/admin/settings" : "/employer/profile"); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"><Settings2 size={14} />Account settings</button>{onRefresh && <button type="button" onClick={() => { setProfileOpen(false); onRefresh(); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50"><RefreshCw size={14} />Refresh data</button>}<button type="button" onClick={() => void logout()} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50"><LogOut size={14} />Sign out</button></div>}</div></div>
      </header>
      {children}
    </main>
  </div>;
}

type PortalData = AnyRecord & { jobs?: AnyRecord[]; payments?: AnyRecord[]; plans?: AnyRecord[]; profile?: AnyRecord; summary?: AnyRecord; allowance?: AnyRecord; account?: AnyRecord };

function LoadingState({ label = "Loading workspace…" }: { label?: string }) {
  return <div className="workspace-grid flex min-h-[calc(100dvh-72px)] items-center justify-center p-6"><div className="workspace-card w-full max-w-sm p-10 text-center"><div className="mx-auto h-7 w-7 animate-spin rounded-full border-2 border-slate-200 border-t-cyan-600" /><p className="mt-4 text-sm font-semibold text-slate-600">{label}</p></div></div>;
}

function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return <div className="workspace-card border-rose-200 bg-rose-50 p-5 text-sm text-rose-700"><p>{message}</p>{onRetry && <button type="button" onClick={onRetry} className="mt-3 font-bold underline">Retry</button>}</div>;
}

function EmployerOverview({ data, go }: { data: PortalData; go: (path: string) => void }) {
  const summary = data.summary || {};
  const jobs = data.jobs || [];
  const applications = Number(summary.totalApplications || 0);
  return <PageFrame eyebrow="Global hiring control centre" title={`Welcome, ${data.profile?.company_name || "employer"}.`} description="A live view of the jobs, applications, allowance and commercial activity attached to your verified account." action="Post a job" onAction={() => go("/post-job?employer=1")}>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard label="Active jobs" value={Number(summary.activeJobs || 0).toLocaleString()} note="linked to this account" icon={BriefcaseBusiness} />
      <StatCard label="Applications" value={applications.toLocaleString()} note="verified Easy Apply records" icon={UsersRound} accent="navy" />
      <StatCard label="Pending review" value={Number(summary.pendingReviews || 0).toLocaleString()} note="jobs or payments awaiting review" icon={Clock3} accent="amber" />
      <StatCard label="Premium Boosts" value={Number(summary.activeBoosts || 0).toLocaleString()} note="currently active" icon={Sparkles} accent="green" />
    </div>
    <div className="mt-5 grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
      <section className="workspace-card p-5 sm:p-6"><SectionHeader eyebrow="Recruitment activity" title="Latest jobs" action="Manage all jobs" onAction={() => go("/employer/jobs")} />{jobs.length === 0 ? <Empty text="No employer jobs are linked to this account yet." action="Post your first job" onAction={() => go("/post-job?employer=1")} /> : <div className="divide-y divide-slate-100">{jobs.slice(0, 5).map((job) => <JobRow key={job.id} job={job} onOpen={() => go("/employer/jobs")} />)}</div>}</section>
      <section className="workspace-card p-5 sm:p-6"><SectionHeader eyebrow="Monthly allowance" title="Posting capacity" /><div className="grid grid-cols-2 gap-3"><Quota label="Regular remaining" value={data.allowance?.regularRemaining} /><Quota label="Featured remaining" value={data.allowance?.featuredRemaining} /></div><div className="mt-4 rounded-xl bg-cyan-50 p-4 text-xs leading-5 text-cyan-900/75"><b className="text-cyan-900">Private account data.</b> Paid listings and Boosts remain subject to the existing admin review process.</div><button type="button" onClick={() => go("/employer/billing")} className="mt-4 text-xs font-bold text-cyan-700">Open payment centre <ArrowUpRight size={13} className="inline" /></button></section>
    </div>
    <section className="workspace-card mt-5 p-5 sm:p-6"><SectionHeader eyebrow="Verified telemetry" title="What is measured" /><div className="grid gap-3 sm:grid-cols-3"><Signal label="Applications" value={applications} /><Signal label="Audience views" value={null} /><Signal label="Clicks and shares" value={null} /></div></section>
  </PageFrame>;
}

function Quota({ label, value }: { label: string; value: unknown }) {
  return <div className="rounded-xl bg-slate-50 p-4"><p className="font-mono-ui text-2xl font-bold text-slate-900">{Number(value || 0).toLocaleString()}</p><p className="mt-1 text-[11px] text-slate-500">{label}</p></div>;
}

function Signal({ label, value }: { label: string; value: number | null }) {
  return <div className="rounded-xl border border-slate-100 bg-slate-50/80 p-4"><p className="text-[10px] font-bold uppercase tracking-[.12em] text-slate-400">{label}</p><p className="mt-2 font-mono-ui text-xl font-bold text-slate-800">{value === null ? "Not tracked yet" : value.toLocaleString()}</p></div>;
}

function Empty({ text, action, onAction }: { text: string; action?: string; onAction?: () => void }) {
  return <div className="rounded-xl bg-slate-50 p-8 text-center text-sm text-slate-500"><p>{text}</p>{action && <button type="button" onClick={onAction} className="mt-3 font-bold text-cyan-700">{action} <ArrowUpRight size={13} className="inline" /></button>}</div>;
}

function JobRow({ job, onOpen }: { job: AnyRecord; onOpen: () => void }) {
  const applications = Number(job.total_applications || 0);
  const status = job.recruitment_status && job.recruitment_status !== "open" ? job.recruitment_status : (job.status || (job.published ? "Live" : "Draft"));
  return <button type="button" onClick={onOpen} className="flex w-full items-center gap-3 py-4 text-left hover:bg-cyan-50/30"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-50 text-cyan-700"><BriefcaseBusiness size={17} /></span><span className="min-w-0 flex-1"><span className="block truncate text-sm font-bold text-slate-800">{job.title || "Untitled job"}</span><span className="mt-1 block truncate text-xs text-slate-400">{job.organization || job.company_name || "—"}{job.location ? ` · ${job.location}` : ""}</span></span><span className="hidden text-right sm:block"><span className="block font-mono-ui text-sm font-bold text-slate-700">{applications}</span><span className="text-[10px] text-slate-400">applications</span></span><StatusPill status={status} /></button>;
}

function EmployerJobs({ data, go, refresh }: { data: PortalData; go: (path: string) => void; refresh: () => void }) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const jobs = useMemo(() => (data.jobs || []).filter((job) => {
    const text = `${job.title || ""} ${job.organization || ""} ${job.location || ""}`.toLowerCase();
    const current = String(job.status || (job.published ? "Live" : "Draft")).toLowerCase();
    return text.includes(query.toLowerCase()) && (status === "all" || current === status.toLowerCase());
  }), [data.jobs, query, status]);
  return <PageFrame eyebrow="Employer workspace" title="My jobs" description="Every vacancy, publishing state and applicant signal attached to your employer account." action="Post a job" onAction={() => go("/post-job?employer=1")}><section className="workspace-card overflow-hidden"><div className="flex flex-col gap-4 border-b border-slate-100 p-5 sm:flex-row sm:items-end sm:justify-between sm:p-6"><SectionHeader eyebrow="Persisted listings" title={`${jobs.length} matching jobs`} /><div className="flex gap-2"><label className="relative"><Search size={14} className="absolute left-3 top-2.5 text-slate-400" /><span className="sr-only">Search jobs</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search jobs" className="h-9 w-full rounded-lg border border-slate-200 pl-9 pr-3 text-xs outline-none focus:border-cyan-500 sm:w-44" /></label><label className="relative"><span className="sr-only">Filter job status</span><select value={status} onChange={(event) => setStatus(event.target.value)} className="h-9 rounded-lg border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600"><option value="all">All states</option><option value="live">Live</option><option value="draft">Draft</option><option value="paused">Paused</option></select><Filter size={12} className="pointer-events-none absolute right-2 top-3 text-slate-400" /></label><button type="button" onClick={refresh} className="rounded-lg border border-slate-200 px-3 text-slate-500 hover:border-cyan-300" aria-label="Refresh jobs"><RefreshCw size={14} /></button></div></div><div className="divide-y divide-slate-100 px-5 sm:px-6">{jobs.length ? jobs.map((job) => <JobRow key={job.id} job={job} onOpen={() => window.open(`/jobs/detail/${Number(job.id)}`, "_blank", "noopener,noreferrer")} />) : <Empty text="No jobs match this view." action="Create a vacancy" onAction={() => go("/post-job?employer=1")} />}</div></section></PageFrame>;
}

function EmployerApplications({ data, go }: { data: PortalData; go: (path: string) => void }) {
  const [items, setItems] = useState<AnyRecord[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState("");
  const load = () => { setItems(null); setError(null); void requestJson<{ items?: AnyRecord[] }>(`/api/v51/employer/applications?limit=500${filter ? `&status=${encodeURIComponent(filter)}` : ""}`).then((result) => setItems(result.items || [])).catch((reason) => setError(errorMessage(reason, "Applications could not be loaded."))); };
  useEffect(load, [filter]);
  const updateStatus = async (id: number, value: string) => { try { await requestJson(`/api/v51/employer/applications/${id}/status`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: value }) }); load(); } catch (reason) { setError(errorMessage(reason, "Application status could not be updated.")); } };
  return <PageFrame eyebrow="Candidate applications" title="Recruitment inbox" description="Review real Easy Apply records, download CVs and move candidates through the existing recruitment workflow." action="Export applications" onAction={() => { window.location.href = "/api/v51/employer/reports/applications.csv"; }}><section className="workspace-card overflow-hidden"><div className="flex flex-col gap-4 border-b border-slate-100 p-5 sm:flex-row sm:items-end sm:justify-between sm:p-6"><SectionHeader eyebrow="Application records" title="Latest applications" /><div className="flex gap-2"><select value={filter} onChange={(event) => setFilter(event.target.value)} className="h-9 rounded-lg border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600"><option value="">All statuses</option>{["received", "under_review", "shortlisted", "interview", "offer", "hired", "not_selected", "withdrawn"].map((value) => <option key={value} value={value}>{value.replaceAll("_", " ")}</option>)}</select><button type="button" onClick={load} className="rounded-lg border border-slate-200 px-3 text-slate-500"><RefreshCw size={14} /></button></div></div>{error && <ErrorState message={error} onRetry={load} />}{items === null && !error && <LoadingState label="Loading applications…" />}{items?.length === 0 && <Empty text="No applications match this view." />}{items && items.length > 0 && <div className="divide-y divide-slate-100">{items.map((item) => <div key={item.id} className="flex flex-wrap items-center gap-3 p-5 sm:p-6"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-700">{initials(item.full_name)}</span><div className="min-w-[180px] flex-1"><p className="text-sm font-bold text-slate-800">{item.full_name || "Candidate"}</p><p className="mt-1 text-xs text-slate-400">{item.title || "Job application"} · {displayDate(item.applied_at)}</p><p className="mt-1 text-[11px] text-slate-400">{item.candidate_email || "Email withheld"}</p></div><div className="mr-2 text-right"><p className="text-xs font-bold text-slate-700">{item.delivery_method === "email" ? "Email delivery" : "DGJ workspace"}</p><a href={`/api/v51/employer/applications/${Number(item.id)}/cv`} className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-cyan-700"><Download size={12} />Download CV</a></div><select value={item.status || "received"} onChange={(event) => void updateStatus(Number(item.id), event.target.value)} className="h-9 rounded-lg border border-slate-200 bg-white px-2 text-xs font-semibold text-slate-600">{["received", "under_review", "shortlisted", "interview", "offer", "hired", "not_selected"].map((value) => <option key={value} value={value}>{value.replaceAll("_", " ")}</option>)}</select><StatusPill status={String(item.status || "received").replaceAll("_", " ")} /></div>)}</div>}</section></PageFrame>;
}

function EmployerAnalytics({ data }: { data: PortalData }) {
  const jobs = data.jobs || [];
  const total = jobs.reduce((sum, job) => sum + Number(job.total_applications || 0), 0);
  return <PageFrame eyebrow="Recruitment analytics" title="Job performance" description="Verified recruitment counts from Easy Apply records. Audience views, clicks and shares are intentionally shown only when the platform has measured them." action="Export performance" onAction={() => { window.location.href = "/api/v51/employer/reports/performance.csv"; }}><div className="grid gap-4 sm:grid-cols-3"><StatCard label="Applications" value={total.toLocaleString()} note="across your jobs" icon={UsersRound} /><StatCard label="Audience views" value="Not tracked yet" note="no source telemetry" icon={Globe2} accent="navy" /><StatCard label="Clicks & shares" value="Not tracked yet" note="no source telemetry" icon={Activity} accent="amber" /></div><section className="workspace-card mt-5 p-5 sm:p-6"><SectionHeader eyebrow="Verified funnel" title="Applications by vacancy" /><div className="space-y-4">{jobs.length ? jobs.map((job) => { const count = Number(job.total_applications || 0); const width = total ? Math.max(4, count / total * 100) : 4; return <div key={job.id}><div className="mb-1 flex justify-between gap-3 text-xs"><span className="truncate font-semibold text-slate-600">{job.title || "Untitled job"}</span><span className="font-mono-ui text-[10px] text-slate-400">{count}</span></div><div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-cyan-500" style={{ width: `${width}%` }} /></div></div>; }) : <Empty text="Analytics will appear after your first job is linked to the account." />}</div></section></PageFrame>;
}

function EmployerProfile({ data, refresh }: { data: PortalData; refresh: () => void }) {
  const [form, setForm] = useState(() => ({ contactName: data.profile?.contact_name || "", companyName: data.profile?.company_name || "", companyWebsite: data.profile?.company_website || "", industry: data.profile?.industry || "", companySize: data.profile?.company_size || "", phone: data.profile?.phone || "", country: data.profile?.country || "", addressLine1: data.profile?.address_line1 || "", city: data.profile?.city || "", stateRegion: data.profile?.state_region || "", postalCode: data.profile?.postal_code || "" }));
  const [state, setState] = useState<"ready" | "saving" | "saved" | "error">("ready");
  const [error, setError] = useState("");
  const update = (key: string, value: string) => setForm((current) => ({ ...current, [key]: value }));
  const submit = async (event: FormEvent) => { event.preventDefault(); setState("saving"); setError(""); try { await requestJson("/api/v46/employer/profile", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) }); setState("saved"); refresh(); } catch (reason) { setState("error"); setError(errorMessage(reason, "Company profile could not be saved.")); } };
  const fields: [string, string, string][] = [["contactName", "Contact person", "text"], ["companyName", "Company / organisation", "text"], ["companyWebsite", "Company website", "url"], ["industry", "Industry", "text"], ["companySize", "Company size", "text"], ["phone", "Phone", "tel"], ["country", "Country", "text"], ["addressLine1", "Address", "text"], ["city", "City", "text"], ["stateRegion", "State / region", "text"], ["postalCode", "Postal code", "text"]];
  return <PageFrame eyebrow="Company & hiring account" title="Company profile" description="Keep the organisation identity connected to your verified employer session accurate for candidates, support and payment review."><div className="grid gap-5 xl:grid-cols-[1fr_.65fr]"><form onSubmit={submit} className="workspace-card p-5 sm:p-7"><SectionHeader eyebrow="Verified identity" title="Organisation details" /><div className="grid gap-4 sm:grid-cols-2">{fields.map(([key, label, type]) => <label key={key} className="text-xs font-bold text-slate-700">{label}<input type={type} value={String(form[key as keyof typeof form])} onChange={(event) => update(key, event.target.value)} required={["contactName", "companyName", "country"].includes(key)} className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-cyan-500" /></label>)}<label className="text-xs font-bold text-slate-700 sm:col-span-2">Verified employer email<input disabled value={data.account?.email || ""} className="mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500" /></label></div>{error && <p className="mt-4 rounded-xl bg-rose-50 p-3 text-xs font-semibold text-rose-700">{error}</p>}<button type="submit" disabled={state === "saving"} className="mt-5 h-11 rounded-xl bg-[#17263a] px-5 text-xs font-bold text-white disabled:opacity-60">{state === "saving" ? "Saving…" : state === "saved" ? "Profile saved" : "Save company profile"}</button></form><section className="workspace-card p-6"><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700"><CheckCircle2 size={23} /></div><h2 className="mt-5 text-lg font-bold text-slate-900">Employer account</h2><p className="mt-2 text-xs leading-5 text-slate-500">Your verified identity is used for job ownership, payment verification and employer communications. It is not mixed into candidate profile data.</p><div className="mt-5 rounded-xl bg-slate-50 p-4"><p className="font-mono-ui text-[10px] uppercase tracking-widest text-slate-400">Account status</p><div className="mt-2"><StatusPill status={data.account?.status || "Verified session"} /></div></div></section></div></PageFrame>;
}

function EmployerCommercial({ data, kind }: { data: PortalData; kind: "plans" | "billing" | "boosts" }) {
  const payments = data.payments || [];
  const jobs = data.jobs || [];
  if (kind === "plans") return <PageFrame eyebrow="Plans & credits" title="Hiring allowances" description="Your current complimentary allowance and administrator-assigned employer plans, read from the existing employer workspace data."><div className="grid gap-5 md:grid-cols-2"><section className="workspace-card p-6"><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Complimentary plan</p><h2 className="mt-2 text-xl font-bold">Monthly employer access</h2><div className="mt-5 grid grid-cols-2 gap-3"><Quota label="Regular remaining" value={data.allowance?.regularRemaining} /><Quota label="Featured remaining" value={data.allowance?.featuredRemaining} /></div></section>{(data.plans || []).length ? (data.plans || []).map((plan) => <section key={plan.id || plan.code_prefix} className="workspace-card p-6"><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">{plan.status === "active" ? "Active employer plan" : "Employer plan"}</p><h2 className="mt-2 text-xl font-bold">{plan.plan_label || "Assigned plan"}</h2><p className="mt-1 text-xs text-slate-500">{plan.duration_months || "—"} month(s) · valid until {displayDate(plan.expires_at)}</p><div className="mt-5 space-y-2 text-xs text-slate-600"><p>Regular remaining <b>{Math.max(0, Number(plan.regular_per_month || 0) - Number(plan.regular_used || 0))}</b></p><p>Featured remaining <b>{Math.max(0, Number(plan.featured_per_month || 0) - Number(plan.featured_used || 0))}</b></p><p>Boost remaining <b>{Math.max(0, Number(plan.boosts_per_month || 0) - Number(plan.boost_used || 0))}</b></p></div><div className="mt-5"><StatusPill status={plan.status || "Assigned"} /></div></section>) : <section className="workspace-card p-6"><Empty text="No administrator-assigned employer plans are attached to this account." /></section>}</div></PageFrame>;
  if (kind === "boosts") { const active = jobs.filter((job) => job.boost_ends_at && new Date(job.boost_ends_at) > new Date()); const pending = payments.filter((payment) => payment.request_type === "boost" && ["pending", "processing"].includes(String(payment.status))); return <PageFrame eyebrow="Premium Boost" title="Priority placement control" description="Active and pending Boost records from the existing commercial layer. New requests continue through the established payment and review flow."><div className="grid gap-5 xl:grid-cols-[1.2fr_.8fr]"><section className="workspace-card p-6"><SectionHeader eyebrow="Active placements" title="Your Boost inventory" />{active.length ? <div className="divide-y divide-slate-100">{active.map((job) => <div key={job.id} className="flex items-center gap-3 py-4"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-700"><Sparkles size={17} /></span><span className="flex-1"><b className="block text-sm text-slate-800">{job.title}</b><small className="text-xs text-slate-400">Active until {displayDate(job.boost_ends_at)}</small></span><StatusPill status="Premium Boost live" /></div>)}</div> : <Empty text="No active Premium Boosts are attached to your live jobs." />}{pending.length > 0 && <div className="mt-5 rounded-xl bg-amber-50 p-4 text-xs leading-5 text-amber-900">You have {pending.length} Boost request{pending.length === 1 ? "" : "s"} awaiting payment review.</div>}</section><section className="workspace-card bg-[#17263a] p-6 text-white"><Sparkles className="text-amber-300" size={24} /><h2 className="mt-4 text-xl font-bold">Transparent paid visibility</h2><p className="mt-2 text-sm leading-6 text-slate-300">Premium placement improves commercial ranking while active; it does not guarantee applications. Use the existing Post a Job or job actions to submit a request.</p><a href="/post-job?employer=1" className="mt-6 inline-flex h-11 items-center rounded-xl bg-cyan-400 px-4 text-xs font-bold text-[#17263a]">Open posting flow</a></section></div></PageFrame>; }
  return <PageFrame eyebrow="Employer payment centre" title="Billing & payments" description="Private payment references, receipts and commercial requests attached to your employer account."><div className="grid gap-5 xl:grid-cols-[.75fr_1.25fr]"><section className="space-y-5"><section className="workspace-card p-6"><p className="font-mono-ui text-[10px] font-bold uppercase tracking-[.18em] text-cyan-700">Payment partners</p><div className="mt-4 space-y-3"><a href="https://wise.com/pay/business/trendnovaworldlimited" target="_blank" rel="nofollow noopener" className="block rounded-xl bg-slate-50 p-4 hover:bg-cyan-50"><b className="block text-sm">Pay with Wise</b><span className="mt-1 block text-xs text-slate-500">Trend Nova World Limited</span></a><a href="https://www.paypal.com/paypalme/tnwdgj" target="_blank" rel="nofollow noopener" className="block rounded-xl bg-slate-50 p-4 hover:bg-cyan-50"><b className="block text-sm">Pay with PayPal</b><span className="mt-1 block text-xs text-slate-500">TNW / Dev Global Jobs</span></a></div></section><section className="workspace-card p-6"><p className="text-xs leading-5 text-slate-500">Paid listings and Premium Boosts activate only after the existing admin verification process confirms the payment reference and receipt.</p></section></section><section className="workspace-card overflow-hidden"><div className="border-b border-slate-100 p-6"><SectionHeader eyebrow="Payment history" title="Your requests" /></div>{payments.length ? <div className="divide-y divide-slate-100">{payments.map((payment) => <div key={payment.id || payment.payment_reference} className="flex flex-wrap items-center gap-3 p-5"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600"><FileCheck2 size={16} /></span><span className="min-w-[170px] flex-1"><b className="block text-xs text-slate-800">{payment.request_type || "Payment request"}</b><small className="mt-1 block text-[10px] text-slate-400">{payment.payment_reference || "No reference"} · {displayDate(payment.created_at)}</small></span><span className="font-mono-ui text-sm font-bold text-slate-700">{displayMoney(payment.amount, payment.currency)}</span><StatusPill status={payment.status} /></div>)}</div> : <Empty text="No payment requests are attached to this account yet." />}</section></div></PageFrame>;
}

function EmployerSettings() {
  return <PageFrame eyebrow="Employer support" title="Workspace support" description="Use the existing support channel for account, job, payment or application questions. No unsupported settings are presented here."><div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]"><section className="workspace-card p-6"><div className="flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-50 text-cyan-700"><LifeBuoy size={23} /></div><h2 className="mt-5 text-xl font-bold">Contact Dev Global Jobs support</h2><p className="mt-2 max-w-xl text-sm leading-6 text-slate-500">Include the relevant job, application, payment or request reference so the team can respond with the correct account context.</p><a href="mailto:info@devglobaljobs.com" className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-[#17263a] px-4 text-xs font-bold text-white"><LifeBuoy size={15} />Email support</a></section><section className="workspace-card bg-[#17263a] p-6 text-white"><ShieldCheck className="text-cyan-300" size={23} /><h2 className="mt-4 text-lg font-bold">Session security</h2><p className="mt-2 text-xs leading-5 text-slate-300">Employer access uses the existing verified session. Candidate and employer records remain separate.</p></section></div></PageFrame>;
}

function AdminOverview({ summary, go }: { summary: AnyRecord; go: (path: string) => void }) {
  const categories = Array.isArray(summary.categories) ? summary.categories : [];
  const revenue = summary.revenue_verified_month ?? summary.revenueMetrics?.revenue?.month;
  return <PageFrame eyebrow="Live operations" title="Marketplace, at a glance." description="Current totals read from the production administration endpoints." action="Review queue" onAction={() => go("/admin/requests")}><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard label="Total jobs" value={countValue(summary.total, summary.totalJobs)} note={`${countValue(summary.today)} posted in the last 24 hours`} icon={BriefcaseBusiness} /><StatCard label="Employer jobs" value={countValue(summary.employer, summary.totalEmployers)} note={`${countValue(summary.featured)} featured listings`} icon={Building2} accent="navy" /><StatCard label="Applications" value={countValue(summary.total_applications, summary.totalApplications)} note={`${countValue(summary.shortlisted)} shortlisted · ${countValue(summary.hires)} hired`} icon={UsersRound} accent="amber" /><StatCard label="Verified revenue" value={revenue === undefined ? "—" : displayMoney(revenue)} note={`${countValue(summary.pending_requests)} payment requests pending`} icon={CircleDollarSign} accent="green" /></div><div className="mt-5 grid gap-5 lg:grid-cols-2"><section className="workspace-card p-6"><SectionHeader eyebrow="Operations" title="Live distribution" />{categories.length ? <div className="space-y-4">{categories.map((category: AnyRecord) => { const value = Number(category.value ?? category.count ?? 0); const max = Math.max(...categories.map((item: AnyRecord) => Number(item.value ?? item.count ?? 0)), 1); return <div key={category.label || category.category}><div className="mb-1 flex justify-between text-xs"><span className="font-semibold text-slate-600">{category.label || category.category || "Uncategorised"}</span><span className="font-mono-ui text-[10px] text-slate-400">{value}</span></div><div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-cyan-500" style={{ width: `${Math.max(3, value / max * 100)}%` }} /></div></div>; })}</div> : <Empty text="No source totals were returned by the administration endpoint." />}</section><section className="workspace-card p-6"><SectionHeader eyebrow="Review health" title="Operational signals" /><div className="grid gap-3 sm:grid-cols-2"><Signal label="Pending payment requests" value={summary.pending_requests === undefined ? null : Number(summary.pending_requests)} /><Signal label="Active Premium Boosts" value={summary.active_boosts === undefined ? null : Number(summary.active_boosts)} /><Signal label="Active plan codes" value={summary.active_codes === undefined ? null : Number(summary.active_codes)} /><Signal label="Open recruitments" value={summary.open_recruitments === undefined ? null : Number(summary.open_recruitments)} /></div><button type="button" onClick={() => go("/admin/employers")} className="mt-5 text-xs font-bold text-cyan-700">Open employer accounts <ArrowUpRight size={13} className="inline" /></button></section></div></PageFrame>;
}

function AdminListPage({ kind, onRefresh }: { kind: "jobs" | "employers" | "applications" | "requests" | "boosts"; onRefresh: () => void }) {
  const [data, setData] = useState<AnyRecord | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState<number | null>(null);
  const endpoint = kind === "jobs" ? `/api/admin/jobs?page=1&limit=50${query ? `&search=${encodeURIComponent(query)}` : ""}` : kind === "employers" ? `/api/v46/admin/employers?limit=300${query ? `&search=${encodeURIComponent(query)}` : ""}` : kind === "applications" ? `/api/v51/admin/applications?limit=500` : kind === "requests" ? "/api/v45/admin/requests?limit=100" : "/api/v45/admin/boosts";
  const load = () => { setData(null); setError(null); void requestJson(endpoint).then(setData).catch((reason) => setError(errorMessage(reason, `${kind} could not be loaded.`))); };
  useEffect(load, [endpoint]);
  const items = data?.items || data?.jobs || data?.employers || [];
  const removeJob = async (id: number) => { if (!window.confirm("Delete this job from the marketplace?")) return; setBusy(id); try { await requestJson(`/api/admin/jobs/${id}`, { method: "DELETE" }); load(); onRefresh(); } catch (reason) { setError(errorMessage(reason, "The job could not be deleted.")); } finally { setBusy(null); } };
  const review = async (id: number, action: "publish" | "reject") => { setBusy(id); try { await requestJson(`/api/v45/admin/requests/${id}/${action}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(action === "reject" ? { note: "Rejected by administrator." } : {}) }); load(); onRefresh(); } catch (reason) { setError(errorMessage(reason, "The request could not be updated.")); } finally { setBusy(null); } };
  const title = ({ jobs: "Jobs", employers: "Employers", applications: "Applications", requests: "Review queue", boosts: "Premium & Boosts" } as AnyRecord)[kind];
  return <PageFrame eyebrow={kind === "requests" || kind === "boosts" ? "Admin moderation" : "Marketplace operations"} title={title} description="Persisted records from the production administration and recruitment routes." action="Refresh" onAction={load}><section className="workspace-card overflow-hidden"><div className="flex flex-col gap-4 border-b border-slate-100 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6"><SectionHeader eyebrow="Live records" title={`${items.length} returned`} />{(kind === "jobs" || kind === "employers") && <label className="relative"><Search size={14} className="absolute left-3 top-2.5 text-slate-400" /><span className="sr-only">Search records</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={`Search ${kind}`} className="h-9 rounded-lg border border-slate-200 pl-9 pr-3 text-xs outline-none focus:border-cyan-500 sm:w-52" /></label>}</div>{error && <ErrorState message={error} onRetry={load} />}{data === null && !error && <LoadingState label={`Loading ${kind}…`} />}{data && items.length === 0 && <Empty text={`No ${kind} records were returned.`} />}{data && items.length > 0 && <div className="divide-y divide-slate-100">{items.map((item: AnyRecord) => <div key={item.id || item.reference} className="flex flex-wrap items-center gap-3 p-5 sm:p-6">{kind === "employers" && <span className="flex h-10 w-10 items-center justify-center rounded-full bg-cyan-50 text-xs font-bold text-cyan-700">{initials(item.companyName)}</span>}<span className="min-w-[180px] flex-1"><b className="block text-sm text-slate-800">{item.title || item.companyName || item.job_title || item.candidateName || item.reference || `Request #${item.id}`}</b><small className="mt-1 block text-xs text-slate-400">{kind === "jobs" ? `${item.organization || "—"} · ${item.location || "—"}` : kind === "employers" ? `${item.email || "—"} · ${Number(item.liveJobCount || item.jobCount || 0)} live jobs` : kind === "applications" ? `${item.jobTitle || item.title || "—"} · ${item.employerName || "—"}` : kind === "boosts" ? `${item.employer_email || item.employerName || "—"} · ends ${displayDate(item.ends_at || item.endsAt)}` : `${item.organization || item.employer_email || item.employerName || "—"} · ${displayDateTime(item.created_at || item.createdAt)}`}</small></span><StatusPill status={item.status || item.accountStatus} />{kind === "jobs" && <><a href={`/jobs/detail/${Number(item.id)}`} target="_blank" rel="noreferrer" className="rounded-lg border border-slate-200 px-3 py-2 text-[11px] font-bold text-slate-600">View</a><button type="button" disabled={busy === Number(item.id)} onClick={() => void removeJob(Number(item.id))} className="rounded-lg bg-rose-50 px-3 py-2 text-[11px] font-bold text-rose-700 disabled:opacity-50">Delete</button></>}{kind === "applications" && <a href={`/api/v51/admin/applications/${Number(item.id)}/cv`} className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-2 text-[11px] font-bold text-slate-600"><Download size={12} />CV</a>}{kind === "requests" && String(item.status).toLowerCase() === "pending" && <div className="flex gap-2"><button type="button" disabled={busy === Number(item.id)} onClick={() => void review(Number(item.id), "publish")} className="rounded-lg bg-emerald-600 px-3 py-2 text-[11px] font-bold text-white disabled:opacity-50">Approve</button><button type="button" disabled={busy === Number(item.id)} onClick={() => void review(Number(item.id), "reject")} className="rounded-lg bg-rose-50 px-3 py-2 text-[11px] font-bold text-rose-700 disabled:opacity-50">Reject</button></div>}</div>)}</div>}</section></PageFrame>;
}

function AdminRevenue({ onRefresh }: { onRefresh: () => void }) {
  const [data, setData] = useState<AnyRecord | null>(null);
  const [error, setError] = useState<string | null>(null);
  const load = () => { setData(null); setError(null); void requestJson("/api/admin/revenue-metrics").then(setData).catch((reason) => setError(errorMessage(reason, "Revenue metrics could not be loaded."))); };
  useEffect(load, []);
  if (error) return <PageFrame eyebrow="Commercial reporting" title="Revenue unavailable" description="The existing revenue metrics endpoint did not return a usable response."><ErrorState message={error} onRetry={load} /></PageFrame>;
  if (!data) return <LoadingState label="Loading revenue metrics…" />;
  const revenue = data.revenue || {};
  return <PageFrame eyebrow="Commercial reporting" title="Revenue" description="Verified marketplace revenue and posting volumes from the existing administration metrics endpoint." action="Refresh" onAction={() => { load(); onRefresh(); }}><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard label="Verified revenue · month" value={displayMoney(revenue.month)} note="paid employer listings" icon={CircleDollarSign} accent="green" /><StatCard label="Regular listings · month" value={countValue(data.regular?.month)} note="commercial posting volume" icon={BriefcaseBusiness} /><StatCard label="Featured listings · month" value={countValue(data.featured?.month)} note="featured posting volume" icon={Sparkles} accent="amber" /><StatCard label="Monthly projection" value={displayMoney(data.projections?.monthly)} note="calculated by existing service" icon={Activity} accent="navy" /></div><section className="workspace-card mt-5 p-6"><SectionHeader eyebrow="Reporting windows" title="Revenue by period" /><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{["today", "week", "month", "year"].map((period) => <div key={period} className="rounded-xl bg-slate-50 p-4"><p className="font-mono-ui text-[10px] uppercase tracking-widest text-slate-400">{period}</p><p className="mt-2 font-mono-ui text-lg font-bold text-slate-800">{displayMoney(revenue[period])}</p><p className="mt-1 text-[11px] text-slate-500">{countValue(data.regular?.[period])} regular · {countValue(data.featured?.[period])} featured</p></div>)}</div></section></PageFrame>;
}

function AdminGrowth({ onRefresh }: { onRefresh: () => void }) {
  const [data, setData] = useState<AnyRecord | null>(null);
  const [subscribers, setSubscribers] = useState<AnyRecord[]>([]);
  const [error, setError] = useState<string | null>(null);
  const load = () => { setData(null); setError(null); void Promise.all([requestJson("/api/admin/growth/overview"), requestJson<AnyRecord[]>("/api/admin/growth/subscribers")]).then(([overview, contacts]) => { setData(overview); setSubscribers(Array.isArray(contacts) ? contacts : []); }).catch((reason) => setError(errorMessage(reason, "Growth data could not be loaded."))); };
  useEffect(load, []);
  if (error) return <PageFrame eyebrow="Audience operations" title="Growth unavailable" description="The existing growth endpoints did not return a usable response."><ErrorState message={error} onRetry={load} /></PageFrame>;
  if (!data) return <LoadingState label="Loading growth signals…" />;
  return <PageFrame eyebrow="Audience operations" title="Growth" description="Subscriber, employer and job-seeker signals from the existing marketing operations endpoints." action="Refresh" onAction={() => { load(); onRefresh(); }}><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard label="Job seekers" value={countValue(data.seekers_total)} note="accounts in the growth view" icon={UsersRound} /><StatCard label="Employers" value={countValue(data.employers_total)} note="employer records in the growth view" icon={Building2} accent="navy" /><StatCard label="Active subscribers" value={countValue(data.active_subscribers)} note="marketing contacts" icon={Bell} accent="green" /><StatCard label="Sign-ins today" value={countValue(data.signins_today)} note="recorded authentication events" icon={Activity} accent="amber" /></div><section className="workspace-card mt-5 overflow-hidden"><div className="border-b border-slate-100 p-6"><SectionHeader eyebrow="Marketing contacts" title="Latest subscribers" /></div>{subscribers.length ? <div className="divide-y divide-slate-100">{subscribers.slice(0, 20).map((subscriber) => <div key={subscriber.id || subscriber.email} className="flex flex-wrap items-center gap-3 p-5"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-50 text-cyan-700"><Bell size={15} /></span><span className="min-w-[190px] flex-1"><b className="block text-xs text-slate-800">{subscriber.name || subscriber.email}</b><small className="mt-1 block text-[11px] text-slate-400">{subscriber.audience || "—"} · {displayDate(subscriber.subscribed_at)}</small></span><StatusPill status={subscriber.active ? "Active" : "Unsubscribed"} /></div>)}</div> : <Empty text="No marketing contacts were returned." />}</section></PageFrame>;
}

function AdminReports({ go }: { go: (path: string) => void }) {
  const reports = [{ label: "Recruitment pipeline", detail: "Applications, candidate stages and retention records.", href: "/api/v51/admin/recruitment.csv" }, { label: "Revenue metrics", detail: "Open the protected JSON metrics endpoint for the current reporting windows.", href: "/api/admin/revenue-metrics" }, { label: "Marketplace jobs", detail: "Open the live admin job records with search and filters.", href: "/admin/jobs" }, { label: "Employer accounts", detail: "Open the live employer account records and commercial signals.", href: "/admin/employers" }];
  return <PageFrame eyebrow="Operations reporting" title="Reports" description="Download only reports backed by existing production routes, or open the live record views for interactive filtering."><div className="grid gap-4 sm:grid-cols-2">{reports.map((report) => <section key={report.label} className="workspace-card p-5"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-50 text-cyan-700"><Download size={18} /></div><h2 className="mt-5 text-sm font-bold text-slate-800">{report.label}</h2><p className="mt-2 text-xs leading-5 text-slate-500">{report.detail}</p>{report.href.startsWith("/api") ? <a href={report.href} className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-cyan-700">Download CSV <ArrowUpRight size={13} /></a> : <button type="button" onClick={() => go(report.href)} className="mt-4 text-xs font-bold text-cyan-700">Open live view <ArrowUpRight size={13} className="inline" /></button>}</section>)}</div></PageFrame>;
}

function AdminSettings() {
  return <PageFrame eyebrow="Enterprise administration" title="Settings" description="The production runtime keeps administrator authentication and operational mutations on the existing protected routes."><div className="grid gap-5 lg:grid-cols-[1fr_.75fr]"><section className="workspace-card p-6"><SectionHeader eyebrow="Protected operations" title="Admin session controls" /><div className="space-y-3 text-sm text-slate-600"><div className="rounded-xl bg-slate-50 p-4"><b className="block text-slate-800">Authentication</b><span className="mt-1 block text-xs">Existing session-based admin sign-in and logout.</span></div><div className="rounded-xl bg-slate-50 p-4"><b className="block text-slate-800">Mutations</b><span className="mt-1 block text-xs">Job deletion and moderation decisions remain on the existing protected API routes.</span></div></div></section><section className="workspace-card bg-[#17263a] p-6 text-white"><ShieldCheck className="text-cyan-300" size={24} /><h2 className="mt-4 text-lg font-bold">Restricted workspace</h2><p className="mt-2 text-xs leading-5 text-slate-300">No unsupported toggles or fabricated platform settings are shown.</p></section></div></PageFrame>;
}

function AdminContent({ account, refresh }: { account: AnyRecord; refresh: () => void }) {
  const [location, setLocation] = useLocation();
  const go = (path: string) => setLocation(path);
  const key = routeKey(location, "admin");
  const [summary, setSummary] = useState<AnyRecord | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { if (key !== "Overview") return; setSummary(null); setError(null); void Promise.all([requestJson("/api/v45/admin/summary").catch(() => ({})), requestJson("/api/v51/admin/summary").catch(() => ({})), requestJson("/api/admin/stats").catch(() => ({})), requestJson("/api/admin/revenue-metrics").catch(() => ({})), requestJson("/api/admin/sources").catch(() => [])]).then(([commercial, recruitment, stats, revenue, sources]) => setSummary({ ...(stats as AnyRecord), ...(recruitment as AnyRecord), ...(commercial as AnyRecord), revenueMetrics: revenue, categories: Array.isArray(sources) ? sources : [] })).catch((reason) => setError(errorMessage(reason, "Admin overview could not be loaded."))); }, [key]);
  if (key === "Overview") return error ? <PageFrame eyebrow="Live operations" title="Marketplace unavailable" description="The production summary endpoint did not return a usable response."><ErrorState message={error} onRetry={refresh} /></PageFrame> : summary ? <AdminOverview summary={summary} go={go} /> : <LoadingState label="Loading marketplace operations…" />;
  if (key === "Jobs") return <AdminListPage kind="jobs" onRefresh={refresh} />;
  if (key === "Employers") return <AdminListPage kind="employers" onRefresh={refresh} />;
  if (key === "Applications") return <AdminListPage kind="applications" onRefresh={refresh} />;
  if (key === "Review" || key === "Requests") return <AdminListPage kind="requests" onRefresh={refresh} />;
  if (key === "Premium & Boosts") return <AdminListPage kind="boosts" onRefresh={refresh} />;
  if (key === "Revenue") return <AdminRevenue onRefresh={refresh} />;
  if (key === "Reports") return <AdminReports go={go} />;
  if (key === "Growth") return <AdminGrowth onRefresh={refresh} />;
  return <AdminSettings />;
}

function EmployerContent({ data, refresh }: { data: PortalData; refresh: () => void }) {
  const [location, setLocation] = useLocation();
  const go = (path: string) => setLocation(path);
  const key = routeKey(location, "employer");
  if (key === "Overview") return <EmployerOverview data={data} go={go} />;
  if (key === "My Jobs") return <EmployerJobs data={data} go={go} refresh={refresh} />;
  if (key === "Applications") return <EmployerApplications data={data} go={go} />;
  if (key === "Analytics") return <EmployerAnalytics data={data} />;
  if (key === "Company Profile") return <EmployerProfile data={data} refresh={refresh} />;
  if (key === "Plans & Credits") return <EmployerCommercial data={data} kind="plans" />;
  if (key === "Billing & Payments") return <EmployerCommercial data={data} kind="billing" />;
  if (key === "Premium Boost") return <EmployerCommercial data={data} kind="boosts" />;
  return <EmployerSettings />;
}

function EmployerWorkspace() {
  const [data, setData] = useState<PortalData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const load = () => { setData(null); setError(null); void requestJson<PortalData>("/api/v46/employer/overview").then(setData).catch((reason) => { const status = (reason as Error & { status?: number }).status; if (status === 401 || status === 403) { window.location.href = `/employer/sign-in?redirect=${encodeURIComponent(window.location.pathname + window.location.search)}`; return; } setError(errorMessage(reason, "Employer workspace could not be loaded.")); }); };
  useEffect(load, []);
  if (error) return <LoadingError label="Employer workspace" message={error} onRetry={load} />;
  if (!data) return <LoadingState label="Loading employer workspace…" />;
  return <WorkspaceShell mode="employer" account={data} onRefresh={load}><EmployerContent data={data} refresh={load} /></WorkspaceShell>;
}

function LoadingError({ label, message, onRetry }: { label: string; message: string; onRetry: () => void }) {
  return <div className="workspace-grid flex min-h-[100dvh] items-center justify-center p-6"><div className="workspace-card w-full max-w-md p-8 text-center"><h1 className="text-xl font-bold text-[#17263a]">{label}</h1><p className="mt-3 text-sm leading-6 text-slate-500">{message}</p><button type="button" onClick={onRetry} className="mt-5 h-11 rounded-xl bg-[#17263a] px-5 text-xs font-bold text-white">Retry securely</button></div></div>;
}

function AdminLogin({ onSuccess }: { onSuccess: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (event: FormEvent) => { event.preventDefault(); setBusy(true); setError(""); try { await requestJson("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: username.trim(), password }) }); onSuccess(); } catch (reason) { setError(errorMessage(reason, "Invalid username or password.")); } finally { setBusy(false); } };
  return <div className="admin-login-screen flex min-h-[100dvh] items-center justify-center bg-[#101c2e] p-5"><div className="w-full max-w-md"><div className="mb-8 text-center"><img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs" className="mx-auto h-14 w-auto" /><p className="mt-5 font-mono-ui text-[10px] font-bold uppercase tracking-[.2em] text-cyan-300">Restricted operations</p><h1 className="mt-2 text-3xl font-bold tracking-[-.04em] text-white">Admin control centre</h1><p className="mt-2 text-sm text-slate-400">Sign in with the existing administrator session.</p></div><form onSubmit={submit} className="rounded-3xl border border-white/10 bg-white/10 p-6 shadow-2xl backdrop-blur sm:p-8"><div className="flex items-center gap-2 text-sm font-bold text-white"><ShieldCheck size={18} className="text-cyan-300" />Secure sign in</div><label className="mt-6 block text-xs font-bold text-slate-300">Username<input value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" required className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-white/10 px-3 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-400" /></label><label className="mt-4 block text-xs font-bold text-slate-300">Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="current-password" required className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-white/10 px-3 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-400" /></label>{error && <p className="mt-4 rounded-xl bg-rose-500/10 p-3 text-xs font-semibold text-rose-200">{error}</p>}<button type="submit" disabled={busy} className="mt-6 h-11 w-full rounded-xl bg-cyan-400 text-sm font-bold text-[#17263a] disabled:opacity-60">{busy ? "Signing in…" : "Sign in to admin"}</button></form></div></div>;
}

function AdminWorkspace() {
  const [account, setAccount] = useState<AnyRecord | null>(null);
  const [checking, setChecking] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const load = () => { setChecking(true); setError(null); void requestJson("/api/admin/me").then((value) => { setAccount(value); setChecking(false); }).catch((reason) => { const status = (reason as Error & { status?: number }).status; if (status === 401 || status === 403) setAccount(null); else setError(errorMessage(reason, "Admin authentication could not be checked.")); setChecking(false); }); };
  useEffect(load, []);
  if (checking) return <LoadingState label="Verifying administrator access…" />;
  if (error) return <LoadingError label="Admin session unavailable" message={error} onRetry={load} />;
  if (!account) return <AdminLogin onSuccess={load} />;
  return <WorkspaceShell mode="admin" account={account} onRefresh={load}><AdminContent account={account} refresh={load} /></WorkspaceShell>;
}

export default function WorkspaceDashboard({ mode }: { mode: Mode }) {
  return mode === "admin" ? <AdminWorkspace /> : <EmployerWorkspace />;
}