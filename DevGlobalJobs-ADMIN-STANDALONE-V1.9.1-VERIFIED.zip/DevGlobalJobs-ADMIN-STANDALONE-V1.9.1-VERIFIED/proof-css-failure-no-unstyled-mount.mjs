// Proves the V1.7 fix: on CSS load FAILURE, Admin JS is never appended —
// only the inline failure screen is shown. Mirrors the actual code paths.
const events = [];
function simulateLoadAdmin() {
  const css = { onload: null, onerror: null };
  events.push("css-link-appended");
  function mountJs() { events.push("admin-js-appended"); }
  function showFailureScreen() { events.push("failure-screen-shown"); }
  css.onload = mountJs;
  css.onerror = showFailureScreen; // V1.7 fix: no longer aliases to mountJs
  return css;
}
const css = simulateLoadAdmin();
css.onerror(); // simulate stylesheet request failing
if (events.includes("admin-js-appended")) {
  console.error("FAIL: Admin JS was appended after a CSS load failure.");
  process.exit(1);
}
if (!events.includes("failure-screen-shown")) {
  console.error("FAIL: failure screen was not shown.");
  process.exit(1);
}
console.log("PASS: CSS failure path ->", events.join(" -> "), "— Admin JS never mounts unstyled.");
