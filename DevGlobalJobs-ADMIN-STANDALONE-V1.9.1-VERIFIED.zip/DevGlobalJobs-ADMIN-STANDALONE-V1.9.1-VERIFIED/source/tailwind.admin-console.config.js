module.exports = {
  content: ["./client/src/pages/admin-console/**/*.{ts,tsx}"],
  important: ".admin-console",
  corePlugins: {
    preflight: false, // never reset global page styles — this CSS loads only on /admin
  },
  theme: {
    extend: {},
  },
  plugins: [],
};
