import { useState } from "react";
import { CheckCircle2, XCircle, Send, Copy, ShieldAlert, Upload } from "lucide-react";
import { requestJson, errorMessage, type AnyRecord, Card, CardHeader, KpiCard, Skeleton, EmptyState, ErrorState, Pill, Btn, Field, inputCls, useAdminApi, ConfirmDialog } from "./core";

export function RevenueSection() {
  const verified = useAdminApi<AnyRecord>("/api/v45/admin/summary");
  const estimate = useAdminApi<AnyRecord>("/api/admin/revenue-metrics");
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Revenue</h1>
      <Card className="p-5">
        <p className="text-[10px] font-bold uppercase tracking-[.14em] text-emerald-700">Verified — actual reviewed payments</p>
        {verified.loading ? <Skeleton className="mt-3 h-10 rounded" /> : verified.error ? <ErrorState message={verified.error} onRetry={verified.reload} /> : (
          <p className="ac-mono mt-2 text-3xl font-bold text-slate-900">${Number(verified.data?.revenue_verified_month || 0).toLocaleString()}<span className="ml-2 text-xs font-normal text-slate-400">this month</span></p>
        )}
        <p className="mt-2 text-[11px] text-slate-400">Sum of payment requests actually reviewed and published/active this month (/api/v45/admin/summary).</p>
      </Card>
      <Card className="p-5">
        <div className="flex items-center gap-2"><p className="text-[10px] font-bold uppercase tracking-[.14em] text-amber-700">Estimated Revenue / Projection</p><Pill tone="amber">Not verified payments</Pill></div>
        <p className="mt-1 text-[11px] leading-5 text-slate-500">Derived from employer-posted job counts × list price ($29 regular / $79 featured) — not from actual payment records. Do not treat as collected revenue.</p>
        {estimate.loading ? <Skeleton className="mt-3 h-24 rounded" /> : estimate.error ? <ErrorState message={estimate.error} onRetry={estimate.reload} /> : (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
            {(["today", "week", "month", "year", "total"] as const).map((k) => <div key={k} className="rounded-xl bg-slate-50 p-3 text-center"><p className="ac-mono text-lg font-bold">${Number(estimate.data?.revenue?.[k] || 0).toLocaleString()}</p><p className="text-[10px] uppercase text-slate-400">{k}</p></div>)}
          </div>
        )}
      </Card>
    </div>
  );
}

function EditRequestModal({ request, onClose, onSaved }: { request: AnyRecord; onClose: () => void; onSaved: () => void }) {
  const payload = request.job_payload || {};
  const [form, setForm] = useState({
    title: payload.title || "", organization: payload.organization || "", location: payload.location || "",
    adminNotes: request.admin_notes || "", paymentReference: request.payment_reference || "", amount: String(request.amount ?? ""),
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));
  async function save() {
    setBusy(true); setError("");
    try {
      const body: AnyRecord = { adminNotes: form.adminNotes, paymentReference: form.paymentReference, amount: form.amount === "" ? undefined : Number(form.amount) };
      if (request.request_type === "job_posting") body.jobPayload = { ...payload, title: form.title, organization: form.organization, location: form.location };
      await requestJson(`/api/v45/admin/requests/${request.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      onSaved(); onClose();
    } catch (e) { setError(errorMessage(e, "Request could not be saved.")); }
    finally { setBusy(false); }
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true">
      <div className="w-full max-w-md rounded-2xl bg-white p-5">
        <div className="flex items-center justify-between"><h3 className="text-sm font-bold">Edit request #{request.id}</h3><button onClick={onClose} aria-label="Close">✕</button></div>
        {error && <p className="mt-3 rounded-lg bg-rose-50 p-2 text-xs text-rose-700">{error}</p>}
        <div className="mt-4 space-y-3">
          {request.request_type === "job_posting" && (
            <>
              <Field label="Job title"><input value={form.title} onChange={(e) => set("title", e.target.value)} className={inputCls} /></Field>
              <Field label="Organization"><input value={form.organization} onChange={(e) => set("organization", e.target.value)} className={inputCls} /></Field>
              <Field label="Location"><input value={form.location} onChange={(e) => set("location", e.target.value)} className={inputCls} /></Field>
            </>
          )}
          <Field label="Payment reference"><input value={form.paymentReference} onChange={(e) => set("paymentReference", e.target.value)} className={inputCls} /></Field>
          <Field label="Amount (USD)"><input type="number" step="0.01" value={form.amount} onChange={(e) => set("amount", e.target.value)} className={inputCls} /></Field>
          <Field label="Admin notes"><textarea value={form.adminNotes} onChange={(e) => set("adminNotes", e.target.value)} className="min-h-[80px] w-full rounded-lg border border-slate-200 p-2 text-xs outline-none" /></Field>
        </div>
        <div className="mt-5 flex justify-end gap-2"><Btn variant="outline" onClick={onClose}>Cancel</Btn><Btn onClick={save} disabled={busy}>{busy ? "Saving…" : "Save changes"}</Btn></div>
      </div>
    </div>
  );
}

function PaidRequestsTab() {
  const requests = useAdminApi<{ items: AnyRecord[] }>("/api/v45/admin/requests?limit=100");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [confirmAction, setConfirmAction] = useState<{ id: number; kind: "publish" | "reject" } | null>(null);
  const [editingRequest, setEditingRequest] = useState<AnyRecord | null>(null);
  const [rejectNote, setRejectNote] = useState("");
  const [actionError, setActionError] = useState("");

  async function publish(id: number) {
    setBusyId(id); setActionError("");
    try { await requestJson(`/api/v45/admin/requests/${id}/publish`, { method: "POST" }); requests.reload(); setConfirmAction(null); }
    catch (e) { setActionError(errorMessage(e, "Request could not be published.")); }
    finally { setBusyId(null); }
  }
  async function reject(id: number) {
    if (rejectNote.trim().length < 3) return;
    setBusyId(id); setActionError("");
    try { await requestJson(`/api/v45/admin/requests/${id}/reject`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ note: rejectNote.trim() }) }); requests.reload(); setConfirmAction(null); setRejectNote(""); }
    catch (e) { setActionError(errorMessage(e, "Request could not be rejected.")); }
    finally { setBusyId(null); }
  }

  const items = requests.data?.items || [];
  return (
    <>
      {actionError && <div className="border-b border-rose-100 bg-rose-50 px-4 py-2.5 text-xs font-semibold text-rose-700">{actionError} <button onClick={() => setActionError("")} className="ml-2 underline">Dismiss</button></div>}
      {requests.loading ? <div className="p-5"><Skeleton className="h-24 rounded" /></div> : requests.error ? <div className="p-5"><ErrorState message={requests.error} onRetry={requests.reload} /></div> : items.length === 0 ? <EmptyState>No paid listing requests match this view.</EmptyState> : (
        <div className="divide-y divide-slate-100">{items.map((r) => (
          <div key={r.id} className="flex flex-wrap items-center gap-3 p-4">
            <div className="min-w-[160px] flex-1"><p className="text-xs font-bold text-slate-800">Request #{r.id} {r.reference ? <span className="ac-mono text-[10px] font-normal text-slate-400">({r.reference})</span> : null}</p><p className="text-[11px] text-slate-400">{r.payment_method} · {r.payment_reference || "no reference"}{r.amount != null ? ` · $${Number(r.amount).toFixed(2)}` : ""}</p></div>
            <Pill tone={r.status === "pending" ? "amber" : r.status === "published" || r.status === "active" ? "green" : r.status === "rejected" ? "rose" : "slate"}>{r.status}</Pill>
            {r.receipt_original_name && <a href={`/api/v45/admin/requests/${r.id}/receipt`} className="text-[11px] font-bold text-cyan-700">View receipt</a>}
            {(r.status === "pending" || r.status === "processing") && (
              <div className="flex gap-1.5">
                <Btn variant="outline" onClick={() => setEditingRequest(r)}>Edit</Btn>
                <Btn onClick={() => setConfirmAction({ id: r.id, kind: "publish" })} disabled={busyId === r.id}><CheckCircle2 size={13} />Publish</Btn>
                <Btn variant="danger" onClick={() => { setConfirmAction({ id: r.id, kind: "reject" }); setRejectNote(""); }} disabled={busyId === r.id}><XCircle size={13} />Reject</Btn>
              </div>
            )}
          </div>
        ))}</div>
      )}
      {editingRequest && <EditRequestModal request={editingRequest} onClose={() => setEditingRequest(null)} onSaved={requests.reload} />}
      {confirmAction?.kind === "publish" && (
        <ConfirmDialog title="Publish this paid request?" description="This will create/activate the live job or Boost for the employer." confirmLabel="Publish" busy={busyId === confirmAction.id} onCancel={() => setConfirmAction(null)} onConfirm={() => publish(confirmAction.id)} />
      )}
      {confirmAction?.kind === "reject" && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4" role="alertdialog" aria-modal="true">
          <div className="w-full max-w-sm rounded-2xl bg-white p-5">
            <p className="text-sm font-bold text-slate-800">Reject request #{confirmAction.id}?</p>
            <Field label="Rejection note (required — shown in admin notes)"><textarea value={rejectNote} onChange={(e) => setRejectNote(e.target.value)} className="min-h-[80px] w-full rounded-lg border border-slate-200 p-2 text-xs outline-none" /></Field>
            {rejectNote.trim().length > 0 && rejectNote.trim().length < 3 && <p className="mt-1 text-[11px] text-rose-600">Note must be at least 3 characters.</p>}
            <div className="mt-4 flex justify-end gap-2"><Btn variant="outline" onClick={() => setConfirmAction(null)}>Cancel</Btn><Btn variant="danger" onClick={() => reject(confirmAction.id)} disabled={busyId === confirmAction.id || rejectNote.trim().length < 3}>{busyId === confirmAction.id ? "Rejecting…" : "Reject"}</Btn></div>
          </div>
        </div>
      )}
    </>
  );
}

function BoostsTab() {
  const boosts = useAdminApi<{ items: AnyRecord[] }>("/api/v45/admin/boosts");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [confirmEnd, setConfirmEnd] = useState<AnyRecord | null>(null);
  const [error, setError] = useState("");
  async function end(id: number) {
    setBusyId(id); setError("");
    try { await requestJson(`/api/v45/admin/boosts/${id}/end`, { method: "POST" }); boosts.reload(); setConfirmEnd(null); }
    catch (e) { setError(errorMessage(e, "Boost could not be ended.")); }
    finally { setBusyId(null); }
  }
  const items = boosts.data?.items || [];
  return (
    <>
      {error && <div className="border-b border-rose-100 bg-rose-50 px-4 py-2.5 text-xs font-semibold text-rose-700">{error}</div>}
      {boosts.loading ? <div className="p-5"><Skeleton className="h-24 rounded" /></div> : boosts.error ? <div className="p-5"><ErrorState message={boosts.error} onRetry={boosts.reload} /></div> : items.length === 0 ? <EmptyState>No Premium Boosts on record.</EmptyState> : (
        <div className="divide-y divide-slate-100">{items.map((b) => (
          <div key={b.id} className="flex flex-wrap items-center gap-3 p-4">
            <div className="min-w-[160px] flex-1"><p className="text-xs font-bold text-slate-800">{b.title || `Job #${b.job_id}`}</p><p className="text-[11px] text-slate-400">{b.organization}</p></div>
            <Pill tone={b.status === "active" ? "green" : "slate"}>{b.status}</Pill>
            {b.status === "active" && <Btn variant="danger" onClick={() => setConfirmEnd(b)} disabled={busyId === b.id}>End boost</Btn>}
          </div>
        ))}</div>
      )}
      {confirmEnd && <ConfirmDialog title={`End boost for "${confirmEnd.title || `Job #${confirmEnd.job_id}`}"?`} description="This immediately removes priority placement." confirmLabel="End boost" danger busy={busyId === confirmEnd.id} onCancel={() => setConfirmEnd(null)} onConfirm={() => end(confirmEnd.id)} />}
    </>
  );
}

function CreateCodeForm({ onCreated }: { onCreated: () => void }) {
  const [form, setForm] = useState({ employerName: "", employerEmail: "", planLabel: "", durationMonths: "1", regularPerMonth: "0", featuredPerMonth: "0", boostsPerMonth: "0" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [revealed, setRevealed] = useState<{ code: string; planLabel: string; expiresAt: string } | null>(null);
  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const r = await requestJson<{ code: string; planLabel: string; expiresAt: string }>("/api/v45/admin/codes", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, durationMonths: Number(form.durationMonths), regularPerMonth: Number(form.regularPerMonth), featuredPerMonth: Number(form.featuredPerMonth), boostsPerMonth: Number(form.boostsPerMonth) }),
      });
      setRevealed(r);
    } catch (e2) { setError(errorMessage(e2, "Code could not be created.")); }
    finally { setBusy(false); }
  }
  if (revealed) {
    return (
      <div className="border-b border-slate-100 p-4">
        <div className="rounded-xl border-2 border-amber-300 bg-amber-50 p-4">
          <p className="flex items-center gap-2 text-xs font-bold text-amber-800"><ShieldAlert size={14} />This code is shown only once — copy or save it now.</p>
          <div className="mt-2 flex items-center gap-2"><code className="ac-mono flex-1 rounded-lg bg-white px-3 py-2 text-sm font-bold">{revealed.code}</code><Btn variant="outline" onClick={() => navigator.clipboard?.writeText(revealed.code)}><Copy size={13} />Copy</Btn></div>
          <p className="mt-2 text-[11px] text-amber-700">{revealed.planLabel} · expires {new Date(revealed.expiresAt).toLocaleDateString()}</p>
          <button type="button" onClick={() => { setRevealed(null); onCreated(); }} className="mt-3 inline-flex h-9 items-center rounded-lg bg-[var(--ac-navy-700)] px-3 text-xs font-bold text-white">Done</button>
        </div>
      </div>
    );
  }
  return (
    <form onSubmit={submit} className="space-y-3 border-b border-slate-100 p-4">
      {error && <div className="rounded-lg bg-rose-50 p-2 text-xs text-rose-700">{error}</div>}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Employer name"><input value={form.employerName} onChange={(e) => set("employerName", e.target.value)} className={inputCls} /></Field>
        <Field label="Employer email"><input value={form.employerEmail} onChange={(e) => set("employerEmail", e.target.value)} className={inputCls} /></Field>
        <Field label="Plan label"><input value={form.planLabel} onChange={(e) => set("planLabel", e.target.value)} placeholder="e.g. 3-Month Growth Plan" className={inputCls} /></Field>
        <Field label="Duration (months)"><select value={form.durationMonths} onChange={(e) => set("durationMonths", e.target.value)} className={inputCls}>{[1, 3, 6, 12].map((m) => <option key={m} value={m}>{m}</option>)}</select></Field>
        <Field label="Regular / month"><input type="number" min={0} value={form.regularPerMonth} onChange={(e) => set("regularPerMonth", e.target.value)} className={inputCls} /></Field>
        <Field label="Featured / month"><input type="number" min={0} value={form.featuredPerMonth} onChange={(e) => set("featuredPerMonth", e.target.value)} className={inputCls} /></Field>
        <Field label="Boosts / month"><input type="number" min={0} value={form.boostsPerMonth} onChange={(e) => set("boostsPerMonth", e.target.value)} className={inputCls} /></Field>
      </div>
      <Btn type="submit" disabled={busy}>{busy ? "Creating…" : "Create code"}</Btn>
    </form>
  );
}
function CodesTab() {
  const codes = useAdminApi<{ items: AnyRecord[] }>("/api/v45/admin/codes");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [confirmRevoke, setConfirmRevoke] = useState<AnyRecord | null>(null);
  const [error, setError] = useState("");
  async function revoke(id: number) {
    setBusyId(id); setError("");
    try { await requestJson(`/api/v45/admin/codes/${id}/revoke`, { method: "POST" }); codes.reload(); setConfirmRevoke(null); }
    catch (e) { setError(errorMessage(e, "Code could not be revoked.")); }
    finally { setBusyId(null); }
  }
  const items = codes.data?.items || [];
  return (
    <>
      <CreateCodeForm onCreated={codes.reload} />
      {error && <div className="border-b border-rose-100 bg-rose-50 px-4 py-2.5 text-xs font-semibold text-rose-700">{error}</div>}
      {codes.loading ? <div className="p-5"><Skeleton className="h-24 rounded" /></div> : codes.error ? <div className="p-5"><ErrorState message={codes.error} onRetry={codes.reload} /></div> : items.length === 0 ? <EmptyState>No Team / Admin plan codes issued.</EmptyState> : (
        <div className="divide-y divide-slate-100">{items.map((c) => (
          <div key={c.id} className="flex flex-wrap items-center gap-3 p-4">
            <div className="min-w-[160px] flex-1"><p className="ac-mono text-xs font-bold text-slate-800">{c.code_prefix}••••{c.code_last4}</p><p className="text-[11px] text-slate-400">{c.plan_label}</p></div>
            <Pill tone={c.status === "active" ? "green" : "slate"}>{c.status}</Pill>
            <span className="text-[11px] text-slate-500">{c.regular_used}/{c.regular_per_month} reg · {c.featured_used}/{c.featured_per_month} feat</span>
            {c.status === "active" && <Btn variant="danger" onClick={() => setConfirmRevoke(c)} disabled={busyId === c.id}>Revoke</Btn>}
          </div>
        ))}</div>
      )}
      {confirmRevoke && <ConfirmDialog title="Revoke this plan code?" description="The employer will no longer be able to use it for postings or Boosts." confirmLabel="Revoke" danger busy={busyId === confirmRevoke.id} onCancel={() => setConfirmRevoke(null)} onConfirm={() => revoke(confirmRevoke.id)} />}
    </>
  );
}
export function CommerceSection({ initialTab }: { initialTab?: "requests" | "boosts" | "codes" }) {
  const [tab, setTab] = useState<"requests" | "boosts" | "codes">(initialTab || "requests");
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Plans, Boosts & Team Codes</h1>
      <Card>
        <div className="flex gap-1 border-b border-slate-100 p-2">{(["requests", "boosts", "codes"] as const).map((t) => <button key={t} onClick={() => setTab(t)} className={`rounded-lg px-3 py-1.5 text-xs font-bold ${tab === t ? "bg-[var(--ac-navy-700)] text-white" : "text-slate-500"}`}>{t === "requests" ? "Paid Requests" : t === "boosts" ? "Premium Boosts" : "Team / Admin Codes"}</button>)}</div>
        {tab === "requests" && <PaidRequestsTab />}
        {tab === "boosts" && <BoostsTab />}
        {tab === "codes" && <CodesTab />}
      </Card>
    </div>
  );
}

function AddSubscriberForm({ onAdded }: { onAdded: () => void }) {
  const [email, setEmail] = useState(""); const [audience, setAudience] = useState<"job_seeker" | "employer">("job_seeker");
  const [busy, setBusy] = useState(false); const [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try { await requestJson("/api/admin/growth/subscribers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, audience }) }); setEmail(""); onAdded(); }
    catch (e2) { setError(errorMessage(e2, "Contact could not be added.")); }
    finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="flex flex-wrap items-end gap-2 p-4">
      {error && <div className="w-full rounded-lg bg-rose-50 p-2 text-xs text-rose-700">{error}</div>}
      <Field label="Add contact email"><input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={inputCls} /></Field>
      <select value={audience} onChange={(e) => setAudience(e.target.value as any)} className="h-10 rounded-lg border border-slate-200 px-2 text-xs"><option value="job_seeker">Job seeker</option><option value="employer">Employer</option></select>
      <Btn type="submit" disabled={busy}>{busy ? "Adding…" : "Add"}</Btn>
    </form>
  );
}
function BulkImportForm({ onImported }: { onImported: () => void }) {
  const [text, setText] = useState(""); const [audience, setAudience] = useState<"job_seeker" | "employer">("job_seeker");
  const [busy, setBusy] = useState(false); const [result, setResult] = useState<{ added: number; invalid: number } | null>(null); const [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError(""); setResult(null);
    const entries = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((email) => ({ email }));
    try { const r = await requestJson<{ added: number; invalid: number }>("/api/admin/growth/subscribers/bulk", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ audience, entries }) }); setResult(r); setText(""); onImported(); }
    catch (e2) { setError(errorMessage(e2, "Bulk import failed.")); }
    finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="space-y-2 p-4">
      {error && <div className="rounded-lg bg-rose-50 p-2 text-xs text-rose-700">{error}</div>}
      {result && <div className="rounded-lg bg-emerald-50 p-2 text-xs text-emerald-700">Added {result.added}, skipped {result.invalid} invalid.</div>}
      <Field label="Bulk import (one email per line, up to 500)"><textarea value={text} onChange={(e) => setText(e.target.value)} className="min-h-[100px] w-full rounded-lg border border-slate-200 p-2 text-xs outline-none" /></Field>
      <div className="flex items-center gap-2"><select value={audience} onChange={(e) => setAudience(e.target.value as any)} className="h-9 rounded-lg border border-slate-200 px-2 text-xs"><option value="job_seeker">Job seeker</option><option value="employer">Employer</option></select><Btn type="submit" disabled={busy}><Upload size={13} />{busy ? "Importing…" : "Import"}</Btn></div>
    </form>
  );
}

export function SubscribersSection() {
  const newsletter = useAdminApi<AnyRecord[]>("/api/admin/newsletter");
  const growthSubs = useAdminApi<AnyRecord[]>("/api/admin/growth/subscribers");
  const campaigns = useAdminApi<AnyRecord[]>("/api/admin/growth/campaigns");
  const [running, setRunning] = useState<string | null>(null);
  const [confirmRun, setConfirmRun] = useState<"job_seeker" | "employer" | null>(null);
  const [confirmDelSub, setConfirmDelSub] = useState<AnyRecord | null>(null);
  const [runError, setRunError] = useState("");
  const [delError, setDelError] = useState("");

  async function runWeekly(audience: "job_seeker" | "employer") {
    setRunning(audience); setRunError("");
    try { await requestJson("/api/admin/growth/run-weekly", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ audience }) }); campaigns.reload(); setConfirmRun(null); }
    catch (e) { setRunError(errorMessage(e, "Campaign could not be started.")); }
    finally { setRunning(null); }
  }
  async function delSub(sub: AnyRecord) {
    setDelError("");
    try { await requestJson(`/api/admin/newsletter/${sub.id}`, { method: "DELETE" }); newsletter.reload(); setConfirmDelSub(null); }
    catch (e) { setDelError(errorMessage(e, "Subscriber could not be deleted.")); }
  }
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Subscribers & Growth</h1>
      <Card>
        <CardHeader title="Weekly campaigns" action={<div className="flex gap-2"><Btn onClick={() => setConfirmRun("job_seeker")} disabled={running !== null}><Send size={12} />Run seeker weekly</Btn><Btn variant="outline" onClick={() => setConfirmRun("employer")} disabled={running !== null}>Run employer weekly</Btn></div>} />
        {runError && <div className="border-b border-rose-100 bg-rose-50 px-4 py-2.5 text-xs font-semibold text-rose-700">{runError}</div>}
        {campaigns.loading ? <div className="p-5"><Skeleton className="h-16 rounded" /></div> : campaigns.error ? <div className="p-5"><ErrorState message={campaigns.error} onRetry={campaigns.reload} /></div> : (campaigns.data?.length ?? 0) === 0 ? <EmptyState>No campaigns have run yet.</EmptyState> : (
          <div className="divide-y divide-slate-100">{campaigns.data!.map((c) => <div key={c.id} className="flex flex-wrap items-center gap-3 p-4"><span className="min-w-[140px] flex-1 text-xs font-bold text-slate-800">{c.subject}</span><Pill tone="slate">{c.audience}</Pill><Pill tone={c.status === "sent" || c.status === "completed" ? "green" : "amber"}>{c.status}</Pill><span className="ac-mono text-[11px] text-slate-500">{c.sent_count}/{c.total_recipients} sent</span></div>)}</div>
        )}
      </Card>
      <Card>
        <CardHeader title="Add / import contacts" />
        <AddSubscriberForm onAdded={growthSubs.reload} />
        <div className="border-t border-slate-100" />
        <BulkImportForm onImported={growthSubs.reload} />
      </Card>
      <Card>
        <CardHeader title="Newsletter subscribers" />
        {delError && <div className="border-b border-rose-100 bg-rose-50 px-4 py-2.5 text-xs font-semibold text-rose-700">{delError}</div>}
        {newsletter.loading ? <div className="p-5"><Skeleton className="h-16 rounded" /></div> : newsletter.error ? <div className="p-5"><ErrorState message={newsletter.error} onRetry={newsletter.reload} /></div> : (newsletter.data?.length ?? 0) === 0 ? <EmptyState>No newsletter subscribers yet.</EmptyState> : (
          <div className="max-h-80 divide-y divide-slate-100 overflow-y-auto">{newsletter.data!.map((s) => <div key={s.id} className="flex items-center gap-3 p-3"><span className="min-w-[180px] flex-1 text-xs text-slate-700">{s.email}</span><Pill tone="slate">{s.type}</Pill><Btn variant="danger" onClick={() => setConfirmDelSub(s)}>Delete</Btn></div>)}</div>
        )}
      </Card>
      <Card>
        <CardHeader title="Growth marketing contacts" />
        {growthSubs.loading ? <div className="p-5"><Skeleton className="h-16 rounded" /></div> : growthSubs.error ? <div className="p-5"><ErrorState message={growthSubs.error} onRetry={growthSubs.reload} /></div> : (growthSubs.data?.length ?? 0) === 0 ? <EmptyState>No marketing contacts yet.</EmptyState> : (
          <div className="max-h-80 divide-y divide-slate-100 overflow-y-auto">{growthSubs.data!.map((s) => <div key={s.id} className="flex items-center gap-3 p-3"><span className="min-w-[180px] flex-1 text-xs text-slate-700">{s.email}</span><Pill tone="cyan">{s.audience}</Pill>{s.active ? <Pill tone="green">Active</Pill> : <Pill tone="slate">Inactive</Pill>}</div>)}</div>
        )}
      </Card>
      {confirmRun && <ConfirmDialog title={`Run weekly ${confirmRun === "employer" ? "employer" : "job seeker"} campaign?`} description="This sends real email to active subscribers immediately." confirmLabel="Run campaign" busy={running !== null} onCancel={() => setConfirmRun(null)} onConfirm={() => runWeekly(confirmRun)} />}
      {confirmDelSub && <ConfirmDialog title={`Delete subscriber "${confirmDelSub.email}"?`} description={delError || "This removes them from the newsletter list."} confirmLabel="Delete" danger onCancel={() => { setConfirmDelSub(null); setDelError(""); }} onConfirm={() => delSub(confirmDelSub)} />}
    </div>
  );
}

function slugify(s: string) {
  return s.trim().toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
}
function plainWordCount(html: string) {
  const text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  return text ? text.split(/\s+/).length : 0;
}
function BlogEditor({ post, onClose, onSaved }: { post: AnyRecord | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    title: post?.title || "", slug: post?.slug || "", status: post?.status || "draft",
    content: post?.content || "", excerpt: post?.excerpt || "", metaDescription: post?.metaDescription || post?.meta_description || "",
  });
  const [slugTouched, setSlugTouched] = useState(Boolean(post));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v, ...(k === "title" && !slugTouched ? { slug: slugify(v) } : {}) }));
  const words = plainWordCount(form.content);
  const h1 = (form.content.match(/<h1\b/gi) || []).length;
  const h2 = (form.content.match(/<h2\b/gi) || []).length;
  const publishIssues: string[] = [];
  if (form.status === "published") {
    if (words < 600) publishIssues.push(`Needs 600+ words (currently ${words}).`);
    if (h1 > 0) publishIssues.push("Remove <h1> tags from content — the title is the page H1.");
    if (h2 < 2) publishIssues.push("Needs at least 2 <h2> section headings.");
    if (!form.metaDescription.trim()) publishIssues.push("Meta description is required to publish.");
  }
  async function save() {
    setBusy(true); setError("");
    try {
      const body = JSON.stringify({ ...form, slug: form.slug || slugify(form.title) });
      if (post) await requestJson(`/api/admin/blog/${post.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body });
      else await requestJson("/api/admin/blog", { method: "POST", headers: { "Content-Type": "application/json" }, body });
      onSaved(); onClose();
    } catch (e) { setError(errorMessage(e, "Post could not be saved.")); }
    finally { setBusy(false); }
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true">
      <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-5">
        <div className="flex items-center justify-between"><h3 className="text-sm font-bold">{post ? `Edit "${post.title}"` : "New blog post"}</h3><button onClick={onClose} aria-label="Close">✕</button></div>
        {error && <p className="mt-3 rounded-lg bg-rose-50 p-2 text-xs text-rose-700">{error}</p>}
        <div className="mt-4 space-y-3">
          <Field label="Title"><input value={form.title} onChange={(e) => set("title", e.target.value)} className={inputCls} /></Field>
          <Field label="Slug" hint="devglobaljobs.com/blog/..."><input value={form.slug} onChange={(e) => { setSlugTouched(true); set("slug", e.target.value); }} className={inputCls} /></Field>
          <Field label="Status"><select value={form.status} onChange={(e) => set("status", e.target.value)} className={inputCls}><option value="draft">Draft</option><option value="published">Published</option></select></Field>
          <Field label="Content (HTML)"><textarea value={form.content} onChange={(e) => set("content", e.target.value)} className="min-h-[220px] w-full rounded-lg border border-slate-200 p-3 font-mono text-xs outline-none" /></Field>
          <p className="text-[11px] text-slate-400">{words} words · {h1} H1 · {h2} H2</p>
          <Field label="Excerpt"><textarea value={form.excerpt} onChange={(e) => set("excerpt", e.target.value)} className="min-h-[60px] w-full rounded-lg border border-slate-200 p-2 text-xs outline-none" /></Field>
          <Field label="Meta description"><input value={form.metaDescription} onChange={(e) => set("metaDescription", e.target.value)} className={inputCls} /></Field>
          {publishIssues.length > 0 && (
            <div className="rounded-lg bg-amber-50 p-3 text-xs text-amber-800"><p className="font-bold">Not ready to publish yet:</p><ul className="mt-1 list-disc pl-4">{publishIssues.map((i) => <li key={i}>{i}</li>)}</ul></div>
          )}
        </div>
        <div className="mt-5 flex justify-end gap-2"><Btn variant="outline" onClick={onClose}>Cancel</Btn><Btn onClick={save} disabled={busy}>{busy ? "Saving…" : post ? "Save changes" : "Create post"}</Btn></div>
      </div>
    </div>
  );
}

export function BlogSection() {
  const [status, setStatus] = useState("");
  const posts = useAdminApi<{ posts?: AnyRecord[]; items?: AnyRecord[] }>(`/api/admin/blog${status ? `?status=${status}` : ""}`);
  const [confirmDel, setConfirmDel] = useState<AnyRecord | null>(null);
  const [editing, setEditing] = useState<AnyRecord | null | "new">(null);
  const [error, setError] = useState("");
  const list = posts.data?.posts || posts.data?.items || [];
  async function del(post: AnyRecord) {
    setError("");
    try { await requestJson(`/api/admin/blog/${post.id}`, { method: "DELETE" }); posts.reload(); setConfirmDel(null); }
    catch (e) { setError(errorMessage(e, "Post could not be deleted.")); }
  }
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Blog / Content</h1>
        <div className="flex gap-2"><select value={status} onChange={(e) => setStatus(e.target.value)} className="h-9 rounded-lg border border-slate-200 px-2 text-xs"><option value="">All</option><option value="draft">Draft</option><option value="published">Published</option></select><Btn onClick={() => setEditing("new")}>New post</Btn></div>
      </div>
      <Card>
        {posts.loading ? <div className="p-5 space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-12 rounded" />)}</div>
          : posts.error ? <div className="p-5"><ErrorState message={posts.error} onRetry={posts.reload} /></div>
          : list.length === 0 ? <EmptyState>No blog posts match this view.</EmptyState>
          : (
            <div className="divide-y divide-slate-100">{list.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center gap-3 p-4">
                <div className="min-w-[180px] flex-1"><p className="text-xs font-bold text-slate-800">{p.title}</p><p className="text-[11px] text-slate-400">/{p.slug}</p></div>
                <Pill tone={p.status === "published" ? "green" : "slate"}>{p.status}</Pill>
                <Btn variant="outline" onClick={() => setEditing(p)}>Edit</Btn>
                <Btn variant="danger" onClick={() => setConfirmDel(p)}>Delete</Btn>
              </div>
            ))}</div>
          )}
      </Card>
      {editing && <BlogEditor post={editing === "new" ? null : editing} onClose={() => setEditing(null)} onSaved={posts.reload} />}
      {confirmDel && <ConfirmDialog title={`Delete "${confirmDel.title}"?`} description={error || "This permanently removes the blog post."} confirmLabel="Delete" danger onCancel={() => { setConfirmDel(null); setError(""); }} onConfirm={() => del(confirmDel)} />}
    </div>
  );
}
