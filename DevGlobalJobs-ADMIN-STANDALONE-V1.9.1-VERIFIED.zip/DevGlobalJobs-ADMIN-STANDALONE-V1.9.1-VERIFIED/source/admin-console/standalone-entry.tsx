import { createRoot } from "react-dom/client";
import AdminConsole from "./index";

// Standalone entry point, bundled by esbuild into dgj-claude-admin-v1.js.
// This file (and everything it imports) is the ENTIRE runtime needed to
// render the Admin Console — react, react-dom, and lucide-react are
// inlined by the bundler. Nothing here imports any shared app chunk.
const rootEl = document.getElementById("root");
if (rootEl) {
  createRoot(rootEl).render(<AdminConsole />);
}
