import { useState, useEffect } from "react";
import { RefreshCw, Search, Download } from "lucide-react";
import { requestJson, errorMessage, type AnyRecord, Card, CardHeader, KpiCard, Skeleton, EmptyState, ErrorState, Pill, Btn, Field, inputCls, useAdminApi, Pagination, ConfirmDialog } from "./core";

export function SourcesSection() {
  const sources = useAdminApi<{ source: string; count: number }[]>("/api/admin/sources");
  const fetchStatus = useAdminApi<AnyRecord>("/api/admin/fetch-status");
  const indexing = useAdminApi<AnyRecord>("/api/admin/google-indexing-status");
  const [triggering, setTriggering] = useState(false);
  const [triggerMsg, setTriggerMsg] = useState("");
  async function triggerFetch() {
    setTriggering(true); setTriggerMsg("");
    try { const r = await requestJson<{ message: string }>("/api/admin/fetch-jobs", { method: "POST" }); setTriggerMsg(r.message || "Fetch triggered."); fetchStatus.reload(); }
    catch (e) { setTriggerMsg(errorMessage(e, "Could not trigger fetch.")); }
    finally { setTriggering(false); }
  }
  const cycles = Array.isArray(fetchStatus.data) ? fetchStatus.data : [];
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Job Sources & Fetcher</h1>
      <div className="grid gap-3 sm:grid-cols-3">
        <KpiCard label="Google index queue" value={indexing.data ? `${indexing.data.pendingUpdates ?? 0} + ${indexing.data.pendingDeletes ?? 0}` : "—"} hint={indexing.data ? `Daily ${indexing.data.dailyCount ?? 0} / ${indexing.data.limit ?? 0}` : undefined} />
        <KpiCard label="Distinct sources" value={sources.data?.length ?? "—"} />
        <KpiCard label="Recent fetch cycles logged" value={cycles.length} />
      </div>
      <Card>
        <CardHeader title="Fetch sources now" action={<Btn onClick={triggerFetch} disabled={triggering}><RefreshCw size={13} className={triggering ? "animate-spin" : ""} />{triggering ? "Triggering…" : "Trigger fetch"}</Btn>} />
        {triggerMsg && <p className="px-5 py-3 text-xs font-semibold text-cyan-700">{triggerMsg}</p>}
        {sources.loading ? <div className="p-5"><Skeleton className="h-24 rounded" /></div> : sources.error ? <div className="p-5"><ErrorState message={sources.error} onRetry={sources.reload} /></div> : (
          <div className="grid grid-cols-2 gap-3 p-5 sm:grid-cols-4">{(sources.data || []).map((s) => <div key={s.source} className="rounded-xl bg-slate-50 p-3"><p className="text-xs font-bold text-slate-700">{s.source}</p><p className="ac-mono text-lg font-bold">{s.count}</p></div>)}</div>
        )}
      </Card>
      <Card>
        <CardHeader title="Recent fetch cycles" />
        {fetchStatus.loading ? <div className="p-5"><Skeleton className="h-16 rounded" /></div> : cycles.length === 0 ? <EmptyState>No fetch cycles have been logged yet.</EmptyState> : (
          <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">{cycles.slice(0, 20).map((c: AnyRecord, i: number) => <div key={i} className="p-3 text-xs text-slate-600"><pre className="whitespace-pre-wrap font-mono text-[11px]">{JSON.stringify(c, null, 0)}</pre></div>)}</div>
        )}
      </Card>
    </div>
  );
}

// Real backend shape (dist/index.cjs GET /api/admin/growth/employers):
// { items: AnyRecord[]; total: number; page: number; limit: number }.
// limit is capped server-side to a max of 100 (min 10, default 50) — it is
// NOT an arbitrary page size, so requesting ?limit=500 would silently be
// clamped to 100 by the backend. This hook pages through every page so
// enrichment doesn't stop after the first 100 records when more exist.
function useAllGrowthEmployers() {
  const [items, setItems] = useState<AnyRecord[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  function load() {
    setLoading(true); setError(null);
    const PAGE_LIMIT = 100; // matches the backend's real maximum
    async function fetchAll(): Promise<AnyRecord[]> {
      const first = await requestJson<{ items: AnyRecord[]; total: number; page: number; limit: number }>(`/api/admin/growth/employers?page=1&limit=${PAGE_LIMIT}`);
      const all = [...(first.items || [])];
      const total = Number(first.total || all.length);
      let page = 2;
      while (all.length < total) {
        const next = await requestJson<{ items: AnyRecord[] }>(`/api/admin/growth/employers?page=${page}&limit=${PAGE_LIMIT}`);
        if (!next.items || next.items.length === 0) break; // defensive: stop rather than loop forever if total is ever inconsistent
        all.push(...next.items);
        page += 1;
      }
      return all;
    }
    fetchAll().then(setItems).catch((e) => setError(errorMessage(e, "Growth employer data could not be loaded."))).finally(() => setLoading(false));
  }
  useEffect(load, []);
  return { items, error, loading, reload: load };
}

export function EmployersSection() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const primary = useAdminApi<{ items: AnyRecord[]; total: number }>("/api/v46/admin/employers");
  const growth = useAllGrowthEmployers();
  // growth.items is always an array (or null while loading) — never assume
  // the raw response is an array itself, since the real endpoint returns
  // {items,total,page,limit}, not a bare array.
  const growthByEmail = new Map((growth.items || []).map((g) => [String(g.email || "").toLowerCase(), g]));
  const items = primary.data?.items || [];
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Employers</h1>
      <Card>
        <CardHeader title={`${items.length} employer account${items.length === 1 ? "" : "s"}`} />
        {primary.loading ? <div className="p-5 space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-14 rounded" />)}</div>
          : primary.error ? <div className="p-5"><ErrorState message={primary.error} onRetry={primary.reload} /></div>
          : items.length === 0 ? <EmptyState>No employer accounts yet.</EmptyState>
          : (
            <div className="divide-y divide-slate-100">{items.map((e) => {
              const g = growthByEmail.get(String(e.email || "").toLowerCase());
              const isOpen = expanded === e.email;
              return (
                <div key={e.email}>
                  <button type="button" onClick={() => setExpanded(isOpen ? null : e.email)} className="flex w-full flex-wrap items-center gap-3 p-4 text-left hover:bg-slate-50">
                    {e.company_logo_url ? <img src={e.company_logo_url} alt="" className="h-8 w-8 rounded-lg object-cover" /> : <div className="h-8 w-8 rounded-lg bg-slate-100" />}
                    <div className="min-w-[180px] flex-1"><p className="text-xs font-bold text-slate-800">{e.company_name || e.email}</p><p className="text-[11px] text-slate-400">{e.email} · {e.country || "—"}</p></div>
                    <span className="ac-mono text-[11px] text-slate-500">{e.regular_post_count ?? 0} reg / {e.featured_post_count ?? 0} feat lifetime</span>
                    {Number(e.pending_payments) > 0 && <Pill tone="amber">{e.pending_payments} pending payment{e.pending_payments === 1 ? "" : "s"}</Pill>}
                    {Number(e.active_boosts) > 0 && <Pill tone="cyan">{e.active_boosts} active boost{e.active_boosts === 1 ? "" : "s"}</Pill>}
                    {Number(e.active_plans) > 0 && <Pill tone="green">{e.active_plans} active plan{e.active_plans === 1 ? "" : "s"}</Pill>}
                  </button>
                  {isOpen && (
                    <div className="border-t border-slate-100 bg-slate-50/60 p-4 text-xs">
                      <div className="grid gap-3 sm:grid-cols-3">
                        <div><p className="text-[10px] font-bold uppercase text-slate-400">Applications</p><p className="ac-mono font-bold">{e.total_applications ?? 0} total · {e.hires ?? 0} hired</p></div>
                        <div><p className="text-[10px] font-bold uppercase text-slate-400">Profile</p><p>{e.industry || "—"} · {e.company_size || "—"}</p><p className="text-slate-500">{e.company_website || "no website on file"}</p></div>
                        <div><p className="text-[10px] font-bold uppercase text-slate-400">This month (Growth)</p><p className="ac-mono">{g?.regular_this_month ?? "—"} reg / {g?.featured_this_month ?? "—"} feat</p>{g?.subscribed ? <Pill tone="green">Newsletter subscribed</Pill> : <Pill tone="slate">Not subscribed</Pill>}</div>
                      </div>
                      {Array.isArray(g?.recent_postings) && g.recent_postings.length > 0 && (
                        <div className="mt-3 border-t border-slate-200 pt-3">
                          <p className="text-[10px] font-bold uppercase text-slate-400">Recent postings (Growth)</p>
                          <div className="mt-1 space-y-1">{g.recent_postings.slice(0, 5).map((p: AnyRecord, i: number) => <p key={i} className="text-[11px] text-slate-600">{p.title} · {p.listing_type}</p>)}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}</div>
          )}
      </Card>
    </div>
  );
}

function SeekerDetailModal({ id, onClose }: { id: number; onClose: () => void }) {
  const detail = useAdminApi<AnyRecord>(`/api/admin/seekers/${id}`);
  const a = detail.data;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true">
      <div className="max-h-[85vh] w-full max-w-md overflow-y-auto rounded-2xl bg-white p-5">
        <div className="flex items-center justify-between"><h3 className="text-sm font-bold">Job seeker detail</h3><button onClick={onClose} aria-label="Close">✕</button></div>
        {detail.loading ? <div className="mt-4"><Skeleton className="h-32 rounded" /></div>
          : detail.error ? <div className="mt-4"><ErrorState message={detail.error} onRetry={detail.reload} /></div>
          : !a ? <EmptyState>Not found.</EmptyState>
          : (
            <div className="mt-4 space-y-2 text-xs">
              <p className="text-sm font-bold text-slate-800">{a.profile?.fullName || a.email}</p>
              <p className="text-slate-500">{a.email}</p>
              {a.type && <Pill tone="slate">{a.type}</Pill>}
              {a.createdAt && <p className="text-slate-400">Joined {new Date(a.createdAt).toLocaleDateString()}</p>}
              <div className="mt-3 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
                {a.profile?.country && <div><p className="text-[10px] font-bold uppercase text-slate-400">Country</p><p>{a.profile.country}</p></div>}
                {a.profile?.phone && <div><p className="text-[10px] font-bold uppercase text-slate-400">Phone</p><p>{a.profile.phone}</p></div>}
                {a.profile?.jobTitle && <div><p className="text-[10px] font-bold uppercase text-slate-400">Job title</p><p>{a.profile.jobTitle}</p></div>}
                {a.profile?.atsScore != null && <div><p className="text-[10px] font-bold uppercase text-slate-400">ATS score</p><p className="ac-mono font-bold">{a.profile.atsScore}</p></div>}
                {a.profile?.linkedin && <div><p className="text-[10px] font-bold uppercase text-slate-400">LinkedIn</p><p className="truncate">{a.profile.linkedin}</p></div>}
                {a.profile?.website && <div><p className="text-[10px] font-bold uppercase text-slate-400">Website</p><p className="truncate">{a.profile.website}</p></div>}
              </div>
              {a.profile?.summary && <div className="border-t border-slate-100 pt-3"><p className="text-[10px] font-bold uppercase text-slate-400">Summary</p><p className="mt-1 leading-5 text-slate-600">{a.profile.summary}</p></div>}
              {!a.profile && <p className="text-slate-400">No profile has been created for this account.</p>}
            </div>
          )}
      </div>
    </div>
  );
}

export function SeekersSection() {
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [confirmDel, setConfirmDel] = useState<AnyRecord | null>(null);
  const [viewingId, setViewingId] = useState<number | null>(null);
  const [delError, setDelError] = useState("");
  const stats = useAdminApi<AnyRecord>("/api/admin/seekers/stats");
  const params = new URLSearchParams({ page: String(page), ...(q ? { q } : {}) });
  const seekers = useAdminApi<{ accounts: AnyRecord[]; total: number }>(`/api/admin/seekers?${params.toString()}`);
  const totalPages = Math.max(1, Math.ceil((seekers.data?.total || 0) / 20));
  async function del(account: AnyRecord) {
    setDelError("");
    try { await requestJson(`/api/admin/seekers/${account.id}`, { method: "DELETE" }); seekers.reload(); setConfirmDel(null); }
    catch (e) { setDelError(errorMessage(e, "This account could not be deleted.")); }
  }
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-xl font-bold text-slate-900">Job Seekers</h1>
        <div className="relative"><Search size={14} className="absolute left-3 top-3 text-slate-400" /><input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Search name or email" className="h-9 w-60 rounded-lg border border-slate-200 pl-9 pr-3 text-xs outline-none" /></div>
      </div>
      <div className="grid gap-3 sm:grid-cols-3"><KpiCard label="Total accounts" value={stats.data?.total ?? "—"} /><KpiCard label="With profile" value={stats.data?.withProfiles ?? "—"} /><KpiCard label="New today" value={stats.data?.today ?? "—"} /></div>
      <Card>
        {seekers.loading ? <div className="p-5 space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-12 rounded" />)}</div>
          : seekers.error ? <div className="p-5"><ErrorState message={seekers.error} onRetry={seekers.reload} /></div>
          : (seekers.data?.accounts?.length ?? 0) === 0 ? <EmptyState>No job seeker accounts match this view.</EmptyState>
          : (
            <div className="divide-y divide-slate-100">{seekers.data!.accounts.map((a) => (
              <div key={a.id} className="flex flex-wrap items-center gap-3 p-4">
                <div className="min-w-[180px] flex-1"><p className="text-xs font-bold text-slate-800">{a.profile?.fullName || a.email}</p><p className="text-[11px] text-slate-400">{a.email} · {a.profile?.country || "—"}</p></div>
                {a.profile?.atsScore != null && <span className="ac-mono text-xs font-bold text-slate-600">ATS {a.profile.atsScore}</span>}
                <Btn variant="outline" onClick={() => setViewingId(a.id)}>View</Btn>
                <Btn variant="danger" onClick={() => setConfirmDel(a)}>Delete</Btn>
              </div>
            ))}</div>
          )}
        <Pagination page={page} totalPages={totalPages} onChange={setPage} />
      </Card>
      {viewingId != null && <SeekerDetailModal id={viewingId} onClose={() => setViewingId(null)} />}
      {confirmDel && <ConfirmDialog title={`Delete "${confirmDel.profile?.fullName || confirmDel.email}"?`} description={delError || "This permanently removes the account and profile."} confirmLabel="Delete" danger onCancel={() => { setConfirmDel(null); setDelError(""); }} onConfirm={() => del(confirmDel)} />}
    </div>
  );
}

export function RecruitmentSection() {
  const [page, setPage] = useState(0);
  const [status, setStatus] = useState("");
  const summary = useAdminApi<AnyRecord>("/api/v51/admin/summary");
  const params = new URLSearchParams({ limit: "50", offset: String(page * 50), ...(status ? { status } : {}) });
  const apps = useAdminApi<{ items: AnyRecord[]; retentionDays: number }>(`/api/v51/admin/applications?${params.toString()}`);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Recruitment / Applications</h1>
        <a href="/api/v51/admin/recruitment.csv" className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 px-3 text-xs font-bold text-slate-700"><Download size={13} />Export CSV</a>
      </div>
      <div className="grid gap-3 sm:grid-cols-4">
        <KpiCard label="Total applications" value={summary.data?.total_applications ?? "—"} hint={`${summary.data?.applications_today ?? 0} today`} />
        <KpiCard label="Shortlisted" value={summary.data?.shortlisted ?? "—"} />
        <KpiCard label="Interviews" value={summary.data?.interviews ?? "—"} />
        <KpiCard label="Hires" value={summary.data?.hires ?? "—"} />
      </div>
      <Card>
        <CardHeader title="Applications" action={<select value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }} className="h-9 rounded-lg border border-slate-200 px-2 text-xs"><option value="">All statuses</option>{["received", "under_review", "shortlisted", "interview", "offer", "hired", "not_selected", "withdrawn"].map((s) => <option key={s} value={s}>{s}</option>)}</select>} />
        {apps.loading ? <div className="p-5 space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-12 rounded" />)}</div>
          : apps.error ? <div className="p-5"><ErrorState message={apps.error} onRetry={apps.reload} /></div>
          : (apps.data?.items?.length ?? 0) === 0 ? <EmptyState>No applications match this view.</EmptyState>
          : (
            <div className="divide-y divide-slate-100">{apps.data!.items.map((a) => (
              <div key={a.id} className="flex flex-wrap items-center gap-3 p-4">
                <div className="min-w-[180px] flex-1"><p className="text-xs font-bold text-slate-800">{a.full_name}</p><p className="text-[11px] text-slate-400">{a.title} · {a.organization}</p></div>
                <Pill tone="slate">{a.status}</Pill>
                <a href={`/api/v51/admin/applications/${a.id}/cv`} className="text-[11px] font-bold text-cyan-700">Download CV</a>
              </div>
            ))}</div>
          )}
        <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3"><Btn variant="outline" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Prev</Btn><span className="ac-mono text-[11px] text-slate-500">Page {page + 1}</span><Btn variant="outline" disabled={(apps.data?.items.length ?? 0) < 50} onClick={() => setPage((p) => p + 1)}>Next</Btn></div>
      </Card>
    </div>
  );
}
