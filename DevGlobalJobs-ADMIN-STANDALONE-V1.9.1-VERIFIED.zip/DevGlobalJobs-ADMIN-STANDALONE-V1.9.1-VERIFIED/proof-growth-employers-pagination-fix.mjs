// Proves the fixed pagination/shape-handling logic against the REAL
// backend response shape ({items,total,page,limit}, 100-record cap),
// including a case with >100 total records to prove pagination actually
// continues instead of silently stopping at page 1.

// Simulate 130 total growth employer records, backend enforcing the real
// 100-record max page size regardless of what limit is requested.
const TOTAL = 130;
function serverPage(page, requestedLimit) {
  const limit = Math.min(100, Math.max(10, requestedLimit || 50)); // mirrors real backend clamp
  const off = (page - 1) * limit;
  const items = [];
  for (let i = off; i < Math.min(off + limit, TOTAL); i++) {
    items.push({ email: `employer${i}@example.com`, regular_this_month: i % 5 });
  }
  return { items, total: TOTAL, page, limit };
}
async function fakeFetchJson(url) {
  const u = new URL(url, "http://x");
  const page = Number(u.searchParams.get("page") || 1);
  const limit = Number(u.searchParams.get("limit") || 50);
  return serverPage(page, limit);
}

// --- exact algorithm under test, copied from useAllGrowthEmployers ---
async function fetchAll() {
  const PAGE_LIMIT = 100;
  const first = await fakeFetchJson(`/api/admin/growth/employers?page=1&limit=${PAGE_LIMIT}`);
  const all = [...(first.items || [])];
  const total = Number(first.total || all.length);
  let page = 2;
  while (all.length < total) {
    const next = await fakeFetchJson(`/api/admin/growth/employers?page=${page}&limit=${PAGE_LIMIT}`);
    if (!next.items || next.items.length === 0) break;
    all.push(...next.items);
    page += 1;
  }
  return all;
}
// --- exact map-building line under test ---
function buildMap(items) {
  return new Map((items || []).map((g) => [String(g.email || "").toLowerCase(), g]));
}

const items = await fetchAll();
console.log(`fetched ${items.length} of ${TOTAL} total (expected: all ${TOTAL}, proving pagination continues past page 1)`);
if (items.length !== TOTAL) { console.error("FAIL: pagination did not fetch all records"); process.exit(1); }

const map = buildMap(items);
console.log(`map built with ${map.size} entries — no .map() TypeError thrown`);
if (map.size !== TOTAL) { console.error("FAIL: map size mismatch"); process.exit(1); }

// Also prove the OLD buggy code (calling .map directly on the raw
// {items,total,...} object instead of .items) WOULD have thrown, to show
// this isn't a vacuous test:
try {
  const rawResponse = await fakeFetchJson("/api/admin/growth/employers?limit=500");
  rawResponse.map((g) => g); // this is what the old buggy code effectively did
  console.error("UNEXPECTED: old buggy pattern did not throw — test is not meaningful");
  process.exit(1);
} catch (e) {
  console.log(`Confirmed old buggy pattern throws as expected: ${e.constructor.name}: ${e.message}`);
}

console.log("\nPASS: fixed logic handles the real {items,total,page,limit} shape correctly, paginates past the 100-record cap, and the old bug is confirmed to have been a real bug (not a false alarm).");
