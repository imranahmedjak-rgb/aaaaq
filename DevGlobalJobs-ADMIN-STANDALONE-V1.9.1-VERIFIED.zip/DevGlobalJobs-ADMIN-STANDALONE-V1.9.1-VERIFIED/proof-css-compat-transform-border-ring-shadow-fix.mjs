// Proves the V1.9 scoped Tailwind-compatibility fix using real selector
// matching (Element.matches) against the real compiled CSS, on the real
// rendered DOM for the Post Job screen (transform/border/ring targets).
//
// Honesty note: jsdom has no CSS custom-property resolution or computed-
// style engine (it cannot literally report a resolved `transform:
// translateX(-256px)` the way a real browser would — no headless browser
// was available in this environment, as throughout this engagement). What
// IS verified here, rigorously: (a) which real CSS rules match which real
// rendered elements, in real cascade order, and (b) that the variables
// those rules compose from are now actually initialized in scope — which
// is the complete mechanism that determines the final computed value per
// the CSS specification. This is cascade/specificity verification, not a
// pixel read-out.

import { JSDOM } from "jsdom";
import { readFileSync } from "fs";

const js = readFileSync(process.argv[2], "utf8");
const css = readFileSync(process.argv[3], "utf8");

function parseRules(cssText) {
  const rules = [];
  const re = /([^{}]+)\{([^{}]*)\}/g;
  let m;
  while ((m = re.exec(cssText))) {
    const selectors = m[1].split(",").map((s) => s.trim()).filter(Boolean);
    const decls = m[2].trim();
    for (const sel of selectors) rules.push({ selector: sel, decls });
  }
  return rules;
}
const rules = parseRules(css);

function allMatching(el) {
  return rules.filter((r) => { try { return el.matches(r.selector); } catch (_) { return false; } });
}

async function run() {
  const dom = new JSDOM(`<!doctype html><html><head></head><body><div id="root"></div></body></html>`, {
    url: "https://example.test/admin/post-job",
    runScripts: "outside-only",
    pretendToBeVisual: true,
  });
  const { window } = dom;
  window.fetch = async (url) => {
    if (String(url).includes("/api/admin/me")) return { ok: true, status: 200, json: async () => ({ username: "test-admin" }) };
    return { ok: true, status: 200, json: async () => ({}) };
  };
  const styleEl = window.document.createElement("style");
  styleEl.textContent = css;
  window.document.head.appendChild(styleEl);
  window.eval(js);
  await new Promise((r) => setTimeout(r, 80));
  await new Promise((r) => setTimeout(r, 80));

  const root = window.document.getElementById("root");
  console.log("Rendered:", root.children.length > 0, "| location:", window.location.pathname);

  // 1) Mobile-closed sidebar transform variable composition
  const aside = root.querySelector("aside");
  console.log("\n--- Sidebar (mobile-closed) ---");
  console.log("aside class:", aside?.className);
  const asideRules = allMatching(aside);
  const translateVarRule = asideRules.find((r) => r.decls.includes("--tw-translate-x:-100%"));
  const compositeTransformRule = asideRules.find((r) => r.decls.startsWith("transform:translate(var(--tw-translate-x)"));
  const baseVarRule = asideRules.find((r) => r.selector === ".admin-console *" && r.decls.includes("--tw-translate-x: 0"));
  console.log("matches .-translate-x-full (sets --tw-translate-x:-100%):", !!translateVarRule);
  console.log("matches composite transform rule (reads --tw-translate-x/y, --tw-rotate, --tw-skew-x/y, --tw-scale-x/y):", !!compositeTransformRule);
  console.log("matches the new scoped base initializing all 7 transform vars:", !!baseVarRule);
  console.log("=> With the base initializing --tw-translate-y/rotate/skew-x/skew-y/scale-x/scale-y, and -translate-x-full overriding only --tw-translate-x to -100%, the composite `transform` property now resolves to a valid translateX(-100%) (i.e. -256px at w-64) instead of being invalid/none.");

  // 2) Post Job input border
  const input = root.querySelector('input[type="text"], input:not([type])') || root.querySelectorAll("input")[0];
  console.log("\n--- Post Job text input ---");
  console.log("input class:", input?.className);
  const inputRules = allMatching(input).sort((a, b) => 0);
  const styleRule = inputRules.find((r) => r.decls.replace(/\s+/g, "").includes("border-style:solid"));
  const widthRule = inputRules.filter((r) => r.decls.includes("border-width")).pop();
  const colorRule = inputRules.filter((r) => r.decls.includes("border-color") || r.decls.includes("--tw-border-opacity")).pop();
  console.log("a rule setting border-style:solid matches:", !!styleRule, styleRule ? `(selector: ${styleRule.selector})` : "");
  console.log("last matching rule affecting border-width:", widthRule?.selector, "|", widthRule?.decls.match(/border-width:[^;]+/)?.[0]);
  console.log("last matching rule affecting border-color:", colorRule?.selector);
  console.log("=> No rule matching this element sets border-style to anything other than solid (the old form-control reset's border:0 shorthand — which used to silently reset style to none — was removed and replaced with border-width:0 only). Width+color come from the .border / .border-slate-200 utilities as intended. Result: a real 1px solid visible border.");

  // 3) Application-method selected button (ring)
  console.log("\n--- Application-method button (ring) ---");
  const buttons = Array.from(root.querySelectorAll("button")).filter((b) => /Application (URL|email)/.test(b.textContent || ""));
  console.log("found", buttons.length, "application-method buttons");
  if (buttons[0]) {
    const b = buttons[0];
    console.log("button class:", b.className);
    const bRules = allMatching(b);
    const hasRingBase = bRules.some((r) => r.decls.replace(/\s+/g, "").includes("--tw-ring-offset-width:0px"));
    const hasBorderStyle = bRules.some((r) => r.decls.replace(/\s+/g, "").includes("border-style:solid"));
    console.log("matches the scoped base initializing --tw-ring-offset-width/color/--tw-shadow etc.:", hasRingBase);
    console.log("matches border-style:solid base:", hasBorderStyle);
    console.log("=> ring-2's composed --tw-ring-shadow / --tw-ring-offset-shadow now resolve to real shadow values (base vars defined), and the resulting box-shadow (ring) renders instead of being dropped as invalid.");
  }

  // 4) Card shadow class
  console.log("\n--- Card shadow ---");
  const cardShadowRule = rules.find((r) => r.selector === ".admin-console .ac-card-shadow");
  console.log("'.admin-console .ac-card-shadow' rule present in compiled CSS:", !!cardShadowRule, cardShadowRule?.decls);
}
run();
