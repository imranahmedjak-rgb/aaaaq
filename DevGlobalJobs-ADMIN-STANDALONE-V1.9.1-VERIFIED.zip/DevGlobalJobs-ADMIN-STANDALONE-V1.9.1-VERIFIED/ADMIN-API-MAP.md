# Admin API Map — V1.2

Unchanged functional scope from V1.1 (all previously completed Admin
modules retained). This round only corrected: A1 script-gating ID
preservation, A2 two additional route aliases, A3 hard-assertion hash
script. No Employer-side changes remain in this package — see
"EXISTING EMPLOYER COMMERCIAL FLOW" in VERIFICATION.txt.

| Section | Endpoints used |
|---|---|
| Session | `POST /api/admin/login`, `GET /api/admin/me`, `POST /api/admin/logout` |
| Executive Overview | `GET /api/admin/stats`, `GET /api/admin/growth/overview`, `GET /api/v45/admin/summary`, `GET /api/v51/admin/summary` |
| Jobs Management | `GET /api/admin/jobs`, `GET /api/admin/sources`, `PUT/DELETE /api/admin/jobs/:id` |
| Post Job | `POST /api/admin/jobs` |
| Sources & Fetcher | `GET /api/admin/sources`, `GET /api/admin/fetch-status`, `POST /api/admin/fetch-jobs`, `GET /api/admin/google-indexing-status` |
| Employers | `GET /api/v46/admin/employers` + `GET /api/admin/growth/employers` (merged) |
| Job Seekers | `GET /api/admin/seekers`, `GET /api/admin/seekers/:id`, `GET /api/admin/seekers/stats`, `DELETE /api/admin/seekers/:id` |
| Recruitment | `GET /api/v51/admin/summary`, `GET /api/v51/admin/applications`, `GET .../applications/:id/cv`, `GET /api/v51/admin/recruitment.csv` |
| Revenue | `GET /api/v45/admin/summary` (verified) + `GET /api/admin/revenue-metrics` (labeled estimate) |
| Plans, Boosts & Codes | `GET/PUT /api/v45/admin/requests(/:id)`, `.../publish`, `.../reject`, `.../receipt`, `GET/POST /api/v45/admin/boosts(/:id/end)`, `GET/POST /api/v45/admin/codes(/:id/revoke)` |
| Subscribers & Growth | `GET/DELETE /api/admin/newsletter(/:id)`, `GET/POST /api/admin/growth/subscribers(/bulk)`, `GET /api/admin/growth/campaigns`, `POST .../run-weekly` |
| Blog | `GET/POST/PUT/DELETE /api/admin/blog(/:id)` |

`GET /api/admin/subscribers` (legacy weak auth) is never called — verified by grep.

## Legacy URL aliases (final)

| URL | Section | Notes |
|---|---|---|
| `/admin`, `/admin/dashboard` | Overview | |
| `/admin/jobs` | Jobs | |
| `/admin/sources` | Sources / Fetcher | |
| `/admin/employers` | Employers | |
| `/admin/seekers` | Job Seekers | |
| `/admin/applications` | Recruitment / Applications | |
| `/admin/review`, `/admin/reviews` | Recruitment / Applications | Closest real equivalent to the legacy "review queue" concept (both singular and plural aliases) |
| `/admin/reports` | Recruitment / Applications | Closest real equivalent (CSV export lives here) |
| `/admin/revenue`, `/admin/revenue-metrics` | Revenue | |
| `/admin/requests`, `/admin/premium` | Plans, Boosts & Codes | opens the "Paid Requests" tab |
| `/admin/boosts` | Plans, Boosts & Codes | opens the "Boosts" tab |
| `/admin/codes` | Plans, Boosts & Codes | opens the "Codes" tab |
| `/admin/newsletter`, `/admin/growth` | Subscribers & Growth | |
| `/admin/blog` | Blog | |
| `/admin/settings` | Overview | No dedicated Settings screen exists — explicit, documented fallback |
| `/admin/support` | Overview | No dedicated Support screen exists — explicit, documented fallback (new this round) |

Every mapping is explicit in code (`LEGACY_ALIASES` in core.tsx) — none of
these fall through to the "unknown route" default path silently; the two
without a real screen (`settings`, `support`) are intentional, documented
fallbacks, not unhandled cases.
