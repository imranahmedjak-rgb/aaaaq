// Real-DOM proof: renders the ACTUAL bundled dgj-claude-admin-v1.js inside
// a real jsdom document, with the ACTUAL compiled dgj-claude-admin-v1.css
// parsed and checked via genuine CSS selector matching (element.matches),
// not string search. Proves the root-layout fix at the DOM/CSS level.

import { JSDOM } from "jsdom";
import { readFileSync } from "fs";

const JS_PATH = process.argv[2];
const CSS_PATH = process.argv[3];
const js = readFileSync(JS_PATH, "utf8");
const css = readFileSync(CSS_PATH, "utf8");

function parseRules(cssText) {
  const rules = [];
  const re = /([^{}]+)\{([^{}]*)\}/g;
  let m;
  while ((m = re.exec(cssText))) {
    const selectors = m[1].split(",").map((s) => s.trim()).filter(Boolean);
    const decls = m[2].trim();
    for (const sel of selectors) rules.push({ selector: sel, decls });
  }
  return rules;
}
const rules = parseRules(css);

function matchedDeclarationsFor(el, propName) {
  const found = [];
  for (const r of rules) {
    try {
      if (el.matches(r.selector)) found.push(r);
    } catch (_) { /* skip selectors jsdom's matcher can't parse */ }
  }
  const withProp = found.filter((r) => r.decls.includes(propName + ":"));
  return withProp.length ? withProp[withProp.length - 1].decls : null;
}

async function run(scenario, fetchImpl) {
  const dom = new JSDOM(`<!doctype html><html><head></head><body><div id="root"></div></body></html>`, {
    url: "https://example.test/admin",
    runScripts: "outside-only",
    pretendToBeVisual: true,
  });
  const { window } = dom;
  window.fetch = fetchImpl;

  const styleEl = window.document.createElement("style");
  styleEl.textContent = css;
  window.document.head.appendChild(styleEl);

  window.eval(js);

  await new Promise((r) => setTimeout(r, 50));
  await new Promise((r) => setTimeout(r, 50));

  const root = window.document.getElementById("root");
  console.log(`\n=== ${scenario} ===`);
  console.log("root innerHTML present:", !!root && root.children.length > 0);

  const adminConsoleEl = root.querySelector(".admin-console");
  console.log("outer .admin-console element found:", !!adminConsoleEl);
  if (adminConsoleEl) {
    const outerDisplay = matchedDeclarationsFor(adminConsoleEl, "display");
    console.log("outer .admin-console matched 'display' rule (should be none — scope-only):", outerDisplay || "(none, expected)");

    const directChild = adminConsoleEl.firstElementChild;
    console.log("direct child tag:", directChild ? directChild.tagName : null, "class=", directChild ? directChild.className : null);
    if (directChild) {
      const childDisplay = matchedDeclarationsFor(directChild, "display");
      const childMinHeight = matchedDeclarationsFor(directChild, "min-height");
      const childAlignItems = matchedDeclarationsFor(directChild, "align-items");
      const childJustify = matchedDeclarationsFor(directChild, "justify-content");
      console.log("child matched display:", childDisplay);
      console.log("child matched min-height:", childMinHeight);
      console.log("child matched align-items:", childAlignItems);
      console.log("child matched justify-content:", childJustify);
      const isFlexCentered = (childDisplay || "").includes("flex") && (childMinHeight || "").includes("100dvh");
      console.log("RESULT — child is flex + min-h-100dvh:", isFlexCentered);
    }
  }
  return { window, root };
}

const run1 = await run("LOGGED OUT — Admin Login screen", async (url) => {
  if (String(url).includes("/api/admin/me")) return { ok: false, status: 401, json: async () => ({}) };
  return { ok: false, status: 404, json: async () => ({}) };
});

const run2 = await run("LOGGED IN — Authenticated Admin shell", async (url) => {
  if (String(url).includes("/api/admin/me")) return { ok: true, status: 200, json: async () => ({ username: "test-admin" }) };
  return { ok: true, status: 200, json: async () => ({}) };
});

const shellRoot = run2.root.querySelector(".admin-console");
if (shellRoot) {
  const flexChild = shellRoot.firstElementChild;
  console.log("\nLogged-in shell child tag/class:", flexChild?.tagName, flexChild?.className);
  const kids = flexChild ? Array.from(flexChild.children).map((c) => c.tagName.toLowerCase()) : [];
  console.log("Logged-in shell child's direct children:", kids);
}

console.log("\nDone.");

// Confirm the sidebar itself has its expected fixed-width/no-shrink classes
// (w-64 shrink-0) so the flex-row layout above resolves to a real
// side-by-side geometry, not just an unstyled row.
if (shellRoot) {
  const flexChild = shellRoot.firstElementChild;
  const aside = flexChild.querySelector("aside");
  console.log("\nSidebar <aside> className:", aside?.className);
  const widthRule = matchedDeclarationsFor(aside, "width");
  console.log("Sidebar matched width rule:", widthRule);
}
