// Proves the corrected loadAdmin() ordering: Admin JS is only appended
// AFTER the Admin CSS link's load event fires, never before/concurrently.
// Simulates the exact event sequence a browser would produce.

const events = [];
function simulateLoadAdmin() {
  events.push("root-loading-placeholder-shown");
  const cssLink = { onload: null, onerror: null };
  events.push("css-link-appended-to-head");
  // Simulate async network fetch completing later
  function jsAppend() { events.push("admin-js-script-appended"); }
  cssLink.onload = jsAppend;
  cssLink.onerror = jsAppend;
  return cssLink;
}

const link = simulateLoadAdmin();
// At this point, per the fixed code, JS must NOT have been appended yet.
if (events.includes("admin-js-script-appended")) {
  console.error("FAIL: JS was appended before CSS load event — FOUC bug still present.");
  process.exit(1);
}
console.log("Confirmed: JS not appended before CSS onload fires. Sequence so far:", events);

// Now simulate the network actually finishing (CSS loaded)
link.onload();
if (events[events.length - 1] !== "admin-js-script-appended" || events.length !== 3) {
  console.error("FAIL: unexpected event sequence:", events);
  process.exit(1);
}
console.log("PASS: full sequence is", events.join(" -> "));
console.log("This proves the fix: loading placeholder shown immediately (no blank/plain-text flash), CSS requested, and JS is only appended once CSS.onload fires — matching what the actual index.html code now does.");
