import {
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const employersTable = pgTable(
  "employers",
  {
    id: serial("id").primaryKey(),
    clerkUserId: text("clerk_user_id"),
    companyName: text("company_name").notNull(),
    email: text("email").notNull(),
    website: text("website"),
    location: text("location"),
    industry: text("industry"),
    companySize: text("company_size"),
    profileStatus: text("profile_status").notNull().default("Verified"),
    accountStatus: text("account_status").notNull().default("Healthy"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [
    index("employers_company_name_idx").on(table.companyName),
    index("employers_status_idx").on(table.accountStatus),
    index("employers_clerk_user_idx").on(table.clerkUserId),
  ],
);

export const employerJobsTable = pgTable(
  "employer_jobs",
  {
    id: serial("id").primaryKey(),
    employerId: integer("employer_id").notNull().references(() => employersTable.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    department: text("department").notNull(),
    location: text("location").notNull(),
    workModel: text("work_model").notNull().default("Remote"),
    employmentType: text("employment_type").notNull().default("Full time"),
    status: text("status").notNull().default("Pending Review"),
    views: integer("views").notNull().default(0),
    applicants: integer("applicants").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [
    index("employer_jobs_employer_idx").on(table.employerId),
    index("employer_jobs_status_idx").on(table.status),
    index("employer_jobs_created_idx").on(table.createdAt),
  ],
);

export const employerApplicationsTable = pgTable(
  "employer_applications",
  {
    id: serial("id").primaryKey(),
    employerId: integer("employer_id").notNull().references(() => employersTable.id, { onDelete: "cascade" }),
    jobId: integer("job_id").notNull().references(() => employerJobsTable.id, { onDelete: "cascade" }),
    candidateName: text("candidate_name").notNull(),
    candidateEmail: text("candidate_email").notNull(),
    role: text("role").notNull(),
    status: text("status").notNull().default("New"),
    matchScore: integer("match_score").notNull().default(0),
    submittedAt: timestamp("submitted_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("employer_applications_employer_idx").on(table.employerId),
    index("employer_applications_job_idx").on(table.jobId),
    index("employer_applications_status_idx").on(table.status),
  ],
);

export const employerPaymentsTable = pgTable(
  "employer_payments",
  {
    id: serial("id").primaryKey(),
    employerId: integer("employer_id").notNull().references(() => employersTable.id, { onDelete: "cascade" }),
    reference: text("reference").notNull(),
    service: text("service").notNull(),
    amountCents: integer("amount_cents").notNull().default(0),
    currency: text("currency").notNull().default("USD"),
    status: text("status").notNull().default("Under Review"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("employer_payments_employer_idx").on(table.employerId),
    index("employer_payments_status_idx").on(table.status),
  ],
);

export const employerRequestsTable = pgTable(
  "employer_requests",
  {
    id: serial("id").primaryKey(),
    employerId: integer("employer_id").notNull().references(() => employersTable.id, { onDelete: "cascade" }),
    requestType: text("request_type").notNull(),
    title: text("title").notNull(),
    priority: text("priority").notNull().default("Medium"),
    status: text("status").notNull().default("Open"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("employer_requests_employer_idx").on(table.employerId),
    index("employer_requests_status_idx").on(table.status),
  ],
);

export const insertEmployerSchema = createInsertSchema(employersTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertEmployerJobSchema = createInsertSchema(employerJobsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertEmployerApplicationSchema = createInsertSchema(employerApplicationsTable).omit({ id: true, submittedAt: true });
export const insertEmployerPaymentSchema = createInsertSchema(employerPaymentsTable).omit({ id: true, createdAt: true });
export const insertEmployerRequestSchema = createInsertSchema(employerRequestsTable).omit({ id: true, createdAt: true });

export type Employer = typeof employersTable.$inferSelect;
export type InsertEmployer = z.infer<typeof insertEmployerSchema>;
export type EmployerJob = typeof employerJobsTable.$inferSelect;
export type InsertEmployerJob = z.infer<typeof insertEmployerJobSchema>;
export type EmployerApplication = typeof employerApplicationsTable.$inferSelect;
export type InsertEmployerApplication = z.infer<typeof insertEmployerApplicationSchema>;
export type EmployerPayment = typeof employerPaymentsTable.$inferSelect;
export type InsertEmployerPayment = z.infer<typeof insertEmployerPaymentSchema>;
export type EmployerRequest = typeof employerRequestsTable.$inferSelect;
export type InsertEmployerRequest = z.infer<typeof insertEmployerRequestSchema>;