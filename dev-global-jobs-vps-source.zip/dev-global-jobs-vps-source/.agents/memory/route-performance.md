---
name: Route performance and ownership
description: Keep employer post-job navigation owned by one SPA route and avoid legacy DOM observers or polling on that path.
---

The employer post-job experience must have a single route owner. Avoid combining SPA navigation with legacy global click/history handlers, DOM replacement, or repeated readiness polling on the same URL.

**Why:** Multiple route owners can create navigation loops and long main-thread work, which surfaces to users as a browser “Page unresponsive” dialog.

**How to apply:** Keep the post-job entry non-blocking, put authentication/loading behind bounded states, and lazy-load dashboard-only code so public routes stay lightweight.