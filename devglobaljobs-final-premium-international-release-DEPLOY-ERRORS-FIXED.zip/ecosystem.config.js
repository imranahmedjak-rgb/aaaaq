const config = {
  apps: [
    {
      name: "devglobaljobs",
      script: "dist/index.cjs",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "512M",
      wait_ready: false,
      listen_timeout: 10000,
      kill_timeout: 5000,
      node_args: "--env-file=.env",
      env: {
        NODE_ENV: "production",
        PORT: 8080,
      },
    },
  ],
};

export default config;
