#!/usr/bin/env python3
from pathlib import Path
import sys, hashlib

if len(sys.argv) != 2:
    raise SystemExit("Usage: patch-v45-category-lock.py /path/to/dist/dgj-v45-commercial.cjs")

p = Path(sys.argv[1])
s = p.read_text()

old = "    const skillCat=classifyJobSkillCategory(payload.title,payload.description||'');"
new = "    const selectedSkillCategory=['technology','healthcare','business','education','engineering','creative','sales','gig','youth'].includes(payload.category)?payload.category:null; const skillCat=selectedSkillCategory||classifyJobSkillCategory(payload.title,payload.description||'');"

if new in s:
    print("CATEGORY_LOCK_ALREADY_PRESENT")
elif s.count(old) == 1:
    s = s.replace(old, new, 1)
    p.write_text(s)
    print("CATEGORY_LOCK_PATCHED")
else:
    raise SystemExit(f"Refusing to patch: expected one createJob classifier line, found {s.count(old)}")

print(hashlib.sha256(p.read_bytes()).hexdigest())
