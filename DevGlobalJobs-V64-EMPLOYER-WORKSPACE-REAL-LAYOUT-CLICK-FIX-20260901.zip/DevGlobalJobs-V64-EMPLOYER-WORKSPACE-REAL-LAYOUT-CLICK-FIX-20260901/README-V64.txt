Dev Global Jobs V64 — Employer Workspace Real Layout + Click Fix

Purpose
-------
Correct the V63 scope mistake: the supplied screenshots are /post-job?employer=1, which renders inside #dgj46-post-shell. V63 only applied layout CSS to #dgj46-employer-root, so the visible Post-a-Job Employer Workspace could remain unchanged.

V64 changes ONLY the Employer Workspace frontend shell:
1. Applies the stable layout to BOTH #dgj46-employer-root and #dgj46-post-shell.
2. Desktop >=1100px: 320px fixed employer sidebar; main workspace uses the remaining viewport width.
3. Tablet/mobile <1100px: sidebar stops squeezing the main area; navigation becomes a horizontal scrollable workspace bar and content uses full width.
4. Keeps the V63 capture-level click/keyboard routing, now marked V64.
5. Does not alter Post-a-Job fields, recruitment/Easy Apply, Admin, backend, database, payments, SEO, Google Jobs or PWA.
6. No PM2 restart/reload.
