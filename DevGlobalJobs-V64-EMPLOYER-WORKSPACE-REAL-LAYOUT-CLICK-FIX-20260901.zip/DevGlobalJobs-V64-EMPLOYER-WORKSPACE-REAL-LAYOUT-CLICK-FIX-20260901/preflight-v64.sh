#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
sha256sum -c PAYLOAD-SHA256SUMS.txt
node --check payload/dist/public/assets/dgj-v51-employer.js >/dev/null
grep -Fq "dgj-v64-employer-workspace-layout" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "#dgj46-post-shell .dgj46-side" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "#dgj46-post-shell .dgj46-post-main" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "window.__DGJ_V64_EMPLOYER_NAV__" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "window.addEventListener('pointerdown'" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "switchPostToEmployerTab(t)" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "activateEmployerTab(t,true)" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "dgj-v51-employer.js?v=64.0.0" payload/dist/public/index.html
! grep -Fq 'dgj-v51-recruitment.js?v=64' payload/dist/public/index.html
! grep -Fq 'dgj-v51-recruitment.css?v=64' payload/dist/public/index.html
echo 'PASS: V64 real Employer Workspace layout + navigation scope verified.'
