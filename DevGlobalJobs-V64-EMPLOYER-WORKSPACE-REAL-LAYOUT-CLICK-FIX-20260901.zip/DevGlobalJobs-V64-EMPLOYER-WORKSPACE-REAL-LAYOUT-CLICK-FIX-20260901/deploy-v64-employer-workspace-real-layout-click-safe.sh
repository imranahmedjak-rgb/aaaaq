#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$HERE/payload/dist/public"
BACKUP="/var/backups/devglobaljobs-v64-employer-workspace-$(date +%Y%m%d-%H%M%S)"

# Exact live V63 baseline currently deployed.
V63_IDX="5e9bd6e774b67a0c40d1c4cdad2de04a387b5060d074256372676023d18fd6ec"
V63_EMP="86c96d957d211d467ef4ed05b09eef252cde12b0e3b9165d4ef7e03deb80a455"
V64_IDX="51a5a2592e8d7d3c85a35905c525d113b150f27940a0060abf1900b8295f88a5"
V64_EMP="e4d23e32dbb0ff6fcd406151379021751772110329cbc46f177da97921e71e32"
REC_JS="25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304"
REC_CSS="4fd6bc549aa36c3c674404d13c9e0ef0e65de46f23988daf759cce421b021042"

fail(){
  echo
  echo '============================================================'
  echo "SAFE STOP: $*"
  if [ -d "$BACKUP" ] && [ -f "$BACKUP/index.html" ]; then
    echo 'ROLLBACK: restoring exact pre-V64 frontend files...'
    cp -af "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -af "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    echo 'ROLLBACK COMPLETE.'
  fi
  echo 'NO BACKEND, DATABASE, RECRUITMENT, PAYMENT, SEO, PWA OR PM2 CHANGE WAS MADE.'
  echo '============================================================'
  exit 1
}

echo '============================================================'
echo 'DEV GLOBAL JOBS V64'
echo 'EMPLOYER WORKSPACE REAL LAYOUT + CLICK FIX ONLY'
echo '============================================================'

echo '1/8 EXACT V63 BASELINE + HEALTH'
[ -f "$APP/dist/public/index.html" ] || fail 'live index missing'
[ -f "$APP/dist/public/assets/dgj-v51-employer.js" ] || fail 'live employer JS missing'
[ -f "$APP/dist/public/assets/dgj-v51-recruitment.js" ] || fail 'live recruitment JS missing'
[ -f "$APP/dist/public/assets/dgj-v51-recruitment.css" ] || fail 'live recruitment CSS missing'
LIVE_IDX="$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')"
LIVE_EMP="$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')"
LIVE_RECJS="$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')"
LIVE_RECCSS="$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')"
[ "$LIVE_IDX" = "$V63_IDX" ] || fail "index is not exact V63 baseline: $LIVE_IDX"
[ "$LIVE_EMP" = "$V63_EMP" ] || fail "employer JS is not exact V63 baseline: $LIVE_EMP"
[ "$LIVE_RECJS" = "$REC_JS" ] || fail 'recruitment JS differs; refusing unrelated overwrite'
[ "$LIVE_RECCSS" = "$REC_CSS" ] || fail 'recruitment CSS differs; refusing unrelated overwrite'
CODE="$(curl -sS -o /tmp/dgj-v64-before.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "homepage health is $HOME"
echo 'PASS: exact V63 + protected assets + live health verified.'

echo '2/8 PACKAGE PREFLIGHT'
bash "$HERE/preflight-v64.sh" || fail 'V64 preflight failed'

echo '3/8 PRIVATE TWO-FILE BACKUP'
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
echo "Backup: $BACKUP"

echo '4/8 ATOMIC TWO-FILE INSTALL'
install -m 0644 "$PAYLOAD/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v64.tmp"
install -m 0644 "$PAYLOAD/index.html" "$APP/dist/public/index.html.v64.tmp"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v64.tmp" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/index.html.v64.tmp" "$APP/dist/public/index.html"
echo 'PASS: only employer JS + index cache reference installed.'

echo '5/8 EXACT BYTE + PROTECTED-ASSET VERIFICATION'
[ "$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')" = "$V64_IDX" ] || fail 'installed index hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')" = "$V64_EMP" ] || fail 'installed employer JS hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')" = "$REC_JS" ] || fail 'protected recruitment JS changed unexpectedly'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')" = "$REC_CSS" ] || fail 'protected recruitment CSS changed unexpectedly'
echo 'PASS: exact V64 bytes + protected recruitment assets verified.'

echo '6/8 ORIGIN CONTRACT — NO PM2 RELOAD'
IDX="$(curl -fsS --max-time 15 http://127.0.0.1:8080/)" || fail 'origin homepage fetch failed'
printf '%s' "$IDX" | grep -F 'dgj-v51-employer.js?v=64.0.0' >/dev/null || fail 'origin index does not expose V64 cache version'
JS="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v51-employer.js)" || fail 'origin employer JS fetch failed'
printf '%s' "$JS" | grep -F 'dgj-v64-employer-workspace-layout' >/dev/null || fail 'origin JS missing V64 layout marker'
printf '%s' "$JS" | grep -F '#dgj46-post-shell .dgj46-side' >/dev/null || fail 'origin JS is not targeting Post-a-Job Employer Workspace shell'
printf '%s' "$JS" | grep -F 'window.__DGJ_V64_EMPLOYER_NAV__' >/dev/null || fail 'origin JS missing V64 navigation marker'
echo 'PASS: origin serves V64 immediately without backend restart.'

echo '7/8 FINAL API + HOME HEALTH'
CODE="$(curl -sS -o /tmp/dgj-v64-after.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "post-install API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "post-install homepage health is $HOME"
echo 'PASS: backend + homepage healthy.'

echo '8/8 FINAL SCOPE'
echo '============================================================'
echo 'SUCCESS: V64 EMPLOYER WORKSPACE REAL LAYOUT + CLICK FIX IS LIVE'
echo '============================================================'
echo '✓ FIXES the screenshot path /post-job?employer=1 (#dgj46-post-shell)'
echo '✓ Employer Dashboard /employer (#dgj46-employer-root) uses the same stable shell rules'
echo '✓ Desktop: fixed 320px employer sidebar + correctly offset full main workspace'
echo '✓ Tablet/mobile: full-width workspace + horizontal employer navigation; no squeezed main column'
echo '✓ Sidebar/menu clicks + keyboard routing retained'
echo '✓ Post-a-Job fields/content/business logic unchanged'
echo '✓ Recruitment/Easy Apply unchanged'
echo '✓ Admin/backend/database/payment/SEO/PWA unchanged'
echo '✓ No PM2 reload/restart performed'
echo "Rollback backup: $BACKUP"
echo '============================================================'
