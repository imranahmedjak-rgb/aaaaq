(function(){
'use strict';
var __emp = /^\/employer(?:\/|$)/.test(location.pathname) || (location.pathname === '/post-job' && new URLSearchParams(location.search).get('employer') === '1');
if (__emp) { window.__DGJ_CLAUDE_EMPLOYER_BRIDGE__ = true; return; }
(function() {
  'use strict';
  function fixLayout() {
    var growth = document.getElementById('dgj-growth-admin');
    var main = document.querySelector('main.dgj57-admin-main') || document.querySelector('main.dgj46-main');
    
    // If the element is mis-parented (often dumped directly onto body or root)
    if (growth && main && growth.parentElement !== main) {
      main.appendChild(growth);
    }
  }
  
  var observer = new MutationObserver(fixLayout);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fixLayout);
  } else {
    fixLayout();
  }
})();


/* Dev Global Jobs V70.1 SAFE — dashboards-only additive layer.
   Current live V69 repair above is preserved byte-for-byte.
   This layer exits immediately outside Employer/Admin dashboard routes. */
(function () {
  'use strict';
  var BUILD = 'DGJ_DASHBOARD_V70_1_SAFE_20260902';
  var path = window.location.pathname.replace(/\/+$/, '') || '/';
  var employerRoutes = new Set(['/employer','/employer/dashboard','/employer/jobs','/employer/applications','/employer/analytics','/employer/boosts','/employer/billing','/employer/plans','/employer/profile','/employer/settings','/employer/support']);
  var adminRoutes = new Set(['/admin','/admin/dashboard','/admin/jobs','/admin/employers','/admin/seekers','/admin/applications','/admin/review','/admin/requests','/admin/premium','/admin/revenue','/admin/reports','/admin/newsletter','/admin/growth','/admin/settings']);
  var mode = employerRoutes.has(path) ? 'employer' : adminRoutes.has(path) ? 'admin' : '';
  if (!mode || mode === 'employer') return;

  var root;
  var adminRetryTimer = null;

  function esc(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  }
  function val(obj, keys, fallback) {
    obj = obj || {};
    for (var i = 0; i < keys.length; i++) {
      var v = obj[keys[i]];
      if (v !== undefined && v !== null && v !== '') return v;
    }
    return fallback;
  }
  function num(obj, keys) {
    var v = val(obj, keys, null);
    if (v === null) return null;
    var n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  function fmtNum(v) { return v === null || v === undefined || v === '' || !Number.isFinite(Number(v)) ? '—' : Number(v).toLocaleString(); }
  function fmtMoney(v, currency) {
    if (v === null || v === undefined || v === '' || !Number.isFinite(Number(v))) return '—';
    try { return new Intl.NumberFormat('en-US', { style: 'currency', currency: currency || 'USD', maximumFractionDigits: 2 }).format(Number(v)); }
    catch (_) { return (currency || 'USD') + ' ' + Number(v).toFixed(2); }
  }
  function fmtDate(v, withTime) {
    if (!v) return '—';
    var d = new Date(v);
    if (isNaN(d.getTime())) return esc(v);
    return withTime ? d.toLocaleString('en-GB', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }) : d.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
  }
  function rows(data) {
    if (Array.isArray(data)) return data;
    if (!data || typeof data !== 'object') return [];
    return data.items || data.jobs || data.rows || data.results || data.data || data.subscribers || [];
  }
  function initials(value) {
    var parts = String(value || 'DG').trim().split(/\s+/).filter(Boolean).slice(0,2);
    return (parts.map(function (x) { return x[0]; }).join('').toUpperCase() || 'DG');
  }
  function humanKey(key) {
    return String(key || '').replace(/_/g,' ').replace(/\b\w/g, function (m) { return m.toUpperCase(); });
  }
  function statusTone(v) {
    var s = String(v || '').toLowerCase();
    if (/active|live|paid|published|approved|healthy|hired|shortlisted|verified|open/.test(s)) return 'good';
    if (/pending|review|processing|interview|draft|paused|waiting/.test(s)) return 'warn';
    if (/reject|failed|closed|ended|revoked|withdrawn|suspend/.test(s)) return 'bad';
    return 'neutral';
  }
  function status(v) { return '<span class="df-status '+statusTone(v)+'"><i></i>'+esc(v || 'Unknown')+'</span>'; }
  function icon(name) {
    var p = {
      overview:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
      jobs:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2"/>',
      users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
      file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h6"/>',
      chart:'<path d="M3 3v18h18M7 16l4-5 4 3 5-7"/>',
      building:'<path d="M3 21h18M6 21V4h9v17M15 8h3v13M9 8h2M9 12h2M9 16h2"/>',
      star:'<path d="m12 2 3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01z"/>',
      card:'<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h2"/>',
      dollar:'<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7H14a3.5 3.5 0 0 1 0 7H6"/>',
      mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
      shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><path d="m9 12 2 2 4-4"/>',
      settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21h-4v-.1A1.7 1.7 0 0 0 8.6 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H3v-4h.1A1.7 1.7 0 0 0 4.6 8.6a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V3h4v.1A1.7 1.7 0 0 0 15.4 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.4 9c.35.3.56.7.6 1.1h.1v4H20c-.04.4-.25.8-.6 1z"/>',
      globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
      logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
      refresh:'<path d="M20 11a8 8 0 1 0 2 5M20 4v7h-7"/>'
    }[name] || '<circle cx="12" cy="12" r="9"/>';
    return '<svg class="df-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+p+'</svg>';
  }
  async function api(url, options) {
    var res = await fetch(url, Object.assign({ credentials: 'include', headers: { 'Accept':'application/json' } }, options || {}));
    var data = {};
    var type = res.headers.get('content-type') || '';
    if (type.indexOf('json') >= 0) { try { data = await res.json(); } catch (_) {} }
    if (!res.ok) {
      var e = new Error(data.message || data.error || ('Request failed ('+res.status+')'));
      e.status = res.status; throw e;
    }
    return data;
  }
  async function safe(url) { try { return await api(url); } catch (_) { return null; } }

  function mount() {
    root = document.getElementById('dgj-dashboard-final-root');
    if (!root) {
      root = document.createElement('div'); root.id = 'dgj-dashboard-final-root'; root.setAttribute('data-build', BUILD);
      document.body.appendChild(root); document.body.classList.add('dgj-dashboard-final-active');
    }
  }
  function unmount() {
    if (root && root.parentNode) root.parentNode.removeChild(root);
    root = null; document.body.classList.remove('dgj-dashboard-final-active');
  }
  function loading(label) {
    mount();
    root.innerHTML = '<div class="df-loading"><div class="df-spinner"></div><strong>'+esc(label)+'</strong><span>Securely connecting to live production data</span></div>';
  }
  function errorScreen(title, message, actionText) {
    mount();
    root.innerHTML = '<div class="df-loading"><div class="df-error-mark">!</div><strong>'+esc(title)+'</strong><span>'+esc(message)+'</span><button class="df-btn primary" data-reload>'+esc(actionText || 'Retry')+'</button></div>';
    bindShell();
  }
  function nav(mode) {
    var employer = [
      ['Overview','/employer','overview'],['My Jobs','/employer/jobs','jobs'],['Applications','/employer/applications','users'],['Post a Job','/post-job?employer=1','star'],['Analytics','/employer/analytics','chart'],['Premium Boost','/employer/boosts','star'],['Billing & Payments','/employer/billing','card'],['Plans & Credits','/employer/plans','file'],['Company Profile','/employer/profile','building'],['Settings','/employer/settings','settings']
    ];
    var admin = [
      ['Overview','/admin','overview'],['Jobs','/admin/jobs','jobs'],['Employers','/admin/employers','building'],['Seekers','/admin/seekers','users'],['Applications','/admin/applications','file'],['Review','/admin/review','shield'],['Premium & Boosts','/admin/premium','star'],['Revenue','/admin/revenue','dollar'],['Reports','/admin/reports','chart'],['Newsletter','/admin/newsletter','mail'],['Growth','/admin/growth','chart'],['Requests','/admin/requests','shield'],['Settings','/admin/settings','settings']
    ];
    return mode === 'admin' ? admin : employer;
  }
  function currentTitle(mode) {
    var items = nav(mode); var clean = path === '/employer/dashboard' ? '/employer' : path === '/admin/dashboard' ? '/admin' : path;
    for (var i=0;i<items.length;i++) if (items[i][1].split('?')[0] === clean) return items[i][0];
    return 'Overview';
  }
  function shell(mode, account, content, subtitle) {
    var name = mode === 'admin' ? (account.username || 'Marketplace Admin') : val(account.profile || {}, ['company_name'], account.email || 'Employer Workspace');
    var active = currentTitle(mode);
    var items = nav(mode).map(function (item) {
      var isActive = item[0] === active;
      return '<a class="df-nav '+(isActive?'active':'')+'" href="'+esc(item[1])+'">'+icon(item[2])+'<span>'+esc(item[0])+'</span></a>';
    }).join('');
    return '<div class="df-app">'
      +'<aside class="df-side"><div class="df-brand"><img src="/dev-global-jobs-logo.png" alt="Dev Global Jobs"><div><b>Dev Global Jobs</b><small>'+(mode==='admin'?'OPERATIONS':'EMPLOYER')+'</small></div></div><div class="df-side-label">'+(mode==='admin'?'Marketplace control':'Hiring workspace')+'</div><nav>'+items+'</nav><div class="df-side-foot"><div class="df-secure">'+icon('shield')+'<div><b>Secure workspace</b><span>Protected by existing production session authentication.</span></div></div><a class="df-nav" href="/">'+icon('globe')+'<span>Public site</span></a></div></aside>'
      +'<div class="df-backdrop" data-mobile-close></div>'
      +'<main class="df-main"><header class="df-top"><div class="df-top-left"><button class="df-icon-btn df-menu" data-mobile-open aria-label="Open menu">☰</button><div><small>Workspace / '+esc(active)+'</small><strong>'+esc(name)+'</strong></div></div><div class="df-top-actions"><button class="df-icon-btn" data-reload title="Refresh">'+icon('refresh')+'</button><span class="df-avatar">'+esc(initials(name))+'</span><button class="df-logout" data-logout>'+icon('logout')+'<span>Sign out</span></button></div></header><div class="df-content"><div class="df-page-head"><div><div class="df-eyebrow">'+(mode==='admin'?'GLOBAL OPERATIONS':'GLOBAL HIRING')+'</div><h1>'+esc(active)+'</h1><p>'+esc(subtitle || (mode==='admin'?'Live marketplace operations connected to protected production APIs.':'Your private international hiring workspace, connected to live account data.'))+'</p></div></div>'+content+'<footer class="df-footnote"><span>'+BUILD+'</span><span>Live API data · No demo records</span></footer></div></main></div>';
  }
  function bindShell() {
    if (!root) return;
    var open = root.querySelector('[data-mobile-open]'); var close = root.querySelector('[data-mobile-close]');
    if (open) open.onclick = function () { root.classList.add('mobile-open'); };
    if (close) close.onclick = function () { root.classList.remove('mobile-open'); };
    root.querySelectorAll('[data-reload]').forEach(function (b) { b.onclick = function () { window.location.reload(); }; });
    var logout = root.querySelector('[data-logout]');
    if (logout) logout.onclick = async function () {
      logout.disabled = true;
      try { await api(mode === 'admin' ? '/api/admin/logout' : '/api/seekers/logout', { method:'POST' }); } catch (_) {}
      window.location.href = mode === 'admin' ? '/admin' : '/employer/sign-in';
    };
  }
  function render(mode, account, content, subtitle) { mount(); root.innerHTML = shell(mode, account, content, subtitle); bindShell(); }
  function kpi(label, value, note, ico, tone) { return '<article class="df-kpi '+(tone||'')+'"><div class="df-kpi-icon">'+icon(ico||'chart')+'</div><span>'+esc(label)+'</span><strong>'+esc(value)+'</strong><small>'+esc(note||'Live production metric')+'</small></article>'; }
  function panel(title, body, eyebrow, extra) { return '<section class="df-panel"><div class="df-panel-head"><div><small>'+esc(eyebrow||'LIVE DATA')+'</small><h2>'+esc(title)+'</h2></div>'+(extra||'')+'</div>'+body+'</section>'; }
  function empty(text) { return '<div class="df-empty">'+icon('shield')+'<strong>No fabricated data</strong><span>'+esc(text)+'</span></div>'; }
  function table(headers, body) { return '<div class="df-table-wrap"><table class="df-table"><thead><tr>'+headers.map(function(h){return '<th>'+esc(h)+'</th>';}).join('')+'</tr></thead><tbody>'+body+'</tbody></table></div>'; }
  function actionLink(text, href, kind) { return '<a class="df-btn '+(kind||'')+'" href="'+esc(href)+'">'+esc(text)+'</a>'; }

  function employerJobRows(jobs) {
    return jobs.map(function (j) {
      var st = val(j,['recruitment_status','status'], 'open');
      var applicants = num(j,['total_applications','applications','applicant_count']);
      return '<tr><td><strong>'+esc(val(j,['title','job_title'],'Untitled job'))+'</strong><small>'+esc(val(j,['organization'],'Your company'))+' · '+esc(val(j,['location','country'],'Location not specified'))+'</small></td><td>'+status(st)+'</td><td class="mono">'+fmtNum(applicants)+'</td><td>'+fmtDate(val(j,['employer_posted_at','posted_at','created_at'],''),false)+'</td><td><a class="df-link" href="/jobs/detail/'+encodeURIComponent(val(j,['job_id','id'],''))+'">View</a></td></tr>';
    }).join('');
  }
  function employerOverview(data) {
    var s = data.summary || {}, jobs = data.jobs || [], allowance = data.allowance || {};
    var content = '<div class="df-kpis">'
      +kpi('Active jobs', fmtNum(num(s,['activeJobs','active_jobs'])), 'Currently open roles','jobs')
      +kpi('Applications', fmtNum(num(s,['totalApplications','total_applications'])), 'Across your linked jobs','users')
      +kpi('Pending reviews', fmtNum(num(s,['pendingReviews','pending_reviews'])), 'Payments or requests awaiting review','shield','amber')
      +kpi('Active Boosts', fmtNum(num(s,['activeBoosts','active_boosts'])), 'Premium visibility currently active','star','green')+'</div>';
    var recent = jobs.slice(0,8);
    content += '<div class="df-grid two">'+panel('Recent jobs', recent.length ? table(['Role','Status','Applicants','Published',''], employerJobRows(recent)) : empty('No employer jobs are linked to this account yet.'), 'HIRING PIPELINE', actionLink('Post a job','/post-job?employer=1','primary'));
    content += panel('Monthly allowance', '<div class="df-metric-list"><div><span>Regular used</span><b>'+fmtNum(num(allowance,['regularUsed','regular_used']))+'</b></div><div><span>Featured used</span><b>'+fmtNum(num(allowance,['featuredUsed','featured_used']))+'</b></div><div><span>Regular limit</span><b>'+fmtNum(num(allowance,['regularLimit','regular_limit']))+'</b></div><div><span>Featured limit</span><b>'+fmtNum(num(allowance,['featuredLimit','featured_limit']))+'</b></div></div>', 'ACCOUNT CAPACITY')+'</div>';
    return content;
  }
  function employerJobs(data) {
    var jobs = data.jobs || [];
    return panel('Your jobs', jobs.length ? table(['Role','Status','Applications','Published',''], employerJobRows(jobs)) : empty('No employer jobs are linked to this account.'), 'LIVE VACANCIES', actionLink('Post a job','/post-job?employer=1','primary'));
  }
  async function employerApplications(data) {
    var res = await safe('/api/v51/employer/applications?limit=250'); var items = rows(res);
    if (!items.length) return panel('Candidate pipeline', empty('No applications were returned by the existing recruitment API.'), 'RECRUITMENT');
    var body = items.map(function(a){return '<tr><td><strong>'+esc(val(a,['full_name'],'Candidate'))+'</strong><small>'+esc(val(a,['candidate_email'],'—'))+' · '+esc(val(a,['current_country','nationality'],'Country not provided'))+'</small></td><td><strong>'+esc(val(a,['title'],'Job'))+'</strong><small>'+esc(val(a,['organization'],'—'))+'</small></td><td>'+status(val(a,['status'],'received'))+'</td><td class="mono">'+fmtNum(num(a,['profile_score']))+'</td><td>'+fmtDate(val(a,['applied_at'],''),true)+'</td><td><a class="df-link" href="/api/v51/employer/applications/'+encodeURIComponent(val(a,['id'],''))+'/cv">CV</a></td></tr>';}).join('');
    return panel('Candidate pipeline', table(['Candidate','Job','Stage','Profile score','Applied',''],body), 'LIVE APPLICATIONS');
  }
  async function employerAnalytics(data) {
    var res = await safe('/api/v51/employer/applications?limit=500'); var items = rows(res), stages = {};
    items.forEach(function(a){var s=String(val(a,['status'],'received')).replace(/_/g,' ');stages[s]=(stages[s]||0)+1;});
    var stageEntries = Object.keys(stages).sort(function(a,b){return stages[b]-stages[a];});
    var total = items.length, jobs = data.jobs || [];
    var content = '<div class="df-kpis">'+kpi('Applications',fmtNum(total),'Live recruitment records','users')+kpi('Jobs tracked',fmtNum(jobs.length),'Employer-linked vacancies','jobs')+kpi('Hires',fmtNum(stages.hired||0),'Candidates marked hired','shield','green')+kpi('Interviews',fmtNum(stages.interview||0),'Candidates at interview stage','chart','amber')+'</div>';
    var bars = stageEntries.length ? '<div class="df-bars">'+stageEntries.map(function(k){var pc=total?Math.max(4,Math.round(stages[k]/total*100)):0;return '<div><div><span>'+esc(humanKey(k))+'</span><b>'+fmtNum(stages[k])+'</b></div><i><em style="width:'+pc+'%"></em></i></div>';}).join('')+'</div>' : empty('Analytics will appear when recruitment applications exist.');
    return content+panel('Recruitment funnel',bars,'LIVE STAGES');
  }
  function employerPlans(data) {
    var plans=data.plans||[], a=data.allowance||{};
    var capacity='<div class="df-kpis">'+kpi('Regular allowance',fmtNum(num(a,['regularLimit','regular_limit'])),'Monthly regular listing limit','jobs')+kpi('Featured allowance',fmtNum(num(a,['featuredLimit','featured_limit'])),'Monthly featured listing limit','star')+kpi('Boost allowance',fmtNum(num(a,['boostLimit','boost_limit'])),'Monthly plan Boost allowance','chart')+kpi('Active plans',fmtNum(num(data.summary||{},['activePlans','active_plans'])),'Currently valid plan codes','shield','green')+'</div>';
    if(!plans.length) return capacity+panel('Employer plans',empty('No active or historical employer plan records were returned.'),'COMMERCIAL ACCOUNT');
    var body=plans.map(function(p){return '<tr><td><strong>'+esc(val(p,['plan_label'],'Employer plan'))+'</strong><small>'+esc(val(p,['code_prefix'],'Plan'))+'••••'+esc(val(p,['code_last4'],''))+'</small></td><td>'+status(val(p,['status'],'unknown'))+'</td><td>'+fmtDate(val(p,['starts_at'],''),false)+'</td><td>'+fmtDate(val(p,['expires_at'],''),false)+'</td><td class="mono">'+fmtMoney(val(p,['paid_amount'],null),val(p,['currency'],'USD'))+'</td></tr>';}).join('');
    return capacity+panel('Employer plans',table(['Plan','Status','Starts','Expires','Paid'],body),'LIVE PLAN RECORDS');
  }
  function employerBilling(data) {
    var payments=data.payments||[];
    if(!payments.length) return panel('Billing & payments',empty('No payment or commercial review records were returned for this employer account.'),'PRIVATE PAYMENT HISTORY');
    var body=payments.map(function(p){return '<tr><td><strong>'+esc(val(p,['organization'],'Employer request'))+'</strong><small>#'+esc(val(p,['id'],'—'))+' · '+esc(humanKey(val(p,['request_type'],'payment')))+'</small></td><td>'+status(val(p,['status'],'pending'))+'</td><td class="mono">'+fmtMoney(val(p,['amount'],null),val(p,['currency'],'USD'))+'</td><td>'+esc(val(p,['payment_method'],'—'))+'</td><td>'+fmtDate(val(p,['created_at'],''),true)+'</td></tr>';}).join('');
    return panel('Billing & payments',table(['Reference','Status','Amount','Method','Created'],body),'LIVE COMMERCIAL RECORDS');
  }
  function employerBoosts(data) {
    var jobs=data.jobs||[], now=Date.now();
    var active=jobs.filter(function(j){var e=new Date(val(j,['boost_ends_at'],'')).getTime();return e && e>now;});
    var requests=(data.payments||[]).filter(function(p){return String(val(p,['request_type'],'')).toLowerCase().indexOf('boost')>=0;});
    var content='<div class="df-kpis">'+kpi('Active Boosts',fmtNum(active.length),'Currently active premium visibility','star','green')+kpi('Boost requests',fmtNum(requests.length),'Historical and pending requests','shield')+kpi('Boosted applications',fmtNum(active.reduce(function(n,j){return n+(num(j,['total_applications'])||0);},0)),'Applications on actively boosted jobs','users')+kpi('Jobs available',fmtNum(jobs.length-active.length),'Jobs not currently Boosted','jobs')+'</div>';
    var list=active.length?active.map(function(j){return '<div class="df-record"><div><strong>'+esc(val(j,['title'],'Job'))+'</strong><span>'+esc(val(j,['location'],'—'))+'</span></div><div>'+status('Active')+'<small>Ends '+fmtDate(val(j,['boost_ends_at'],''),true)+'</small></div></div>';}).join(''):empty('No active Premium Boost is attached to this account right now.');
    return content+panel('Premium Boost inventory',list,'VERIFIED VISIBILITY',actionLink('Open Post a Job','/post-job?employer=1','primary'));
  }
  function employerProfile(data) {
    var p=data.profile||{}, a=data.account||{};
    return '<form class="df-panel df-form" id="df-profile-form"><div class="df-panel-head"><div><small>VERIFIED EMPLOYER IDENTITY</small><h2>Company profile</h2></div><button class="df-btn primary" type="submit">Save profile</button></div><div class="df-form-grid">'
      +field('Company name','companyName',val(p,['company_name'],''),true)+field('Contact name','contactName',val(p,['contact_name'],''))+field('Company website','companyWebsite',val(p,['company_website'],''))+field('Industry','industry',val(p,['industry'],''))+field('Company size','companySize',val(p,['company_size'],''))+field('Phone','phone',val(p,['phone'],''))+field('Country','country',val(p,['country'],''))+field('City','city',val(p,['city'],''))+field('Address line 1','addressLine1',val(p,['address_line1'],''))+field('Address line 2','addressLine2',val(p,['address_line2'],''))+field('State / region','stateRegion',val(p,['state_region'],''))+field('Postal code','postalCode',val(p,['postal_code'],''))
      +'<label class="full"><span>Verified account email</span><input value="'+esc(val(a,['email'],''))+'" disabled></label></div><div class="df-form-status" id="df-profile-status"></div></form>';
  }
  function field(label,name,value,required){return '<label><span>'+esc(label)+'</span><input name="'+esc(name)+'" value="'+esc(value)+'" '+(required?'required':'')+'></label>';}
  function employerSettings(data) {
    var p=data.profile||{}, a=data.account||{};
    return '<div class="df-grid two">'+panel('Account security','<div class="df-record"><div><strong>'+esc(val(a,['email'],'Employer account'))+'</strong><span>Authenticated through the existing production session.</span></div>'+status(val(p,['profile_status'],'active'))+'</div>','PRIVATE ACCOUNT')+panel('Support & privacy','<div class="df-metric-list"><a href="/contact"><span>Contact support</span><b>Open</b></a><a href="/privacy"><span>Privacy policy</span><b>Review</b></a><a href="/terms"><span>Employer terms</span><b>Review</b></a></div>','ACCOUNT CONTROL')+'</div>';
  }
  function bindEmployerProfile(data) {
    var form=root.querySelector('#df-profile-form'); if(!form)return;
    form.onsubmit=async function(e){e.preventDefault();var btn=form.querySelector('button[type=submit]'),msg=form.querySelector('#df-profile-status');btn.disabled=true;msg.textContent='Saving securely…';var obj={};new FormData(form).forEach(function(v,k){obj[k]=String(v).trim();});try{await api('/api/v46/employer/profile',{method:'PUT',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(obj)});msg.textContent='Company profile saved.';msg.className='df-form-status good';}catch(err){msg.textContent=err.message||'Profile could not be saved.';msg.className='df-form-status bad';}finally{btn.disabled=false;}};
  }
  async function initEmployer() {
    loading('Loading employer workspace…');
    var data;
    try { data=await api('/api/v46/employer/overview'); }
    catch(e){ if(e.status===401||e.status===403){window.location.href='/employer/sign-in?redirect='+encodeURIComponent(window.location.pathname+window.location.search);return;} errorScreen('Employer workspace unavailable',e.message,'Retry securely');return; }
    var section=path.split('/').pop(); var content, subtitle='Live employer data from your protected hiring account.';
    if(path==='/employer'||path==='/employer/dashboard') content=employerOverview(data);
    else if(section==='jobs') content=employerJobs(data);
    else if(section==='applications') content=await employerApplications(data);
    else if(section==='analytics') content=await employerAnalytics(data);
    else if(section==='plans') content=employerPlans(data);
    else if(section==='billing') content=employerBilling(data);
    else if(section==='boosts') content=employerBoosts(data);
    else if(section==='profile') content=employerProfile(data);
    else content=employerSettings(data);
    render('employer',{profile:data.profile||{},email:val(data.account||{},['email'],'')},content,subtitle);
    if(section==='profile') bindEmployerProfile(data);
  }

  function adminMerged(parts){var out={};parts.forEach(function(p){if(p&&typeof p==='object'&&!Array.isArray(p))Object.assign(out,p);});return out;}
  async function adminOverview(account) {
    var parts=await Promise.all([safe('/api/admin/stats'),safe('/api/v45/admin/summary'),safe('/api/v51/admin/summary'),safe('/api/admin/revenue-metrics'),safe('/api/admin/sources'),safe('/api/admin/growth/overview')]);
    var s=adminMerged([parts[0],parts[1],parts[2],parts[5]]), revenue=parts[3]||{}, sources=rows(parts[4]);
    var totalJobs=num(s,['total','totalJobs','total_jobs']), employers=num(s,['employers','totalEmployers','total_employers']), apps=num(s,['total_applications','totalApplications','applications']), pending=num(s,['pending_requests','pendingRequests','pending_reviews']);
    var content='<div class="df-kpis">'+kpi('Marketplace jobs',fmtNum(totalJobs),'Total live database inventory','jobs')+kpi('Employers',fmtNum(employers),'Registered employer records','building')+kpi('Applications',fmtNum(apps),'Recruitment applications','users')+kpi('Pending review',fmtNum(pending),'Commercial requests awaiting action','shield','amber')+'</div>';
    var revMonth=revenue&&revenue.revenue?revenue.revenue.month:null;
    content+='<div class="df-grid two">'+panel('Marketplace pulse','<div class="df-metric-list"><div><span>Jobs added today</span><b>'+fmtNum(num(s,['today']))+'</b></div><div><span>Featured jobs</span><b>'+fmtNum(num(s,['featured']))+'</b></div><div><span>Applications today</span><b>'+fmtNum(num(s,['applications_today']))+'</b></div><div><span>Verified revenue this month</span><b>'+fmtMoney(revMonth,'USD')+'</b></div><div><span>Active subscribers</span><b>'+fmtNum(num(s,['active_subscribers','subscribers']))+'</b></div><div><span>Sign-ins today</span><b>'+fmtNum(num(s,['signins_today','signinsToday']))+'</b></div></div>','LIVE PLATFORM SIGNALS')+panel('Job sources',sources.length?'<div class="df-bars">'+sources.slice(0,10).map(function(r){var c=num(r,['count','value'])||0;return '<div><div><span>'+esc(val(r,['source','label','category'],'Unknown source'))+'</span><b>'+fmtNum(c)+'</b></div><i><em style="width:'+Math.min(100,Math.max(4,c/(Math.max.apply(null,sources.map(function(x){return num(x,['count','value'])||0;}))||1)*100))+'%"></em></i></div>';}).join('')+'</div>':empty('No source analytics returned.'),'DISTRIBUTION')+'</div>';
    return content;
  }
  async function adminList(kind) {
    var conf={
      jobs:['/api/admin/jobs?page=1&limit=100','Marketplace jobs',['Role','Organisation','Location','Source','Published',''],function(x){return '<tr><td><strong>'+esc(val(x,['title'],'Untitled job'))+'</strong><small>#'+esc(val(x,['id'],'—'))+'</small></td><td>'+esc(val(x,['organization'],'—'))+'</td><td>'+esc(val(x,['location','country'],'—'))+'</td><td>'+esc(val(x,['source'],'—'))+'</td><td>'+fmtDate(val(x,['postedAt','posted_at','createdAt','created_at'],''),false)+'</td><td><a class="df-link" href="/jobs/detail/'+encodeURIComponent(val(x,['id'],''))+'">View</a></td></tr>'; }],
      employers:['/api/v46/admin/employers?limit=300','Employer accounts',['Employer','Email','Country','Jobs','Status'],function(x){return '<tr><td><strong>'+esc(val(x,['companyName','company_name'],'Employer'))+'</strong><small>'+esc(val(x,['contactName','contact_name'],'—'))+'</small></td><td>'+esc(val(x,['email'],'—'))+'</td><td>'+esc(val(x,['country'],'—'))+'</td><td class="mono">'+fmtNum((num(x,['regular_post_count'])||0)+(num(x,['featured_post_count'])||0))+'</td><td>'+status(x.active===false?'Inactive':val(x,['profile_status','status'],'Active'))+'</td></tr>'; }],
      seekers:['/api/admin/growth/job-seekers?page=1&limit=100','Job seeker network',['Seeker','Email','Country','Job title','Subscribed','Joined'],function(x){return '<tr><td><strong>'+esc(val(x,['full_name','name'],'Seeker'))+'</strong></td><td>'+esc(val(x,['email'],'—'))+'</td><td>'+esc(val(x,['country'],'—'))+'</td><td>'+esc(val(x,['job_title'],'—'))+'</td><td>'+status(x.subscribed?'Subscribed':'Not subscribed')+'</td><td>'+fmtDate(val(x,['created_at'],''),false)+'</td></tr>'; }],
      applications:['/api/v51/admin/applications?limit=200','Applications',['Candidate','Job','Employer','Status','Profile','Applied'],function(x){return '<tr><td><strong>'+esc(val(x,['full_name'],'Candidate'))+'</strong><small>'+esc(val(x,['candidate_email'],'—'))+'</small></td><td>'+esc(val(x,['title'],'—'))+'</td><td>'+esc(val(x,['employer_company','organization'],'—'))+'</td><td>'+status(val(x,['status'],'received'))+'</td><td class="mono">'+fmtNum(num(x,['profile_score']))+'</td><td>'+fmtDate(val(x,['applied_at'],''),true)+'</td></tr>'; }]
    }[kind];
    var data=await safe(conf[0]), list=rows(data);
    return panel(conf[1],list.length?table(conf[2],list.map(conf[3]).join('')):empty('No records were returned by this protected endpoint.'),'LIVE RECORDS');
  }
  async function adminRequests() {
    var data=await safe('/api/v45/admin/requests?limit=100'), list=rows(data);
    if(!list.length)return panel('Review queue',empty('No payment or commercial requests are waiting in the current result set.'),'MODERATION');
    var body=list.map(function(x){var st=val(x,['status'],'pending'),id=val(x,['id'],'');return '<tr><td><strong>'+esc(val(x,['live_job_title','organization'],'Commercial request'))+'</strong><small>#'+esc(id)+' · '+esc(humanKey(val(x,['request_type'],'request')))+'</small></td><td>'+esc(val(x,['employer_email','organization'],'—'))+'</td><td class="mono">'+fmtMoney(val(x,['amount'],null),val(x,['currency'],'USD'))+'</td><td>'+status(st)+'</td><td>'+fmtDate(val(x,['created_at'],''),true)+'</td><td>'+(String(st).toLowerCase()==='pending'?'<div class="df-actions"><button class="df-link good" data-approve="'+esc(id)+'">Approve</button><button class="df-link bad" data-reject="'+esc(id)+'">Reject</button></div>':'—')+'</td></tr>';}).join('');
    return panel('Review queue',table(['Request','Employer','Amount','Status','Received','Action'],body),'COMMERCIAL MODERATION');
  }
  async function adminBoosts() {
    var data=await safe('/api/v45/admin/boosts'),list=rows(data);
    var content='<div class="df-kpis">'+kpi('Active Boosts',fmtNum(list.filter(function(x){return String(val(x,['status'],'')).toLowerCase()==='active';}).length),'Premium placements currently active','star','green')+kpi('Boost records',fmtNum(list.length),'Total returned commercial records','shield')+'</div>';
    if(!list.length)return content+panel('Premium & Boosts',empty('No Boost records were returned.'),'COMMERCIAL VISIBILITY');
    var body=list.map(function(x){var st=val(x,['status'],'unknown'),id=val(x,['id'],'');return '<tr><td><strong>'+esc(val(x,['title'],'Job'))+'</strong><small>'+esc(val(x,['organization'],'—'))+'</small></td><td>'+status(st)+'</td><td>'+fmtDate(val(x,['starts_at'],''),true)+'</td><td>'+fmtDate(val(x,['ends_at'],''),true)+'</td><td>'+(String(st).toLowerCase()==='active'?'<button class="df-link bad" data-end-boost="'+esc(id)+'">End Boost</button>':'—')+'</td></tr>';}).join('');
    return content+panel('Premium & Boosts',table(['Job','Status','Starts','Ends','Action'],body),'LIVE BOOST INVENTORY');
  }
  async function adminRevenue() {
    var data=await safe('/api/admin/revenue-metrics'); if(!data)return panel('Revenue operations',empty('Revenue metrics endpoint is currently unavailable.'),'VERIFIED COMMERCIAL METRICS');
    var r=data.revenue||{}, reg=data.regular||{}, feat=data.featured||{}, proj=data.projections||{};
    var content='<div class="df-kpis">'+kpi('Revenue today',fmtMoney(r.today,'USD'),'Calculated from employer postings','dollar','green')+kpi('Revenue month',fmtMoney(r.month,'USD'),'Current 30-day window','dollar')+kpi('Revenue year',fmtMoney(r.year,'USD'),'Current 365-day window','chart')+kpi('Projected month',fmtMoney(proj.monthly,'USD'),'Projection from current posting rate','chart','amber')+'</div>';
    content+= '<div class="df-grid two">'+panel('Regular listings','<div class="df-metric-list"><div><span>Today</span><b>'+fmtNum(reg.today)+'</b></div><div><span>Week</span><b>'+fmtNum(reg.week)+'</b></div><div><span>Month</span><b>'+fmtNum(reg.month)+'</b></div><div><span>Total</span><b>'+fmtNum(reg.total)+'</b></div></div>','EMPLOYER POSTINGS')+panel('Featured listings','<div class="df-metric-list"><div><span>Today</span><b>'+fmtNum(feat.today)+'</b></div><div><span>Week</span><b>'+fmtNum(feat.week)+'</b></div><div><span>Month</span><b>'+fmtNum(feat.month)+'</b></div><div><span>Total</span><b>'+fmtNum(feat.total)+'</b></div></div>','PREMIUM INVENTORY')+'</div>';
    return content;
  }
  async function adminNewsletter() {
    var subs=await safe('/api/admin/growth/subscribers'),campaigns=await safe('/api/admin/growth/campaigns'),list=rows(subs),camps=rows(campaigns);
    var active=list.filter(function(x){return x.active!==false;}).length;
    var content='<div class="df-kpis">'+kpi('Subscribers',fmtNum(list.length),'Marketing contacts returned','mail')+kpi('Active',fmtNum(active),'Currently subscribed contacts','shield','green')+kpi('Campaigns',fmtNum(camps.length),'Recent campaign records','chart')+kpi('Employers',fmtNum(list.filter(function(x){return val(x,['audience'],'')==='employer';}).length),'Employer audience contacts','building')+'</div>';
    var body=list.slice(0,100).map(function(x){return '<tr><td><strong>'+esc(val(x,['name'],'Subscriber'))+'</strong><small>'+esc(val(x,['email'],'—'))+'</small></td><td>'+esc(humanKey(val(x,['audience'],'job_seeker')))+'</td><td>'+esc(val(x,['country'],'—'))+'</td><td>'+status(x.active===false?'Unsubscribed':'Active')+'</td><td>'+fmtDate(val(x,['subscribed_at'],''),false)+'</td></tr>';}).join('');
    return content+panel('Newsletter contacts',body?table(['Contact','Audience','Country','Status','Subscribed'],body):empty('No newsletter contacts were returned.'),'LIVE AUDIENCE');
  }
  async function adminGrowth() {
    var o=await safe('/api/admin/growth/overview'),s=await safe('/api/admin/growth/subscribers'),list=rows(s),x=o||{};
    var content='<div class="df-kpis">'+kpi('Job seekers',fmtNum(num(x,['seekers_total','job_seekers','seekers'])),'Registered seeker accounts','users')+kpi('Employers',fmtNum(num(x,['employers_total','employers'])),'Employer CRM records','building')+kpi('Subscribers',fmtNum(num(x,['active_subscribers','subscribers'])),'Active marketing contacts','mail','green')+kpi('Sign-ins today',fmtNum(num(x,['signins_today'])),'Authentication activity today','chart')+'</div>';
    var countries={};list.forEach(function(r){var c=String(val(r,['country'],'Unknown'));countries[c]=(countries[c]||0)+1;});var entries=Object.keys(countries).sort(function(a,b){return countries[b]-countries[a];}).slice(0,12),max=entries.length?countries[entries[0]]:1;
    return content+panel('Audience geography',entries.length?'<div class="df-bars">'+entries.map(function(c){return '<div><div><span>'+esc(c)+'</span><b>'+fmtNum(countries[c])+'</b></div><i><em style="width:'+Math.max(4,countries[c]/max*100)+'%"></em></i></div>';}).join('')+'</div>':empty('No subscriber geography is available yet.'),'GROWTH INTELLIGENCE');
  }
  async function adminReports() {
    return '<div class="df-grid three">'+reportCard('Recruitment applications','Download the protected recruitment pipeline CSV.','/api/v51/admin/recruitment.csv')+reportCard('Revenue metrics','Open the live protected revenue metrics JSON.','/api/admin/revenue-metrics')+reportCard('Marketplace jobs','Review the current marketplace job inventory.','/admin/jobs')+reportCard('Employer accounts','Review employer account and commercial signals.','/admin/employers')+reportCard('Newsletter audience','Review current marketing contacts and campaigns.','/admin/newsletter')+reportCard('Growth intelligence','Open live audience and account growth signals.','/admin/growth')+'</div>';
  }
  function reportCard(title,detail,href){return '<section class="df-panel df-report"><div class="df-kpi-icon">'+icon('chart')+'</div><h2>'+esc(title)+'</h2><p>'+esc(detail)+'</p><a class="df-btn" href="'+esc(href)+'">Open report</a></section>';}
  async function adminSettings(account) {
    var codes=await safe('/api/v45/admin/codes'),list=rows(codes);
    return '<div class="df-grid two">'+panel('Administrator session','<div class="df-record"><div><strong>'+esc(val(account,['username'],'Administrator'))+'</strong><span>Authenticated using the existing restricted Express session.</span></div>'+status('Verified')+'</div>','SECURITY')+panel('Commercial plan codes','<div class="df-metric-list"><div><span>Codes returned</span><b>'+fmtNum(list.length)+'</b></div><div><span>Active codes</span><b>'+fmtNum(list.filter(function(x){return String(val(x,['status'],'')).toLowerCase()==='active';}).length)+'</b></div><a href="/admin/revenue"><span>Revenue operations</span><b>Open</b></a><a href="/admin/reports"><span>Reports</span><b>Open</b></a></div>','ADMIN CONTROL')+'</div>';
  }
  function bindAdminActions() {
    root.querySelectorAll('[data-approve]').forEach(function(b){b.onclick=async function(){var id=b.getAttribute('data-approve');b.disabled=true;try{await api('/api/v45/admin/requests/'+encodeURIComponent(id)+'/publish',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:'{}'});window.location.reload();}catch(e){alert(e.message||'Request could not be approved.');b.disabled=false;}};});
    root.querySelectorAll('[data-reject]').forEach(function(b){b.onclick=async function(){var id=b.getAttribute('data-reject'),note=prompt('Reason for rejection:','Rejected by administrator.');if(note===null)return;b.disabled=true;try{await api('/api/v45/admin/requests/'+encodeURIComponent(id)+'/reject',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({note:note})});window.location.reload();}catch(e){alert(e.message||'Request could not be rejected.');b.disabled=false;}};});
    root.querySelectorAll('[data-end-boost]').forEach(function(b){b.onclick=async function(){if(!confirm('End this active Boost now?'))return;var id=b.getAttribute('data-end-boost');b.disabled=true;try{await api('/api/v45/admin/boosts/'+encodeURIComponent(id)+'/end',{method:'POST'});window.location.reload();}catch(e){alert(e.message||'Boost could not be ended.');b.disabled=false;}};});
  }
  async function initAdmin() {
    var account;
    try { account=await api('/api/admin/me'); }
    catch(e){ if(e.status===401||e.status===403){unmount();clearTimeout(adminRetryTimer);adminRetryTimer=setTimeout(initAdmin,5000);return;} errorScreen('Admin session unavailable',e.message,'Retry securely');return; }
    loading('Loading marketplace operations…');
    var section=path.split('/').pop(), content;
    if(path==='/admin'||path==='/admin/dashboard') content=await adminOverview(account);
    else if(section==='jobs') content=await adminList('jobs');
    else if(section==='employers') content=await adminList('employers');
    else if(section==='seekers') content=await adminList('seekers');
    else if(section==='applications') content=await adminList('applications');
    else if(section==='review'||section==='requests') content=await adminRequests();
    else if(section==='premium') content=await adminBoosts();
    else if(section==='revenue') content=await adminRevenue();
    else if(section==='reports') content=await adminReports();
    else if(section==='newsletter') content=await adminNewsletter();
    else if(section==='growth') content=await adminGrowth();
    else content=await adminSettings(account);
    render('admin',account,content,'Restricted marketplace operations powered only by existing protected production APIs.');
    bindAdminActions();
  }

  if (mode === 'employer') initEmployer(); else initAdmin();
})();


/* Dev Global Jobs V70.3 STEP 1 — Employer Overview + shell only.
   Runtime-last style injection defeats the older V65 inline layout style safely.
   No backend/API/auth/payment/public-page changes. */
(function(){
  'use strict';
  var path=window.location.pathname.replace(/\/+$/,'')||'/';
  if(path!=='/employer') return;
  var STYLE_ID='dgj-v703-step1-employer-overview';
  var TABS=new Set(['overview','jobs','applications','analytics','boosts','billing','plans','profile']);
  function installStyle(){
    if(document.getElementById(STYLE_ID)) return;
    var st=document.createElement('style');st.id=STYLE_ID;st.textContent='#dgj46-employer-root{--dgj703-side:292px}\n@media(min-width:1100px){\n#dgj46-employer-root .dgj46-side{width:var(--dgj703-side)!important;min-width:var(--dgj703-side)!important;padding:18px 14px 18px!important}\n#dgj46-employer-root .dgj46-main{margin-left:var(--dgj703-side)!important;width:calc(100% - var(--dgj703-side))!important;max-width:none!important}\n}\n#dgj46-employer-root .dgj46-side-brand{padding:6px 7px 18px!important;margin:0 0 14px!important;gap:12px!important}\n#dgj46-employer-root .dgj46-side-brand img{width:48px!important;height:48px!important;flex:0 0 48px!important}\n#dgj46-employer-root .dgj46-side-brand b{font-size:17px!important;line-height:1.2!important}\n#dgj46-employer-root .dgj46-side-company{position:relative!important;box-sizing:border-box!important;min-height:76px!important;margin:0 5px 16px!important;padding:13px 12px 13px 60px!important;overflow:hidden!important;border-radius:14px!important}\n#dgj46-employer-root .dgj46-side-company .dgj49-company-avatar{position:absolute!important;left:12px!important;top:50%!important;transform:translateY(-50%)!important;width:38px!important;height:38px!important;border-radius:10px!important}\n#dgj46-employer-root .dgj46-side-company>span,#dgj46-employer-root .dgj46-side-company>b,#dgj46-employer-root .dgj46-side-company>small{position:static!important;display:block!important;width:100%!important;max-width:100%!important;min-width:0!important}\n#dgj46-employer-root .dgj46-side-company>span{margin:0 0 4px!important;font-size:8px!important;line-height:1.2!important}\n#dgj46-employer-root .dgj46-side-company>b{margin:0!important;font-size:13px!important;line-height:1.28!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}\n#dgj46-employer-root .dgj46-side-company>small{margin:4px 0 0!important;font-size:10px!important;line-height:1.25!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}\n#dgj46-employer-root .dgj46-side nav{gap:3px!important;margin-top:0!important;padding:0 0 8px!important}\n#dgj46-employer-root .dgj46-side nav a,#dgj46-employer-root .dgj46-side nav button{min-height:42px!important;padding:0 12px!important;border-radius:10px!important;font-size:12px!important;line-height:1.2!important;transform:none!important;transition:background-color .14s ease,color .14s ease,box-shadow .14s ease!important}\n#dgj46-employer-root .dgj46-top{min-height:76px!important;padding:12px 28px!important;gap:16px!important}\n#dgj46-employer-root .dgj46-top h1{font-size:23px!important}\n#dgj46-employer-root .dgj46-top-actions .dgj46-primary{min-height:42px!important;padding:0 15px!important;white-space:nowrap!important}\n#dgj46-employer-root .dgj46-content{width:100%!important;max-width:1380px!important;margin:0 auto!important;padding:26px 28px 52px!important}\n#dgj46-employer-root .dgj46-hero{align-items:center!important;padding:28px 30px!important;gap:24px!important;border-radius:20px!important}\n#dgj46-employer-root .dgj46-hero h2{font-size:28px!important;line-height:1.18!important;margin:6px 0 7px!important}\n#dgj46-employer-root .dgj46-hero p{font-size:11.5px!important;line-height:1.55!important}\n#dgj46-employer-root .dgj46-trust{max-width:360px!important;white-space:normal!important;line-height:1.45!important;padding:11px 13px!important}\n#dgj46-employer-root .dgj46-cards{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:12px!important;margin:16px 0!important;align-items:stretch!important}\n#dgj46-employer-root .dgj46-cards>div{min-height:96px!important;padding:16px 17px!important;display:flex!important;flex-direction:column!important;justify-content:space-between!important}\n#dgj46-employer-root .dgj46-cards b{font-size:26px!important;margin-top:7px!important}\n#dgj46-employer-root .dgj46-grid2{grid-template-columns:minmax(0,1.2fr) minmax(300px,.8fr)!important;gap:14px!important;margin-bottom:14px!important;align-items:start!important}\n#dgj46-employer-root .dgj46-grid2>.dgj46-panel{align-self:start!important;height:auto!important;min-height:0!important}\n#dgj46-employer-root .dgj46-panel{padding:18px!important;height:auto!important;min-height:0!important}\n#dgj46-employer-root .dgj46-panel-head{margin-bottom:13px!important;gap:12px!important}\n#dgj46-employer-root .dgj46-panel-head h3{font-size:16px!important;line-height:1.25!important}\n#dgj46-employer-root .dgj46-panel-head small{max-width:380px!important;line-height:1.4!important;text-align:right!important}\n#dgj46-employer-root .dgj46-performance.big{width:100%!important;max-width:none!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:9px!important}\n#dgj46-employer-root .dgj46-performance.big .dgj46-metric{min-height:108px!important;padding:14px 12px!important;justify-content:center!important}\n#dgj46-employer-root .dgj46-performance.big .dgj46-metric b{font-size:25px!important}\n#dgj46-employer-root .dgj46-allow{gap:9px!important}\n#dgj46-employer-root .dgj46-allow>div{padding:13px!important;min-height:88px!important}\n#dgj46-employer-root .dgj46-allow b{font-size:24px!important}\n#dgj46-employer-root .dgj46-grid2 .dgj46-primary.block{display:inline-flex!important;width:auto!important;min-width:118px!important;max-width:180px!important;height:40px!important;min-height:40px!important;max-height:40px!important;flex:0 0 40px!important;margin:13px 0 0!important;padding:0 15px!important;align-self:flex-start!important}\nhtml.dgj70-employer-switching #dgj46-employer-root .dgj46-main{opacity:1!important;visibility:visible!important}\nhtml.dgj70-employer-switching #dgj46-employer-root .dgj46-content{opacity:.985!important;transition:opacity .08s linear!important}\n@media(max-width:1240px) and (min-width:1100px){#dgj46-employer-root{--dgj703-side:270px}#dgj46-employer-root .dgj46-content{padding-left:22px!important;padding-right:22px!important}}\n@media(max-width:1099px){#dgj46-employer-root .dgj46-grid2{grid-template-columns:1fr!important}}\n@media(max-width:760px){#dgj46-employer-root .dgj46-content{padding:14px 12px 36px!important}#dgj46-employer-root .dgj46-hero{display:block!important;padding:20px!important;border-radius:16px!important}#dgj46-employer-root .dgj46-hero h2{font-size:22px!important}#dgj46-employer-root .dgj46-trust{display:inline-block!important;margin-top:14px!important;max-width:100%!important}#dgj46-employer-root .dgj46-cards{grid-template-columns:repeat(2,minmax(0,1fr))!important}#dgj46-employer-root .dgj46-performance.big{grid-template-columns:repeat(2,minmax(0,1fr))!important}}';document.head.appendChild(st);
  }
  function hrefFor(tab){return tab==='post'?'/post-job?employer=1':'/employer?tab='+encodeURIComponent(TABS.has(tab)?tab:'overview')}
  function sanitize(){
    installStyle();
    var root=document.getElementById('dgj46-employer-root');if(!root)return;
    root.querySelectorAll('[data-dgj46-nav]').forEach(function(el){
      var tab=el.getAttribute('data-dgj46-nav')||'overview';el.setAttribute('data-dgj703-tab',tab);el.removeAttribute('data-dgj46-nav');
      if(el.tagName==='A')el.setAttribute('href',hrefFor(tab));
    });
  }
  function switchTab(tab){
    var state={dgjEmployerTab:tab,dgj703:true};
    document.documentElement.classList.add('dgj70-employer-switching');
    try{history.pushState(state,'',hrefFor(tab));var evt;try{evt=new PopStateEvent('popstate',{state:state})}catch(_){evt=document.createEvent('Event');evt.initEvent('popstate',true,true)}window.dispatchEvent(evt);requestAnimationFrame(function(){sanitize();window.scrollTo(0,0);requestAnimationFrame(function(){document.documentElement.classList.remove('dgj70-employer-switching')})});}catch(_){document.documentElement.classList.remove('dgj70-employer-switching')}
  }
  document.addEventListener('click',function(e){
    if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
    var el=e.target&&e.target.closest?e.target.closest('#dgj46-employer-root [data-dgj703-tab]'):null;if(!el)return;
    var tab=el.getAttribute('data-dgj703-tab')||'overview';
    if(tab==='post')return; /* distinct Post-a-Job route remains native */
    e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();switchTab(tab);
  },true);
  var mo=new MutationObserver(sanitize);mo.observe(document.documentElement,{childList:true,subtree:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sanitize,{once:true});else sanitize();
  window.addEventListener('pageshow',function(){document.documentElement.classList.remove('dgj70-employer-switching');sanitize()});
})();

})();
