# Changed Files Report

## Runtime files changed

| File | Before SHA-256 | After SHA-256 |
|---|---|---|
| `dist/index.cjs` | `2ca247c9c12e49922fba567a05cdc7cdd72799aab2d5fbb645b589986a958186` | `25f74a4e2c8f87a7ac1146868415e7e5c1fe41dc9f3f19fdf8876a6b1c88d5aa` |

**This is the only runtime file changed.** No other file was opened for writing this session.

## Exact nature of the change (190-line diff, 2 locations)

1. **Insertion only, 181 lines, 0 deletions** — a new conditional branch added at the top of `renderSeekerAuthPage()`'s return logic: `if (options.layout === "split") { return ...new split-screen template... }`, followed immediately by the **original template, copied verbatim**, as the fallback when the flag is absent.

2. **4-line change inside `/sign-in`'s route registration** (not inside the render function itself):
   - `heading` string changed: "Welcome to Dev Global Jobs" -> "Build your career globally."
   - `subheading` string changed: "International Careers - 190+ Countries" -> "Find international jobs, track applications and save opportunities from one Job Seeker account."
   - one new line added: `layout: "split",`

Every other line in the 6,900+ line file is unchanged. Confirmed by:
- Full-file diff shows exactly these 2 locations.
- Every unrelated route handler appearing after the change (`/api/seekers/login`, `/api/seekers/google-auth`, etc.) shifted by the exact same constant +182 line offset -- proof nothing else was inserted or removed anywhere else in the file.

## Files confirmed untouched (never opened for writing)

- `dgj-claude-employer-v3.1.js` -- `cad0720626baf48f36b65e328bf1bde551c35faf2d43cb558c037543ac8296e7`
- `dgj-claude-employer-v2.css` -- `cf32941f8fdf81394b2df8141f2e781ef470dda529627045467d288a4205cf95`
- `/employer/sign-in`'s route registration -- diffed directly against the original, 100% byte-identical, zero changes.
- `/api/seekers/login` handler body -- diffed directly, byte-identical.
- `/api/seekers/google-auth` handler body -- diffed directly, byte-identical.
- All other `/api/seekers/*` route handlers (register, password-reset/request, password-reset/confirm, resend-verification, cancel-verification), session logic, redirect logic.
- Database/schema, .env, nginx, PM2 configuration, Admin console, commercial (V45) backend, recruitment backend -- not referenced anywhere in the diff; this session made no attempt to open any of these files.
