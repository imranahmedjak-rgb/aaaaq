"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc2) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc2 = __getOwnPropDesc(from, key)) || desc2.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/index.ts
var index_exports = {};
__export(index_exports, {
  log: () => log
});
module.exports = __toCommonJS(index_exports);
var import_config = require("dotenv/config");
var import_express2 = __toESM(require("express"), 1);
var import_express_session = __toESM(require("express-session"), 1);
var import_connect_pg_simple = __toESM(require("connect-pg-simple"), 1);
var import_pg2 = __toESM(require("pg"), 1);

// server/routes.ts
var import_crypto2 = __toESM(require("crypto"), 1);

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  blogPosts: () => blogPosts,
  insertJobSchema: () => insertJobSchema,
  insertSubscriberSchema: () => insertSubscriberSchema,
  insertUserSchema: () => insertUserSchema,
  jobSeekerAccounts: () => jobSeekerAccounts,
  jobSeekerProfiles: () => jobSeekerProfiles,
  jobs: () => jobs,
  newsletterSubscribers: () => newsletterSubscribers,
  pendingJobs: () => pendingJobs,
  postJobSchema: () => postJobSchema,
  subscribeSchema: () => subscribeSchema,
  users: () => users
});
var import_drizzle_orm = require("drizzle-orm");
var import_pg_core = require("drizzle-orm/pg-core");
var import_drizzle_zod = require("drizzle-zod");
var import_zod = require("zod");
var users = (0, import_pg_core.pgTable)("users", {
  id: (0, import_pg_core.varchar)("id").primaryKey().default(import_drizzle_orm.sql`gen_random_uuid()`),
  username: (0, import_pg_core.text)("username").notNull().unique(),
  password: (0, import_pg_core.text)("password").notNull()
});
var jobs = (0, import_pg_core.pgTable)("jobs", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  title: (0, import_pg_core.text)("title").notNull(),
  organization: (0, import_pg_core.text)("organization").notNull(),
  location: (0, import_pg_core.text)("location"),
  category: (0, import_pg_core.text)("category").notNull(),
  skillCategory: (0, import_pg_core.text)("skill_category"),
  description: (0, import_pg_core.text)("description"),
  url: (0, import_pg_core.text)("url"),
  source: (0, import_pg_core.text)("source").notNull(),
  sourceId: (0, import_pg_core.text)("source_id").unique(),
  postedAt: (0, import_pg_core.timestamp)("posted_at").defaultNow(),
  startDate: (0, import_pg_core.timestamp)("start_date"),
  closingDate: (0, import_pg_core.timestamp)("closing_date"),
  jobType: (0, import_pg_core.text)("job_type"),
  salary: (0, import_pg_core.text)("salary"),
  country: (0, import_pg_core.text)("country"),
  isEmployerPosted: (0, import_pg_core.boolean)("is_employer_posted").default(false),
  applyEmail: (0, import_pg_core.text)("apply_email"),
  stripePaymentId: (0, import_pg_core.text)("stripe_payment_id"),
  featured: (0, import_pg_core.boolean)("featured").default(false)
});
var pendingJobs = (0, import_pg_core.pgTable)("pending_jobs", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  stripeSessionId: (0, import_pg_core.text)("stripe_session_id").notNull().unique(),
  title: (0, import_pg_core.text)("title").notNull(),
  organization: (0, import_pg_core.text)("organization").notNull(),
  location: (0, import_pg_core.text)("location"),
  category: (0, import_pg_core.text)("category").notNull(),
  description: (0, import_pg_core.text)("description"),
  url: (0, import_pg_core.text)("url"),
  jobType: (0, import_pg_core.text)("job_type"),
  salary: (0, import_pg_core.text)("salary"),
  country: (0, import_pg_core.text)("country"),
  applyEmail: (0, import_pg_core.text)("apply_email"),
  featured: (0, import_pg_core.boolean)("featured").default(false),
  startDate: (0, import_pg_core.timestamp)("start_date"),
  closingDate: (0, import_pg_core.timestamp)("closing_date"),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow(),
  published: (0, import_pg_core.boolean)("published").default(false)
});
var newsletterSubscribers = (0, import_pg_core.pgTable)("newsletter_subscribers", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  email: (0, import_pg_core.text)("email").notNull().unique(),
  name: (0, import_pg_core.text)("name"),
  type: (0, import_pg_core.text)("type").notNull().default("job_seeker"),
  subscribedAt: (0, import_pg_core.timestamp)("subscribed_at").defaultNow(),
  active: (0, import_pg_core.boolean)("active").default(true)
});
var insertSubscriberSchema = (0, import_drizzle_zod.createInsertSchema)(newsletterSubscribers).omit({
  id: true,
  subscribedAt: true,
  active: true
});
var subscribeSchema = import_zod.z.object({
  email: import_zod.z.string().email("Please enter a valid email address"),
  name: import_zod.z.string().optional(),
  type: import_zod.z.enum(["job_seeker", "employer"]).default("job_seeker")
});
var insertUserSchema = (0, import_drizzle_zod.createInsertSchema)(users).pick({
  username: true,
  password: true
});
var insertJobSchema = (0, import_drizzle_zod.createInsertSchema)(jobs).omit({
  id: true,
  postedAt: true
});
var postJobSchema = import_zod.z.object({
  title: import_zod.z.string().min(3, "Job title must be at least 3 characters"),
  organization: import_zod.z.string().min(2, "Company name is required"),
  location: import_zod.z.string().min(2, "Location is required"),
  category: import_zod.z.enum(["un", "ngo", "remote", "international", "technology", "healthcare", "business", "education", "engineering", "creative", "sales", "gig", "youth", "sponsored"]),
  description: import_zod.z.string().min(1,"").refine(function(v){return v.trim().split(/\s+/).filter(Boolean).length>=600;},"Description must be at least 600 words. Best: 800–1,000 words for quality SEO job postings."),
  url: import_zod.z.string().url("Please enter a valid URL").optional().or(import_zod.z.literal("")),
  jobType: import_zod.z.string().optional(),
  salary: import_zod.z.string().optional(),
  country: import_zod.z.string().optional(),
  applyEmail: import_zod.z.string().email("Please enter a valid email").optional().or(import_zod.z.literal("")),
  adminCode: import_zod.z.string().optional(),
  listingType: import_zod.z.enum(["regular", "featured"]).default("regular"),
  startDate: import_zod.z.string().optional().or(import_zod.z.literal("")),
  closingDate: import_zod.z.string().optional().or(import_zod.z.literal(""))
});
var blogPosts = (0, import_pg_core.pgTable)("blog_posts", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  title: (0, import_pg_core.text)("title").notNull(),
  slug: (0, import_pg_core.text)("slug").notNull().unique(),
  metaTitle: (0, import_pg_core.text)("meta_title"),
  metaDescription: (0, import_pg_core.text)("meta_description"),
  focusKeyword: (0, import_pg_core.text)("focus_keyword"),
  secondaryKeywords: (0, import_pg_core.text)("secondary_keywords"),
  content: (0, import_pg_core.text)("content").notNull().default(""),
  excerpt: (0, import_pg_core.text)("excerpt"),
  featuredImageUrl: (0, import_pg_core.text)("featured_image_url"),
  featuredImageAlt: (0, import_pg_core.text)("featured_image_alt"),
  author: (0, import_pg_core.text)("author").notNull().default("Dev Global Jobs"),
  category: (0, import_pg_core.text)("category"),
  tags: (0, import_pg_core.text)("tags"),
  status: (0, import_pg_core.text)("status").notNull().default("draft"),
  canonicalUrl: (0, import_pg_core.text)("canonical_url"),
  ogTitle: (0, import_pg_core.text)("og_title"),
  ogDescription: (0, import_pg_core.text)("og_description"),
  schemaType: (0, import_pg_core.text)("schema_type").notNull().default("BlogPosting"),
  wordCount: (0, import_pg_core.integer)("word_count"),
  readingTimeMinutes: (0, import_pg_core.integer)("reading_time_minutes"),
  publishedAt: (0, import_pg_core.timestamp)("published_at"),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow(),
  updatedAt: (0, import_pg_core.timestamp)("updated_at").defaultNow()
});
var jobSeekerAccounts = (0, import_pg_core.pgTable)("job_seeker_accounts", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  email: (0, import_pg_core.text)("email").notNull().unique(),
  passwordHash: (0, import_pg_core.text)("password_hash").notNull(),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow(),
  lastLoginAt: (0, import_pg_core.timestamp)("last_login_at")
});
var jobSeekerProfiles = (0, import_pg_core.pgTable)("job_seeker_profiles", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  accountId: (0, import_pg_core.integer)("account_id").notNull().unique(),
  fullName: (0, import_pg_core.text)("full_name").notNull().default(""),
  phone: (0, import_pg_core.text)("phone").default(""),
  city: (0, import_pg_core.text)("city").default(""),
  country: (0, import_pg_core.text)("country").default(""),
  linkedin: (0, import_pg_core.text)("linkedin").default(""),
  website: (0, import_pg_core.text)("website").default(""),
  jobTitle: (0, import_pg_core.text)("job_title").default(""),
  summary: (0, import_pg_core.text)("summary").default(""),
  skills: (0, import_pg_core.text)("skills").default("[]"),
  languages: (0, import_pg_core.text)("languages").default("[]"),
  workExperience: (0, import_pg_core.text)("work_experience").default("[]"),
  education: (0, import_pg_core.text)("education").default("[]"),
  certifications: (0, import_pg_core.text)("certifications").default("[]"),
  atsScore: (0, import_pg_core.integer)("ats_score").default(0),
  updatedAt: (0, import_pg_core.timestamp)("updated_at").defaultNow()
});

// server/db.ts
var import_node_postgres = require("drizzle-orm/node-postgres");
var import_pg = __toESM(require("pg"), 1);
var pool = new import_pg.default.Pool({
  connectionString: process.env.DATABASE_URL
});
var db = (0, import_node_postgres.drizzle)(pool, { schema: schema_exports });

// Auto-create saved_jobs table if not exists
pool.query(`
  CREATE TABLE IF NOT EXISTS saved_jobs (
    id SERIAL PRIMARY KEY,
    account_id INTEGER NOT NULL,
    job_id INTEGER NOT NULL,
    saved_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(account_id, job_id)
  )
`).catch(function(e) { console.error("saved_jobs table init error:", e.message); });

// server/storage.ts
var import_drizzle_orm2 = require("drizzle-orm");
function activeJobConditions() {
  const now = /* @__PURE__ */ new Date();
  return [
    (0, import_drizzle_orm2.or)(import_drizzle_orm2.sql`${jobs.closingDate} IS NULL`, (0, import_drizzle_orm2.gt)(jobs.closingDate, now)),
    (0, import_drizzle_orm2.or)(import_drizzle_orm2.sql`${jobs.startDate} IS NULL`, (0, import_drizzle_orm2.lt)(jobs.startDate, now))
  ];
}
var SOURCE_CATEGORIES = ["un", "ngo", "remote", "international"];
var SKILL_CATEGORIES = ["technology", "healthcare", "business", "education", "engineering", "creative", "sales", "gig", "youth"];
var DatabaseStorage = class {
  async getUser(id) {
    const [user] = await db.select().from(users).where((0, import_drizzle_orm2.eq)(users.id, id));
    return user;
  }
  async getUserByUsername(username) {
    const [user] = await db.select().from(users).where((0, import_drizzle_orm2.eq)(users.username, username));
    return user;
  }
  async createUser(insertUser) {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  async getJobs(category) {
    if (!category) {
      return db.select().from(jobs).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id));
    }
    if (SOURCE_CATEGORIES.includes(category)) {
      if (category === "international") {
        return db.select().from(jobs).where((0, import_drizzle_orm2.and)((0, import_drizzle_orm2.eq)(jobs.category, category), (0, import_drizzle_orm2.ne)(jobs.skillCategory, "youth"))).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id));
      }
      return db.select().from(jobs).where((0, import_drizzle_orm2.eq)(jobs.category, category)).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id));
    }
    if (SKILL_CATEGORIES.includes(category)) {
      return db.select().from(jobs).where((0, import_drizzle_orm2.eq)(jobs.skillCategory, category)).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id));
    }
    return db.select().from(jobs).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id));
  }
  async getJobsPaginated(category, limit, offset, search, easyApplyOnly = false) {
    const conditions = [...activeJobConditions()];
    const isAllCategory = !category || category === "all";
    if (category && category !== "all") {
      if (SOURCE_CATEGORIES.includes(category)) {
        conditions.push((0, import_drizzle_orm2.eq)(jobs.category, category));
        if (category === "international") {
          conditions.push((0, import_drizzle_orm2.ne)(jobs.skillCategory, "youth"));
        }
      } else if (SKILL_CATEGORIES.includes(category)) {
        conditions.push((0, import_drizzle_orm2.eq)(jobs.skillCategory, category));
      }
    }
    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      conditions.push(
        (0, import_drizzle_orm2.or)(
          (0, import_drizzle_orm2.ilike)(jobs.title, q),
          (0, import_drizzle_orm2.ilike)(jobs.organization, q),
          (0, import_drizzle_orm2.ilike)(jobs.location, q),
          (0, import_drizzle_orm2.ilike)(jobs.country, q)
        )
      );
    }
    if (easyApplyOnly) {
      conditions.push(import_drizzle_orm2.sql`COALESCE(BTRIM(${jobs.applyEmail}), '') <> ''`);
    }
    const whereClause = conditions.length > 0 ? (0, import_drizzle_orm2.and)(...conditions) : void 0;
    const [countResult] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where(whereClause);
    const total = Number(countResult?.count || 0);
    const orderClauses = [import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id)];
    const result = await db.select().from(jobs).where(whereClause).orderBy(...orderClauses).limit(limit).offset(offset);
    return { jobs: result, total };
  }
  async getJobById(id) {
    const [job] = await db.select().from(jobs).where((0, import_drizzle_orm2.eq)(jobs.id, id));
    return job;
  }
  async getFeaturedJobs() {
    return db.select().from(jobs)
      .where((0, import_drizzle_orm2.and)((0, import_drizzle_orm2.eq)(jobs.featured, true), ...activeJobConditions()))
      .orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id))
      .limit(60);
  }
  async getFeaturedEmployerJobs(category, easyApplyOnly = false) {
    const conditions = [(0, import_drizzle_orm2.eq)(jobs.featured, true), ...activeJobConditions()];
    if (category && category !== "all") {
      if (SOURCE_CATEGORIES.includes(category)) {
        conditions.push((0, import_drizzle_orm2.eq)(jobs.category, category));
      } else if (SKILL_CATEGORIES.includes(category)) {
        conditions.push((0, import_drizzle_orm2.eq)(jobs.skillCategory, category));
      }
    }
    if (easyApplyOnly) conditions.push(import_drizzle_orm2.sql`COALESCE(BTRIM(${jobs.applyEmail}), '') <> ''`);
    return db.select().from(jobs).where((0, import_drizzle_orm2.and)(...conditions)).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id));
  }
  async getJobStats() {
    const sourceCounts = await db.select({ category: jobs.category, count: import_drizzle_orm2.sql`count(*)` }).from(jobs).groupBy(jobs.category);
    const skillCounts = await db.select({ skillCategory: jobs.skillCategory, count: import_drizzle_orm2.sql`count(*)` }).from(jobs).groupBy(jobs.skillCategory);
    const [youthInInternational] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where((0, import_drizzle_orm2.and)((0, import_drizzle_orm2.eq)(jobs.category, "international"), (0, import_drizzle_orm2.eq)(jobs.skillCategory, "youth")));
    const youthInIntlCount = Number(youthInInternational?.count || 0);
    const stats = { total: 0 };
    for (const row of sourceCounts) {
      const count = Number(row.count);
      stats.total += count;
      if (row.category === "international") {
        stats[row.category] = count - youthInIntlCount;
      } else {
        stats[row.category] = count;
      }
    }
    for (const row of skillCounts) {
      if (row.skillCategory) {
        stats[row.skillCategory] = Number(row.count);
      }
    }
    return stats;
  }
  async insertJob(job) {
    const [inserted] = await db.insert(jobs).values(job).returning();
    return inserted;
  }
  async insertJobs(jobsList) {
    if (jobsList.length === 0) return;
    const batchSize = 100;
    for (let i = 0; i < jobsList.length; i += batchSize) {
      const batch = jobsList.slice(i, i + batchSize);
      try {
        await db.insert(jobs).values(batch).onConflictDoNothing();
      } catch (err) {
        if (err?.message?.includes("duplicate key") || err?.code === "23505") {
          for (const job of batch) {
            try {
              await db.insert(jobs).values(job).onConflictDoNothing();
            } catch (innerErr) {
              if (!innerErr?.message?.includes("duplicate key") && innerErr?.code !== "23505") {
                console.error(`Insert job error: ${innerErr.message}`);
              }
            }
          }
        } else {
          console.error(`Batch insert error: ${err.message}`);
        }
      }
    }
  }
  async insertJobsReturningIds(jobsList) {
    if (jobsList.length === 0) return [];
    const ids = [];
    const batchSize = 50;
    for (let i = 0; i < jobsList.length; i += batchSize) {
      const batch = jobsList.slice(i, i + batchSize);
      try {
        const result = await db.insert(jobs).values(batch).onConflictDoNothing().returning({ id: jobs.id });
        ids.push(...result.map((r) => r.id));
      } catch (err) {
        if (err?.message?.includes("duplicate key") || err?.code === "23505") {
          for (const job of batch) {
            try {
              const result = await db.insert(jobs).values(job).onConflictDoNothing().returning({ id: jobs.id });
              ids.push(...result.map((r) => r.id));
            } catch (innerErr) {
              if (!innerErr?.message?.includes("duplicate key") && innerErr?.code !== "23505") {
                console.error(`Insert job error: ${innerErr.message}`);
              }
            }
          }
        } else {
          console.error(`Batch insert returning error: ${err.message}`);
        }
      }
    }
    return ids;
  }
  async jobExistsBySourceId(sourceId, source) {
    const [existing] = await db.select({ id: jobs.id }).from(jobs).where((0, import_drizzle_orm2.and)((0, import_drizzle_orm2.eq)(jobs.sourceId, sourceId), (0, import_drizzle_orm2.eq)(jobs.source, source))).limit(1);
    return !!existing;
  }
  async deleteOldJobs(daysOld) {
    await db.delete(jobs).where(
      (0, import_drizzle_orm2.and)(
        import_drizzle_orm2.sql`${jobs.postedAt} < NOW() - INTERVAL '${import_drizzle_orm2.sql.raw(daysOld.toString())} days'`,
        (0, import_drizzle_orm2.eq)(jobs.isEmployerPosted, false)
      )
    );
    await db.delete(jobs).where(
      (0, import_drizzle_orm2.and)(
        import_drizzle_orm2.sql`${jobs.postedAt} < NOW() - INTERVAL '30 days'`,
        (0, import_drizzle_orm2.eq)(jobs.isEmployerPosted, true),
        (0, import_drizzle_orm2.eq)(jobs.featured, false)
      )
    );
    await db.delete(jobs).where(
      (0, import_drizzle_orm2.and)(
        import_drizzle_orm2.sql`${jobs.postedAt} < NOW() - INTERVAL '45 days'`,
        (0, import_drizzle_orm2.eq)(jobs.isEmployerPosted, true),
        (0, import_drizzle_orm2.eq)(jobs.featured, true)
      )
    );
  }
  async removeDuplicateJobs() {
    const result = await db.execute(import_drizzle_orm2.sql`
      WITH duplicates AS (
        SELECT id, ROW_NUMBER() OVER (
          PARTITION BY source_id 
          ORDER BY id DESC
        ) as rn
        FROM jobs
        WHERE source_id IS NOT NULL
      )
      DELETE FROM jobs WHERE id IN (
        SELECT id FROM duplicates WHERE rn > 1
      )
    `);
    return Number(result.rowCount) || 0;
  }
  async runFullCleanup() {
    const stats = { expiredByClosingDate: 0, staleJobs: 0, employerRegular: 0, employerFeatured: 0, duplicates: 0 };
    const r1 = await db.execute(import_drizzle_orm2.sql`
      DELETE FROM jobs 
      WHERE closing_date IS NOT NULL 
        AND closing_date < NOW()
    `);
    stats.expiredByClosingDate = Number(r1.rowCount) || 0;
    const r2 = await db.execute(import_drizzle_orm2.sql`
      DELETE FROM jobs 
      WHERE posted_at < NOW() - INTERVAL '30 days'
        AND is_employer_posted = false
    `);
    stats.staleJobs = Number(r2.rowCount) || 0;
    const r3 = await db.execute(import_drizzle_orm2.sql`
      DELETE FROM jobs 
      WHERE posted_at < NOW() - INTERVAL '30 days'
        AND is_employer_posted = true
        AND featured = false
    `);
    stats.employerRegular = Number(r3.rowCount) || 0;
    const r4 = await db.execute(import_drizzle_orm2.sql`
      DELETE FROM jobs 
      WHERE posted_at < NOW() - INTERVAL '45 days'
        AND is_employer_posted = true
        AND featured = true
    `);
    stats.employerFeatured = Number(r4.rowCount) || 0;
    stats.duplicates = await this.removeDuplicateJobs();
    return stats;
  }
  async removeExpiredClosingDateJobs() {
    const result = await db.execute(import_drizzle_orm2.sql`
      DELETE FROM jobs
      WHERE closing_date IS NOT NULL
        AND closing_date < NOW()
    `);
    return Number(result.rowCount) || 0;
  }
  async createPendingJob(data, sessionId) {
    const [pending] = await db.insert(pendingJobs).values({
      stripeSessionId: sessionId,
      title: data.title,
      organization: data.organization,
      location: data.location,
      category: data.category,
      description: data.description,
      url: data.url || null,
      jobType: data.jobType || null,
      salary: data.salary || null,
      country: data.country || null,
      applyEmail: data.applyEmail || null,
      featured: data.listingType === "featured"
    }).returning();
    return pending;
  }
  async getPendingJobBySessionId(sessionId) {
    const [pending] = await db.select().from(pendingJobs).where((0, import_drizzle_orm2.and)((0, import_drizzle_orm2.eq)(pendingJobs.stripeSessionId, sessionId), (0, import_drizzle_orm2.eq)(pendingJobs.published, false)));
    return pending;
  }
  async markPendingJobPublished(sessionId) {
    await db.update(pendingJobs).set({ published: true }).where((0, import_drizzle_orm2.eq)(pendingJobs.stripeSessionId, sessionId));
  }
  async getAllJobIds() {
    return db.select({ id: jobs.id, postedAt: jobs.postedAt, isEmployerPosted: jobs.isEmployerPosted }).from(jobs).orderBy((0, import_drizzle_orm2.desc)(jobs.postedAt));
  }
  async getJobsByCountryPaginated(countryCode, limit, offset, search) {
    const conditions = [(0, import_drizzle_orm2.eq)(jobs.country, countryCode.toUpperCase()), ...activeJobConditions()];
    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      conditions.push(
        (0, import_drizzle_orm2.or)(
          (0, import_drizzle_orm2.ilike)(jobs.title, q),
          (0, import_drizzle_orm2.ilike)(jobs.organization, q),
          (0, import_drizzle_orm2.ilike)(jobs.location, q)
        )
      );
    }
    const whereClause = (0, import_drizzle_orm2.and)(...conditions);
    const [countResult] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where(whereClause);
    const total = Number(countResult?.count || 0);
    const result = await db.select().from(jobs).where(whereClause).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id)).limit(limit).offset(offset);
    return { jobs: result, total };
  }
  async getJobsByCityPaginated(city, limit, offset, search) {
    const cityPattern = `%${city.trim()}%`;
    const conditions = [(0, import_drizzle_orm2.ilike)(jobs.location, cityPattern), ...activeJobConditions()];
    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      conditions.push(
        (0, import_drizzle_orm2.or)(
          (0, import_drizzle_orm2.ilike)(jobs.title, q),
          (0, import_drizzle_orm2.ilike)(jobs.organization, q)
        )
      );
    }
    const whereClause = (0, import_drizzle_orm2.and)(...conditions);
    const [countResult] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where(whereClause);
    const total = Number(countResult?.count || 0);
    const result = await db.select().from(jobs).where(whereClause).orderBy(import_drizzle_orm2.sql`CASE WHEN EXISTS (SELECT 1 FROM dgj_v45_boosts b WHERE b.job_id = ${jobs.id} AND b.status = 'active' AND b.starts_at <= NOW() AND b.ends_at > NOW()) THEN 0 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'featured' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 1 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type IN ('paid','code') AND u.listing_type = 'regular' AND (u.priority_ends_at IS NULL OR u.priority_ends_at > NOW())) THEN 2 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'featured') THEN 3 WHEN ${jobs.isEmployerPosted} = true AND ${jobs.featured} = true THEN 3 WHEN EXISTS (SELECT 1 FROM dgj_v45_allowance_usage u WHERE u.job_id = ${jobs.id} AND u.allowance_type = 'free' AND u.listing_type = 'regular') THEN 4 WHEN ${jobs.isEmployerPosted} = true THEN 4 WHEN ${jobs.featured} = true THEN 5 ELSE 6 END`, (0, import_drizzle_orm2.desc)(jobs.postedAt), (0, import_drizzle_orm2.desc)(jobs.id)).limit(limit).offset(offset);
    return { jobs: result, total };
  }
  async getCountryStats() {
    const result = await db.select({ code: jobs.country, count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where(import_drizzle_orm2.sql`${jobs.country} IS NOT NULL AND ${jobs.country} != ''`).groupBy(jobs.country).orderBy(import_drizzle_orm2.sql`count(*) DESC`);
    return result.map((r) => ({ code: r.code || "", count: Number(r.count) }));
  }
  async getJobIdsByCountry(countryCode) {
    return db.select({ id: jobs.id, postedAt: jobs.postedAt, isEmployerPosted: jobs.isEmployerPosted }).from(jobs).where((0, import_drizzle_orm2.eq)(jobs.country, countryCode.toUpperCase())).orderBy((0, import_drizzle_orm2.desc)(jobs.postedAt));
  }
  async getLatestJobIds(limit) {
    return db.select({ id: jobs.id, postedAt: jobs.postedAt, isEmployerPosted: jobs.isEmployerPosted }).from(jobs).orderBy((0, import_drizzle_orm2.desc)(jobs.postedAt)).limit(limit);
  }
  async addSubscriber(data) {
    const [subscriber] = await db.insert(newsletterSubscribers).values(data).returning();
    return subscriber;
  }
  async getSubscribers() {
    return db.select().from(newsletterSubscribers).orderBy((0, import_drizzle_orm2.desc)(newsletterSubscribers.subscribedAt));
  }
  async getSubscriberByEmail(email) {
    const [subscriber] = await db.select().from(newsletterSubscribers).where((0, import_drizzle_orm2.eq)(newsletterSubscribers.email, email.toLowerCase()));
    return subscriber;
  }
  async deleteSubscriber(id) {
    await db.delete(newsletterSubscribers).where((0, import_drizzle_orm2.eq)(newsletterSubscribers.id, id));
  }
  async getSubscriberCount() {
    const [result] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(newsletterSubscribers);
    return Number(result.count);
  }
  async getSubscriberCountByType() {
    const [total] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(newsletterSubscribers);
    const [employers] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(newsletterSubscribers).where((0, import_drizzle_orm2.eq)(newsletterSubscribers.type, "employer"));
    const [jobSeekers] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(newsletterSubscribers).where((0, import_drizzle_orm2.eq)(newsletterSubscribers.type, "job_seeker"));
    return {
      total: Number(total.count),
      employers: Number(employers.count),
      jobSeekers: Number(jobSeekers.count)
    };
  }
  async getAdminJobs(page, limit, search, source, category) {
    const offset = (page - 1) * limit;
    const conditions = [];
    if (search) {
      conditions.push((0, import_drizzle_orm2.or)(
        (0, import_drizzle_orm2.ilike)(jobs.title, `%${search}%`),
        (0, import_drizzle_orm2.ilike)(jobs.organization, `%${search}%`),
        (0, import_drizzle_orm2.ilike)(jobs.location, `%${search}%`)
      ));
    }
    if (source) conditions.push((0, import_drizzle_orm2.eq)(jobs.source, source));
    if (category) conditions.push((0, import_drizzle_orm2.eq)(jobs.category, category));
    const whereClause = conditions.length > 0 ? (0, import_drizzle_orm2.and)(...conditions) : void 0;
    const [countResult] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where(whereClause);
    const jobsList = await db.select().from(jobs).where(whereClause).orderBy((0, import_drizzle_orm2.desc)(jobs.postedAt)).limit(limit).offset(offset);
    return { jobs: jobsList, total: Number(countResult.count) };
  }
  async deleteJobById(id) {
    await db.delete(jobs).where((0, import_drizzle_orm2.eq)(jobs.id, id));
  }
  async updateJobById(id, data) {
    const [updated] = await db.update(jobs).set(data).where((0, import_drizzle_orm2.eq)(jobs.id, id)).returning();
    return updated;
  }
  async getAdminStats() {
    const [total] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs);
    const [today] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where(import_drizzle_orm2.sql`${jobs.postedAt} >= NOW() - INTERVAL '24 hours'`);
    const [employer] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where((0, import_drizzle_orm2.eq)(jobs.isEmployerPosted, true));
    const [featured] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(jobs).where((0, import_drizzle_orm2.eq)(jobs.featured, true));
    const sourcesResult = await db.selectDistinct({ source: jobs.source }).from(jobs);
    const [subscribers] = await db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(newsletterSubscribers);
    return {
      total: Number(total.count),
      today: Number(today.count),
      employer: Number(employer.count),
      featured: Number(featured.count),
      sources: sourcesResult.length,
      subscribers: Number(subscribers.count)
    };
  }
  async getSourcesList() {
    const result = await db.select({ source: jobs.source, count: import_drizzle_orm2.sql`count(*)` }).from(jobs).groupBy(jobs.source).orderBy((0, import_drizzle_orm2.desc)(import_drizzle_orm2.sql`count(*)`));
    return result.map((r) => ({ source: r.source, count: Number(r.count) }));
  }
  async getRevenueMetrics() {
    const REGULAR_PRICE = 29;
    const FEATURED_PRICE = 79;
    const [row] = await db.select({
      regTotal: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false)`,
      regToday: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= CURRENT_DATE)`,
      regWeek: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= NOW() - INTERVAL '7 days')`,
      regMonth: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= NOW() - INTERVAL '30 days')`,
      regYear: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = false AND posted_at >= NOW() - INTERVAL '365 days')`,
      featTotal: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true)`,
      featToday: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= CURRENT_DATE)`,
      featWeek: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= NOW() - INTERVAL '7 days')`,
      featMonth: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= NOW() - INTERVAL '30 days')`,
      featYear: import_drizzle_orm2.sql`COUNT(*) FILTER (WHERE is_employer_posted = true AND featured = true AND posted_at >= NOW() - INTERVAL '365 days')`
    }).from(jobs);
    const r = (v) => Number(v) || 0;
    const regular = { today: r(row.regToday), week: r(row.regWeek), month: r(row.regMonth), year: r(row.regYear), total: r(row.regTotal) };
    const featured = { today: r(row.featToday), week: r(row.featWeek), month: r(row.featMonth), year: r(row.featYear), total: r(row.featTotal) };
    const rev = (reg, feat) => reg * REGULAR_PRICE + feat * FEATURED_PRICE;
    const revenue = {
      today: rev(regular.today, featured.today),
      week: rev(regular.week, featured.week),
      month: rev(regular.month, featured.month),
      year: rev(regular.year, featured.year),
      total: rev(regular.total, featured.total)
    };
    const dailyRegRate = regular.month / 30;
    const dailyFeatRate = featured.month / 30;
    const dailyRev = dailyRegRate * REGULAR_PRICE + dailyFeatRate * FEATURED_PRICE;
    const projections = {
      daily: Math.round(dailyRev),
      weekly: Math.round(dailyRev * 7),
      monthly: Math.round(dailyRev * 30),
      yearly: Math.round(dailyRev * 365)
    };
    return { regular, featured, revenue, projections };
  }
  async getBlogPosts(page, limit, status) {
    const offset = (page - 1) * limit;
    const where = status ? (0, import_drizzle_orm2.eq)(blogPosts.status, status) : void 0;
    const [posts, [{ count }]] = await Promise.all([
      db.select().from(blogPosts).where(where).orderBy((0, import_drizzle_orm2.desc)(blogPosts.createdAt)).limit(limit).offset(offset),
      db.select({ count: import_drizzle_orm2.sql`count(*)` }).from(blogPosts).where(where)
    ]);
    return { posts, total: Number(count) };
  }
  async getBlogPostBySlug(slug) {
    const [post] = await db.select().from(blogPosts).where((0, import_drizzle_orm2.eq)(blogPosts.slug, slug));
    return post;
  }
  async getBlogPostById(id) {
    const [post] = await db.select().from(blogPosts).where((0, import_drizzle_orm2.eq)(blogPosts.id, id));
    return post;
  }
  async createBlogPost(data) {
    const [post] = await db.insert(blogPosts).values(data).returning();
    return post;
  }
  async updateBlogPost(id, data) {
    const [post] = await db.update(blogPosts).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where((0, import_drizzle_orm2.eq)(blogPosts.id, id)).returning();
    return post;
  }
  async deleteBlogPost(id) {
    await db.delete(blogPosts).where((0, import_drizzle_orm2.eq)(blogPosts.id, id));
  }
  async createSeekerAccount(email, passwordHash) {
    const [account] = await db.insert(jobSeekerAccounts).values({ email, passwordHash }).returning();
    return account;
  }
  async getSeekerAccountByEmail(email) {
    const [account] = await db.select().from(jobSeekerAccounts).where((0, import_drizzle_orm2.eq)(jobSeekerAccounts.email, email.toLowerCase().trim()));
    return account;
  }
  async getSeekerAccountById(id) {
    const [account] = await db.select().from(jobSeekerAccounts).where((0, import_drizzle_orm2.eq)(jobSeekerAccounts.id, id));
    return account;
  }
  async updateSeekerLastLogin(id) {
    await db.update(jobSeekerAccounts).set({ lastLoginAt: /* @__PURE__ */ new Date() }).where((0, import_drizzle_orm2.eq)(jobSeekerAccounts.id, id));
  }
  async getSeekerProfile(accountId) {
    const [profile] = await db.select().from(jobSeekerProfiles).where((0, import_drizzle_orm2.eq)(jobSeekerProfiles.accountId, accountId));
    return profile;
  }
  async upsertSeekerProfile(accountId, data) {
    const existing = await this.getSeekerProfile(accountId);
    if (existing) {
      const [updated] = await db.update(jobSeekerProfiles).set({ ...data, updatedAt: /* @__PURE__ */ new Date() }).where((0, import_drizzle_orm2.eq)(jobSeekerProfiles.accountId, accountId)).returning();
      return updated;
    } else {
      const [created] = await db.insert(jobSeekerProfiles).values({ accountId, ...data }).returning();
      return created;
    }
  }
  async getSavedJobs(accountId) {
    const rows = await pool.query(
      `SELECT j.* FROM saved_jobs sj JOIN jobs j ON j.id = sj.job_id WHERE sj.account_id = $1 ORDER BY sj.saved_at DESC`,
      [accountId]
    );
    return rows.rows;
  }
  async saveJob(accountId, jobId) {
    await pool.query(
      `INSERT INTO saved_jobs (account_id, job_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
      [accountId, jobId]
    );
  }
  async unsaveJob(accountId, jobId) {
    await pool.query(
      `DELETE FROM saved_jobs WHERE account_id = $1 AND job_id = $2`,
      [accountId, jobId]
    );
  }
  async isJobSaved(accountId, jobId) {
    const rows = await pool.query(
      `SELECT 1 FROM saved_jobs WHERE account_id = $1 AND job_id = $2`,
      [accountId, jobId]
    );
    return rows.rows.length > 0;
  }
  async getSeekerStats() {
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const [{ total }] = await db.select({ total: import_drizzle_orm2.sql`count(*)` }).from(jobSeekerAccounts);
    const [{ withProfiles }] = await db.select({ withProfiles: import_drizzle_orm2.sql`count(*)` }).from(jobSeekerProfiles);
    const [{ todayCount }] = await db.select({ todayCount: import_drizzle_orm2.sql`count(*)` }).from(jobSeekerAccounts).where(import_drizzle_orm2.sql`created_at >= ${today}`);
    const countriesRaw = await db.select({ country: jobSeekerProfiles.country, count: import_drizzle_orm2.sql`count(*)` }).from(jobSeekerProfiles).where(import_drizzle_orm2.sql`country IS NOT NULL AND country != ''`).groupBy(jobSeekerProfiles.country).orderBy((0, import_drizzle_orm2.desc)(import_drizzle_orm2.sql`count(*)`)).limit(10);
    return {
      total: Number(total),
      withProfiles: Number(withProfiles),
      today: Number(todayCount),
      countries: countriesRaw.map((r) => ({ country: r.country || "", count: Number(r.count) }))
    };
  }
  async getSeekerAccountsForAdmin(page, limit, search) {
    const offset = (page - 1) * limit;
    if (search && (search.q || search.country || search.atsMin !== void 0 || search.atsMax !== void 0)) {
      const qLike = search.q ? `%${search.q.toLowerCase()}%` : null;
      const countryLike = search.country ? `%${search.country.toLowerCase()}%` : null;
      const atsMin = search.atsMin ?? 0;
      const atsMax = search.atsMax ?? 100;
      const allProfiles = await db.select().from(jobSeekerProfiles);
      const allAccounts = await db.select().from(jobSeekerAccounts);
      const accountMap = new Map(allAccounts.map((a) => [a.id, a]));
      const filtered = allProfiles.filter((p) => {
        const acc = accountMap.get(p.accountId);
        if (!acc) return false;
        if (qLike) {
          const q = qLike.replace(/%/g, "");
          if (!acc.email.toLowerCase().includes(q) && !p.fullName.toLowerCase().includes(q)) return false;
        }
        if (countryLike) {
          const c = countryLike.replace(/%/g, "");
          if (!p.country.toLowerCase().includes(c)) return false;
        }
        const score = p.atsScore ?? 0;
        if (score < atsMin || score > atsMax) return false;
        return true;
      });
      const total2 = filtered.length;
      const paged = filtered.slice(offset, offset + limit);
      const accounts2 = paged.map((p) => ({ ...accountMap.get(p.accountId), profile: p }));
      return { accounts: accounts2, total: total2 };
    }
    const [accounts, [{ total }]] = await Promise.all([
      db.select().from(jobSeekerAccounts).orderBy((0, import_drizzle_orm2.desc)(jobSeekerAccounts.createdAt)).limit(limit).offset(offset),
      db.select({ total: import_drizzle_orm2.sql`count(*)` }).from(jobSeekerAccounts)
    ]);
    const ids = accounts.map((a) => a.id);
    const profiles = ids.length > 0 ? await db.select().from(jobSeekerProfiles).where((0, import_drizzle_orm2.inArray)(jobSeekerProfiles.accountId, ids)) : [];
    const profileMap = new Map(profiles.map((p) => [p.accountId, p]));
    return {
      accounts: accounts.map((a) => ({ ...a, profile: profileMap.get(a.id) })),
      total: Number(total)
    };
  }
  async getSeekerByIdForAdmin(id) {
    const [account] = await db.select().from(jobSeekerAccounts).where((0, import_drizzle_orm2.eq)(jobSeekerAccounts.id, id));
    if (!account) return void 0;
    const [profile] = await db.select().from(jobSeekerProfiles).where((0, import_drizzle_orm2.eq)(jobSeekerProfiles.accountId, id));
    return { ...account, profile };
  }
  async deleteSeekerAccount(id) {
    await db.delete(jobSeekerProfiles).where((0, import_drizzle_orm2.eq)(jobSeekerProfiles.accountId, id));
    await db.delete(jobSeekerAccounts).where((0, import_drizzle_orm2.eq)(jobSeekerAccounts.id, id));
  }
};
var storage = new DatabaseStorage();

// server/routes.ts
var import_drizzle_orm3 = require("drizzle-orm");

// server/jobFetcher.ts
var import_sanitize_html = __toESM(require("sanitize-html"), 1);

// server/jobClassifier.ts
var SKILL_CATEGORIES2 = {
  technology: {
    titleKeywords: [
      "software",
      "developer",
      "engineer",
      "programming",
      "frontend",
      "backend",
      "fullstack",
      "full-stack",
      "full stack",
      "devops",
      "sre",
      "data scientist",
      "data engineer",
      "machine learning",
      "ml engineer",
      "ai engineer",
      "cloud engineer",
      "web developer",
      "mobile developer",
      "ios developer",
      "android developer",
      "qa engineer",
      "test engineer",
      "security engineer",
      "cybersecurity",
      "network engineer",
      "system administrator",
      "sysadmin",
      "database administrator",
      "dba",
      "tech lead",
      "cto",
      "vp engineering",
      "platform engineer",
      "infrastructure",
      "site reliability",
      "python developer",
      "java developer",
      "react developer",
      "node developer",
      "golang",
      "rust developer",
      ".net developer",
      "php developer",
      "ruby developer",
      "scala developer",
      "kotlin developer",
      "solutions architect",
      "cloud architect",
      "it manager",
      "it director",
      "scrum master",
      "agile coach",
      "product owner"
    ],
    keywords: [
      "javascript",
      "typescript",
      "python",
      "java",
      "react",
      "angular",
      "vue",
      "node.js",
      "nodejs",
      "aws",
      "azure",
      "gcp",
      "docker",
      "kubernetes",
      "terraform",
      "ci/cd",
      "api development",
      "microservices",
      "sql",
      "postgresql",
      "mongodb",
      "redis",
      "graphql",
      "rest api",
      "agile",
      "scrum",
      "jira",
      "github",
      "gitlab"
    ]
  },
  healthcare: {
    titleKeywords: [
      "nurse",
      "doctor",
      "physician",
      "surgeon",
      "medical",
      "clinical",
      "healthcare",
      "health care",
      "pharmacist",
      "pharmacy",
      "dental",
      "dentist",
      "therapist",
      "psychologist",
      "psychiatrist",
      "radiologist",
      "pathologist",
      "laboratory",
      "lab technician",
      "biomedical",
      "biotech",
      "biotechnology",
      "pharmaceutical",
      "epidemiologist",
      "public health",
      "health officer",
      "health specialist",
      "nutrition",
      "nutritionist",
      "dietitian",
      "veterinary",
      "optometrist",
      "physiotherapist",
      "occupational therapist",
      "speech therapist",
      "midwife",
      "paramedic",
      "emt",
      "health coordinator",
      "wash specialist",
      "wash officer",
      "medical officer",
      "health advisor",
      "clinical officer"
    ],
    keywords: [
      "patient care",
      "clinical trial",
      "drug development",
      "fda",
      "hipaa",
      "ehr",
      "electronic health",
      "telemedicine",
      "diagnosis",
      "treatment",
      "hospital",
      "clinic",
      "medical device",
      "life sciences",
      "genomics",
      "bioinformatics"
    ]
  },
  business: {
    titleKeywords: [
      "accountant",
      "accounting",
      "financial analyst",
      "finance manager",
      "controller",
      "cfo",
      "treasurer",
      "auditor",
      "tax specialist",
      "investment",
      "banker",
      "banking",
      "actuarial",
      "actuary",
      "economist",
      "business analyst",
      "operations manager",
      "supply chain",
      "logistics",
      "procurement",
      "purchasing",
      "compliance officer",
      "risk manager",
      "risk analyst",
      "management consultant",
      "strategy consultant",
      "consultant",
      "project manager",
      "program manager",
      "portfolio manager",
      "hr manager",
      "human resources",
      "recruiter",
      "talent acquisition",
      "compensation",
      "payroll",
      "benefits",
      "people operations",
      "office manager",
      "executive assistant",
      "chief of staff",
      "business development",
      "general manager",
      "coo",
      "fund manager",
      "grants manager",
      "budget",
      "fiscal"
    ],
    keywords: [
      "financial reporting",
      "gaap",
      "ifrs",
      "quickbooks",
      "sap",
      "oracle financials",
      "erp",
      "crm",
      "salesforce",
      "business intelligence",
      "kpi",
      "roi",
      "p&l",
      "strategic planning",
      "change management",
      "lean",
      "six sigma",
      "process improvement"
    ]
  },
  education: {
    titleKeywords: [
      "teacher",
      "professor",
      "instructor",
      "lecturer",
      "tutor",
      "education",
      "academic",
      "faculty",
      "dean",
      "principal",
      "curriculum",
      "training",
      "trainer",
      "learning",
      "e-learning",
      "teaching",
      "school",
      "university",
      "college",
      "research fellow",
      "research assistant",
      "postdoctoral",
      "librarian",
      "library",
      "admissions",
      "registrar",
      "education officer",
      "education specialist",
      "education coordinator",
      "capacity building",
      "workshop facilitator"
    ],
    keywords: [
      "pedagogy",
      "syllabus",
      "classroom",
      "student",
      "scholarship",
      "fellowship",
      "academic research",
      "distance learning",
      "online learning",
      "lms",
      "moodle",
      "canvas",
      "blackboard"
    ]
  },
  engineering: {
    titleKeywords: [
      "mechanical engineer",
      "civil engineer",
      "electrical engineer",
      "structural engineer",
      "chemical engineer",
      "industrial engineer",
      "manufacturing",
      "production engineer",
      "process engineer",
      "quality engineer",
      "quality assurance",
      "safety engineer",
      "environmental engineer",
      "mining engineer",
      "petroleum engineer",
      "aerospace engineer",
      "marine engineer",
      "naval architect",
      "construction manager",
      "site engineer",
      "project engineer",
      "maintenance engineer",
      "reliability engineer",
      "architect",
      "drafter",
      "cad",
      "autocad",
      "field engineer",
      "plant manager",
      "factory",
      "materials engineer",
      "metallurgist",
      "surveyor"
    ],
    keywords: [
      "manufacturing",
      "production",
      "assembly",
      "fabrication",
      "blueprint",
      "schematic",
      "iso 9001",
      "lean manufacturing",
      "cnc",
      "plc",
      "hvac",
      "piping",
      "welding",
      "structural analysis",
      "finite element",
      "solidworks",
      "catia",
      "revit",
      "bim"
    ]
  },
  creative: {
    titleKeywords: [
      "designer",
      "graphic designer",
      "ui designer",
      "ux designer",
      "ui/ux",
      "product designer",
      "visual designer",
      "brand designer",
      "creative director",
      "art director",
      "illustrator",
      "animator",
      "motion designer",
      "video editor",
      "videographer",
      "photographer",
      "cinematographer",
      "content creator",
      "copywriter",
      "copy editor",
      "editor",
      "journalist",
      "writer",
      "author",
      "blogger",
      "content writer",
      "social media manager",
      "community manager",
      "public relations",
      "pr specialist",
      "communications",
      "media specialist",
      "multimedia"
    ],
    keywords: [
      "photoshop",
      "illustrator",
      "figma",
      "sketch",
      "indesign",
      "after effects",
      "premiere",
      "final cut",
      "davinci",
      "typography",
      "branding",
      "visual identity",
      "wireframe",
      "prototype",
      "user research",
      "usability",
      "content strategy",
      "editorial",
      "storytelling"
    ]
  },
  sales: {
    titleKeywords: [
      "sales manager",
      "sales representative",
      "sales engineer",
      "account executive",
      "account manager",
      "key account",
      "business development",
      "bdr",
      "sdr",
      "marketing manager",
      "digital marketing",
      "marketing specialist",
      "seo specialist",
      "sem specialist",
      "ppc specialist",
      "growth hacker",
      "growth manager",
      "growth marketing",
      "customer success",
      "customer support",
      "customer service",
      "client relations",
      "partnership manager",
      "brand manager",
      "campaign manager",
      "demand generation",
      "revenue operations",
      "revops",
      "marketing director",
      "cmo",
      "vp sales",
      "head of sales",
      "head of marketing",
      "product marketing",
      "email marketing",
      "performance marketing",
      "advertising",
      "media buyer",
      "affiliate manager"
    ],
    keywords: [
      "lead generation",
      "pipeline",
      "quota",
      "commission",
      "hubspot",
      "marketo",
      "mailchimp",
      "google analytics",
      "a/b testing",
      "conversion",
      "funnel",
      "retention",
      "churn",
      "nps",
      "customer satisfaction",
      "upsell",
      "cross-sell",
      "cold calling",
      "outbound"
    ]
  },
  gig: {
    titleKeywords: [
      "freelance",
      "contractor",
      "contract",
      "temporary",
      "part-time",
      "part time",
      "intern",
      "internship",
      "consultant",
      "gig",
      "project-based",
      "flexible",
      "casual",
      "seasonal",
      "volunteer",
      "per diem"
    ],
    keywords: [
      "freelancing",
      "short-term",
      "contract work",
      "independent contractor",
      "1099",
      "self-employed",
      "remote work",
      "work from home",
      "telecommute",
      "flexible hours",
      "flexible schedule"
    ]
  },
  youth: {
    titleKeywords: [
      "fellowship",
      "scholar",
      "scholarship",
      "training program",
      "workshop",
      "youth",
      "young professional",
      "young leader",
      "exchange program",
      "volunteer program",
      "capacity building",
      "mentorship",
      "mentoring",
      "graduate program",
      "trainee",
      "apprentice",
      "apprenticeship",
      "summer program",
      "winter school",
      "spring school",
      "summer school",
      "bootcamp",
      "boot camp",
      "cohort",
      "accelerator program",
      "leadership program",
      "development program",
      "emerging leader",
      "junior professional",
      "early career",
      "entry level",
      "graduate trainee",
      "research grant",
      "grant opportunity",
      "funded program",
      "fully funded",
      "stipend",
      "bursary",
      "award program",
      "prize",
      "competition"
    ],
    keywords: [
      "fellowship",
      "scholarship",
      "fully funded",
      "stipend",
      "bursary",
      "training opportunity",
      "workshop",
      "seminar",
      "conference",
      "exchange",
      "mobility",
      "erasmus",
      "fulbright",
      "chevening",
      "commonwealth scholarship",
      "daad",
      "study abroad",
      "youth empowerment",
      "youth engagement",
      "youth development",
      "capacity development",
      "skill building",
      "professional development",
      "certificate program",
      "certification",
      "diploma program",
      "online course",
      "mooc",
      "webinar",
      "hackathon",
      "incubator",
      "innovation challenge",
      "pitch competition",
      "social impact",
      "civic engagement",
      "community service",
      "peace building",
      "sustainable development",
      "sdg",
      "global south",
      "developing countries",
      "emerging markets"
    ]
  }
};
function classifyJobSkillCategory(title, description) {
  const titleLower = title.toLowerCase();
  const descLower = (description || "").toLowerCase().substring(0, 2e3);
  let bestMatch = null;
  let bestScore = 0;
  for (const [category, { titleKeywords, keywords }] of Object.entries(SKILL_CATEGORIES2)) {
    let score = 0;
    for (const kw of titleKeywords) {
      if (titleLower.includes(kw.toLowerCase())) {
        score += 10;
      }
    }
    for (const kw of keywords) {
      if (titleLower.includes(kw.toLowerCase())) {
        score += 5;
      }
      if (descLower.includes(kw.toLowerCase())) {
        score += 1;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = category;
    }
  }
  return bestScore >= 3 ? bestMatch : null;
}
var SKILL_CATEGORY_LIST = Object.keys(SKILL_CATEGORIES2);

// server/searchEnginePing.ts
var BASE_URL = "https://devglobaljobs.com";
var INDEXNOW_KEY = "d8f4e2a1b7c3d9e5f6a0b4c8d2e7f1a3";
var lastPingTime = 0;
var PING_INTERVAL = 30 * 60 * 1e3;
var CATEGORIES = ["all", "un", "ngo", "remote", "international", "technology", "healthcare", "business", "education", "engineering", "creative", "sales", "gig"];
var COUNTRY_SLUGS = ["uk", "us", "canada", "australia", "germany", "france", "india", "brazil", "south-africa", "netherlands", "poland", "italy", "belgium", "austria", "switzerland", "new-zealand", "singapore"];
var CITY_SLUGS = ["london", "new-york", "dubai", "toronto", "sydney", "berlin", "paris", "amsterdam", "singapore", "tokyo", "zurich", "stockholm", "geneva", "vienna", "brussels", "melbourne", "vancouver", "boston", "san-francisco", "chicago", "los-angeles", "washington-dc", "ottawa", "dublin", "edinburgh", "madrid", "barcelona", "rome", "oslo", "copenhagen", "helsinki", "seoul", "hong-kong", "kuala-lumpur", "bangkok", "montreal", "lisbon", "abu-dhabi", "warsaw", "prague", "budapest", "cape-town", "nairobi", "istanbul", "shanghai", "munich", "frankfurt", "milan", "auckland", "denver"];
async function pingSearchEngines() {
  const now = Date.now();
  if (now - lastPingTime < PING_INTERVAL) return;
  lastPingTime = now;
  const sitemapUrl = encodeURIComponent(`${BASE_URL}/sitemap-index.xml`);
  const pingUrls = [
    `https://www.google.com/ping?sitemap=${sitemapUrl}`,
    `https://www.bing.com/ping?sitemap=${sitemapUrl}`
  ];
  for (const url of pingUrls) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(1e4) });
      log(`Sitemap ping ${url.split("?")[0].split("//")[1].split("/")[0]}: ${res.status}`, "seo");
    } catch (e) {
      log(`Sitemap ping failed: ${url.split("//")[1]?.split("/")[0]}`, "seo");
    }
  }
}
async function submitUrlsToIndexNow(urls) {
  if (urls.length === 0) return;
  const batch = urls.slice(0, 1e4);
  try {
    const payload = {
      host: "devglobaljobs.com",
      key: INDEXNOW_KEY,
      keyLocation: `${BASE_URL}/${INDEXNOW_KEY}.txt`,
      urlList: batch
    };
    const res = await fetch("https://api.indexnow.org/IndexNow", {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(15e3)
    });
    log(`IndexNow submitted ${batch.length} URLs, status: ${res.status}`, "seo");
  } catch (e) {
    log(`IndexNow submission failed for ${batch.length} URLs`, "seo");
  }
}
var pendingUrls = [];
var submitTimeout = null;
function queueUrlForIndexing(url) {
  pendingUrls.push(url);
  if (submitTimeout) return;
  submitTimeout = setTimeout(async () => {
    const urls = [...pendingUrls];
    pendingUrls = [];
    submitTimeout = null;
    if (urls.length > 0) {
      await submitUrlsToIndexNow(urls);
      await pingSearchEngines();
    }
  }, 6e4);
}
function queueNewJobUrls(jobIds) {
  for (const id of jobIds) {
    queueUrlForIndexing(`${BASE_URL}/jobs/detail/${id}`);
  }
}
function submitAllPagesToIndexNow() {
  const urls = [BASE_URL];
  for (const cat of CATEGORIES) {
    urls.push(`${BASE_URL}/jobs/${cat}`);
  }
  for (const slug of COUNTRY_SLUGS) {
    urls.push(`${BASE_URL}/jobs/country/${slug}`);
  }
  for (const city of CITY_SLUGS) {
    urls.push(`${BASE_URL}/jobs/city/${city}`);
  }
  urls.push(`${BASE_URL}/post-job`);
  urls.push(`${BASE_URL}/about`);
  urls.push(`${BASE_URL}/privacy`);
  urls.push(`${BASE_URL}/terms`);
  for (const url of urls) {
    queueUrlForIndexing(url);
  }
  log(`Queued ${urls.length} page URLs for IndexNow submission`, "seo");
}
function getIndexNowKey() {
  return INDEXNOW_KEY;
}

// server/jobFetcher.ts
var import_rss_parser = __toESM(require("rss-parser"), 1);
async function fetchWithRetry(url, options = {}, maxRetries = 3) {
  let lastError = new Error("Unknown error");
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const res = await fetch(url, options);
      if (res.ok || res.status === 404) return res;
      if (res.status === 429 || res.status >= 500) {
        const delay = Math.min(1e3 * Math.pow(2, attempt), 1e4);
        await new Promise((r) => setTimeout(r, delay));
        continue;
      }
      return res;
    } catch (err) {
      lastError = err;
      if (attempt < maxRetries - 1) {
        const delay = Math.min(1e3 * Math.pow(2, attempt), 1e4);
        await new Promise((r) => setTimeout(r, delay));
      }
    }
  }
  throw lastError;
}
var COUNTRY_NAME_TO_CODE = {
  "united states": "US",
  "united states of america": "US",
  "usa": "US",
  "united kingdom": "GB",
  "uk": "GB",
  "great britain": "GB",
  "england": "GB",
  "scotland": "GB",
  "wales": "GB",
  "canada": "CA",
  "australia": "AU",
  "germany": "DE",
  "deutschland": "DE",
  "france": "FR",
  "india": "IN",
  "brazil": "BR",
  "brasil": "BR",
  "south africa": "ZA",
  "netherlands": "NL",
  "holland": "NL",
  "poland": "PL",
  "italy": "IT",
  "italia": "IT",
  "belgium": "BE",
  "austria": "AT",
  "switzerland": "CH",
  "new zealand": "NZ",
  "singapore": "SG",
  "spain": "ES",
  "portugal": "PT",
  "japan": "JP",
  "china": "CN",
  "south korea": "KR",
  "korea": "KR",
  "mexico": "MX",
  "sweden": "SE",
  "norway": "NO",
  "denmark": "DK",
  "finland": "FI",
  "ireland": "IE",
  "czech republic": "CZ",
  "czechia": "CZ",
  "romania": "RO",
  "hungary": "HU",
  "greece": "GR",
  "turkey": "TR",
  "russia": "RU",
  "ukraine": "UA",
  "argentina": "AR",
  "chile": "CL",
  "colombia": "CO",
  "philippines": "PH",
  "indonesia": "ID",
  "malaysia": "MY",
  "thailand": "TH",
  "vietnam": "VN",
  "pakistan": "PK",
  "bangladesh": "BD",
  "sri lanka": "LK",
  "nepal": "NP",
  "kenya": "KE",
  "nigeria": "NG",
  "ghana": "GH",
  "egypt": "EG",
  "morocco": "MA",
  "ethiopia": "ET",
  "tanzania": "TZ",
  "uganda": "UG",
  "united arab emirates": "AE",
  "uae": "AE",
  "saudi arabia": "SA",
  "israel": "IL",
  "qatar": "QA",
  "kuwait": "KW",
  "luxembourg": "LU",
  "malta": "MT",
  "cyprus": "CY",
  "iceland": "IS",
  "estonia": "EE",
  "latvia": "LV",
  "lithuania": "LT",
  "croatia": "HR",
  "serbia": "RS",
  "bulgaria": "BG",
  "slovakia": "SK",
  "slovenia": "SI"
};
function normalizeCountryCode(location, existingCode) {
  if (existingCode && existingCode.length === 2) return existingCode.toUpperCase();
  if (!location) return null;
  const lower = location.toLowerCase().trim();
  for (const [name, code] of Object.entries(COUNTRY_NAME_TO_CODE)) {
    if (lower.includes(name)) return code;
  }
  if (lower.includes("remote") || lower === "global" || lower === "worldwide" || lower === "anywhere") return null;
  return null;
}
var UN_FULL_NAMES = [
  "United Nations",
  "UN Development Programme",
  "UN Children's Fund",
  "UN High Commissioner for Refugees",
  "UN Office for Project Services",
  "UN Educational, Scientific and Cultural Organization",
  "International Organization for Migration",
  "World Health Organization",
  "World Food Programme",
  "Food and Agriculture Organization",
  "International Labour Organization",
  "International Monetary Fund",
  "International Court of Justice",
  "International Criminal Court",
  "World Trade Organization",
  "World Bank Group",
  "UN Women",
  "UN Secretariat",
  "UN Peacekeeping",
  "UN Global Compact",
  "UN Volunteers",
  "UN-Habitat",
  "UN-SPIDER"
];
var UN_ACRONYMS = [
  "UNDP",
  "UNICEF",
  "UNHCR",
  "UNOPS",
  "UNESCO",
  "WFP",
  "FAO",
  "UNFPA",
  "UNEP",
  "UNODC",
  "UNCTAD",
  "UNIDO",
  "UNWTO",
  "IAEA",
  "OPCW",
  "CTBTO",
  "UNAIDS",
  "UNRWA",
  "UNITAR",
  "UNCDF",
  "UNCITRAL",
  "UNDSS",
  "UNDRR",
  "UNFCCC",
  "UNRISD",
  "UNSSC",
  "UNECE",
  "UNECA",
  "UNESCAP",
  "UNESCWA",
  "ECLAC",
  "ESCAP",
  "ESCWA",
  "OHCHR",
  "DPPA",
  "UNMISS",
  "MINUSMA",
  "MONUSCO",
  "UNIFIL",
  "UNDOF",
  "UNFICYP",
  "MINURSO",
  "MINUSCA",
  "UNISFA",
  "UNMIK",
  "UNSOM",
  "BINUH",
  "UNMAS",
  "IFAD"
];
var UN_EXACT_MATCH = [
  "WHO",
  "ILO",
  "ITU",
  "UPU",
  "WMO",
  "WIPO",
  "IOM",
  "IMF",
  "ICJ",
  "ICC",
  "WTO",
  "UNV",
  "UNU",
  "DPKO",
  "DPO",
  "ECA",
  "ECE",
  "OCHA",
  "DESA"
];
var NGO_FULL_NAMES = [
  "Save the Children",
  "Red Cross",
  "Red Crescent",
  "Oxfam",
  "CARE International",
  "M\xE9decins Sans Fronti\xE8res",
  "Doctors Without Borders",
  "World Vision",
  "International Rescue Committee",
  "Mercy Corps",
  "Catholic Relief Services",
  "Plan International",
  "ActionAid",
  "Amnesty International",
  "Human Rights Watch",
  "Greenpeace",
  "World Wildlife Fund",
  "Danish Refugee Council",
  "Norwegian Refugee Council",
  "Islamic Relief",
  "Action Against Hunger",
  "Action contre la Faim",
  "Handicap International",
  "Humanity & Inclusion",
  "M\xE9decins du Monde",
  "Solidarit\xE9s International",
  "Terre des hommes",
  "War Child",
  "SOS Children",
  "GOAL Global",
  "Concern Worldwide",
  "Welthungerhilfe",
  "Chemonics",
  "DAI Global",
  "DT Global",
  "Palladium",
  "FHI 360",
  "Jhpiego",
  "Population Services International",
  "Global Alliance for Improved Nutrition",
  "Clinton Health Access",
  "International Medical Corps",
  "One Acre Fund",
  "Heifer International",
  "Aga Khan Foundation",
  "Near East Foundation",
  "Lutheran World Federation",
  "Tearfund",
  "Relief International",
  "International Alert",
  "Samaritan's Purse",
  "INTERSOS",
  "Premi\xE8re Urgence Internationale",
  "Cooperazione Internazionale",
  "Danish Church Aid",
  "Diakonia",
  "Mines Advisory Group",
  "HALO Trust",
  "Geneva Call",
  "MedGlobal",
  "UK-Med",
  "Peace Winds",
  "Committed To Good",
  "People in Need",
  "Malteser International",
  "Cordaid",
  "M\xE9decins d'Afrique",
  "Search for Common Ground",
  "Internews",
  "Creative Associates",
  "Winrock International",
  "Management Sciences for Health",
  "International Center for Transitional Justice",
  "Transparency International",
  "Global Witness",
  "Doctors of the World",
  "Partners in Health",
  "WaterAid",
  "charity: water",
  "Habitat for Humanity",
  "Build Change",
  "Seeds of Peace",
  "Pathfinder International",
  "EngenderHealth",
  "Marie Stopes",
  "IMPACT Initiatives",
  "REACH Initiative",
  "Polish Humanitarian Action",
  "Finnish Red Cross",
  "Danish Red Cross",
  "British Red Cross",
  "American Red Cross",
  "F\xE9d\xE9ration internationale pour les droits humains",
  "International Crisis Group",
  "Aga Khan Development Network",
  "SEED Madagascar",
  "African Wildlife Foundation",
  "Conservation International",
  "The Nature Conservancy",
  "Global Fund",
  "GAVI Alliance",
  "Pathfinder",
  "Water.org"
];
var NGO_ACRONYMS = [
  "ACTED",
  "COOPI",
  "ICRC",
  "IFRC",
  "FIDH",
  "AKDN",
  "ICTJ",
  "WWF"
];
var NGO_EXACT_MATCH = [
  "MSF",
  "IRC",
  "CRS",
  "DRC",
  "NRC",
  "PSI",
  "GAIN",
  "CHAI",
  "IMC",
  "MDM",
  "BRAC",
  "PUI",
  "MAG",
  "CTG",
  "PIN",
  "ZOA",
  "MSH",
  "ICG",
  "JSI",
  "PATH",
  "Pact",
  "Gavi",
  "Ipas",
  "Caritas"
];
function matchesWordBoundary(text2, term) {
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(`(?:^|[\\s,;:()/\\-])${escaped}(?:$|[\\s,;:()/\\-])`, "i");
  return regex.test(text2);
}
function isUNOrganization(orgName) {
  const lower = orgName.toLowerCase();
  if (UN_FULL_NAMES.some((name) => lower.includes(name.toLowerCase()))) return true;
  if (UN_ACRONYMS.some((acr) => lower.includes(acr.toLowerCase()))) return true;
  if (UN_EXACT_MATCH.some((exact) => matchesWordBoundary(orgName, exact))) return true;
  return false;
}
function isNGOOrganization(orgName) {
  const lower = orgName.toLowerCase();
  if (NGO_FULL_NAMES.some((name) => lower.includes(name.toLowerCase()))) return true;
  if (NGO_ACRONYMS.some((acr) => lower.includes(acr.toLowerCase()))) return true;
  if (NGO_EXACT_MATCH.some((exact) => matchesWordBoundary(orgName, exact))) return true;
  return false;
}
function detectCategory(orgName, defaultCategory) {
  if (isUNOrganization(orgName)) return "un";
  if (isNGOOrganization(orgName)) return "ngo";
  return defaultCategory;
}
function sanitizeDescription(html) {
  if (!html) return "";
  return (0, import_sanitize_html.default)(html, {
    allowedTags: ["b", "i", "em", "strong", "p", "br", "ul", "ol", "li", "h2", "h3", "h4", "a", "span"],
    allowedAttributes: {
      a: ["href", "target", "rel"]
    }
  });
}
function assignSkillCategory(title, description, sourceCategory) {
  const skill = classifyJobSkillCategory(title, description);
  if (skill) return skill;
  if (sourceCategory === "remote") return "technology";
  if (sourceCategory === "international") return "business";
  if (sourceCategory === "ngo") return "business";
  if (sourceCategory === "un") return "business";
  return "business";
}
var FRESHNESS_DAYS = 30;
var MIN_DESCRIPTION_LENGTH = 300;
var MIN_DESCRIPTION_WORDS = 150;
function isWithinDays(dateStr, days) {
  if (!dateStr) return false;
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return false;
  const cutoff = /* @__PURE__ */ new Date();
  cutoff.setDate(cutoff.getDate() - days);
  return date >= cutoff;
}
async function fetchReliefWebJobs() {
  const allJobs = [];
  try {
    let page = 0;
    while (true) {
      const reliefUrl = "https://api.reliefweb.int/v2/jobs?appname=TrendNova-v5ofdaDo&limit=1000&offset=" + page * 1e3;
      const fromDate = new Date(Date.now() - FRESHNESS_DAYS * 24 * 60 * 60 * 1e3);
      const fromDateStr = fromDate.toISOString().replace("Z", "+00:00").replace(/\.\d{3}/, "");
      const reliefBody = {
        fields: {
          include: ["title", "body", "url", "source.name", "country.name", "date.created", "date.closing", "type.name"]
        },
        sort: ["date.created:desc"],
        filter: {
          field: "date.created",
          value: {
            from: fromDateStr
          }
        }
      };
      const res = await fetchWithRetry(reliefUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reliefBody),
        signal: AbortSignal.timeout(3e4)
      });
      if (!res.ok) {
        log(`ReliefWeb: API returned ${res.status} ${res.statusText}`, "jobFetcher");
        break;
      }
      const data = await res.json();
      const items = data.data || [];
      log(`ReliefWeb page ${page}: totalCount=${data.totalCount || 0}, items=${items.length}`, "jobFetcher");
      if (items.length === 0) break;
      for (const item of items) {
        const fields = item.fields;
        if (!isWithinDays(fields.date?.created, FRESHNESS_DAYS)) continue;
        const orgName = fields.source?.[0]?.name || "Unknown";
        const isUN = isUNOrganization(orgName);
        const country = fields.country?.map((c) => c.name).join(", ") || "";
        const title = fields.title || "Untitled";
        const desc2 = sanitizeDescription(fields.body);
        const sourceCategory = isUN ? "un" : "ngo";
        allJobs.push({
          title,
          organization: orgName,
          location: country,
          category: sourceCategory,
          description: desc2,
          url: fields.url,
          source: "ReliefWeb",
          sourceId: `reliefweb-${item.id}`,
          jobType: fields.type?.[0]?.name || null,
          salary: null,
          country: normalizeCountryCode(country, null),
          closingDate: fields.date?.closing ? new Date(fields.date.closing) : null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, sourceCategory)
        });
      }
      if (items.length < 1e3) break;
      page++;
    }
    log(`ReliefWeb: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`ReliefWeb error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchRemoteOKJobs() {
  const allJobs = [];
  try {
    const res = await fetchWithRetry("https://remoteok.com/api", {
      headers: { "User-Agent": "DevGlobalJobs/1.0" },
      signal: AbortSignal.timeout(15e3)
    });
    if (!res.ok) return [];
    const data = await res.json();
    for (const item of data.slice(1)) {
      if (!item.position) continue;
      if (!isWithinDays(item.date, FRESHNESS_DAYS)) continue;
      const title = item.position;
      const desc2 = sanitizeDescription(item.description);
      const loc = item.location || "Remote";
      allJobs.push({
        title,
        organization: item.company || "Unknown",
        location: loc,
        category: "remote",
        description: desc2,
        url: item.url || item.apply_url,
        source: "RemoteOK",
        sourceId: `remoteok-${item.id}`,
        jobType: "Full-time",
        salary: item.salary || null,
        country: normalizeCountryCode(loc, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc2, "remote")
      });
    }
    log(`RemoteOK: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`RemoteOK error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchRemotiveJobs() {
  const allJobs = [];
  try {
    const res = await fetchWithRetry("https://remotive.com/api/remote-jobs?limit=0", {
      signal: AbortSignal.timeout(3e4)
    });
    if (!res.ok) return [];
    const data = await res.json();
    for (const item of data.jobs || []) {
      if (!isWithinDays(item.publication_date, FRESHNESS_DAYS)) continue;
      const title = item.title;
      const desc2 = sanitizeDescription(item.description);
      const remotiveLoc = item.candidate_required_location || "Remote";
      allJobs.push({
        title,
        organization: item.company_name || "Unknown",
        location: remotiveLoc,
        category: "remote",
        description: desc2,
        url: item.url,
        source: "Remotive",
        sourceId: `remotive-${item.id}`,
        jobType: item.job_type?.replace(/_/g, " ") || "Full-time",
        salary: item.salary || null,
        country: normalizeCountryCode(remotiveLoc, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc2, "remote")
      });
    }
    log(`Remotive: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`Remotive error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchJobicyJobs() {
  const allJobs = [];
  try {
    const res = await fetchWithRetry("https://jobicy.com/api/v2/remote-jobs?count=500", {
      signal: AbortSignal.timeout(2e4)
    });
    if (!res.ok) return [];
    const data = await res.json();
    for (const item of data.jobs || []) {
      if (!isWithinDays(item.pubDate, FRESHNESS_DAYS)) continue;
      const title = item.jobTitle;
      const desc2 = sanitizeDescription(item.jobDescription);
      const jobicyLoc = item.jobGeo || "Remote";
      allJobs.push({
        title,
        organization: item.companyName || "Unknown",
        location: jobicyLoc,
        category: "remote",
        description: desc2,
        url: item.url,
        source: "Jobicy",
        sourceId: `jobicy-${item.id}`,
        jobType: item.jobType || "Full-time",
        salary: item.annualSalaryMin && item.annualSalaryMax ? `$${item.annualSalaryMin} - $${item.annualSalaryMax}` : null,
        country: normalizeCountryCode(jobicyLoc, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc2, "remote")
      });
    }
    log(`Jobicy: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`Jobicy error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchArbeitnowJobs() {
  const allJobs = [];
  try {
    let page = 1;
    while (true) {
      const res = await fetchWithRetry(`https://www.arbeitnow.com/api/job-board-api?page=${page}`, {
        signal: AbortSignal.timeout(2e4)
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.data || [];
      if (items.length === 0) break;
      let pageHasFresh = false;
      for (const item of items) {
        if (!isWithinDays(item.created_at, FRESHNESS_DAYS)) continue;
        pageHasFresh = true;
        const title = item.title;
        const desc2 = sanitizeDescription(item.description);
        const isRemote = item.remote;
        const arbLoc = item.location || (isRemote ? "Remote" : "International");
        allJobs.push({
          title,
          organization: item.company_name || "Unknown",
          location: arbLoc,
          category: isRemote ? "remote" : detectCategory(item.company_name || "Unknown", "international"),
          description: desc2,
          url: item.url,
          source: "Arbeitnow",
          sourceId: `arbeitnow-${item.slug}`,
          jobType: "Full-time",
          salary: null,
          country: normalizeCountryCode(arbLoc, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, isRemote ? "remote" : "international")
        });
      }
      if (!pageHasFresh) break;
      page++;
    }
    log(`Arbeitnow: fetched ${allJobs.length} jobs (${page - 1} pages)`, "jobFetcher");
  } catch (err) {
    log(`Arbeitnow error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchTheMuseJobs() {
  const allJobs = [];
  try {
    let page = 1;
    while (true) {
      const res = await fetchWithRetry(`https://www.themuse.com/api/public/jobs?page=${page}&descending=true`, {
        signal: AbortSignal.timeout(2e4)
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.results || [];
      if (items.length === 0) break;
      let pageHasFresh = false;
      for (const item of items) {
        if (!isWithinDays(item.publication_date, FRESHNESS_DAYS)) continue;
        pageHasFresh = true;
        const location = item.locations?.map((l) => l.name).join(", ") || "Global";
        const title = item.name;
        const desc2 = sanitizeDescription(item.contents);
        allJobs.push({
          title,
          organization: item.company?.name || "Unknown",
          location,
          category: detectCategory(item.company?.name || "Unknown", "international"),
          description: desc2,
          url: item.refs?.landing_page,
          source: "The Muse",
          sourceId: `themuse-${item.id}`,
          jobType: item.type || "Full-time",
          salary: null,
          country: normalizeCountryCode(location, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, "international")
        });
      }
      if (!pageHasFresh) break;
      page++;
    }
    log(`TheMuse: fetched ${allJobs.length} jobs (${page - 1} pages)`, "jobFetcher");
  } catch (err) {
    log(`TheMuse error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchHimalayasJobs() {
  const allJobs = [];
  try {
    let offset = 0;
    const batchSize = 500;
    while (true) {
      const res = await fetchWithRetry(`https://himalayas.app/jobs/api?limit=${batchSize}&offset=${offset}`, {
        signal: AbortSignal.timeout(3e4)
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.jobs || [];
      if (items.length === 0) break;
      let pageHasFresh = false;
      for (const item of items) {
        if (!isWithinDays(item.pubDate || item.updated, FRESHNESS_DAYS)) continue;
        pageHasFresh = true;
        const title = item.title;
        const desc2 = sanitizeDescription(item.description || item.excerpt);
        const location = item.locationRestrictions?.join(", ") || "Remote";
        const salary = item.minSalary && item.maxSalary ? `${item.currency || "$"}${item.minSalary.toLocaleString()} - ${item.currency || "$"}${item.maxSalary.toLocaleString()}` : null;
        allJobs.push({
          title,
          organization: item.companyName || "Unknown",
          location,
          category: "remote",
          description: desc2,
          url: item.applicationLink || `https://himalayas.app/jobs/${item.guid}`,
          source: "Himalayas",
          sourceId: `himalayas-${item.guid}`,
          jobType: item.employmentType || "Full-time",
          salary,
          country: normalizeCountryCode(location, null),
          closingDate: item.expiryDate ? new Date(item.expiryDate) : null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, "remote")
        });
      }
      if (!pageHasFresh || items.length < batchSize) break;
      offset += batchSize;
    }
    log(`Himalayas: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`Himalayas error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchWorkingNomadsJobs() {
  const allJobs = [];
  try {
    const res = await fetchWithRetry("https://www.workingnomads.com/api/exposed_jobs/", {
      signal: AbortSignal.timeout(15e3)
    });
    if (!res.ok) return [];
    const data = await res.json();
    for (const item of data || []) {
      if (!item.title) continue;
      if (!isWithinDays(item.pub_date, FRESHNESS_DAYS)) continue;
      const title = item.title;
      const desc2 = sanitizeDescription(item.description);
      const location = item.location || "Remote";
      allJobs.push({
        title,
        organization: item.company_name || "Unknown",
        location,
        category: "remote",
        description: desc2,
        url: item.url,
        source: "WorkingNomads",
        sourceId: `workingnomads-${item.id || item.url}`,
        jobType: "Full-time",
        salary: null,
        country: normalizeCountryCode(location, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc2, "remote")
      });
    }
    log(`WorkingNomads: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`WorkingNomads error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
var ADZUNA_COUNTRIES = ["us", "gb", "ca", "au", "in", "de", "fr", "nz", "za", "nl"];
var ADZUNA_MAX_PAGES_PER_COUNTRY = 4;
var ADZUNA_DAILY_CALL_LIMIT = 200;
var lastAdzunaFetch = 0;
var ADZUNA_FETCH_INTERVAL = 4 * 60 * 60 * 1e3;
var adzunaDayCallCount = 0;
var adzunaLastResetDay = -1;
function checkAndResetAdzunaDaily() {
  const today = (/* @__PURE__ */ new Date()).getUTCDay();
  if (today !== adzunaLastResetDay) {
    adzunaDayCallCount = 0;
    adzunaLastResetDay = today;
  }
}
async function fetchAdzunaJobs() {
  const now = Date.now();
  if (lastAdzunaFetch > 0 && now - lastAdzunaFetch < ADZUNA_FETCH_INTERVAL) {
    return [];
  }
  checkAndResetAdzunaDaily();
  if (adzunaDayCallCount >= ADZUNA_DAILY_CALL_LIMIT) {
    log(`Adzuna: daily call limit reached (${adzunaDayCallCount}/${ADZUNA_DAILY_CALL_LIMIT}), skipping`, "jobFetcher");
    return [];
  }
  const allJobs = [];
  const appId = process.env.ADZUNA_APP_ID;
  const appKey = process.env.ADZUNA_APP_KEY;
  if (!appId || !appKey) {
    log("Adzuna: skipping (no API keys configured)", "jobFetcher");
    return [];
  }
  try {
    for (const country of ADZUNA_COUNTRIES) {
      if (adzunaDayCallCount >= ADZUNA_DAILY_CALL_LIMIT) {
        log(`Adzuna: daily limit hit mid-fetch, stopping at country ${country}`, "jobFetcher");
        break;
      }
      try {
        let page = 1;
        while (page <= ADZUNA_MAX_PAGES_PER_COUNTRY) {
          if (adzunaDayCallCount >= ADZUNA_DAILY_CALL_LIMIT) break;
          const url = `https://api.adzuna.com/v1/api/jobs/${country}/search/${page}?app_id=${appId}&app_key=${appKey}&results_per_page=50&max_days_old=${FRESHNESS_DAYS}&content-type=application/json`;
          const res = await fetchWithRetry(url, { signal: AbortSignal.timeout(2e4) });
          adzunaDayCallCount++;
          if (res.status === 429) {
            log(`Adzuna ${country}: rate limited (429), stopping`, "jobFetcher");
            break;
          }
          if (!res.ok) break;
          const data = await res.json();
          const items = data.results || [];
          if (items.length === 0) break;
          for (const item of items) {
            const title = item.title?.replace(/<[^>]*>/g, "") || "Untitled";
            const desc2 = sanitizeDescription(item.description);
            const location = item.location?.display_name || country.toUpperCase();
            const org = item.company?.display_name || "Unknown";
            const salary = item.salary_min && item.salary_max ? `${item.salary_min.toLocaleString()} - ${item.salary_max.toLocaleString()}` : null;
            const PREMIUM_COUNTRIES = ["us", "gb", "ca", "au", "nz", "de", "nl", "fr"];
            const isSponsored = PREMIUM_COUNTRIES.includes(country) && !!salary;
            allJobs.push({
              title,
              organization: org,
              location,
              category: isSponsored ? "sponsored" : detectCategory(org, "international"),
              description: desc2,
              url: item.redirect_url,
              source: "Adzuna",
              sourceId: `adzuna-${item.id}`,
              jobType: item.contract_type || "Full-time",
              salary,
              country: country.toUpperCase(),
              closingDate: null,
              isEmployerPosted: false,
              applyEmail: null,
              stripePaymentId: null,
              featured: false,
              skillCategory: assignSkillCategory(title, desc2, "international")
            });
          }
          if (items.length < 50) break;
          page++;
        }
      } catch (err) {
        log(`Adzuna ${country}: ${err.message}`, "jobFetcher");
      }
    }
    lastAdzunaFetch = Date.now();
    log(`Adzuna: fetched ${allJobs.length} jobs (${adzunaDayCallCount} API calls used today)`, "jobFetcher");
  } catch (err) {
    log(`Adzuna error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchUSAJobsJobs() {
  const allJobs = [];
  const apiKey = process.env.USAJOBS_API_KEY;
  const email = process.env.USAJOBS_EMAIL || "info@devglobaljobs.com";
  if (!apiKey) {
    log("USAJobs: skipping (no API key configured)", "jobFetcher");
    return [];
  }
  try {
    let page = 1;
    const maxPages = 20;
    while (page <= maxPages) {
      const url = `https://data.usajobs.gov/api/Search?DatePosted=${FRESHNESS_DAYS}&ResultsPerPage=500&Page=${page}`;
      const res = await fetchWithRetry(url, {
        headers: {
          "Authorization-Key": apiKey,
          "User-Agent": email
        },
        signal: AbortSignal.timeout(3e4)
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.SearchResult?.SearchResultItems || [];
      if (items.length === 0) break;
      for (const item of items) {
        const desc_obj = item.MatchedObjectDescriptor;
        if (!desc_obj) continue;
        const title = desc_obj.PositionTitle || "Untitled";
        const org = desc_obj.OrganizationName || desc_obj.DepartmentName || "US Government";
        const location = desc_obj.PositionLocationDisplay || "United States";
        const jobUrl = desc_obj.PositionURI || desc_obj.ApplyURI?.[0] || "";
        const salary = desc_obj.PositionRemuneration?.[0]?.Description || null;
        const schedule = desc_obj.PositionSchedule?.[0]?.Name || "Full-time";
        const qualifications = desc_obj.QualificationSummary || "";
        const duties = desc_obj.UserArea?.Details?.MajorDuties || "";
        const desc2 = sanitizeDescription(`<p>${qualifications}</p><p>${duties}</p>`);
        allJobs.push({
          title,
          organization: org,
          location,
          category: detectCategory(org, "international"),
          description: desc2,
          url: jobUrl,
          source: "USAJobs",
          sourceId: `usajobs-${desc_obj.PositionID || item.MatchedObjectId}`,
          jobType: schedule,
          salary,
          country: "US",
          closingDate: desc_obj.ApplicationCloseDate ? new Date(desc_obj.ApplicationCloseDate) : null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, "international")
        });
      }
      const totalResults = data.SearchResult?.SearchResultCountAll || 0;
      if (page * 500 >= totalResults) break;
      page++;
    }
    log(`USAJobs: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`USAJobs error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function fetchFindWorkJobs() {
  const allJobs = [];
  try {
    let page = 1;
    const maxPages = 10;
    while (page <= maxPages) {
      const res = await fetchWithRetry(`https://findwork.dev/api/jobs/?page=${page}&sort_by=date`, {
        signal: AbortSignal.timeout(15e3)
      });
      if (!res.ok) break;
      const data = await res.json();
      const items = data.results || [];
      if (items.length === 0) break;
      for (const item of items) {
        if (!isWithinDays(item.date_posted, FRESHNESS_DAYS)) continue;
        const title = item.role || "Untitled";
        const desc2 = sanitizeDescription(item.text);
        const location = item.location || (item.remote ? "Remote" : "Global");
        allJobs.push({
          title,
          organization: item.company_name || "Unknown",
          location,
          category: item.remote ? "remote" : detectCategory(item.company_name || "Unknown", "international"),
          description: desc2,
          url: item.url,
          source: "FindWork",
          sourceId: `findwork-${item.id}`,
          jobType: item.employment_type || "Full-time",
          salary: null,
          country: normalizeCountryCode(location, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, item.remote ? "remote" : "international")
        });
      }
      if (!data.next) break;
      page++;
    }
    log(`FindWork: fetched ${allJobs.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`FindWork error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
var rssParser = new import_rss_parser.default();
async function fetchYouthOpportunitiesRSS() {
  const allJobs = [];
  const feeds = [
    { url: "https://opportunitiesforyouth.org/feed/", source: "OpportunitiesForYouth" },
    { url: "https://opportunitiesforyouth.org/category/scholarships/feed/", source: "OpportunitiesForYouth" },
    { url: "https://opportunitiesforyouth.org/category/jobs/fellowship/feed/", source: "OpportunitiesForYouth" },
    { url: "https://scholarshipscorner.website/feed/", source: "ScholarshipsCorner" },
    { url: "https://scholarshipscorner.website/fellowships/feed/", source: "ScholarshipsCorner" },
    { url: "https://www2.fundsforngos.org/category/fellowships/feed/", source: "FundsForNGOs" },
    { url: "https://www2.fundsforngos.org/category/scholarships-2/feed/", source: "FundsForNGOs" }
  ];
  for (const feed of feeds) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      for (const item of parsed.items || []) {
        if (!item.title) continue;
        const title = item.title.trim();
        const link = item.link || "";
        const pubDate = item.pubDate || item.isoDate;
        const desc2 = sanitizeDescription(item["content:encoded"] || item.contentSnippet || item.content || "");
        const sourceId = `${feed.source.toLowerCase()}-${link || title}`;
        if (pubDate && !isWithinDays(pubDate, FRESHNESS_DAYS)) continue;
        allJobs.push({
          title,
          organization: feed.source === "OpportunitiesForYouth" ? "Opportunities For Youth" : feed.source === "ScholarshipsCorner" ? "Scholarships Corner" : "Funds For NGOs",
          location: "Global",
          category: "international",
          description: desc2,
          url: link,
          source: feed.source,
          sourceId,
          jobType: "Fellowship",
          salary: null,
          country: null,
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: "youth"
        });
      }
      log(`${feed.source}: fetched ${parsed.items?.length || 0} items from RSS`, "jobFetcher");
    } catch (err) {
      log(`${feed.source} RSS error: ${err.message}`, "jobFetcher");
    }
  }
  log(`Youth RSS total: fetched ${allJobs.length} opportunities`, "jobFetcher");
  return allJobs;
}
async function fetchGulfJobs() {
  const allJobs = [];
  const gulfFeeds = [
    { url: "https://www.gulftalent.com/jobs/rss", source: "GulfTalent" },
    { url: "https://www.bayt.com/rss/jobs/", source: "Bayt" }
  ];
  const GULF_COUNTRY_CODES = {
    "UAE": "AE",
    "United Arab Emirates": "AE",
    "Dubai": "AE",
    "Abu Dhabi": "AE",
    "Qatar": "QA",
    "Doha": "QA",
    "Saudi Arabia": "SA",
    "KSA": "SA",
    "Riyadh": "SA",
    "Jeddah": "SA",
    "Kuwait": "KW",
    "Oman": "OM",
    "Muscat": "OM",
    "Bahrain": "BH"
  };
  for (const feed of gulfFeeds) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      for (const item of parsed.items || []) {
        if (!item.title) continue;
        const title = item.title.replace(/<[^>]*>/g, "").trim();
        const link = item.link || "";
        const pubDate = item.pubDate || item.isoDate;
        if (pubDate && !isWithinDays(pubDate, FRESHNESS_DAYS)) continue;
        const desc2 = sanitizeDescription(item["content:encoded"] || item.contentSnippet || item.content || item.summary || "");
        const locationRaw = item.location || "";
        const countryCode = Object.entries(GULF_COUNTRY_CODES).find(([k]) => locationRaw.includes(k) || title.includes(k))?.[1] || null;
        const sourceId = `gulf-${feed.source.toLowerCase()}-${link || title}`;
        allJobs.push({
          title,
          organization: item.author || "Gulf Employer",
          location: locationRaw || "Gulf Region",
          category: "sponsored",
          description: desc2,
          url: link,
          source: feed.source,
          sourceId,
          jobType: "Full-time",
          salary: null,
          country: countryCode,
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, "international")
        });
      }
      log(`${feed.source}: fetched ${parsed.items?.length || 0} Gulf jobs`, "jobFetcher");
    } catch (err) {
      log(`${feed.source} RSS error: ${err.message}`, "jobFetcher");
    }
  }
  return allJobs;
}
async function fetchWeWorkRemotelyJobs() {
  const allJobs = [];
  const feeds = [
    { url: "https://weworkremotely.com/remote-jobs.rss", cat: "remote" },
    { url: "https://weworkremotely.com/categories/remote-programming-jobs.rss", cat: "technology" },
    { url: "https://weworkremotely.com/categories/remote-design-jobs.rss", cat: "design" },
    { url: "https://weworkremotely.com/categories/remote-management-and-finance-jobs.rss", cat: "business" },
    { url: "https://weworkremotely.com/categories/remote-customer-support-jobs.rss", cat: "customer-support" },
    { url: "https://weworkremotely.com/categories/remote-devops-sysadmin-jobs.rss", cat: "technology" }
  ];
  for (const feed of feeds) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      for (const item of parsed.items || []) {
        if (!item.title) continue;
        const title = item.title.replace(/<[^>]*>/g, "").trim();
        const link = item.link || "";
        const pubDate = item.pubDate || item.isoDate;
        if (pubDate && !isWithinDays(pubDate, FRESHNESS_DAYS)) continue;
        const desc2 = sanitizeDescription(item["content:encoded"] || item.contentSnippet || item.content || item.summary || "");
        const org = item.author || item["company"] || "Remote Company";
        const sourceId = `weworkremotely-${link || title}`;
        allJobs.push({
          title,
          organization: org,
          location: "Remote / Worldwide",
          category: feed.cat,
          description: desc2,
          url: link,
          source: "WeWorkRemotely",
          sourceId,
          jobType: "Remote",
          salary: null,
          country: null,
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: feed.cat === "technology" ? "technology" : feed.cat === "design" ? "design" : "business"
        });
      }
      log(`WeWorkRemotely (${feed.cat}): fetched ${parsed.items?.length || 0} items`, "jobFetcher");
    } catch (err) {
      log(`WeWorkRemotely RSS error (${feed.cat}): ${err.message}`, "jobFetcher");
    }
  }
  return allJobs;
}
var GREENHOUSE_COMPANIES = [
  "stripe",
  "airbnb",
  "coinbase",
  "doordash",
  "reddit",
  "pinterest",
  "lyft",
  "figma",
  "notion",
  "discord",
  "linear",
  "vercel",
  "shopify",
  "mongodb",
  "elastic",
  "cloudflare",
  "hashicorp",
  "confluent",
  "cockroachdb",
  "sentry",
  "postman",
  "brex",
  "ramp",
  "gusto",
  "rippling",
  "lattice",
  "intercom",
  "zendesk",
  "hubspot",
  "freshworks",
  "datadog",
  "crowdstrike",
  "okta",
  "twilio",
  "amplitude",
  "mixpanel",
  "segment",
  "fivetran",
  "dbt-labs",
  "airtable",
  "webflow",
  "retool",
  "supabase",
  "browserstack",
  "duolingo",
  "grammarly",
  "carta",
  "plaid",
  "robinhood",
  "chime",
  "openai"
];
/* DGJ_ASHBY_EMIRATES_FETCHERS_START */

async function fetchAshbyJobs() {
  const allJobs = [];

  const boards = [
    { slug: "openai", organization: "OpenAI" },
    { slug: "ramp", organization: "Ramp" },
    { slug: "notion", organization: "Notion" },
  ];

  for (const board of boards) {
    try {
      const response = await fetchWithRetry(
        `https://api.ashbyhq.com/posting-api/job-board/${board.slug}`,
        {
          signal: AbortSignal.timeout(45000),
          headers: {
            Accept: "application/json",
            "User-Agent": "DevGlobalJobsBot/1.0 (+https://devglobaljobs.com)",
          },
        }
      );

      if (!response.ok) {
        log(
          `Ashby ${board.organization}: HTTP ${response.status}`,
          "jobFetcher"
        );
        continue;
      }

      const data = await response.json();
      const jobs = Array.isArray(data.jobs) ? data.jobs : [];

      for (const item of jobs) {
        if (!item || !item.id || !item.title || item.isListed === false) {
          continue;
        }

        const description = sanitizeDescription(
          item.descriptionPlain ||
          item.descriptionHtml ||
          ""
        );

        const postalAddress =
          item.address &&
          item.address.postalAddress
            ? item.address.postalAddress
            : {};

        const primaryLocation =
          item.location ||
          postalAddress.addressLocality ||
          (item.isRemote ? "Remote" : "International");

        const secondaryLocations = Array.isArray(item.secondaryLocations)
          ? item.secondaryLocations
              .map((location) => {
                if (typeof location === "string") return location;

                return (
                  location.location ||
                  location.addressLocality ||
                  location.name ||
                  ""
                );
              })
              .filter(Boolean)
          : [];

        const location = [
          primaryLocation,
          ...secondaryLocations,
        ]
          .filter(Boolean)
          .filter((value, index, array) => array.indexOf(value) === index)
          .join(", ");

        const countryName =
          postalAddress.addressCountry ||
          location ||
          null;

        allJobs.push({
          title: item.title,
          organization: board.organization,
          location: location || "International",
          category: item.isRemote
            ? "remote"
            : detectCategory(
                item.department ||
                item.team ||
                board.organization,
                "international"
              ),
          description,
          url: item.applyUrl || item.jobUrl,
          source: "Ashby",
          sourceId: `ashby-${board.slug}-${item.id}`,
          jobType: item.employmentType || "Full-time",
          salary: null,
          country: normalizeCountryCode(countryName, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(
            item.title,
            description,
            item.isRemote ? "remote" : "international"
          ),
        });
      }

      log(
        `Ashby ${board.organization}: fetched ${jobs.length} jobs`,
        "jobFetcher"
      );
    } catch (error) {
      log(
        `Ashby ${board.organization} error: ${error.message}`,
        "jobFetcher"
      );
    }
  }

  log(
    `Ashby total: fetched ${allJobs.length} jobs`,
    "jobFetcher"
  );

  return allJobs;
}

async function fetchEmiratesGroupJobs() {
  const allJobs = [];

  try {
    const response = await fetchWithRetry(
      "https://www.emiratesgroupcareers.com/api/v1/jobs/",
      {
        signal: AbortSignal.timeout(45000),
        headers: {
          Accept: "application/json",
          "User-Agent": "Mozilla/5.0",
        },
      }
    );

    if (!response.ok) {
      log(
        `Emirates Group Careers: HTTP ${response.status}`,
        "jobFetcher"
      );
      return allJobs;
    }

    const data = await response.json();
    const jobs = Array.isArray(data.data) ? data.data : [];

    for (const item of jobs) {
      if (!item || !item.title || !item.redirectionurl) {
        continue;
      }

      const description = sanitizeDescription(
        item.jobdescription || ""
      );

      const location = [
        item.location,
        item.city,
        item.state,
        item.country,
      ]
        .filter(Boolean)
        .filter((value, index, array) => array.indexOf(value) === index)
        .join(", ");

      let closingDate = null;

      if (item.closingdate) {
        const closingValue = Number(item.closingdate);

        closingDate = Number.isFinite(closingValue)
          ? new Date(
              closingValue < 1000000000000
                ? closingValue * 1000
                : closingValue
            )
          : new Date(item.closingdate);

        if (
          closingDate instanceof Date &&
          Number.isNaN(closingDate.getTime())
        ) {
          closingDate = null;
        }
      }

      allJobs.push({
        title: item.title,
        organization:
          item.brand ||
          "Emirates Group",
        location: location || "Dubai, United Arab Emirates",
        category: detectCategory(
          item.category ||
          item.subcategory ||
          item.brand ||
          "Emirates Group",
          "international"
        ),
        description,
        url: item.redirectionurl,
        source: "EmiratesGroupCareers",
        sourceId: `emirates-${item.id || item.reqid || item.reqno}`,
        jobType: "Full-time",
        salary: null,
        country: normalizeCountryCode(
          item.country || location,
          null
        ),
        closingDate,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(
          item.title,
          description,
          "international"
        ),
      });
    }

    log(
      `Emirates Group Careers: fetched ${allJobs.length} jobs`,
      "jobFetcher"
    );
  } catch (error) {
    log(
      `Emirates Group Careers error: ${error.message}`,
      "jobFetcher"
    );
  }

  return allJobs;
}

/* DGJ_ASHBY_EMIRATES_FETCHERS_END */

async function fetchGreenhouseJobs() {
  const allJobs = [];
  const results = await Promise.allSettled(
    GREENHOUSE_COMPANIES.map(async (company) => {
      const url = `https://boards-api.greenhouse.io/v1/boards/${company}/jobs?content=true`;
      const res = await fetchWithRetry(url, { signal: AbortSignal.timeout(15e3) }, 2);
      if (!res.ok) return [];
      const data = await res.json();
      const jobs2 = [];
      for (const job of data.jobs || []) {
        const title = job.title || "Untitled";
        const desc2 = sanitizeDescription(job.content || job.description || "");
        const locationName = job.location?.name || "Remote / Worldwide";
        const deptName = job.departments?.[0]?.name || "General";
        const updatedAt = job.updated_at;
        if (updatedAt && !isWithinDays(updatedAt, FRESHNESS_DAYS)) continue;
        jobs2.push({
          title,
          organization: company.charAt(0).toUpperCase() + company.slice(1).replace(/-/g, " "),
          location: locationName,
          category: detectCategory(company, "technology"),
          description: desc2,
          url: job.absolute_url || `https://boards.greenhouse.io/${company}/jobs/${job.id}`,
          source: "Greenhouse",
          sourceId: `greenhouse-${job.id}`,
          jobType: "Full-time",
          salary: null,
          country: normalizeCountryCode(locationName, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, "technology")
        });
      }
      return jobs2;
    })
  );
  let total = 0;
  for (const r of results) {
    if (r.status === "fulfilled") {
      allJobs.push(...r.value);
      total += r.value.length;
    }
  }
  log(`Greenhouse: fetched ${total} jobs from ${GREENHOUSE_COMPANIES.length} companies`, "jobFetcher");
  return allJobs;
}
var LEVER_COMPANIES = [
  "netflix",
  "khan-academy",
  "carta",
  "remote",
  "deel",
  "gofundme",
  "duolingo",
  "canva",
  "loom",
  "pitch",
  "doist",
  "basecamp",
  "automattic",
  "close",
  "zapier",
  "invision",
  "mattermost",
  "aha",
  "superside",
  "toptal",
  "crossover",
  "X-team",
  "convertkit",
  "calendly",
  "bevy",
  "hotjar",
  "netlify"
];
async function fetchLeverJobs() {
  const allJobs = [];
  const results = await Promise.allSettled(
    LEVER_COMPANIES.map(async (company) => {
      const url = `https://api.lever.co/v0/postings/${company}?mode=json`;
      const res = await fetchWithRetry(url, { signal: AbortSignal.timeout(15e3) }, 2);
      if (!res.ok) return [];
      const data = await res.json();
      const jobs2 = [];
      for (const job of Array.isArray(data) ? data : []) {
        const title = job.text || "Untitled";
        const desc2 = sanitizeDescription(job.descriptionBody || job.description || "");
        const locationName = job.categories?.location || job.workplaceType || "Remote / Worldwide";
        const team = job.categories?.team || "General";
        const createdAt = job.createdAt ? new Date(job.createdAt).toISOString() : null;
        if (createdAt && !isWithinDays(createdAt, FRESHNESS_DAYS)) continue;
        jobs2.push({
          title,
          organization: company.charAt(0).toUpperCase() + company.slice(1).replace(/-/g, " "),
          location: locationName,
          category: detectCategory(company, "technology"),
          description: desc2,
          url: job.hostedUrl || job.applyUrl || "",
          source: "Lever",
          sourceId: `lever-${job.id}`,
          jobType: job.categories?.commitment || "Full-time",
          salary: null,
          country: normalizeCountryCode(locationName, null),
          closingDate: null,
          isEmployerPosted: false,
          applyEmail: null,
          stripePaymentId: null,
          featured: false,
          skillCategory: assignSkillCategory(title, desc2, "technology")
        });
      }
      return jobs2;
    })
  );
  let total = 0;
  for (const r of results) {
    if (r.status === "fulfilled") {
      allJobs.push(...r.value);
      total += r.value.length;
    }
  }
  log(`Lever: fetched ${total} jobs from ${LEVER_COMPANIES.length} companies`, "jobFetcher");
  return allJobs;
}
async function fetchNoFluffJobs() {
  const allJobs = [];
  try {
    const res = await fetchWithRetry("https://nofluffjobs.com/api/posting?salaryCurrency=USD&salaryPeriod=month", { signal: AbortSignal.timeout(15e3) }, 2);
    if (!res.ok) {
      log(`NoFluffJobs: HTTP ${res.status}`, "jobFetcher");
      return [];
    }
    const data = await res.json();
    const postings = data.postings || [];
    for (const item of postings) {
      const title = item.title || "Untitled";
      const org = item.name || item.company?.name || "Unknown Company";
      const cityRaw = item.location?.places?.[0]?.city;
      const locationName = (typeof cityRaw === "string" ? cityRaw : null) || (typeof item.location?.place === "string" ? item.location.place : null) || "Remote";
      const countryRaw = item.location?.places?.[0]?.country;
      const countryStr = typeof countryRaw === "string" ? countryRaw : countryRaw && typeof countryRaw === "object" ? countryRaw.name || null : null;
      const desc2 = sanitizeDescription((Array.isArray(item.requirements) ? item.requirements.join("\n") : "") || (typeof item.description === "string" ? item.description : "") || "");
      const salary = item.salary ? `${item.salary.from || ""} - ${item.salary.to || ""} ${item.salary.currency || ""}`.trim() : null;
      allJobs.push({
        title,
        organization: org,
        location: locationName,
        category: detectCategory(org, "technology"),
        description: desc2,
        url: `https://nofluffjobs.com/job/${item.id}`,
        source: "NoFluffJobs",
        sourceId: `nofluff-${item.id}`,
        jobType: item.seniority?.[0] || "Full-time",
        salary,
        country: normalizeCountryCode(countryStr || locationName, null),
        closingDate: null,
        isEmployerPosted: false,
        applyEmail: null,
        stripePaymentId: null,
        featured: false,
        skillCategory: assignSkillCategory(title, desc2, "technology")
      });
    }
    log(`NoFluffJobs: fetched ${postings.length} jobs`, "jobFetcher");
  } catch (err) {
    log(`NoFluffJobs error: ${err.message}`, "jobFetcher");
  }
  return allJobs;
}
async function deduplicateAndStore(newJobs) {
  const uniqueJobs = [];
  const seenKeys = /* @__PURE__ */ new Set();
  let shortDescFiltered = 0;
  for (const job of newJobs) {
    const plainDesc = (job.description || "").replace(/<[^>]*>/g, "").trim();
    const _wc = plainDesc.split(/\s+/).filter(Boolean).length;
    if (plainDesc.length < MIN_DESCRIPTION_LENGTH || _wc < MIN_DESCRIPTION_WORDS) {
      shortDescFiltered++;
      continue;
    }
    const key = job.sourceId || `${job.source}-${job.title}-${job.organization}`;
    if (seenKeys.has(key)) continue;
    seenKeys.add(key);
    uniqueJobs.push(job);
  }
  if (shortDescFiltered > 0) {
    log(`Filtered ${shortDescFiltered} jobs with descriptions < ${MIN_DESCRIPTION_WORDS} words (< ${MIN_DESCRIPTION_LENGTH} chars)`, "jobFetcher");
  }
  if (uniqueJobs.length > 0) {
    const insertedIds = await storage.insertJobsReturningIds(uniqueJobs);
    if (insertedIds.length > 0) {
      queueNewJobUrls(insertedIds);
    }
    return insertedIds.length;
  }
  return 0;
}
var MAX_CYCLES = 10;
var fetchCycleLogs = [];
function getAllFetchCycles() {
  return fetchCycleLogs;
}
async function fetchAllJobs() {
  log("Starting job fetch cycle...", "jobFetcher");
  const cycleAt = (/* @__PURE__ */ new Date()).toISOString();
  try {
    const results = await Promise.allSettled([
      fetchReliefWebJobs(),
      fetchRemoteOKJobs(),
      fetchRemotiveJobs(),
      fetchJobicyJobs(),
      fetchArbeitnowJobs(),
      fetchTheMuseJobs(),
      fetchHimalayasJobs(),
      fetchWorkingNomadsJobs(),
      fetchAdzunaJobs(),
      fetchUSAJobsJobs(),
      fetchYouthOpportunitiesRSS(),
      fetchWeWorkRemotelyJobs(),
      fetchGulfJobs(),
      fetchAshbyJobs(),
      fetchEmiratesGroupJobs(),
      fetchGreenhouseJobs(),
      fetchLeverJobs(),
      fetchNoFluffJobs()
    ]);
    const allJobs = [];
    const sourceNames = [
      "ReliefWeb",
      "RemoteOK",
      "Remotive",
      "Jobicy",
      "Arbeitnow",
      "TheMuse",
      "Himalayas",
      "WorkingNomads",
      "Adzuna",
      "USAJobs",
      "YouthRSS",
      "WeWorkRemotely",
      "GulfJobs",
      "Ashby",
      "EmiratesGroupCareers",
      "Greenhouse",
      "Lever",
      "NoFluffJobs"
    ];
    let successCount = 0;
    let failCount = 0;
    const sourceStatuses = [];
    for (let i = 0; i < results.length; i++) {
      const result = results[i];
      if (result.status === "fulfilled") {
        allJobs.push(...result.value);
        successCount++;
        const count = result.value.length;
        if (count === 0) {
          log(`${sourceNames[i]}: returned 0 jobs`, "jobFetcher");
        }
        sourceStatuses.push({ name: sourceNames[i], status: count === 0 ? "empty" : "ok", jobsFetched: count, lastFetchAt: cycleAt });
      } else {
        log(`${sourceNames[i]}: failed - ${result.reason}`, "jobFetcher");
        failCount++;
        sourceStatuses.push({ name: sourceNames[i], status: "error", jobsFetched: 0, lastError: String(result.reason), lastFetchAt: cycleAt });
      }
    }
    const insertedCount = await deduplicateAndStore(allJobs);
    log(`Job fetch complete: ${allJobs.length} fetched from ${successCount} sources, ${insertedCount} new jobs stored, ${failCount} sources failed`, "jobFetcher");
    fetchCycleLogs.unshift({ cycleAt, totalFetched: allJobs.length, newStored: insertedCount, successCount, failCount, sources: sourceStatuses });
    if (fetchCycleLogs.length > MAX_CYCLES) fetchCycleLogs.splice(MAX_CYCLES);
    const totalSources = results.length;
    const successRate = successCount / totalSources;
    const currentTotal = (await storage.getJobStats()).total || 0;
    const MIN_JOBS_FOR_CLEANUP = 5e3;
    const MIN_SUCCESS_RATE = 0.5;
    if (successRate >= MIN_SUCCESS_RATE && currentTotal > MIN_JOBS_FOR_CLEANUP) {
      const cleanupStats = await storage.runFullCleanup();
      const totalCleaned = cleanupStats.expiredByClosingDate + cleanupStats.staleJobs + cleanupStats.employerRegular + cleanupStats.employerFeatured + cleanupStats.duplicates;
      log(`Auto-cleanup complete: ${totalCleaned} jobs removed [expired closing dates: ${cleanupStats.expiredByClosingDate}, stale 30d+: ${cleanupStats.staleJobs}, employer regular 30d+: ${cleanupStats.employerRegular}, employer featured 60d+: ${cleanupStats.employerFeatured}, duplicates: ${cleanupStats.duplicates}]`, "jobFetcher");
    } else {
      log(`Skipping cleanup: ${Math.round(successRate * 100)}% sources succeeded (need ${Math.round(MIN_SUCCESS_RATE * 100)}%), ${currentTotal} total jobs (need ${MIN_JOBS_FOR_CLEANUP}+)`, "jobFetcher");
    }
    if (insertedCount > 0) {
      pingSearchEngines().catch(() => {
      });
    }
  } catch (err) {
    log(`Job fetch cycle error: ${err.message}`, "jobFetcher");
  }
}
var isFetching = false;
async function fetchAllJobsSafe() {
  if (isFetching) {
    log("Fetch already in progress, skipping...", "jobFetcher");
    return;
  }
  isFetching = true;
  try {
    await fetchAllJobs();
  } finally {
    isFetching = false;
  }
}
var FETCH_INTERVAL = 30 * 60 * 1e3;
var CLEANUP_INTERVAL = 6 * 60 * 60 * 1e3;
async function runStartupCleanup() {
  try {
    log("Running startup cleanup (removing duplicates + expired jobs)...", "jobFetcher");
    const stats = await storage.runFullCleanup();
    const total = stats.expiredByClosingDate + stats.staleJobs + stats.employerRegular + stats.employerFeatured + stats.duplicates;
    log(`Startup cleanup done: ${total} jobs removed [expired closing dates: ${stats.expiredByClosingDate}, stale 30d+: ${stats.staleJobs}, employer regular 30d+: ${stats.employerRegular}, employer featured 60d+: ${stats.employerFeatured}, duplicates: ${stats.duplicates}]`, "jobFetcher");
    const jobStats = await storage.getJobStats();
    log(`Database status after cleanup: ${jobStats.total} total jobs`, "jobFetcher");
  } catch (err) {
    log(`Startup cleanup error: ${err.message}`, "jobFetcher");
  }
}
async function runScheduledCleanup() {
  try {
    log("Running scheduled cleanup...", "jobFetcher");
    const stats = await storage.runFullCleanup();
    const total = stats.expiredByClosingDate + stats.staleJobs + stats.employerRegular + stats.employerFeatured + stats.duplicates;
    if (total > 0) {
      log(`Scheduled cleanup: ${total} jobs removed [expired: ${stats.expiredByClosingDate}, stale: ${stats.staleJobs}, emp-regular: ${stats.employerRegular}, emp-featured: ${stats.employerFeatured}, duplicates: ${stats.duplicates}]`, "jobFetcher");
    } else {
      log("Scheduled cleanup: no stale jobs found, database is clean", "jobFetcher");
    }
  } catch (err) {
    log(`Scheduled cleanup error: ${err.message}`, "jobFetcher");
  }
}
var EXPIRED_CLEANUP_INTERVAL = 60 * 60 * 1e3;
async function runExpiredJobsCleanup() {
  try {
    const removed = await storage.removeExpiredClosingDateJobs();
    if (removed > 0) {
      log(`Hourly expired cleanup: removed ${removed} jobs with passed closing dates`, "jobFetcher");
    }
  } catch (err) {
    log(`Hourly expired cleanup error: ${err.message}`, "jobFetcher");
  }
}
function startJobFetchScheduler() {
  runStartupCleanup().then(() => {
    fetchAllJobsSafe();
  });
  setInterval(() => {
    fetchAllJobsSafe();
  }, FETCH_INTERVAL);
  setInterval(() => {
    runScheduledCleanup();
  }, CLEANUP_INTERVAL);
  setInterval(() => {
    runExpiredJobsCleanup();
  }, EXPIRED_CLEANUP_INTERVAL);
  log(`Job fetch scheduler started (fetch every ${FETCH_INTERVAL / 6e4} min, cleanup every ${CLEANUP_INTERVAL / 36e5} hrs)`, "jobFetcher");
}

// server/googleIndexing.ts
var import_google_auth_library = require("google-auth-library");
var INDEXING_API_URL = "https://indexing.googleapis.com/v3/urlNotifications:publish";
var SCOPES = ["https://www.googleapis.com/auth/indexing"];
var BASE_URL2 = "https://devglobaljobs.com";
var authClient = null;
function getAuthClient() {
  if (authClient) return authClient;
  const saJson = process.env.GOOGLE_INDEXING_SA_JSON;
  if (!saJson) {
    log("Google Indexing API: GOOGLE_INDEXING_SA_JSON not set \u2014 skipping", "seo");
    return null;
  }
  try {
    const credentials = JSON.parse(saJson);
    authClient = new import_google_auth_library.GoogleAuth({
      credentials,
      scopes: SCOPES
    });
    return authClient;
  } catch (e) {
    log("Google Indexing API: Failed to parse service account JSON", "seo");
    return null;
  }
}
async function getAccessToken() {
  try {
    const auth = getAuthClient();
    if (!auth) return null;
    const client = await auth.getClient();
    const tokenResponse = await client.getAccessToken();
    return tokenResponse.token || null;
  } catch (e) {
    log(`Google Indexing API: Auth error \u2014 ${e.message}`, "seo");
    return null;
  }
}
async function notifyGoogleJobUrl(url, type = "URL_UPDATED") {
  const token = await getAccessToken();
  if (!token) return false;
  try {
    const res = await fetch(INDEXING_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ url, type }),
      signal: AbortSignal.timeout(15e3)
    });
    if (res.ok) {
      log(`Google Indexing API: ${type} submitted for ${url}`, "seo");
      return true;
    } else {
      const body = await res.text();
      log(`Google Indexing API: ${type} failed (${res.status}) for ${url} \u2014 ${body.slice(0, 200)}`, "seo");
      return false;
    }
  } catch (e) {
    log(`Google Indexing API: Request failed for ${url} \u2014 ${e.message}`, "seo");
    return false;
  }
}
var googlePendingUpdates = [];
var googlePendingDeletes = [];
var googleSubmitTimeout = null;
var DAILY_LIMIT = 190;
var dailyCount = 0;
var dailyResetAt = Date.now() + 24 * 60 * 60 * 1e3;
function resetDailyCountIfNeeded() {
  if (Date.now() >= dailyResetAt) {
    dailyCount = 0;
    dailyResetAt = Date.now() + 24 * 60 * 60 * 1e3;
  }
}
async function flushGoogleQueue() {
  resetDailyCountIfNeeded();
  const remaining = DAILY_LIMIT - dailyCount;
  if (remaining <= 0) {
    log(`Google Indexing API: Daily limit reached (${DAILY_LIMIT}/day), skipping`, "seo");
    googlePendingUpdates = [];
    googlePendingDeletes = [];
    return;
  }
  const updates = googlePendingUpdates.splice(0, Math.min(remaining, googlePendingUpdates.length));
  const deletes = googlePendingDeletes.splice(0, Math.min(remaining - updates.length, googlePendingDeletes.length));
  googleSubmitTimeout = null;
  for (const url of updates) {
    if (dailyCount >= DAILY_LIMIT) break;
    const ok = await notifyGoogleJobUrl(url, "URL_UPDATED");
    if (ok) dailyCount++;
    await new Promise((r) => setTimeout(r, 200));
  }
  for (const url of deletes) {
    if (dailyCount >= DAILY_LIMIT) break;
    const ok = await notifyGoogleJobUrl(url, "URL_DELETED");
    if (ok) dailyCount++;
    await new Promise((r) => setTimeout(r, 200));
  }
}
function queueGoogleIndexingUpdate(jobId) {
  const url = `${BASE_URL2}/jobs/detail/${jobId}`;
  if (!googlePendingUpdates.includes(url)) {
    googlePendingUpdates.push(url);
  }
  scheduleFlush();
}
function queueGoogleIndexingDelete(jobId) {
  const url = `${BASE_URL2}/jobs/detail/${jobId}`;
  if (!googlePendingDeletes.includes(url)) {
    googlePendingDeletes.push(url);
  }
  scheduleFlush();
}
function queueGoogleBlogUpdate(slug) {
  const url = `${BASE_URL2}/blog/${slug}`;
  if (!googlePendingUpdates.includes(url)) {
    googlePendingUpdates.push(url);
  }
  scheduleFlush();
}
function queueGoogleBlogDelete(slug) {
  const url = `${BASE_URL2}/blog/${slug}`;
  if (!googlePendingDeletes.includes(url)) {
    googlePendingDeletes.push(url);
  }
  scheduleFlush();
}
function scheduleFlush() {
  if (googleSubmitTimeout) return;
  googleSubmitTimeout = setTimeout(flushGoogleQueue, 60 * 1e3);
}
function getGoogleIndexingStatus() {
  return {
    dailyCount,
    limit: DAILY_LIMIT,
    pendingUpdates: googlePendingUpdates.length,
    pendingDeletes: googlePendingDeletes.length,
    resetsAt: new Date(dailyResetAt).toISOString()
  };
}

// server/adminAuth.ts
var import_crypto = __toESM(require("crypto"), 1);
function hashPassword(password) {
  return import_crypto.default.createHash("sha256").update(password + "dgj-admin-salt-9x2024").digest("hex");
}
var ADMIN_USERS = {
  admin: hashPassword("Imranjakhro123@"),
  imranusmanf6: hashPassword("Imranjakhro12341234@@@2@"),
  maheenbutt110: hashPassword("Imranjakhro123@Maheenbu1122"),
  zakirabbas1: hashPassword("Imranahmedjakhro123222@@@2@3"),
  kinzahayat: hashPassword("Alikhan12345672882223@"),
  dolehkhan1: hashPassword("Usmanjakhro123@@22334")
};
function validateAdminUser(username, password) {
  const storedHash = ADMIN_USERS[username];
  if (!storedHash) return false;
  return storedHash === hashPassword(password);
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.adminUser) {
    return next();
  }
  return res.status(401).json({ message: "Unauthorized" });
}

// server/routes.ts
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var rateLimitStore = /* @__PURE__ */ new Map();
function rateLimit(maxRequests, windowMs) {
  return (req, res, next) => {
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    const entry = rateLimitStore.get(ip);
    if (!entry || now > entry.resetAt) {
      rateLimitStore.set(ip, { count: 1, resetAt: now + windowMs });
      return next();
    }
    if (entry.count >= maxRequests) {
      return res.status(429).json({ message: "Too many requests. Please try again later." });
    }
    entry.count++;
    next();
  };
}
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore) {
    if (now > entry.resetAt) rateLimitStore.delete(key);
  }
}, 6e4);
var cache = /* @__PURE__ */ new Map();
function getCached(key) {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expires) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}
function setCache(key, data, ttlMs) {
  cache.set(key, { data, expires: Date.now() + ttlMs });
}
var CACHE_TTL_STATS = 30 * 1e3;
var CACHE_TTL_FEATURED = 15 * 1e3;
var CACHE_TTL_COUNTRY_STATS = 60 * 1e3;
var VALID_CATEGORIES = [
  "all",
  "un",
  "ngo",
  "remote",
  "international",
  "technology",
  "healthcare",
  "business",
  "education",
  "engineering",
  "creative",
  "sales",
  "gig",
  "youth",
  "sponsored"
];
var BASE_URL3 = "https://devglobaljobs.com";
var MAX_URLS_PER_SITEMAP = 1e4;
var COUNTRY_MAP = {
  uk: { code: "GB", name: "United Kingdom", hreflang: "en-GB" },
  us: { code: "US", name: "United States", hreflang: "en-US" },
  canada: { code: "CA", name: "Canada", hreflang: "en-CA" },
  australia: { code: "AU", name: "Australia", hreflang: "en-AU" },
  germany: { code: "DE", name: "Germany", hreflang: "de-DE" },
  france: { code: "FR", name: "France", hreflang: "fr-FR" },
  india: { code: "IN", name: "India", hreflang: "en-IN" },
  brazil: { code: "BR", name: "Brazil", hreflang: "pt-BR" },
  "south-africa": { code: "ZA", name: "South Africa", hreflang: "en-ZA" },
  netherlands: { code: "NL", name: "Netherlands", hreflang: "nl-NL" },
  poland: { code: "PL", name: "Poland", hreflang: "pl-PL" },
  italy: { code: "IT", name: "Italy", hreflang: "it-IT" },
  belgium: { code: "BE", name: "Belgium", hreflang: "fr-BE" },
  austria: { code: "AT", name: "Austria", hreflang: "de-AT" },
  switzerland: { code: "CH", name: "Switzerland", hreflang: "de-CH" },
  "new-zealand": { code: "NZ", name: "New Zealand", hreflang: "en-NZ" },
  singapore: { code: "SG", name: "Singapore", hreflang: "en-SG" }
};

function dgjEscapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
function renderSeekerAuthPage(options = {}) {
  const pageTitle = dgjEscapeHtml(options.title || "Sign In to Dev Global Jobs");
  const pageDescription = dgjEscapeHtml(options.description || "Secure access to Dev Global Jobs.");
  const pageCanonical = dgjEscapeHtml(options.canonical || "https://devglobaljobs.com/sign-in");
  const pageRobots = dgjEscapeHtml(options.robots || "noindex,nofollow");
  const heading = dgjEscapeHtml(options.heading || "Welcome to Dev Global Jobs");
  const subheading = dgjEscapeHtml(options.subheading || "International Careers · 190+ Countries");
  const intro = dgjEscapeHtml(options.intro || "Use Google or your verified email account to continue securely.");
  const redirectValue = String(options.redirect || "/");
  const redirectJson = JSON.stringify(redirectValue);
  const redirectHtml = dgjEscapeHtml(redirectValue);
  const initialMode = options.initialMode === "signup" ? "signup" : "signin";
  const serverPendingEmail = String(options.pendingEmail || "");
  const initialVerifyError = String(options.verifyError || "");
  const hasServerPendingVerification = !!serverPendingEmail;
  const initialModeJson = JSON.stringify(initialMode);
  const serverPendingEmailJson = JSON.stringify(serverPendingEmail);
  const initialVerifyErrorJson = JSON.stringify(initialVerifyError);
  const signinTabClass = !hasServerPendingVerification && initialMode === "signin" ? "tab active" : "tab";
  const signupTabClass = !hasServerPendingVerification && initialMode === "signup" ? "tab active" : "tab";
  const signinPanelClass = !hasServerPendingVerification && initialMode === "signin" ? "panel active" : "panel";
  const signupPanelClass = !hasServerPendingVerification && initialMode === "signup" ? "panel active" : "panel";
  const authMainStyle = hasServerPendingVerification ? ' style="display:none"' : "";
  const verifyPanelClass = hasServerPendingVerification ? "panel verify active" : "panel verify";
  const initialStatusClass = initialVerifyError ? "status show err" : "status";
  const initialStatusText = dgjEscapeHtml(initialVerifyError);
  if (options.layout === "split") {
    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=5,viewport-fit=cover"/>
<meta name="robots" content="${pageRobots}"/>
<meta name="googlebot" content="${pageRobots}"/>
<meta name="description" content="${pageDescription}"/>
<link rel="canonical" href="${pageCanonical}"/>
<title>${pageTitle}</title>
<link rel="icon" href="/favicon.png"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300..800&display=swap" rel="stylesheet"/>
<script src="https://accounts.google.com/gsi/client" async defer></script>
<style>
:root{color-scheme:light;--navy:#17263a;--cyan300:#67e8f9;--cyan700:#0369a1;--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;--ok:#047857;--bad:#b91c1c}
*{box-sizing:border-box}
html,body{margin:0;padding:0;max-width:100%;overflow-x:hidden}
html{min-height:100%;-webkit-text-size-adjust:100%;text-size-adjust:100%}
body{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;min-height:100vh;min-height:100dvh;background:#fff;color:var(--ink)}
.split-shell{display:flex;min-height:100vh;min-height:100dvh}
.brand-panel{display:none}
@media(min-width:1024px){
.brand-panel{display:flex;flex-direction:column;justify-content:space-between;width:42%;background:var(--navy);color:#cbd5e1;padding:44px 40px;position:relative;overflow:hidden}
}
.brand-logo-row{display:flex;align-items:center;gap:12px}
.brand-logo-badge{display:flex;align-items:center;justify-content:center;background:#fff;border-radius:12px;padding:8px 10px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
.brand-logo-badge img{height:26px;width:auto;display:block}
.brand-eyebrow{font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--cyan300);font-weight:700}
.brand-heading{margin-top:52px;font-size:clamp(26px,3vw,34px);font-weight:800;line-height:1.15;letter-spacing:-.03em;color:#fff}
.brand-sub{margin-top:14px;max-width:360px;font-size:14px;line-height:1.6;color:#94a3b8}
.brand-features{display:flex;flex-direction:column;gap:14px}
.brand-feature{display:flex;gap:12px;align-items:flex-start;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);border-radius:16px;padding:16px}
.brand-feature svg{flex-shrink:0;margin-top:2px}
.brand-feature p{margin:0;font-size:12.5px;line-height:1.55;color:#94a3b8}
.brand-feature b{color:#fff}
.auth-col{flex:1;display:flex;flex-direction:column;min-height:100vh;min-height:100dvh;background:#fff}
.auth-col-scroll{flex:1;display:flex;flex-direction:column;justify-content:center;padding:40px 20px;width:100%}
.auth-col-inner{width:100%;max-width:420px;margin:0 auto}
.mobile-brand-header{display:flex;align-items:center;gap:10px;margin-bottom:28px}
@media(min-width:1024px){.mobile-brand-header{display:none}}
.mobile-brand-header img{height:34px;width:auto;display:block}
.mobile-brand-header span{font-size:9px;text-transform:uppercase;letter-spacing:.14em;color:var(--cyan700);font-weight:700}
.intro{font-size:13px;line-height:1.55;color:#64748b;margin:0 0 16px}
.status{display:none}
.status.show{display:block;font-size:12.5px;padding:10px 12px;border-radius:10px;margin-bottom:14px}
.status.show.ok{background:#ecfdf5;color:var(--ok)}
.status.show.err{background:#fef2f2;color:var(--bad)}
.status.show.info{background:#eff6ff;color:#1d4ed8}
.google-wrap{display:flex;justify-content:center;width:100%;min-height:44px;overflow:hidden;margin-bottom:16px}
.google-wrap>div,.google-wrap iframe{max-width:100%!important}
.or{display:flex;align-items:center;gap:12px;margin:16px 0}
.or:before,.or:after{content:"";height:1px;flex:1;background:var(--line)}
.or span{font-size:10.5px;color:#94a3b8;font-weight:700;letter-spacing:.35px;text-transform:uppercase}
.tabs{display:grid;grid-template-columns:1fr 1fr;background:#f1f5f9;border-radius:11px;padding:4px;margin-bottom:20px}
.tab{border:0;background:transparent;color:#64748b;font:inherit;font-size:12.5px;font-weight:750;padding:9px 10px;border-radius:8px;cursor:pointer}
.tab.active{background:#fff;color:var(--navy);box-shadow:0 2px 8px rgba(15,23,42,.08)}
.panel{display:none}
.panel.active{display:block}
.field{margin-bottom:14px}
.field label{display:block;font-size:11.5px;font-weight:750;color:#334155;margin:0 0 6px}
.input-wrap{position:relative}
.field input,.field select{width:100%;height:46px;border:1px solid #cbd5e1;border-radius:10px;background:#fff;color:#0f172a;padding:0 12px;font:inherit;font-size:13px;outline:none;transition:border-color .16s,box-shadow .16s}
.field input:focus,.field select:focus{border-color:var(--cyan700);box-shadow:0 0 0 3px rgba(3,105,161,.12)}
.field input::placeholder{color:#94a3b8}
.pass{padding-right:58px!important}
.showpass{position:absolute;right:7px;top:50%;transform:translateY(-50%);border:0;background:#eff6ff;color:#1d4ed8;border-radius:7px;padding:6px 8px;font-size:10.5px;font-weight:750;cursor:pointer}
.hint{font-size:10.5px;color:#64748b;margin-top:5px;line-height:1.45}
.signin-actions{display:flex;justify-content:flex-end;margin:-3px 0 12px}
.forgot{border:0;background:transparent;color:var(--cyan700);font:inherit;font-size:11.5px;font-weight:750;padding:3px 0;cursor:pointer}
.forgot:hover{text-decoration:underline}
.forgot:focus-visible{outline:3px solid rgba(3,105,161,.18);outline-offset:3px;border-radius:4px}
.strength{height:4px;background:#e2e8f0;border-radius:99px;margin-top:7px;overflow:hidden}
.strength>i{display:block;width:0;height:100%;border-radius:99px;background:#94a3b8;transition:width .2s,background .2s}
.btn{width:100%;border:0;border-radius:11px;min-height:46px;padding:11px 14px;font:inherit;font-size:13px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:transform .15s,box-shadow .15s,background .15s}
.btn-primary{background:var(--navy);color:#fff;box-shadow:0 10px 24px rgba(23,38,58,.18)}
.btn-primary:hover{transform:translateY(-1px);box-shadow:0 13px 28px rgba(23,38,58,.24)}
.btn:disabled{opacity:.62;cursor:not-allowed;transform:none}
.btn-ghost{background:#eff6ff;color:var(--cyan700);border:1px solid #bfdbfe;margin-top:8px}
.spinner{display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;border-radius:50%;animation:dgjspin .7s linear infinite;vertical-align:middle}
@keyframes dgjspin{to{transform:rotate(360deg)}}
.verify{text-align:center}
.verify-icon{width:52px;height:52px;border-radius:50%;background:#eff6ff;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;font-size:22px}
.verify h2{font-size:18px;margin:0 0 6px;color:#0f172a}
.verify p{font-size:13px;color:#64748b;margin:0 0 16px;line-height:1.5}
.otp{text-align:center;font-size:24px!important;letter-spacing:10px;font-weight:700}
.verify-meta{font-size:11px;color:#94a3b8;margin-top:12px}
.security{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:24px;padding-top:20px;border-top:1px solid var(--line)}
.security div{text-align:center;padding:8px 4px}
.security b{display:block;font-size:10.5px;color:#334155}
.security span{display:block;font-size:9px;color:#94a3b8;margin-top:2px}
.legal{font-size:10.5px;color:#94a3b8;line-height:1.5;margin-top:18px;text-align:center}
.legal a{color:var(--cyan700);text-decoration:none;font-weight:600}
.footer{padding:16px 20px;text-align:center;font-size:10.5px;color:#94a3b8}
.footer a{color:#64748b;text-decoration:none}
@media(max-width:560px){
body{padding-bottom:env(safe-area-inset-bottom,0px)}
.auth-col-scroll{padding:28px max(16px,env(safe-area-inset-right,0px)) max(24px,env(safe-area-inset-bottom,0px)) max(16px,env(safe-area-inset-left,0px))}
.field input,.field select{height:50px;font-size:16px}
.btn{min-height:50px}
.otp{height:52px!important;font-size:22px!important;letter-spacing:8px}
.security{grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}
.security b{font-size:9.5px}
.security span{font-size:8px}
}
@media(max-width:360px){.brand-heading{font-size:22px}.auth-col-scroll{padding-left:10px;padding-right:10px}}
</style>
</head>
<body>
<div class="split-shell">
<aside class="brand-panel">
<div>
<div class="brand-logo-row">
<div class="brand-logo-badge"><img src="/logo.png" alt="Dev Global Jobs"/></div>
<span class="brand-eyebrow">Job Seeker Access</span>
</div>
<h1 id="auth-title" class="brand-heading">${heading}</h1>
<p class="brand-sub">${subheading}</p>
</div>
<div class="brand-features">
<div class="brand-feature"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#67e8f9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9 12l2 2 4-4"/></svg><p><b>Global opportunities.</b> Search thousands of international roles across 190+ countries.</p></div>
<div class="brand-feature"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#67e8f9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg><p><b>Stay organised.</b> Track applications, save jobs and manage alerts from one dashboard.</p></div>
</div>
</aside>
<div class="auth-col"><div class="auth-col-scroll"><div class="auth-col-inner">
<div class="mobile-brand-header"><img src="/dev-global-jobs-logo-mark.png" alt="Dev Global Jobs"/><span>Job Seeker Access</span></div>
<p class="intro">${intro}</p>
<div id="auth-status" class="${initialStatusClass}" role="status" aria-live="polite">${initialStatusText}</div>
<div class="google-wrap" id="dgj-g-btn" aria-label="Google sign in"></div>
<div class="or"><span>or continue with email</span></div>
<div id="auth-main"${authMainStyle}><div class="tabs" role="tablist"><button type="button" id="tab-signin" class="${signinTabClass}" data-mode="signin" role="tab">Sign In</button><button type="button" id="tab-signup" class="${signupTabClass}" data-mode="signup" role="tab">Create Account</button></div><form id="form-signin" class="${signinPanelClass}" autocomplete="on"><div class="field"><label for="si-email">Email address</label><input id="si-email" name="email" type="email" autocomplete="email" inputmode="email" maxlength="254" required placeholder="you@example.com"/></div><div class="field"><label for="si-password">Password</label><div class="input-wrap"><input id="si-password" class="pass" name="password" type="password" autocomplete="current-password" maxlength="128" required placeholder="Your password"/><button class="showpass" type="button" data-target="si-password">Show</button></div></div><div class="signin-actions"><button id="btn-forgot" class="forgot" type="button">Forgot password?</button></div><button id="btn-signin" class="btn btn-primary" type="submit">Sign In Securely</button><p class="hint" style="text-align:center;margin-top:10px">New to Dev Global Jobs? Choose <strong>Create a job seeker account</strong> above.</p></form><form id="form-signup" class="${signupPanelClass}" autocomplete="on"><div class="field"><label for="su-name">Full name</label><input id="su-name" name="fullName" type="text" autocomplete="name" maxlength="100" required placeholder="Your full name"/></div><div class="field"><label for="su-email">Email address</label><input id="su-email" name="email" type="email" autocomplete="email" inputmode="email" maxlength="254" required placeholder="you@example.com"/></div><div class="field"><label for="su-country">Country</label><select id="su-country" name="country" autocomplete="country-name" required><option value="">Select your country</option></select></div><div class="field"><label for="su-password">Create password</label><div class="input-wrap"><input id="su-password" class="pass" name="password" type="password" autocomplete="new-password" maxlength="128" required placeholder="Create a strong password"/><button class="showpass" type="button" data-target="su-password">Show</button></div><div class="strength" aria-hidden="true"><i id="strength-bar"></i></div><div id="password-hint" class="hint">Use 10+ characters with a mix of uppercase, lowercase, numbers and symbols.</div></div><div class="field"><label for="su-confirm">Confirm password</label><div class="input-wrap"><input id="su-confirm" class="pass" name="confirm" type="password" autocomplete="new-password" maxlength="128" required placeholder="Re-enter your password"/><button class="showpass" type="button" data-target="su-confirm">Show</button></div></div><button id="btn-signup" class="btn btn-primary" type="submit">Create & Verify Account</button><p class="hint" style="text-align:center;margin-top:10px">We will send a 6-digit verification code from <strong>info@devglobaljobs.com</strong>. Your account also joins the free weekly Global Jobs digest; every email includes one-click unsubscribe.</p></form></div><div id="verify-panel" class="${verifyPanelClass}"><div class="verify-icon">✉</div><h2>Verify your email</h2><p>Enter the 6-digit code sent to <strong id="verify-email"></strong>. The code expires in 10 minutes.</p><form id="form-verify" method="post" action="/auth/verify-email" novalidate><input type="hidden" name="redirect" value="${redirectHtml}"/><div class="field"><label for="verify-code">Verification code</label><input id="verify-code" class="otp" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="32" required placeholder="000000" aria-describedby="auth-status"/></div><button id="btn-verify" class="btn btn-primary" type="submit">Verify & Continue</button><button id="btn-resend" class="btn btn-ghost" type="button">Resend Code</button><p class="verify-meta">For your security, verification attempts and resends are rate-limited.</p></form></div><div id="reset-panel" class="panel verify"><div class="verify-icon">↻</div><h2>Reset your password</h2><p id="reset-copy">Enter your verified email address and we will send a secure 6-digit reset code.</p><form id="form-reset-request"><div class="field"><label for="reset-email">Email address</label><input id="reset-email" type="email" autocomplete="email" inputmode="email" maxlength="254" required placeholder="you@example.com"/></div><button id="btn-reset-send" class="btn btn-primary" type="submit">Send Reset Code</button><button id="btn-reset-cancel" class="btn btn-ghost" type="button">Back to Sign In</button></form><form id="form-reset-confirm" style="display:none" novalidate><div class="field"><label for="reset-code">Reset code</label><input id="reset-code" class="otp" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required placeholder="000000"/></div><div class="field"><label for="reset-password">New password</label><div class="input-wrap"><input id="reset-password" class="pass" type="password" autocomplete="new-password" maxlength="128" required placeholder="Create a strong new password"/><button class="showpass" type="button" data-target="reset-password">Show</button></div></div><div class="field"><label for="reset-confirm">Confirm new password</label><div class="input-wrap"><input id="reset-confirm" class="pass" type="password" autocomplete="new-password" maxlength="128" required placeholder="Re-enter new password"/><button class="showpass" type="button" data-target="reset-confirm">Show</button></div></div><button id="btn-reset-confirm" class="btn btn-primary" type="submit">Set New Password</button><button id="btn-reset-back" class="btn btn-ghost" type="button">Back to Sign In</button><p class="verify-meta">Reset codes expire in 10 minutes and can be used only once.</p></form></div><div class="security"><div><b>Verified email</b><span>Account ownership check</span></div><div><b>Secure sessions</b><span>Protected sign-in</span></div><div><b>Privacy-first</b><span>You control applications</span></div></div><p class="legal">By continuing, you agree to our <a href="/terms">Terms of Service</a> and <a href="/privacy">Privacy Policy</a>. Google Sign-In is used only for account authentication.</p>
</div></div>
<div class="footer"><a href="/">Jobs</a> · <a href="/pricing">Pricing</a> · <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a> · © 2026 Dev Global Jobs</div>
</div>
</div>
<script>
(function(){
'use strict';
var CLIENT_ID='76830429948-0afbgal53ch1o03ph8dan9pttp44ngsn.apps.googleusercontent.com';
var REDIRECT=${redirectJson};
var INITIAL_MODE=${initialModeJson};
var SERVER_PENDING_EMAIL=${serverPendingEmailJson};
var INITIAL_VERIFY_ERROR=${initialVerifyErrorJson};
var pendingEmail=SERVER_PENDING_EMAIL||'';try{if(SERVER_PENDING_EMAIL){sessionStorage.setItem('dgjPendingVerificationEmail',SERVER_PENDING_EMAIL);}else{sessionStorage.removeItem('dgjPendingVerificationEmail');}}catch(_storageErr){}
var statusEl=document.getElementById('auth-status');
function status(message,type){if(!message){statusEl.className='status';statusEl.textContent='';return;}statusEl.className='status show '+(type||'info');statusEl.textContent=message;}
if(INITIAL_VERIFY_ERROR){status(INITIAL_VERIFY_ERROR,'err');}
function setBusy(btn,busy,label){if(!btn)return;btn.disabled=!!busy;btn.innerHTML=busy?'<span class="spinner"></span> Please wait…':label;}
function mode(next){status('');if(next==='signup'){pendingEmail='';try{sessionStorage.removeItem('dgjPendingVerificationEmail');}catch(_e){}fetch('/api/seekers/cancel-verification',{method:'POST',credentials:'include'}).catch(function(){});}document.querySelectorAll('.tab').forEach(function(b){b.classList.toggle('active',b.getAttribute('data-mode')===next)});document.getElementById('form-signin').classList.toggle('active',next==='signin');document.getElementById('form-signup').classList.toggle('active',next==='signup');document.getElementById('verify-panel').classList.remove('active');document.getElementById('reset-panel').classList.remove('active');document.getElementById('auth-main').style.display='block';}
document.querySelectorAll('.tab').forEach(function(b){b.addEventListener('click',function(){mode(b.getAttribute('data-mode'))})});
document.querySelectorAll('.showpass').forEach(function(b){b.addEventListener('click',function(){var i=document.getElementById(b.getAttribute('data-target'));if(!i)return;var show=i.type==='password';i.type=show?'text':'password';b.textContent=show?'Hide':'Show';})});
var countryCodes='AF AL DZ AS AD AO AI AQ AG AR AM AW AU AT AZ BS BH BD BB BY BE BZ BJ BM BT BO BQ BA BW BV BR IO BN BG BF BI CV KH CM CA KY CF TD CL CN CX CC CO KM CG CD CK CR CI HR CU CW CY CZ DK DJ DM DO EC EG SV GQ ER EE SZ ET FK FO FJ FI FR GF PF TF GA GM GE DE GH GI GR GL GD GP GU GT GG GN GW GY HT HM VA HN HK HU IS IN ID IR IQ IE IM IL IT JM JP JE JO KZ KE KI KP KR KW KG LA LV LB LS LR LY LI LT LU MO MG MW MY MV ML MT MH MQ MR MU YT MX FM MD MC MN ME MS MA MZ MM NA NR NP NL NC NZ NI NE NG NU NF MK MP NO OM PK PW PS PA PG PY PE PH PN PL PT PR QA RE RO RU RW BL SH KN LC MF PM VC WS SM ST SA SN RS SC SL SG SX SK SI SB SO ZA GS SS ES LK SD SR SJ SE CH SY TW TJ TZ TH TL TG TK TO TT TN TR TM TC TV UG UA AE GB US UM UY UZ VU VE VN VG VI WF EH YE ZM ZW'.split(' ');
try{var dn=new Intl.DisplayNames(['en'],{type:'region'});var items=countryCodes.map(function(c){return{code:c,name:dn.of(c)||c}}).sort(function(a,b){return a.name.localeCompare(b.name)});var sel=document.getElementById('su-country');items.forEach(function(it){var o=document.createElement('option');o.value=it.name;o.textContent=it.name;sel.appendChild(o);});}catch(e){}
var pw=document.getElementById('su-password');var bar=document.getElementById('strength-bar');pw.addEventListener('input',function(){var v=pw.value;var score=0;if(v.length>=10)score++;if(/[a-z]/.test(v)&&/[A-Z]/.test(v))score++;if(/\d/.test(v))score++;if(/[^A-Za-z0-9]/.test(v))score++;var widths=['0%','28%','54%','78%','100%'];var colors=['#cbd5e1','#ef4444','#f59e0b','#3b82f6','#059669'];bar.style.width=widths[score];bar.style.background=colors[score];});
function strongPassword(v){var classes=0;if(/[a-z]/.test(v))classes++;if(/[A-Z]/.test(v))classes++;if(/\d/.test(v))classes++;if(/[^A-Za-z0-9]/.test(v))classes++;return v.length>=10&&classes>=3;}
document.getElementById('form-signin').addEventListener('submit',function(ev){ev.preventDefault();status('');var btn=document.getElementById('btn-signin');setBusy(btn,true,'Sign In Securely');fetch('/api/seekers/login',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:document.getElementById('si-email').value.trim(),password:document.getElementById('si-password').value})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Sign-in failed.');status('Signed in successfully. Redirecting…','ok');window.location.replace(REDIRECT);}).catch(function(e){status(e.message||'Sign-in failed.','err');setBusy(btn,false,'Sign In Securely');});});
document.getElementById('form-signup').addEventListener('submit',function(ev){ev.preventDefault();status('');var password=document.getElementById('su-password').value;var confirm=document.getElementById('su-confirm').value;if(password!==confirm){status('Passwords do not match.','err');return;}if(!strongPassword(password)){status('Use at least 10 characters and combine at least three of: uppercase, lowercase, numbers and symbols.','err');return;}var payload={fullName:document.getElementById('su-name').value.trim(),email:document.getElementById('su-email').value.trim(),country:document.getElementById('su-country').value,password:password};var btn=document.getElementById('btn-signup');setBusy(btn,true,'Create & Verify Account');fetch('/api/seekers/register',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Registration failed.');pendingEmail=payload.email.toLowerCase();sessionStorage.setItem('dgjPendingVerificationEmail',pendingEmail);document.getElementById('verify-email').textContent=pendingEmail;document.getElementById('auth-main').style.display='none';document.getElementById('verify-panel').classList.add('active');document.getElementById('verify-code').focus();status('Verification code sent. Check your inbox and spam folder.','ok');}).catch(function(e){status(e.message||'Registration failed.','err');}).finally(function(){setBusy(btn,false,'Create & Verify Account');});});
function normalizeOtp(value){return String(value||'').replace(/[٠-٩]/g,function(ch){return String('٠١٢٣٤٥٦٧٨٩'.indexOf(ch));}).replace(/[۰-۹]/g,function(ch){return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(ch));}).replace(/[^0-9]/g,'').slice(0,6);}
var verifyCodeInput=document.getElementById('verify-code');
function syncVerifyCode(value){var normalized=normalizeOtp(value);verifyCodeInput.value=normalized;if(normalized.length===6){status('');}return normalized;}
verifyCodeInput.addEventListener('input',function(){syncVerifyCode(this.value);});
verifyCodeInput.addEventListener('paste',function(ev){var clipboard=ev.clipboardData||window.clipboardData;if(!clipboard)return;var normalized=normalizeOtp(clipboard.getData('text'));if(!normalized)return;ev.preventDefault();syncVerifyCode(normalized);setTimeout(function(){verifyCodeInput.focus();verifyCodeInput.setSelectionRange(verifyCodeInput.value.length,verifyCodeInput.value.length);},0);});
// Native server-side verification is the primary path. JavaScript only normalizes the input and provides immediate visual feedback.
document.getElementById('form-verify').addEventListener('submit',function(){var code=syncVerifyCode(verifyCodeInput.value);if(!/^\d{6}$/.test(code)){status('Enter the latest 6-digit verification code.','err');verifyCodeInput.focus();return false;}status('Verifying your email…','info');var btn=document.getElementById('btn-verify');if(btn){btn.disabled=true;btn.innerHTML='<span class="spinner"></span> Please wait…';}return true;});
document.getElementById('btn-resend').addEventListener('click',function(){if(!pendingEmail)return;var btn=this;btn.disabled=true;fetch('/api/seekers/resend-verification',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:pendingEmail})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Could not resend code.');status('A new verification code has been sent.','ok');setTimeout(function(){btn.disabled=false},60000);}).catch(function(e){status(e.message||'Could not resend code.','err');btn.disabled=false;});});
var resetEmail='';
function showReset(){status('');document.getElementById('auth-main').style.display='none';document.getElementById('verify-panel').classList.remove('active');document.getElementById('reset-panel').classList.add('active');var e=document.getElementById('si-email').value.trim();if(e)document.getElementById('reset-email').value=e;document.getElementById('form-reset-request').style.display='block';document.getElementById('form-reset-confirm').style.display='none';document.getElementById('reset-copy').textContent='Enter your verified email address and we will send a secure 6-digit reset code.';document.getElementById('reset-email').focus();}
document.getElementById('btn-forgot').addEventListener('click',showReset);
function backToSignin(){mode('signin');document.getElementById('si-email').focus();}
document.getElementById('btn-reset-cancel').addEventListener('click',backToSignin);document.getElementById('btn-reset-back').addEventListener('click',backToSignin);
document.getElementById('reset-code').addEventListener('input',function(){this.value=this.value.replace(/\D/g,'').slice(0,6)});
document.getElementById('form-reset-request').addEventListener('submit',function(ev){ev.preventDefault();var email=document.getElementById('reset-email').value.trim().toLowerCase();if(!email){status('Enter your email address.','err');return;}var btn=document.getElementById('btn-reset-send');setBusy(btn,true,'Send Reset Code');fetch('/api/seekers/password-reset/request',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:email})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Reset code could not be sent.');resetEmail=email;document.getElementById('form-reset-request').style.display='none';document.getElementById('form-reset-confirm').style.display='block';document.getElementById('reset-copy').textContent='If this email belongs to a Dev Global Jobs account, a 6-digit reset code has been sent. Enter it below with your new password.';status('If an account exists for this email, a reset code has been sent.','ok');document.getElementById('reset-code').focus();}).catch(function(e){status(e.message||'Reset request could not be completed.','err');}).finally(function(){setBusy(btn,false,'Send Reset Code');});});
document.getElementById('form-reset-confirm').addEventListener('submit',function(ev){ev.preventDefault();var code=normalizeOtp(document.getElementById('reset-code').value);document.getElementById('reset-code').value=code;var password=document.getElementById('reset-password').value;var confirm=document.getElementById('reset-confirm').value;if(!/^\d{6}$/.test(code)){status('Enter the 6-digit reset code.','err');return;}if(password!==confirm){status('Passwords do not match.','err');return;}if(!strongPassword(password)){status('Use at least 10 characters and combine at least three of: uppercase, lowercase, numbers and symbols.','err');return;}var btn=document.getElementById('btn-reset-confirm');setBusy(btn,true,'Set New Password');fetch('/api/seekers/password-reset/confirm',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:resetEmail,code:code,password:password})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Password reset failed.');status('Password updated successfully. You can now sign in with your new password.','ok');document.getElementById('si-email').value=resetEmail;document.getElementById('si-password').value='';setTimeout(function(){backToSignin()},900);}).catch(function(e){status(e.message||'Password reset failed.','err');setBusy(btn,false,'Set New Password');});});
function initGoogle(){if(!window.google||!window.google.accounts||!window.google.accounts.id){setTimeout(initGoogle,350);return;}var el=document.getElementById('dgj-g-btn');if(!el)return;google.accounts.id.initialize({client_id:CLIENT_ID,auto_select:false,callback:function(r){status('Signing in with Google…','info');fetch('/api/seekers/google-auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({credential:r.credential}),credentials:'include'}).then(function(res){return res.json().then(function(d){return{ok:res.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Google sign-in failed.');window.location.replace(REDIRECT);}).catch(function(e){status(e.message||'Google sign-in failed.','err');});}});var available=Math.floor(el.getBoundingClientRect().width||360);var buttonWidth=Math.max(220,Math.min(360,available));google.accounts.id.renderButton(el,{theme:'outline',size:'large',text:'continue_with',shape:'rectangular',width:buttonWidth,logo_alignment:'left',locale:'en'});}
if(pendingEmail){document.getElementById('verify-email').textContent=pendingEmail;document.getElementById('auth-main').style.display='none';document.getElementById('verify-panel').classList.add('active');}else{document.getElementById('verify-panel').classList.remove('active');document.getElementById('auth-main').style.display='block';}setTimeout(initGoogle,250);
})();
</script>
</body></html>`;
  }
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=5,viewport-fit=cover"/>
<meta name="robots" content="${pageRobots}"/>
<meta name="googlebot" content="${pageRobots}"/>
<meta name="description" content="${pageDescription}"/>
<link rel="canonical" href="${pageCanonical}"/>
<title>${pageTitle}</title>
<link rel="icon" href="/favicon.png"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300..800&display=swap" rel="stylesheet"/>
<script src="https://accounts.google.com/gsi/client" async defer></script>
<style>
:root{color-scheme:light;--blue:#2563eb;--blue2:#1d4ed8;--navy:#0f1e6e;--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;--soft:#f8fafc;--ok:#047857;--bad:#b91c1c}
*{box-sizing:border-box}html,body{margin:0;padding:0;max-width:100%;overflow-x:hidden}html{min-height:100%;-webkit-text-size-adjust:100%;text-size-adjust:100%}body{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;min-height:100vh;min-height:100dvh;background:radial-gradient(circle at 18% 10%,rgba(37,99,235,.10),transparent 34%),linear-gradient(135deg,#f8fbff 0%,#eef4ff 55%,#f8fafc 100%);color:var(--ink);display:flex;flex-direction:column}
.top-bar{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:14px clamp(16px,3vw,34px);background:rgba(255,255,255,.94);border-bottom:1px solid #e5e7eb;backdrop-filter:blur(12px)}
.brand{display:flex;align-items:center;gap:11px;text-decoration:none;color:inherit}.brand img{width:40px;height:40px;border-radius:10px;box-shadow:0 4px 14px rgba(37,99,235,.12)}.brand strong{display:block;font-size:15px;letter-spacing:-.2px}.brand small{display:block;font-size:10px;color:#64748b;letter-spacing:1.2px;margin-top:1px}.back{font-size:12px;color:var(--blue);text-decoration:none;font-weight:700}
.main{flex:1;display:grid;place-items:center;padding:26px 16px 34px}.shell{width:min(100%,520px)}
.card{background:#fff;border:1px solid rgba(148,163,184,.28);border-radius:24px;overflow:hidden;box-shadow:0 26px 80px rgba(30,64,175,.14)}
.hero{position:relative;background:linear-gradient(135deg,#0f1e6e 0%,#1e3a8a 48%,#2563eb 100%);padding:30px 34px 25px;text-align:center;overflow:hidden}.hero:before{content:"";position:absolute;width:220px;height:220px;border-radius:50%;background:rgba(255,255,255,.08);right:-90px;top:-120px}.hero:after{content:"";position:absolute;width:150px;height:150px;border-radius:50%;background:rgba(255,255,255,.06);left:-70px;bottom:-105px}.logo{position:relative;z-index:1;width:64px;height:64px;border-radius:16px;background:#fff;padding:5px;box-shadow:0 10px 30px rgba(0,0,0,.20);margin:0 auto 13px}.logo img{width:100%;height:100%;object-fit:contain;border-radius:12px}.hero h1{position:relative;z-index:1;color:#fff;margin:0 0 6px;font-size:22px;letter-spacing:-.45px}.hero p{position:relative;z-index:1;color:rgba(255,255,255,.80);margin:0;font-size:12.5px}
.body{padding:24px 30px 28px}.intro{text-align:center;color:#475569;font-size:13.5px;line-height:1.55;margin:0 0 17px}
.google-wrap{display:flex;justify-content:center;width:100%;min-height:44px;overflow:hidden}.google-wrap>div,.google-wrap iframe{max-width:100%!important}.or{display:flex;align-items:center;gap:12px;margin:16px 0}.or:before,.or:after{content:"";height:1px;flex:1;background:var(--line)}.or span{font-size:10.5px;color:#94a3b8;font-weight:700;letter-spacing:.35px;text-transform:uppercase}
.tabs{display:grid;grid-template-columns:1fr 1fr;background:#f1f5f9;border-radius:11px;padding:4px;margin-bottom:18px}.tab{border:0;background:transparent;color:#64748b;font:inherit;font-size:12.5px;font-weight:750;padding:9px 10px;border-radius:8px;cursor:pointer}.tab.active{background:#fff;color:#1e3a8a;box-shadow:0 2px 8px rgba(15,23,42,.08)}
.panel{display:none}.panel.active{display:block}.field{margin-bottom:13px}.field label{display:block;font-size:11.5px;font-weight:750;color:#334155;margin:0 0 6px}.input-wrap{position:relative}.field input,.field select{width:100%;height:45px;border:1px solid #cbd5e1;border-radius:10px;background:#fff;color:#0f172a;padding:0 12px;font:inherit;font-size:13px;outline:none;transition:border-color .16s,box-shadow .16s}.field input:focus,.field select:focus{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.12)}.field input::placeholder{color:#94a3b8}.pass{padding-right:58px!important}.showpass{position:absolute;right:7px;top:50%;transform:translateY(-50%);border:0;background:#eff6ff;color:#1d4ed8;border-radius:7px;padding:6px 8px;font-size:10.5px;font-weight:750;cursor:pointer}
.hint{font-size:10.5px;color:#64748b;margin-top:5px;line-height:1.45}.signin-actions{display:flex;justify-content:flex-end;margin:-3px 0 11px}.forgot{border:0;background:transparent;color:#1d4ed8;font:inherit;font-size:11.5px;font-weight:750;padding:3px 0;cursor:pointer}.forgot:hover{text-decoration:underline}.forgot:focus-visible{outline:3px solid rgba(37,99,235,.18);outline-offset:3px;border-radius:4px}.strength{height:4px;background:#e2e8f0;border-radius:99px;margin-top:7px;overflow:hidden}.strength>i{display:block;width:0;height:100%;border-radius:99px;background:#94a3b8;transition:width .2s,background .2s}
.btn{width:100%;border:0;border-radius:11px;min-height:45px;padding:11px 14px;font:inherit;font-size:13px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:transform .15s,box-shadow .15s,background .15s}.btn-primary{background:linear-gradient(135deg,#1d4ed8,#2563eb);color:#fff;box-shadow:0 10px 24px rgba(37,99,235,.22)}.btn-primary:hover{transform:translateY(-1px);box-shadow:0 13px 28px rgba(37,99,235,.28)}.btn:disabled{opacity:.62;cursor:not-allowed;transform:none}.btn-ghost{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;margin-top:8px}
.status{display:none;margin:0 0 14px;padding:10px 12px;border-radius:9px;font-size:11.5px;line-height:1.5}.status.show{display:block}.status.ok{background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46}.status.err{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}.status.info{background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af}
.verify{text-align:center}.verify-icon{width:52px;height:52px;border-radius:15px;background:#eff6ff;color:#2563eb;display:grid;place-items:center;margin:0 auto 12px;font-size:23px}.verify h2{font-size:17px;margin:0 0 6px}.verify p{font-size:12px;color:#64748b;line-height:1.55;margin:0 0 15px}.otp{width:100%!important;height:54px!important;text-align:center;font-size:24px!important;font-weight:800!important;letter-spacing:10px;padding-left:20px!important;font-variant-numeric:tabular-nums}.verify-meta{font-size:10.5px!important;color:#94a3b8!important;margin-top:10px!important}
.security{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:18px;padding-top:17px;border-top:1px solid #e2e8f0}.security div{background:#f8fafc;border:1px solid #eef2f7;border-radius:9px;padding:9px 7px;text-align:center}.security b{display:block;font-size:10.5px;color:#334155;margin-bottom:2px}.security span{display:block;font-size:9px;color:#94a3b8;line-height:1.3}.legal{text-align:center;font-size:10px;color:#94a3b8;line-height:1.55;margin:17px 4px 0}.legal a{color:#2563eb}.footer{text-align:center;padding:17px;font-size:10.5px;color:#94a3b8}.footer a{color:#2563eb;text-decoration:none}
.spinner{width:15px;height:15px;border:2px solid rgba(255,255,255,.45);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
/* DGJ_AUTH_MOBILE_V19: iPhone + Android responsive auth polish */
@media(max-width:560px){
body{background:#f5f8ff;padding-bottom:env(safe-area-inset-bottom,0px)}
.top-bar{gap:10px;padding:10px max(12px,env(safe-area-inset-right,0px)) 10px max(12px,env(safe-area-inset-left,0px));min-height:58px}.brand{gap:9px;min-width:0}.brand img{width:34px;height:34px;border-radius:9px;flex:0 0 auto}.brand strong{font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.brand small{display:none}.back{font-size:12px;white-space:nowrap;flex:0 0 auto}
.main{display:block;flex:1;padding:8px max(8px,env(safe-area-inset-right,0px)) max(18px,env(safe-area-inset-bottom,0px)) max(8px,env(safe-area-inset-left,0px));width:100%}.shell{width:100%;max-width:520px;margin:0 auto}.card{width:100%;border-radius:18px;box-shadow:0 14px 40px rgba(30,64,175,.12)}
.hero{padding:18px 16px 16px}.hero:before{width:170px;height:170px;right:-72px;top:-98px}.hero:after{width:110px;height:110px;left:-54px;bottom:-78px}.logo{width:52px;height:52px;border-radius:14px;margin:0 auto 10px;padding:4px}.logo img{border-radius:10px}.hero h1{font-size:20px;line-height:1.18;letter-spacing:-.35px;margin-bottom:5px}.hero p{font-size:12px;line-height:1.4}
.body{padding:15px 14px 18px}.intro{font-size:13px;line-height:1.48;margin:0 2px 12px}.status{font-size:12px;margin-bottom:11px;padding:9px 10px}.google-wrap{min-height:44px}.or{gap:9px;margin:12px 0}.or span{font-size:10px;white-space:nowrap}
.tabs{padding:4px;border-radius:13px;margin-bottom:14px}.tab{min-height:44px;padding:9px 8px;border-radius:10px;font-size:14px}.field{margin-bottom:12px}.field label{font-size:13px;margin-bottom:6px}.field input,.field select{height:50px;min-height:50px;border-radius:12px;padding:0 13px;font-size:16px;line-height:1.2}.pass{padding-right:72px!important}.showpass{right:7px;min-width:54px;min-height:36px;padding:6px 9px;border-radius:9px;font-size:12px}.hint{font-size:11px;line-height:1.42}.signin-actions{margin:-2px 0 10px}.forgot{font-size:12.5px;min-height:32px}.btn{min-height:50px;border-radius:12px;padding:12px 14px;font-size:14px}.btn-ghost{margin-top:7px}
.verify-icon{width:48px;height:48px;margin-bottom:10px}.verify h2{font-size:17px}.verify p{font-size:12px;margin-bottom:13px}.otp{height:52px!important;font-size:22px!important;letter-spacing:8px;padding-left:16px!important}.security{grid-template-columns:repeat(3,minmax(0,1fr));gap:5px;margin-top:15px;padding-top:14px}.security div{padding:7px 4px;border-radius:8px;min-width:0}.security b{font-size:9.5px}.security span{font-size:8px;line-height:1.2}.legal{font-size:9.5px;line-height:1.48;margin-top:14px}.footer{padding:12px 8px max(12px,env(safe-area-inset-bottom,0px));font-size:10px}
}
@media(max-width:360px){.top-bar{padding-left:10px;padding-right:10px}.brand strong{font-size:13px}.back{font-size:11px}.main{padding-left:6px;padding-right:6px}.hero{padding:16px 12px 14px}.hero h1{font-size:18.5px}.body{padding:14px 12px 17px}.intro{font-size:12.5px}.tab{font-size:13px}.security b{font-size:9px}.security span{font-size:7.5px}}
@media(max-width:560px) and (max-height:740px){.top-bar{min-height:52px;padding-top:8px;padding-bottom:8px}.hero{padding-top:14px;padding-bottom:13px}.logo{width:46px;height:46px;margin-bottom:8px}.hero h1{font-size:19px}.body{padding-top:13px}.intro{margin-bottom:10px}.or{margin:10px 0}.tabs{margin-bottom:12px}}
@media(max-width:560px) and (orientation:landscape){.main{padding-top:6px}.hero{padding:12px 16px}.logo{width:42px;height:42px;margin-bottom:6px}.hero h1{font-size:18px}.hero p{font-size:11px}.body{padding-top:12px}}

</style>
</head>
<body>
<header class="top-bar"><a class="brand" href="/"><img src="/logo.png" alt="Dev Global Jobs logo"/><span><strong>Dev Global Jobs</strong><small>INTERNATIONAL CAREERS</small></span></a><a class="back" href="/">← Back to Jobs</a></header>
<main class="main"><div class="shell"><section class="card" aria-labelledby="auth-title"><div class="hero"><div class="logo"><img src="/logo.png" alt="Dev Global Jobs"/></div><h1 id="auth-title">${heading}</h1><p>${subheading}</p></div><div class="body"><p class="intro">${intro}</p><div id="auth-status" class="${initialStatusClass}" role="status" aria-live="polite">${initialStatusText}</div><div class="google-wrap" id="dgj-g-btn" aria-label="Google sign in"></div><div class="or"><span>or continue with email</span></div><div id="auth-main"${authMainStyle}><div class="tabs" role="tablist"><button type="button" id="tab-signin" class="${signinTabClass}" data-mode="signin" role="tab">Sign In</button><button type="button" id="tab-signup" class="${signupTabClass}" data-mode="signup" role="tab">Create Account</button></div><form id="form-signin" class="${signinPanelClass}" autocomplete="on"><div class="field"><label for="si-email">Email address</label><input id="si-email" name="email" type="email" autocomplete="email" inputmode="email" maxlength="254" required placeholder="you@example.com"/></div><div class="field"><label for="si-password">Password</label><div class="input-wrap"><input id="si-password" class="pass" name="password" type="password" autocomplete="current-password" maxlength="128" required placeholder="Your password"/><button class="showpass" type="button" data-target="si-password">Show</button></div></div><div class="signin-actions"><button id="btn-forgot" class="forgot" type="button">Forgot password?</button></div><button id="btn-signin" class="btn btn-primary" type="submit">Sign In Securely</button><p class="hint" style="text-align:center;margin-top:10px">New to Dev Global Jobs? Choose <strong>Create Account</strong> above.</p></form><form id="form-signup" class="${signupPanelClass}" autocomplete="on"><div class="field"><label for="su-name">Full name</label><input id="su-name" name="fullName" type="text" autocomplete="name" maxlength="100" required placeholder="Your full name"/></div><div class="field"><label for="su-email">Email address</label><input id="su-email" name="email" type="email" autocomplete="email" inputmode="email" maxlength="254" required placeholder="you@example.com"/></div><div class="field"><label for="su-country">Country</label><select id="su-country" name="country" autocomplete="country-name" required><option value="">Select your country</option></select></div><div class="field"><label for="su-password">Create password</label><div class="input-wrap"><input id="su-password" class="pass" name="password" type="password" autocomplete="new-password" maxlength="128" required placeholder="Create a strong password"/><button class="showpass" type="button" data-target="su-password">Show</button></div><div class="strength" aria-hidden="true"><i id="strength-bar"></i></div><div id="password-hint" class="hint">Use 10+ characters with a mix of uppercase, lowercase, numbers and symbols.</div></div><div class="field"><label for="su-confirm">Confirm password</label><div class="input-wrap"><input id="su-confirm" class="pass" name="confirm" type="password" autocomplete="new-password" maxlength="128" required placeholder="Re-enter your password"/><button class="showpass" type="button" data-target="su-confirm">Show</button></div></div><button id="btn-signup" class="btn btn-primary" type="submit">Create & Verify Account</button><p class="hint" style="text-align:center;margin-top:10px">We will send a 6-digit verification code from <strong>info@devglobaljobs.com</strong>. Your account also joins the free weekly Global Jobs digest; every email includes one-click unsubscribe.</p></form></div><div id="verify-panel" class="${verifyPanelClass}"><div class="verify-icon">✉</div><h2>Verify your email</h2><p>Enter the 6-digit code sent to <strong id="verify-email"></strong>. The code expires in 10 minutes.</p><form id="form-verify" method="post" action="/auth/verify-email" novalidate><input type="hidden" name="redirect" value="${redirectHtml}"/><div class="field"><label for="verify-code">Verification code</label><input id="verify-code" class="otp" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="32" required placeholder="000000" aria-describedby="auth-status"/></div><button id="btn-verify" class="btn btn-primary" type="submit">Verify & Continue</button><button id="btn-resend" class="btn btn-ghost" type="button">Resend Code</button><p class="verify-meta">For your security, verification attempts and resends are rate-limited.</p></form></div><div id="reset-panel" class="panel verify"><div class="verify-icon">↻</div><h2>Reset your password</h2><p id="reset-copy">Enter your verified email address and we will send a secure 6-digit reset code.</p><form id="form-reset-request"><div class="field"><label for="reset-email">Email address</label><input id="reset-email" type="email" autocomplete="email" inputmode="email" maxlength="254" required placeholder="you@example.com"/></div><button id="btn-reset-send" class="btn btn-primary" type="submit">Send Reset Code</button><button id="btn-reset-cancel" class="btn btn-ghost" type="button">Back to Sign In</button></form><form id="form-reset-confirm" style="display:none" novalidate><div class="field"><label for="reset-code">Reset code</label><input id="reset-code" class="otp" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required placeholder="000000"/></div><div class="field"><label for="reset-password">New password</label><div class="input-wrap"><input id="reset-password" class="pass" type="password" autocomplete="new-password" maxlength="128" required placeholder="Create a strong new password"/><button class="showpass" type="button" data-target="reset-password">Show</button></div></div><div class="field"><label for="reset-confirm">Confirm new password</label><div class="input-wrap"><input id="reset-confirm" class="pass" type="password" autocomplete="new-password" maxlength="128" required placeholder="Re-enter new password"/><button class="showpass" type="button" data-target="reset-confirm">Show</button></div></div><button id="btn-reset-confirm" class="btn btn-primary" type="submit">Set New Password</button><button id="btn-reset-back" class="btn btn-ghost" type="button">Back to Sign In</button><p class="verify-meta">Reset codes expire in 10 minutes and can be used only once.</p></form></div><div class="security"><div><b>Verified email</b><span>Account ownership check</span></div><div><b>Secure sessions</b><span>Protected sign-in</span></div><div><b>Privacy-first</b><span>You control applications</span></div></div><p class="legal">By continuing, you agree to our <a href="/terms">Terms of Service</a> and <a href="/privacy">Privacy Policy</a>. Google Sign-In is used only for account authentication.</p></div></section><div class="footer"><a href="/">Jobs</a> · <a href="/pricing">Pricing</a> · <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a> · © 2026 Dev Global Jobs</div></div></main>
<script>
(function(){
'use strict';
var CLIENT_ID='76830429948-0afbgal53ch1o03ph8dan9pttp44ngsn.apps.googleusercontent.com';
var REDIRECT=${redirectJson};
var INITIAL_MODE=${initialModeJson};
var SERVER_PENDING_EMAIL=${serverPendingEmailJson};
var INITIAL_VERIFY_ERROR=${initialVerifyErrorJson};
var pendingEmail=SERVER_PENDING_EMAIL||'';try{if(SERVER_PENDING_EMAIL){sessionStorage.setItem('dgjPendingVerificationEmail',SERVER_PENDING_EMAIL);}else{sessionStorage.removeItem('dgjPendingVerificationEmail');}}catch(_storageErr){}
var statusEl=document.getElementById('auth-status');
function status(message,type){if(!message){statusEl.className='status';statusEl.textContent='';return;}statusEl.className='status show '+(type||'info');statusEl.textContent=message;}
if(INITIAL_VERIFY_ERROR){status(INITIAL_VERIFY_ERROR,'err');}
function setBusy(btn,busy,label){if(!btn)return;btn.disabled=!!busy;btn.innerHTML=busy?'<span class="spinner"></span> Please wait…':label;}
function mode(next){status('');if(next==='signup'){pendingEmail='';try{sessionStorage.removeItem('dgjPendingVerificationEmail');}catch(_e){}fetch('/api/seekers/cancel-verification',{method:'POST',credentials:'include'}).catch(function(){});}document.querySelectorAll('.tab').forEach(function(b){b.classList.toggle('active',b.getAttribute('data-mode')===next)});document.getElementById('form-signin').classList.toggle('active',next==='signin');document.getElementById('form-signup').classList.toggle('active',next==='signup');document.getElementById('verify-panel').classList.remove('active');document.getElementById('reset-panel').classList.remove('active');document.getElementById('auth-main').style.display='block';}
document.querySelectorAll('.tab').forEach(function(b){b.addEventListener('click',function(){mode(b.getAttribute('data-mode'))})});
document.querySelectorAll('.showpass').forEach(function(b){b.addEventListener('click',function(){var i=document.getElementById(b.getAttribute('data-target'));if(!i)return;var show=i.type==='password';i.type=show?'text':'password';b.textContent=show?'Hide':'Show';})});
var countryCodes='AF AL DZ AS AD AO AI AQ AG AR AM AW AU AT AZ BS BH BD BB BY BE BZ BJ BM BT BO BQ BA BW BV BR IO BN BG BF BI CV KH CM CA KY CF TD CL CN CX CC CO KM CG CD CK CR CI HR CU CW CY CZ DK DJ DM DO EC EG SV GQ ER EE SZ ET FK FO FJ FI FR GF PF TF GA GM GE DE GH GI GR GL GD GP GU GT GG GN GW GY HT HM VA HN HK HU IS IN ID IR IQ IE IM IL IT JM JP JE JO KZ KE KI KP KR KW KG LA LV LB LS LR LY LI LT LU MO MG MW MY MV ML MT MH MQ MR MU YT MX FM MD MC MN ME MS MA MZ MM NA NR NP NL NC NZ NI NE NG NU NF MK MP NO OM PK PW PS PA PG PY PE PH PN PL PT PR QA RE RO RU RW BL SH KN LC MF PM VC WS SM ST SA SN RS SC SL SG SX SK SI SB SO ZA GS SS ES LK SD SR SJ SE CH SY TW TJ TZ TH TL TG TK TO TT TN TR TM TC TV UG UA AE GB US UM UY UZ VU VE VN VG VI WF EH YE ZM ZW'.split(' ');
try{var dn=new Intl.DisplayNames(['en'],{type:'region'});var items=countryCodes.map(function(c){return{code:c,name:dn.of(c)||c}}).sort(function(a,b){return a.name.localeCompare(b.name)});var sel=document.getElementById('su-country');items.forEach(function(it){var o=document.createElement('option');o.value=it.name;o.textContent=it.name;sel.appendChild(o);});}catch(e){}
var pw=document.getElementById('su-password');var bar=document.getElementById('strength-bar');pw.addEventListener('input',function(){var v=pw.value;var score=0;if(v.length>=10)score++;if(/[a-z]/.test(v)&&/[A-Z]/.test(v))score++;if(/\d/.test(v))score++;if(/[^A-Za-z0-9]/.test(v))score++;var widths=['0%','28%','54%','78%','100%'];var colors=['#cbd5e1','#ef4444','#f59e0b','#3b82f6','#059669'];bar.style.width=widths[score];bar.style.background=colors[score];});
function strongPassword(v){var classes=0;if(/[a-z]/.test(v))classes++;if(/[A-Z]/.test(v))classes++;if(/\d/.test(v))classes++;if(/[^A-Za-z0-9]/.test(v))classes++;return v.length>=10&&classes>=3;}
document.getElementById('form-signin').addEventListener('submit',function(ev){ev.preventDefault();status('');var btn=document.getElementById('btn-signin');setBusy(btn,true,'Sign In Securely');fetch('/api/seekers/login',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:document.getElementById('si-email').value.trim(),password:document.getElementById('si-password').value})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Sign-in failed.');status('Signed in successfully. Redirecting…','ok');window.location.replace(REDIRECT);}).catch(function(e){status(e.message||'Sign-in failed.','err');setBusy(btn,false,'Sign In Securely');});});
document.getElementById('form-signup').addEventListener('submit',function(ev){ev.preventDefault();status('');var password=document.getElementById('su-password').value;var confirm=document.getElementById('su-confirm').value;if(password!==confirm){status('Passwords do not match.','err');return;}if(!strongPassword(password)){status('Use at least 10 characters and combine at least three of: uppercase, lowercase, numbers and symbols.','err');return;}var payload={fullName:document.getElementById('su-name').value.trim(),email:document.getElementById('su-email').value.trim(),country:document.getElementById('su-country').value,password:password};var btn=document.getElementById('btn-signup');setBusy(btn,true,'Create & Verify Account');fetch('/api/seekers/register',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Registration failed.');pendingEmail=payload.email.toLowerCase();sessionStorage.setItem('dgjPendingVerificationEmail',pendingEmail);document.getElementById('verify-email').textContent=pendingEmail;document.getElementById('auth-main').style.display='none';document.getElementById('verify-panel').classList.add('active');document.getElementById('verify-code').focus();status('Verification code sent. Check your inbox and spam folder.','ok');}).catch(function(e){status(e.message||'Registration failed.','err');}).finally(function(){setBusy(btn,false,'Create & Verify Account');});});
function normalizeOtp(value){return String(value||'').replace(/[٠-٩]/g,function(ch){return String('٠١٢٣٤٥٦٧٨٩'.indexOf(ch));}).replace(/[۰-۹]/g,function(ch){return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(ch));}).replace(/[^0-9]/g,'').slice(0,6);}
var verifyCodeInput=document.getElementById('verify-code');
function syncVerifyCode(value){var normalized=normalizeOtp(value);verifyCodeInput.value=normalized;if(normalized.length===6){status('');}return normalized;}
verifyCodeInput.addEventListener('input',function(){syncVerifyCode(this.value);});
verifyCodeInput.addEventListener('paste',function(ev){var clipboard=ev.clipboardData||window.clipboardData;if(!clipboard)return;var normalized=normalizeOtp(clipboard.getData('text'));if(!normalized)return;ev.preventDefault();syncVerifyCode(normalized);setTimeout(function(){verifyCodeInput.focus();verifyCodeInput.setSelectionRange(verifyCodeInput.value.length,verifyCodeInput.value.length);},0);});
// Native server-side verification is the primary path. JavaScript only normalizes the input and provides immediate visual feedback.
document.getElementById('form-verify').addEventListener('submit',function(){var code=syncVerifyCode(verifyCodeInput.value);if(!/^\d{6}$/.test(code)){status('Enter the latest 6-digit verification code.','err');verifyCodeInput.focus();return false;}status('Verifying your email…','info');var btn=document.getElementById('btn-verify');if(btn){btn.disabled=true;btn.innerHTML='<span class="spinner"></span> Please wait…';}return true;});
document.getElementById('btn-resend').addEventListener('click',function(){if(!pendingEmail)return;var btn=this;btn.disabled=true;fetch('/api/seekers/resend-verification',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:pendingEmail})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Could not resend code.');status('A new verification code has been sent.','ok');setTimeout(function(){btn.disabled=false},60000);}).catch(function(e){status(e.message||'Could not resend code.','err');btn.disabled=false;});});
var resetEmail='';
function showReset(){status('');document.getElementById('auth-main').style.display='none';document.getElementById('verify-panel').classList.remove('active');document.getElementById('reset-panel').classList.add('active');var e=document.getElementById('si-email').value.trim();if(e)document.getElementById('reset-email').value=e;document.getElementById('form-reset-request').style.display='block';document.getElementById('form-reset-confirm').style.display='none';document.getElementById('reset-copy').textContent='Enter your verified email address and we will send a secure 6-digit reset code.';document.getElementById('reset-email').focus();}
document.getElementById('btn-forgot').addEventListener('click',showReset);
function backToSignin(){mode('signin');document.getElementById('si-email').focus();}
document.getElementById('btn-reset-cancel').addEventListener('click',backToSignin);document.getElementById('btn-reset-back').addEventListener('click',backToSignin);
document.getElementById('reset-code').addEventListener('input',function(){this.value=this.value.replace(/\D/g,'').slice(0,6)});
document.getElementById('form-reset-request').addEventListener('submit',function(ev){ev.preventDefault();var email=document.getElementById('reset-email').value.trim().toLowerCase();if(!email){status('Enter your email address.','err');return;}var btn=document.getElementById('btn-reset-send');setBusy(btn,true,'Send Reset Code');fetch('/api/seekers/password-reset/request',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:email})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Reset code could not be sent.');resetEmail=email;document.getElementById('form-reset-request').style.display='none';document.getElementById('form-reset-confirm').style.display='block';document.getElementById('reset-copy').textContent='If this email belongs to a Dev Global Jobs account, a 6-digit reset code has been sent. Enter it below with your new password.';status('If an account exists for this email, a reset code has been sent.','ok');document.getElementById('reset-code').focus();}).catch(function(e){status(e.message||'Reset request could not be completed.','err');}).finally(function(){setBusy(btn,false,'Send Reset Code');});});
document.getElementById('form-reset-confirm').addEventListener('submit',function(ev){ev.preventDefault();var code=normalizeOtp(document.getElementById('reset-code').value);document.getElementById('reset-code').value=code;var password=document.getElementById('reset-password').value;var confirm=document.getElementById('reset-confirm').value;if(!/^\d{6}$/.test(code)){status('Enter the 6-digit reset code.','err');return;}if(password!==confirm){status('Passwords do not match.','err');return;}if(!strongPassword(password)){status('Use at least 10 characters and combine at least three of: uppercase, lowercase, numbers and symbols.','err');return;}var btn=document.getElementById('btn-reset-confirm');setBusy(btn,true,'Set New Password');fetch('/api/seekers/password-reset/confirm',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({email:resetEmail,code:code,password:password})}).then(function(r){return r.json().then(function(d){return{ok:r.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Password reset failed.');status('Password updated successfully. You can now sign in with your new password.','ok');document.getElementById('si-email').value=resetEmail;document.getElementById('si-password').value='';setTimeout(function(){backToSignin()},900);}).catch(function(e){status(e.message||'Password reset failed.','err');setBusy(btn,false,'Set New Password');});});
function initGoogle(){if(!window.google||!window.google.accounts||!window.google.accounts.id){setTimeout(initGoogle,350);return;}var el=document.getElementById('dgj-g-btn');if(!el)return;google.accounts.id.initialize({client_id:CLIENT_ID,auto_select:false,callback:function(r){status('Signing in with Google…','info');fetch('/api/seekers/google-auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({credential:r.credential}),credentials:'include'}).then(function(res){return res.json().then(function(d){return{ok:res.ok,d:d}})}).then(function(x){if(!x.ok)throw new Error(x.d.message||'Google sign-in failed.');window.location.replace(REDIRECT);}).catch(function(e){status(e.message||'Google sign-in failed.','err');});}});var available=Math.floor(el.getBoundingClientRect().width||360);var buttonWidth=Math.max(220,Math.min(360,available));google.accounts.id.renderButton(el,{theme:'outline',size:'large',text:'continue_with',shape:'rectangular',width:buttonWidth,logo_alignment:'left',locale:'en'});}
if(pendingEmail){document.getElementById('verify-email').textContent=pendingEmail;document.getElementById('auth-main').style.display='none';document.getElementById('verify-panel').classList.add('active');}else{document.getElementById('verify-panel').classList.remove('active');document.getElementById('auth-main').style.display='block';}setTimeout(initGoogle,250);
})();
</script>
</body></html>`;
}

async function registerRoutes(httpServer2, app2) {
  // DGJ V45: isolated commercial posting / receipt review / Premium Boost layer.
  const dgjV45 = await require("./dgj-v45-commercial.cjs").install({
    app: app2,
    pool,
    storage,
    requireAdmin,
    classifyJobSkillCategory,
    queueUrlForIndexing,
    queueGoogleIndexingUpdate,
    dgjRecordEmployerPosting,
    postJobSchema,
    getVerificationMailer
  });
  // Register before the existing employer route. Unknown legacy codes safely fall through to V44 logic.
  app2.post("/api/admin-post-job", dgjV45.handlePostJob);

  // DGJ V48_PREMIUM_EMPLOYER_ZERO_FLASH_LOCK
  // DGJ V46: dedicated Employer Workspace on top of the existing verified identity system.
  // Job-seeker authentication remains unchanged; employer role/profile data is additive.
  const dgjV46 = await require("./dgj-v46-employer.cjs").install({
    app: app2,
    pool,
    requireAdmin,
    dgjUpsertContact,
    dgjEvent
  });

  // DGJ V48: server-owned employer entry routes eliminate SPA 404 flashes and keep Post a Job in the employer journey.
  // Employer authentication still uses the existing verified Google/email identity system.
  app2.get("/employer/login", (req, res) => {
    const q = new URLSearchParams();
    if (req.query?.redirect) q.set("redirect", String(req.query.redirect).slice(0, 2048));
    if (req.query?.mode) q.set("mode", String(req.query.mode).slice(0, 20));
    return res.redirect(302, `/employer/sign-in${q.toString() ? `?${q.toString()}` : ""}`);
  });
  app2.get("/employer/sign-in", (req, res) => {
    const requestedRedirect = String(req.query?.redirect || "/employer");
    const safeRedirect = requestedRedirect.startsWith("/") && !requestedRedirect.startsWith("//") ? requestedRedirect.slice(0, 2048) : "/employer";
    if (req.session && req.session.seekerAccountId) return res.redirect(302, safeRedirect);
    if (req.session) req.session.dgjEmployerIntent = true;
    let html = renderSeekerAuthPage({
      title: "Employer Sign In | Dev Global Jobs",
      description: "Secure employer sign in for Dev Global Jobs. Manage jobs, Premium Boost, payments, plans and performance from one employer workspace.",
      canonical: "https://devglobaljobs.com/employer/sign-in",
      robots: "noindex,nofollow",
      heading: "Dev Global Jobs for Employers",
      subheading: "Hire globally · Manage jobs · Track performance",
      intro: "Continue with Google or your verified email account to access the secure Employer Workspace.",
      redirect: safeRedirect,
      initialMode: String(req.query?.mode || "").toLowerCase() === "signup" ? "signup" : "signin",
      pendingEmail: req.session?.pendingVerificationEmail || "",
      verifyError: String(req.query?.verify_error || "").slice(0, 220)
    });
    html = html
      .replace("New to Dev Global Jobs? Choose <strong>Create Account</strong> above.", "New employer? Choose <strong>Create Account</strong> above.")
      .replace("We will send a 6-digit verification code from <strong>info@devglobaljobs.com</strong>. Your account also joins the free weekly Global Jobs digest; every email includes one-click unsubscribe.", "We will send a 6-digit verification code from <strong>info@devglobaljobs.com</strong>. After verification, complete your company profile to activate your Employer Workspace and employer updates.")
      .replace("Privacy-first</b><span>You control applications", "Employer controls</b><span>You control jobs and billing")
      .replace("Jobs</a> · <a href=\"/pricing\">Pricing", "Employer Home</a> · <a href=\"/pricing\">Pricing");
    res.set("Cache-Control", "no-store, no-cache, must-revalidate");
    res.set("Content-Type", "text/html; charset=utf-8");
    return res.status(200).send(html);
  });

  app2.get("/employer", (req, res) => {
    if (!req.session || !req.session.seekerAccountId) return res.redirect(302, "/employer/sign-in");
    const import_path3 = require("path");
    const import_fs3 = require("fs");
    const idxPath = import_path3.resolve(__dirname, "public", "index.html");
    res.set("Cache-Control", "no-cache, no-store, must-revalidate");
    res.set("Content-Type", "text/html; charset=utf-8");
    return res.status(200).send(injectMetaTags(import_fs3.readFileSync(idxPath, "utf-8"), "/employer"));
  });

  app2.get("/employer/post-job", (req, res) => {
    const target = "/post-job?employer=1";
    if (req.session && req.session.seekerAccountId) return res.redirect(302, target);
    return res.redirect(302, `/employer/sign-in?redirect=${encodeURIComponent(target)}`);
  });

  // Unified Google + verified email authentication.
  app2.get("/sign-in", (req, res) => {
    const requestedRedirect = String(req.query?.redirect || "/");
    const safeRedirect = requestedRedirect.startsWith("/") && !requestedRedirect.startsWith("//") ? requestedRedirect.slice(0, 2048) : "/";
    const initialMode = String(req.query?.mode || "").toLowerCase() === "signup" ? "signup" : "signin";
    if (req.session && req.session.seekerAccountId) return res.redirect(302, safeRedirect === "/" ? "/profile" : safeRedirect);
    if (initialMode === "signup" && req.session?.pendingVerificationEmail) delete req.session.pendingVerificationEmail;
    const pendingEmail = initialMode === "signup" ? "" : (req.session?.pendingVerificationEmail || "");
    const verifyError = initialMode === "signup" ? "" : String(req.query?.verify_error || "").slice(0, 220);
    res.set("Cache-Control", "no-store, no-cache, must-revalidate");
    res.set("Content-Type", "text/html; charset=utf-8");
    return res.status(200).send(renderSeekerAuthPage({
      title: "Sign In or Create Account | Dev Global Jobs",
      heading: "Build your career globally.",
      subheading: "Find international jobs, track applications and save opportunities from one Job Seeker account.",
      intro: "Continue with Google or sign in with your verified email account.",
      layout: "split",
      redirect: safeRedirect,
      initialMode,
      pendingEmail,
      verifyError
    }));
  });
  app2.post("/api/seekers/cancel-verification", rateLimit(20, 10 * 60 * 1e3), (req, res) => {
    if (!req.session) return res.json({ success: true });
    delete req.session.pendingVerificationEmail;
    return req.session.save(() => res.json({ success: true }));
  });
  app2.get("/post-job", (req, res, next) => {
    const employerTarget = "/post-job?employer=1";
    const isEmployerMode = String(req.query?.employer || "") === "1";
    if (req.session && req.session.seekerAccountId) {
      if (!isEmployerMode) return res.redirect(302, employerTarget);
      const import_path3 = require("path");
      const import_fs3 = require("fs");
      const idxPath = import_path3.resolve(__dirname, "public", "index.html");
      res.set("Cache-Control", "no-cache, no-store, must-revalidate");
      res.set("Content-Type", "text/html; charset=utf-8");
      return res.status(200).send(injectMetaTags(import_fs3.readFileSync(idxPath, "utf-8"), "/post-job"));
    }
    // A Post a Job visit is an employer journey, not a job-seeker sign-in journey.
    res.set("Cache-Control", "no-store, no-cache, must-revalidate");
    res.set("Content-Type", "text/html; charset=utf-8");
    let html = renderSeekerAuthPage({
      title: "Employer Sign In to Post a Job | Dev Global Jobs",
      description: "Secure employer access to post jobs, manage hiring activity, Premium Boost and job performance on Dev Global Jobs.",
      canonical: "https://devglobaljobs.com/post-job",
      robots: "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1",
      heading: "Dev Global Jobs for Employers",
      subheading: "Post jobs · Reach international talent · Track performance",
      intro: "Sign in with Google or your verified employer email to continue to the secure job-publishing workspace.",
      redirect: employerTarget,
      initialMode: String(req.query?.mode || "").toLowerCase() === "signup" ? "signup" : "signin",
      pendingEmail: req.session?.pendingVerificationEmail || "",
      verifyError: String(req.query?.verify_error || "").slice(0, 220)
    });
    html = html
      .replace("New to Dev Global Jobs? Choose <strong>Create Account</strong> above.", "New employer? Choose <strong>Create Account</strong> above.")
      .replace("Privacy-first</b><span>You control applications", "Employer controls</b><span>You control jobs and billing");
    return res.status(200).send(html);
  });

  app2.use("/api/", (_req, res, next) => {
    res.set("X-Robots-Tag", "noindex, nofollow");
    res.set("X-Content-Type-Options", "nosniff");
    res.set("X-Frame-Options", "DENY");
    res.set("X-XSS-Protection", "1; mode=block");
    res.set("Referrer-Policy", "strict-origin-when-cross-origin");
    res.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    next();
  });
  app2.get("/api/download-vps", (_req, res) => {
    const filePath = import_path.default.resolve("devglobaljobs-vps-clean.tar.gz");
    if (import_fs.default.existsSync(filePath)) {
      res.download(filePath, "devglobaljobs-vps-clean.tar.gz");
    } else {
      res.status(404).send("File not found. Please regenerate the deployment archive.");
    }
  });
  app2.post("/api/subscribe", rateLimit(5, 6e4), async (req, res) => {
    try {
      const parsed = subscribeSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.errors[0]?.message || "Invalid email" });
      }
      const email = parsed.data.email.toLowerCase().trim();
      const type = parsed.data.type || "job_seeker";
      await ensureGrowthTables();
      await dgjUpsertContact(pool,email,type,parsed.data.name||null,null,"newsletter_form");
      try {
        const existing = await storage.getSubscriberByEmail(email);
        if (existing) {
          return res.json({ message: "You're already subscribed! We'll keep you updated.", alreadySubscribed: true });
        }
      } catch (e) {
      }
      try {
        const subscriber = await storage.addSubscriber({
          email,
          name: parsed.data.name || null,
          type
        });
        res.json({ message: "Successfully subscribed! You'll receive job alerts soon.", subscriber: { id: subscriber.id, email } });
      } catch (dbError) {
        if (dbError?.code === "23505" || dbError?.message?.includes("unique") || dbError?.message?.includes("duplicate")) {
          return res.json({ message: "You're already subscribed! We'll keep you updated.", alreadySubscribed: true });
        }
        throw dbError;
      }
    } catch (error) {
      console.error("Subscribe error:", error);
      res.json({ message: "Thank you! You've been added to our list.", alreadySubscribed: false });
    }
  });
  app2.get("/api/admin/subscribers", async (req, res) => {
    try {
      const adminCode = req.query.code;
      const validCodes = ["DEVGLOBAL2024", "TRENDNOVA2024", "ADMIN2024", "TNW2024"];
      if (!adminCode || !validCodes.includes(adminCode)) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const subscribers = await storage.getSubscribers();
      const counts = await storage.getSubscriberCountByType();
      res.json({
        total: counts.total,
        employers: counts.employers,
        jobSeekers: counts.jobSeekers,
        subscribers
      });
    } catch (error) {
      console.error("Admin subscribers error:", error);
      res.status(500).json({ message: "Failed to fetch subscribers" });
    }
  });
  app2.get("/api/jobs/stats", async (_req, res) => {
    try {
      const cached = getCached("stats");
      if (cached) return res.json(cached);
      const stats = await storage.getJobStats();
      setCache("stats", stats, CACHE_TTL_STATS);
      res.json(stats);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/jobs/featured", async (_req, res) => {
    try {
      const cached = getCached("featured");
      if (cached) return res.json(cached);
      const jobsList = await storage.getFeaturedJobs();
      setCache("featured", jobsList, CACHE_TTL_FEATURED);
      res.json(jobsList);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/jobs/featured-employer", async (req, res) => {
    try {
      const category = req.query.category;
      const easyApplyOnly = String(req.query.easyApply || "").toLowerCase() === "true";
      const cacheKey = `${category ? `featured_employer_${category}` : "featured_employer"}${easyApplyOnly ? "_easy" : ""}`;
      const cached = getCached(cacheKey);
      if (cached) return res.json(cached);
      const jobsList = await storage.getFeaturedEmployerJobs(category, easyApplyOnly);
      setCache(cacheKey, jobsList, CACHE_TTL_FEATURED);
      res.json(jobsList);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/jobs/detail/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid job ID" });
      }
      const job = await storage.getJobById(id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      res.json(job);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/jobs/:id/related-priority", rateLimit(120, 6e4), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ message: "Invalid job ID" });
      const requestedLimit = Math.max(1, Math.min(parseInt(req.query.limit) || 4, 6));
      const currentResult = await pool.query(`SELECT id,title,organization,category,skill_category,country FROM jobs WHERE id=$1 LIMIT 1`, [id]);
      const current = currentResult.rows[0];
      if (!current) return res.status(404).json({ message: "Job not found" });
      async function related(featured) {
        const q = await pool.query(`
          SELECT id,title,organization,location,country,category,skill_category,job_type,salary,posted_at,closing_date,featured,is_employer_posted,
                 CASE WHEN COALESCE(BTRIM(apply_email),'') <> '' THEN true ELSE false END AS easy_apply
          FROM jobs
          WHERE id <> $1
            AND featured = $2
            AND (closing_date IS NULL OR closing_date > NOW())
            AND (start_date IS NULL OR start_date < NOW())
            AND (
              category = $3
              OR ($4::text IS NOT NULL AND skill_category = $4)
              OR ($5::text IS NOT NULL AND country = $5)
            )
          ORDER BY
            CASE WHEN is_employer_posted = true THEN 0 ELSE 1 END,
            CASE WHEN $4::text IS NOT NULL AND skill_category = $4 THEN 0 ELSE 1 END,
            CASE WHEN category = $3 THEN 0 ELSE 1 END,
            CASE WHEN $5::text IS NOT NULL AND country = $5 THEN 0 ELSE 1 END,
            posted_at DESC,
            id DESC
          LIMIT $6
        `,[id,featured,current.category,current.skill_category||null,current.country||null,requestedLimit]);
        return q.rows.map((r) => ({
          id:r.id,title:r.title,organization:r.organization,location:r.location,country:r.country,category:r.category,
          skillCategory:r.skill_category,jobType:r.job_type,salary:r.salary,postedAt:r.posted_at,closingDate:r.closing_date,
          featured:!!r.featured,isEmployerPosted:!!r.is_employer_posted,easyApply:!!r.easy_apply
        }));
      }
      const [featured, regular] = await Promise.all([related(true), related(false)]);
      res.set("Cache-Control", "public, max-age=120, stale-while-revalidate=300");
      res.json({ jobId:id, featured, regular });
    } catch (err) {
      console.error("Related priority jobs error:", err);
      res.status(500).json({ message: "Unable to load related jobs" });
    }
  });

  app2.options("/api/v1/jobs", (_req, res) => {
    res.set("Access-Control-Allow-Origin", "*");
    res.set("Access-Control-Allow-Methods", "GET, OPTIONS");
    res.set("Access-Control-Allow-Headers", "Content-Type, Accept");
    res.status(204).end();
  });
  app2.get("/api/v1/jobs", rateLimit(120, 6e4), async (req, res) => {
    try {
      const limit = Math.max(1, Math.min(parseInt(req.query.limit) || 25, 100));
      const offset = Math.max(0, Math.min(parseInt(req.query.offset) || 0, 1e4));
      const category = String(req.query.category || "").trim().toLowerCase();
      const country = String(req.query.country || "").trim().toUpperCase();
      const search = String(req.query.search || "").trim().slice(0,120);
      const easyApply = String(req.query.easyApply || "").toLowerCase() === "true";
      const featuredRaw = String(req.query.featured || "").toLowerCase();
      const clauses = ["(closing_date IS NULL OR closing_date > NOW())", "(start_date IS NULL OR start_date < NOW())"];
      const params = [];
      function add(value) { params.push(value); return `$${params.length}`; }
      if (category) {
        if (SKILL_CATEGORIES.includes(category)) clauses.push(`skill_category = ${add(category)}`);
        else if (SOURCE_CATEGORIES.includes(category)) clauses.push(`category = ${add(category)}`);
        else return res.status(400).json({ message: "Invalid category" });
      }
      if (country) clauses.push(`UPPER(country) = ${add(country)}`);
      if (search) {
        const p = add(`%${search}%`);
        clauses.push(`(title ILIKE ${p} OR organization ILIKE ${p} OR location ILIKE ${p} OR country ILIKE ${p})`);
      }
      if (easyApply) clauses.push("COALESCE(BTRIM(apply_email),'') <> ''");
      if (featuredRaw === "true" || featuredRaw === "false") clauses.push(`featured = ${add(featuredRaw === "true")}`);
      const where = clauses.join(" AND ");
      const countResult = await pool.query(`SELECT COUNT(*)::bigint AS count FROM jobs WHERE ${where}`, params);
      const dataParams = params.slice();
      dataParams.push(limit, offset);
      const rows = await pool.query(`
        SELECT id,title,organization,location,country,category,skill_category,job_type,salary,description,posted_at,closing_date,featured,is_employer_posted,
               CASE WHEN COALESCE(BTRIM(apply_email),'') <> '' THEN true ELSE false END AS easy_apply
        FROM jobs
        WHERE ${where}
        ORDER BY
          CASE WHEN is_employer_posted = true AND featured = true THEN 0
               WHEN is_employer_posted = true THEN 1
               WHEN featured = true THEN 2 ELSE 3 END,
          posted_at DESC,id DESC
        LIMIT $${dataParams.length-1} OFFSET $${dataParams.length}
      `, dataParams);
      const total = Number(countResult.rows[0]?.count || 0);
      const base = "https://devglobaljobs.com/jobs/detail/";
      const items = rows.rows.map((r) => ({
        id:r.id,title:r.title,organization:r.organization,location:r.location,country:r.country,category:r.category,
        skillCategory:r.skill_category,jobType:r.job_type,salary:r.salary,
        descriptionExcerpt:String(r.description||"").replace(/\s+/g," ").trim().slice(0,500),
        postedAt:r.posted_at,closingDate:r.closing_date,featured:!!r.featured,isEmployerPosted:!!r.is_employer_posted,
        easyApply:!!r.easy_apply,url:base+r.id
      }));
      res.set("Access-Control-Allow-Origin", "*");
      res.set("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
      res.set("X-Robots-Tag", "noindex, follow");
      res.json({
        meta:{total,limit,offset,hasMore:offset+limit<total,updatedAt:new Date().toISOString(),license:"Free display API with Dev Global Jobs attribution",documentation:"https://devglobaljobs.com/developers"},
        jobs:items
      });
    } catch (err) {
      console.error("Public jobs API error:", err);
      res.status(500).json({ message: "Unable to load jobs" });
    }
  });
  app2.get("/api/v1/jobs/:id", rateLimit(120, 6e4), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ message: "Invalid job ID" });
      const q = await pool.query(`
        SELECT id,title,organization,location,country,category,skill_category,job_type,salary,description,posted_at,closing_date,featured,is_employer_posted,
               CASE WHEN COALESCE(BTRIM(apply_email),'') <> '' THEN true ELSE false END AS easy_apply
        FROM jobs WHERE id=$1 AND (closing_date IS NULL OR closing_date > NOW()) AND (start_date IS NULL OR start_date < NOW()) LIMIT 1
      `,[id]);
      const r=q.rows[0];
      if(!r)return res.status(404).json({message:"Job not found"});
      res.set("Access-Control-Allow-Origin","*");res.set("Cache-Control","public, max-age=120");res.set("X-Robots-Tag","noindex, follow");
      res.json({id:r.id,title:r.title,organization:r.organization,location:r.location,country:r.country,category:r.category,skillCategory:r.skill_category,jobType:r.job_type,salary:r.salary,description:r.description||"",postedAt:r.posted_at,closingDate:r.closing_date,featured:!!r.featured,isEmployerPosted:!!r.is_employer_posted,easyApply:!!r.easy_apply,url:`https://devglobaljobs.com/jobs/detail/${r.id}`});
    } catch(err){res.status(500).json({message:"Unable to load job"})}
  });
  function dgjXml(value) {
    return String(value == null ? "" : value).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");
  }
  app2.get("/jobs.rss", rateLimit(120, 6e4), async (req, res) => {
    try {
      const category = String(req.query.category || "").trim().toLowerCase();
      const clauses=["(closing_date IS NULL OR closing_date > NOW())","(start_date IS NULL OR start_date < NOW())"];
      const params=[];
      if(category){
        params.push(category);
        if(SKILL_CATEGORIES.includes(category))clauses.push(`skill_category=$1`);
        else if(SOURCE_CATEGORIES.includes(category))clauses.push(`category=$1`);
        else return res.status(400).send("Invalid category");
      }
      const q=await pool.query(`SELECT id,title,organization,location,country,description,posted_at,featured,is_employer_posted FROM jobs WHERE ${clauses.join(" AND ")} ORDER BY CASE WHEN is_employer_posted=true AND featured=true THEN 0 WHEN is_employer_posted=true THEN 1 WHEN featured=true THEN 2 ELSE 3 END, posted_at DESC,id DESC LIMIT 100`,params);
      const base="https://devglobaljobs.com";
      const items=q.rows.map((r)=>`\n    <item>\n      <title>${dgjXml(r.title)} - ${dgjXml(r.organization)}</title>\n      <link>${base}/jobs/detail/${r.id}</link>\n      <guid isPermaLink="true">${base}/jobs/detail/${r.id}</guid>\n      <pubDate>${new Date(r.posted_at||Date.now()).toUTCString()}</pubDate>\n      <description>${dgjXml(String(r.description||`${r.title} at ${r.organization}`).replace(/\\s+/g," ").slice(0,700))}</description>\n      <category>${r.featured?"Featured":"Regular"}</category>\n    </item>`).join("");
      const xml=`<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">\n  <channel>\n    <title>Dev Global Jobs - International Careers</title>\n    <link>${base}/</link>\n    <description>International job opportunities with employer-posted jobs prioritised.</description>\n    <language>en</language>\n    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>\n    <atom:link href="${base}/jobs.rss${category?`?category=${encodeURIComponent(category)}`:""}" rel="self" type="application/rss+xml" />${items}\n  </channel>\n</rss>`;
      res.set("Content-Type","application/rss+xml; charset=utf-8");res.set("Cache-Control","public, max-age=300, stale-while-revalidate=600");res.send(xml);
    } catch(err){console.error("Jobs RSS error:",err);res.status(500).send("Unable to generate feed")}
  });
  app2.get("/llms.txt", (_req,res)=>{
    res.type("text/plain").set("Cache-Control","public, max-age=3600").send(`# Dev Global Jobs

> Dev Global Jobs is an international careers platform for discovering jobs by category, industry, country and city, together with remote work, sponsored opportunities, early-career pathways, career tools, resources, employer hiring access and developer feeds.

## Canonical brand identity
- Brand: Dev Global Jobs
- Primary identity: International Careers Platform
- Website: https://devglobaljobs.com/
- All jobs: https://devglobaljobs.com/jobs/all
- International jobs and work abroad: https://devglobaljobs.com/jobs/international
- Sponsored jobs: https://devglobaljobs.com/jobs/sponsored
- Developer API and RSS: https://devglobaljobs.com/developers
- Sitemap: https://devglobaljobs.com/sitemap.xml

## Important route semantics
- /jobs/all is the complete jobs marketplace across categories, industries, countries, cities, career levels and work styles.
- /jobs/international is specifically for international and cross-border work-abroad opportunities.
- /jobs/sponsored is specifically for sponsored, employer-promoted job listings.
- Featured is a placement/status shown on the homepage and category pages. It is not a standalone SEO page and featured discovery leads to /jobs/all.
- UN Jobs and NGO Jobs are specialist categories inside the wider international careers platform; they are not the overall identity of Dev Global Jobs.

## Career coverage
Dev Global Jobs includes technology, healthcare, business and finance, education, engineering, creative and media, sales and marketing, freelance and contract, remote, UN, NGO, youth and other career pathways. Location discovery includes country and city job pages.

## Tools and resources
The platform includes salary comparison, cost-of-living, resume checking, ATS keyword scanning, interview preparation, cover-letter guidance, work-permit information, remote-work tax guidance, salary negotiation, career-path planning, LinkedIn optimisation, universities, courses, certifications, internships, scholarships, visa guidance, eligibility resources and volunteer opportunities.

## Machine-readable brand contract
https://devglobaljobs.com/brand-contract.json

This file describes the platform accurately and does not make ranking, traffic or market-leadership guarantees.`);
  });

  app2.get("/api/jobs/:category", async (req, res) => {
    try {
      const { category } = req.params;
      if (!VALID_CATEGORIES.includes(category)) {
        return res.status(400).json({ message: "Invalid category" });
      }
      const limit = Math.min(parseInt(req.query.limit) || 30, 100);
      const offset = parseInt(req.query.offset) || 0;
      const search = req.query.search || "";
      const easyApplyOnly = String(req.query.easyApply || "").toLowerCase() === "true";
      const result = await storage.getJobsPaginated(
        category === "all" ? void 0 : category,
        limit,
        offset,
        search,
        easyApplyOnly
      );
      res.json({
        jobs: result.jobs,
        total: result.total,
        limit,
        offset,
        hasMore: offset + limit < result.total
      });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/jobs/country/stats", async (_req, res) => {
    try {
      const cachedCountryStats = getCached("country_stats");
      if (cachedCountryStats) return res.json(cachedCountryStats);
      const stats = await storage.getCountryStats();
      const mapped = stats.filter((s) => s.code && s.code.length <= 3).map((s) => {
        const slug = Object.entries(COUNTRY_MAP).find(([_, v]) => v.code === s.code);
        return {
          code: s.code,
          slug: slug ? slug[0] : s.code.toLowerCase(),
          name: slug ? slug[1].name : s.code,
          count: s.count
        };
      });
      setCache("country_stats", mapped, CACHE_TTL_COUNTRY_STATS);
      res.json(mapped);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/universities", async (req, res) => {
    try {
      const country = req.query.country || "";
      const name = req.query.name || "";
      const cacheKey = `universities_${country}_${name}`;
      const cached = getCached(cacheKey);
      if (cached) return res.json(cached);
      let apiUrl = "http://universities.hipolabs.com/search";
      const params = new URLSearchParams();
      if (country) params.set("country", country);
      if (name) params.set("name", name);
      const qs = params.toString();
      if (qs) apiUrl += "?" + qs;
      const response = await fetch(apiUrl);
      if (!response.ok) {
        return res.status(502).json({ message: "Failed to fetch universities" });
      }
      const data = await response.json();
      const universities = data.slice(0, 200).map((u) => ({
        name: u.name,
        country: u.country,
        code: u.alpha_two_code,
        domains: u.domains || [],
        webPages: u.web_pages || [],
        stateProvince: u["state-province"] || null
      }));
      setCache(cacheKey, universities, 300 * 1e3);
      res.json(universities);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/jobs/country/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const countryInfo = COUNTRY_MAP[slug];
      let code;
      let name;
      let hreflang;
      if (countryInfo) {
        code = countryInfo.code;
        name = countryInfo.name;
        hreflang = countryInfo.hreflang;
      } else if (/^[a-z]{2}$/.test(slug)) {
        code = slug.toUpperCase();
        name = slug.toUpperCase();
        hreflang = `en-${code}`;
      } else {
        return res.status(400).json({ message: "Invalid country" });
      }
      const limit = Math.min(parseInt(req.query.limit) || 30, 100);
      const offset = parseInt(req.query.offset) || 0;
      const search = req.query.search || "";
      const result = await storage.getJobsByCountryPaginated(
        code,
        limit,
        offset,
        search
      );
      res.json({
        jobs: result.jobs,
        total: result.total,
        limit,
        offset,
        hasMore: offset + limit < result.total,
        country: { code, name, slug, hreflang }
      });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/jobs/city/:city", async (req, res) => {
    try {
      const city = decodeURIComponent(req.params.city).replace(/-/g, " ").trim();
      if (!city || city.length < 2 || city.length > 60) {
        return res.status(400).json({ message: "Invalid city" });
      }
      const limit = Math.min(parseInt(req.query.limit) || 30, 100);
      const offset = parseInt(req.query.offset) || 0;
      const search = req.query.search || "";
      const result = await storage.getJobsByCityPaginated(city, limit, offset, search);
      res.json({
        jobs: result.jobs,
        total: result.total,
        limit,
        offset,
        hasMore: offset + limit < result.total,
        city: { name: city.split(" ").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" "), slug: req.params.city }
      });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/admin-post-job", rateLimit(10, 6e4), async (req, res) => {
    let quotaClient;
    try {
      const parsed = postJobSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid job data", errors: parsed.error.flatten() });
      }
      const VALID_ADMIN_CODES = [
        "TNW112288899", "TNW1122888910", "TNW112288811", "TNW1122887789",
        "TNW1122888726", "TNW112287625", "TNW11228876829", "TNW112288879",
        "TNW1122809872", "TNW1122887829", "TNW1122880928", "TNW1122888792"
      ];
      const envCodes = process.env.ADMIN_POST_CODES?.split(",").map((c) => c.trim()).filter(Boolean) || [];
      const allCodes = [...VALID_ADMIN_CODES, ...envCodes];
      const submittedCode = parsed.data.adminCode?.trim() || "";
      const hasValidAdminCode = submittedCode.length > 0 && allCodes.includes(submittedCode);
      const isFeatured = parsed.data.listingType === "featured";
      const employerEmail = (parsed.data.applyEmail || "").trim().toLowerCase();

      if (submittedCode && !hasValidAdminCode) {
        return res.status(403).json({ message: "Invalid admin code" });
      }
      if (!hasValidAdminCode && !req.session?.seekerAccountId) {
        return res.status(401).json({ message: "Please sign in or create a verified account before posting a free employer job." });
      }
      if (!hasValidAdminCode && !employerEmail) {
        return res.status(400).json({ message: "Application email is required to use the monthly free employer allowance." });
      }

      await ensureGrowthTables();
      let regularMonthlyCount = 0;
      let featuredMonthlyCount = 0;
      if (!hasValidAdminCode) {
        quotaClient = await pool.connect();
        await quotaClient.query("BEGIN");
        const employerAccountId = Number(req.session.seekerAccountId);
        await quotaClient.query("SELECT pg_advisory_xact_lock(hashtext($1))", [`dgj-free-account:${employerAccountId}`]);
        const quotaResult = await quotaClient.query(`
          SELECT
            COUNT(*) FILTER (WHERE p.listing_type='regular')::int AS regular_count,
            COUNT(*) FILTER (WHERE p.listing_type='featured')::int AS featured_count
          FROM dgj_employer_postings p
          WHERE p.allowance_type = 'free'
            AND p.posted_at >= date_trunc('month', CURRENT_TIMESTAMP)
            AND p.posted_at < date_trunc('month', CURRENT_TIMESTAMP) + INTERVAL '1 month'
            AND (p.account_id=$1 OR (p.account_id IS NULL AND p.employer_email=$2))
        `, [employerAccountId,employerEmail]);
        regularMonthlyCount = Number(quotaResult.rows?.[0]?.regular_count || 0);
        featuredMonthlyCount = Number(quotaResult.rows?.[0]?.featured_count || 0);
        const reached = isFeatured ? featuredMonthlyCount >= 2 : regularMonthlyCount >= 5;
        if (reached) {
          await quotaClient.query("ROLLBACK");
          quotaClient.release();
          quotaClient = undefined;
          return res.status(403).json({
            message: isFeatured ? "You have used your 2 free Featured job posts for this month. Contact our team for additional premium placements." : "You have used your 5 free Regular job posts for this month. Contact our team for additional placements.",
            code: isFeatured ? "MONTHLY_FREE_FEATURED_LIMIT_REACHED" : "MONTHLY_FREE_REGULAR_LIMIT_REACHED",
            regularUsed: regularMonthlyCount, regularRemaining: Math.max(0,5-regularMonthlyCount),
            featuredUsed: featuredMonthlyCount, featuredRemaining: Math.max(0,2-featuredMonthlyCount)
          });
        }
      }

      const skillCat = classifyJobSkillCategory(parsed.data.title, parsed.data.description || "");
      const job = await storage.insertJob({
        title: parsed.data.title,
        organization: parsed.data.organization,
        location: parsed.data.location,
        category: parsed.data.category,
        skillCategory: skillCat || "business",
        description: parsed.data.description,
        url: parsed.data.url || null,
        source: "Employer",
        sourceId: `employer-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        jobType: parsed.data.jobType || null,
        salary: parsed.data.salary || null,
        country: parsed.data.country || null,
        startDate: parsed.data.startDate ? new Date(parsed.data.startDate) : null,
        closingDate: parsed.data.closingDate ? new Date(parsed.data.closingDate) : null,
        isEmployerPosted: true,
        applyEmail: parsed.data.applyEmail || null,
        stripePaymentId: null,
        featured: isFeatured
      });

      if (quotaClient) {
        await quotaClient.query("COMMIT");
        quotaClient.release();
        quotaClient = undefined;
      }
      queueUrlForIndexing(`https://devglobaljobs.com/jobs/detail/${job.id}`);
      queueGoogleIndexingUpdate(job.id);
      await dgjRecordEmployerPosting(employerEmail,parsed.data.organization,parsed.data.country||null,req.session?.seekerAccountId||null,job,hasValidAdminCode?'admin':'free');
      res.json({
        success: true,
        job,
        postingType: hasValidAdminCode ? (isFeatured ? "featured-admin" : "admin") : (isFeatured ? "free-featured" : "free-regular"),
        allowance: hasValidAdminCode ? undefined : {
          regularUsed: regularMonthlyCount + (isFeatured ? 0 : 1),
          regularRemaining: Math.max(0,5-regularMonthlyCount-(isFeatured?0:1)),
          featuredUsed: featuredMonthlyCount + (isFeatured ? 1 : 0),
          featuredRemaining: Math.max(0,2-featuredMonthlyCount-(isFeatured?1:0))
        },
        url: "/payment-success?free=1"
      });
    } catch (err) {
      if (quotaClient) {
        try { await quotaClient.query("ROLLBACK"); } catch {}
        quotaClient.release();
      }
      console.error("Admin post job error:", err);
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/create-payment-intent", rateLimit(10, 6e4), async (req, res) => {
    // The public form historically calls this route. Preserve the form while routing the request
    // into the new monthly free allowance engine without rebuilding the stale client bundle.
    return res.redirect(307, "/api/admin-post-job");
  });
  app2.post("/api/confirm-payment", rateLimit(10, 6e4), async (_req, res) => {
    res.status(410).json({ message: "Payment confirmation not available. Please email info@devglobaljobs.com with your Wise receipt." });
  });
  app2.get("/sitemap-index.xml", async (_req, res) => {
    try {
      const jobIds = await storage.getAllJobIds();
      const totalJobs = jobIds.length;
      const sitemapCount = Math.ceil(totalJobs / MAX_URLS_PER_SITEMAP) + 1;
      const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
      let xml = `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>${BASE_URL3}/sitemap-pages.xml</loc>
    <lastmod>${today}</lastmod>
  </sitemap>
  <sitemap>
    <loc>${BASE_URL3}/sitemap-jobs-latest.xml</loc>
    <lastmod>${today}</lastmod>
  </sitemap>`;
      for (const slug of Object.keys(COUNTRY_MAP)) {
        xml += `
  <sitemap>
    <loc>${BASE_URL3}/sitemap-jobs-${slug}.xml</loc>
    <lastmod>${today}</lastmod>
  </sitemap>`;
      }
      for (let i = 1; i < sitemapCount; i++) {
        xml += `
  <sitemap>
    <loc>${BASE_URL3}/sitemap-jobs-${i}.xml</loc>
    <lastmod>${today}</lastmod>
  </sitemap>`;
      }
      xml += `
</sitemapindex>`;
      res.set("Content-Type", "application/xml");
      res.set("Cache-Control", "public, max-age=3600");
      res.send(xml);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/sitemap-pages.xml", async (_req, res) => {
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
  <url>
    <loc>${BASE_URL3}/</loc>
    <lastmod>${today}</lastmod>
    <changefreq>hourly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/jobs/all</loc>
    <lastmod>${today}</lastmod>
    <changefreq>hourly</changefreq>
    <priority>0.9</priority>
  </url>`;
    const categories = VALID_CATEGORIES.filter((c) => c !== "all");
    for (const cat of categories) {
      xml += `
  <url>
    <loc>${BASE_URL3}/jobs/${cat}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>hourly</changefreq>
    <priority>0.8</priority>
  </url>`;
    }
    const countrySlugs = Object.keys(COUNTRY_MAP);
    for (const slug of countrySlugs) {
      const info = COUNTRY_MAP[slug];
      xml += `
  <url>
    <loc>${BASE_URL3}/jobs/country/${slug}</loc>
    <xhtml:link rel="alternate" hreflang="x-default" href="${BASE_URL3}/jobs/country/${slug}" />`;
      for (const altSlug of countrySlugs) {
        const altInfo = COUNTRY_MAP[altSlug];
        xml += `
    <xhtml:link rel="alternate" hreflang="${altInfo.hreflang}" href="${BASE_URL3}/jobs/country/${altSlug}" />`;
      }
      xml += `
    <lastmod>${today}</lastmod>
    <changefreq>hourly</changefreq>
    <priority>0.8</priority>
  </url>`;
    }
    const TOP_CITIES = [
      "london",
      "new-york",
      "dubai",
      "toronto",
      "sydney",
      "berlin",
      "paris",
      "amsterdam",
      "singapore",
      "tokyo",
      "zurich",
      "stockholm",
      "geneva",
      "vienna",
      "brussels",
      "melbourne",
      "vancouver",
      "boston",
      "san-francisco",
      "chicago",
      "los-angeles",
      "washington-dc",
      "ottawa",
      "dublin",
      "edinburgh",
      "madrid",
      "barcelona",
      "rome",
      "oslo",
      "copenhagen",
      "helsinki",
      "seoul",
      "hong-kong",
      "kuala-lumpur",
      "bangkok",
      "montreal",
      "lisbon",
      "abu-dhabi",
      "warsaw",
      "prague",
      "budapest",
      "cape-town",
      "nairobi",
      "istanbul",
      "shanghai",
      "munich",
      "frankfurt",
      "milan",
      "auckland",
      "denver"
    ];
    for (const citySlug of TOP_CITIES) {
      xml += `
  <url>
    <loc>${BASE_URL3}/jobs/city/${citySlug}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>`;
    }
    xml += `
  <url>
    <loc>${BASE_URL3}/post-job</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/pricing</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/universities</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/online-courses</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/free-certifications</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/internships</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/scholarships</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/visa-guide</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/eligibility-checker</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/volunteers</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/country-salary-calculator</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/salary-calculator</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/ngo-salary-guide</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/cost-of-living</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/resume-checker</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/interview-prep</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/cover-letter</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/work-permit-guide</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/remote-work-tax</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/ats-keywords</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/salary-negotiation</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/career-path</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/tools/linkedin-optimizer</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/developers</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/about</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/privacy</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.3</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/terms</loc>
    <lastmod>${today}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.3</priority>
  </url>
  <url>
    <loc>${BASE_URL3}/blog</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`;
    const staticBlogSlugs = [
      "how-to-find-international-remote-jobs-2026",
      "top-companies-hiring-internationally-remote-2026",
      "remote-jobs-open-to-african-candidates-2026",
      "un-jobs-application-guide-beginners",
      "work-from-anywhere-entry-level-jobs-guide",
      "optimize-linkedin-profile-international-jobs",
      "best-remote-jobs-career-changers-2026",
      "how-to-get-hired-international-ngos",
      "remote-data-analyst-jobs-no-experience",
      "cross-cultural-remote-work-skills",
      "digital-nomad-visa-guide-2026",
      "ats-friendly-resume-tips-global-job-seekers",
      "best-countries-remote-workers-2026",
      "how-to-negotiate-salary-international-jobs",
      "remote-work-tax-guide-international-workers",
      "top-scholarships-international-students-2026",
      "how-to-prepare-un-job-interviews",
      "ngo-salary-guide-country-role",
      "remote-engineering-jobs-international-2026",
      "healthcare-jobs-abroad-without-experience",
      "international-internship-programs-guide-2026",
      "async-communication-remote-careers",
      "cost-of-living-comparison-expats-2026",
      "freelance-project-manager-remote-jobs-2026",
      "remote-sustainability-consultant-jobs",
      "bilingual-customer-service-remote-jobs",
      "how-to-write-un-cv-that-gets-noticed",
      "remote-ux-design-jobs-international",
      "cover-letter-guide-international-job-applications",
      "work-permit-guide-international-workers-2026",
      "ai-literacy-remote-jobs-international",
      "remote-content-strategist-jobs-international"
    ];
    for (const slug of staticBlogSlugs) {
      xml += `
  <url>
    <loc>${BASE_URL3}/blog/${slug}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`;
    }
    try {
      const dbPosts = await storage.getBlogPosts(1, 500, "published");
      const staticSlugSet = new Set(staticBlogSlugs);
      for (const post of dbPosts.posts || []) {
        if (!staticSlugSet.has(post.slug)) {
          const lastmod = post.updatedAt ? new Date(post.updatedAt).toISOString().split("T")[0] : today;
          xml += `
  <url>
    <loc>${BASE_URL3}/blog/${post.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.75</priority>
  </url>`;
        }
      }
    } catch (_) {
    }
    xml += `
</urlset>`;
    res.set("Content-Type", "application/xml");
    res.set("Cache-Control", "public, max-age=3600");
    res.send(xml);
  });
  app2.get("/sitemap-jobs-:param.xml", async (req, res) => {
    const param = req.params.param;
    try {
      if (param === "latest") {
        const latestJobs = await storage.getLatestJobIds(5e3);
        const indexableJobs = latestJobs;
        let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`;
        for (const job of indexableJobs) {
          const lastmod = job.postedAt ? new Date(job.postedAt).toISOString().split("T")[0] : (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
          xml += `
  <url>
    <loc>${BASE_URL3}/jobs/detail/${job.id}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>`;
        }
        xml += `
</urlset>`;
        res.set("Content-Type", "application/xml");
        res.set("Cache-Control", "public, max-age=3600");
        return res.send(xml);
      }
      const countryInfo = COUNTRY_MAP[param];
      if (countryInfo) {
        const jobIds = await storage.getJobIdsByCountry(countryInfo.code);
        const indexableJobs = jobIds;
        let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${BASE_URL3}/jobs/country/${param}</loc>
    <lastmod>${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}</lastmod>
    <changefreq>hourly</changefreq>
    <priority>0.9</priority>
  </url>`;
        for (const job of indexableJobs) {
          const lastmod = job.postedAt ? new Date(job.postedAt).toISOString().split("T")[0] : (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
          xml += `
  <url>
    <loc>${BASE_URL3}/jobs/detail/${job.id}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`;
        }
        xml += `
</urlset>`;
        res.set("Content-Type", "application/xml");
        res.set("Cache-Control", "public, max-age=3600");
        return res.send(xml);
      }
      const num = parseInt(param);
      if (!isNaN(num) && num >= 1) {
        const allJobIds = await storage.getAllJobIds();
        const indexableJobs = allJobIds;
        const startIdx = (num - 1) * MAX_URLS_PER_SITEMAP;
        const endIdx = startIdx + MAX_URLS_PER_SITEMAP;
        const batch = indexableJobs.slice(startIdx, endIdx);
        if (batch.length === 0) {
          return res.status(404).send("Not found");
        }
        let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`;
        for (const job of batch) {
          const lastmod = job.postedAt ? new Date(job.postedAt).toISOString().split("T")[0] : (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
          xml += `
  <url>
    <loc>${BASE_URL3}/jobs/detail/${job.id}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`;
        }
        xml += `
</urlset>`;
        res.set("Content-Type", "application/xml");
        res.set("Cache-Control", "public, max-age=3600");
        return res.send(xml);
      }
      res.status(404).send("Not found");
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/sitemap.xml", (_req, res) => {
    res.redirect(301, "/sitemap-index.xml");
  });
  app2.get("/ads.txt", (_req, res) => {
    res.set("Content-Type", "text/plain");
    res.send("google.com, pub-9745549403756141, DIRECT, f08c47fec0942fa0\n");
  });
  app2.get("/.well-known/assetlinks.json", (_req, res) => {
    res.set("Content-Type", "application/json");
    res.set("Cache-Control", "public, max-age=86400");
    res.json([{
      "relation": ["delegate_permission/common.handle_all_urls"],
      "target": {
        "namespace": "android_app",
        "package_name": "com.devglobaljobs.app",
        "sha256_cert_fingerprints": ["4A:08:64:0F:E3:07:5E:0B:87:6C:B3:E2:BC:FD:04:A2:8A:30:48:F3:E4:2A:59:8E:F2:35:E0:8E:4E:79:8E:13"]
      }
    }]);
  });
  app2.get("/robots.txt", (_req, res) => {
    const countrySitemaps = Object.keys(COUNTRY_MAP).map((slug) => `Sitemap: ${BASE_URL3}/sitemap-jobs-${slug}.xml`).join("\n");
    res.set("Content-Type", "text/plain");
    res.set("Cache-Control", "public, max-age=3600");
    res.send(`User-agent: Googlebot
Allow: /
Allow: /jobs/
Allow: /jobs/all
Allow: /jobs/un
Allow: /jobs/ngo
Allow: /jobs/remote
Allow: /jobs/international
Allow: /jobs/technology
Allow: /jobs/healthcare
Allow: /jobs/business
Allow: /jobs/education
Allow: /jobs/engineering
Allow: /jobs/creative
Allow: /jobs/sales
Allow: /jobs/gig
Allow: /jobs/youth
Allow: /jobs/sponsored
Allow: /jobs/country/
Allow: /jobs/detail/
Allow: /universities
Allow: /online-courses
Allow: /free-certifications
Allow: /internships
Allow: /scholarships
Allow: /visa-guide
Allow: /eligibility-checker
Allow: /volunteers
Allow: /tools/salary-calculator
Allow: /tools/ngo-salary-guide
Allow: /tools/cost-of-living
Allow: /tools/resume-checker
Allow: /tools/interview-prep
Allow: /tools/cover-letter
Allow: /tools/work-permit-guide
Allow: /tools/remote-work-tax
Allow: /tools/country-salary-calculator
Allow: /tools/ats-keywords
Allow: /tools/salary-negotiation
Allow: /tools/career-path
Allow: /tools/linkedin-optimizer
Allow: /post-job
Allow: /pricing
Allow: /about
Allow: /privacy
Allow: /terms
Disallow: /api/
Disallow: /payment-success

User-agent: Bingbot
Allow: /
Allow: /jobs/
Allow: /jobs/country/
Allow: /jobs/detail/
Allow: /universities
Allow: /online-courses
Allow: /free-certifications
Allow: /internships
Allow: /scholarships
Allow: /visa-guide
Allow: /eligibility-checker
Allow: /volunteers
Allow: /tools/
Allow: /post-job
Allow: /pricing
Allow: /about
Disallow: /api/
Disallow: /payment-success

User-agent: *
Allow: /
Allow: /jobs/
Allow: /jobs/country/
Allow: /jobs/detail/
Allow: /universities
Allow: /online-courses
Allow: /free-certifications
Allow: /internships
Allow: /scholarships
Allow: /visa-guide
Allow: /eligibility-checker
Allow: /volunteers
Allow: /tools/
Allow: /post-job
Allow: /pricing
Allow: /about
Disallow: /api/
Disallow: /payment-success
Disallow: /admin
Crawl-delay: 1

Sitemap: ${BASE_URL3}/sitemap-index.xml
Sitemap: ${BASE_URL3}/sitemap-pages.xml
Sitemap: ${BASE_URL3}/sitemap-jobs-latest.xml
${countrySitemaps}
`);
  });
  const indexNowKey = getIndexNowKey();
  app2.get(`/${indexNowKey}.txt`, (_req, res) => {
    res.set("Content-Type", "text/plain");
    res.send(indexNowKey);
  });
  app2.post("/api/jobs/refresh", rateLimit(3, 6e4), async (_req, res) => {
    try {
      fetchAllJobsSafe();
      res.json({ success: true, message: "Job refresh triggered" });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/admin/login", rateLimit(10, 6e4), async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
      }
      if (!validateAdminUser(username, password)) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      req.session.adminUser = username;
      req.session.save((err) => {
        if (err) return res.status(500).json({ message: "Session error. Please try again." });
        res.json({ success: true, username });
      });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/admin/logout", (req, res) => {
    req.session.destroy(() => {
      res.clearCookie("connect.sid");
      res.json({ success: true });
    });
  });
  app2.get("/api/admin/me", (req, res) => {
    if (req.session?.adminUser) {
      return res.json({ username: req.session.adminUser });
    }
    res.status(401).json({ message: "Not authenticated" });
  });
  app2.get("/api/admin/jobs", requireAdmin, async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 50;
      const search = req.query.search || void 0;
      const source = req.query.source || void 0;
      const category = req.query.category || void 0;
      const result = await storage.getAdminJobs(page, limit, search, source, category);
      res.json(result);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/admin/jobs", requireAdmin, async (req, res) => {
    try {
      const {
        title,
        organization,
        location,
        category,
        description,
        url,
        jobType,
        salary,
        country,
        applyEmail,
        featured,
        source,
        sourceId,
        startDate,
        closingDate
      } = req.body;
      if (!title || !organization || !category) {
        return res.status(400).json({ message: "Title, organization and category are required" });
      }
      const skillCategory = classifyJobSkillCategory(title, description || "");
      const job = await storage.insertJob({
        title,
        organization,
        location: location || "Remote",
        category,
        skillCategory,
        description: description || "",
        url: url || null,
        source: source || "Admin",
        sourceId: sourceId || `admin-${Date.now()}-${Math.random().toString(36).slice(2)}`,
        jobType: jobType || null,
        salary: salary || null,
        country: country || null,
        isEmployerPosted: true,
        applyEmail: applyEmail || null,
        featured: featured === true || featured === "true",
        stripePaymentId: null,
        startDate: startDate ? new Date(startDate) : null,
        closingDate: closingDate ? new Date(closingDate) : null
      });
      queueGoogleIndexingUpdate(job.id);
      res.json({ success: true, job });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.put("/api/admin/jobs/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updated = await storage.updateJobById(id, req.body);
      if (!updated) return res.status(404).json({ message: "Job not found" });
      res.json({ success: true, job: updated });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.delete("/api/admin/jobs/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteJobById(id);
      queueGoogleIndexingDelete(id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/stats", requireAdmin, async (_req, res) => {
    try {
      const stats = await storage.getAdminStats();
      try { const growth = await dgjGrowthOverview(); stats.subscribers = growth.active_subscribers; stats.seekers = growth.seekers_total; stats.employers = growth.employers_total; stats.signinsToday = growth.signins_today; } catch(_e) {}
      res.json(stats);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/sources", requireAdmin, async (_req, res) => {
    try {
      const sources = await storage.getSourcesList();
      res.json(sources);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/revenue-metrics", requireAdmin, async (_req, res) => {
    try {
      const metrics = await storage.getRevenueMetrics();
      res.json(metrics);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/newsletter", requireAdmin, async (_req, res) => {
    try {
      const subscribers = await storage.getSubscribers();
      res.json(subscribers);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.delete("/api/admin/newsletter/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid subscriber ID" });
      await storage.deleteSubscriber(id);
      res.json({ success: true, message: "Subscriber deleted" });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/google-indexing-status", requireAdmin, (_req, res) => {
    res.json(getGoogleIndexingStatus());
  });
  app2.get("/api/admin/fetch-status", requireAdmin, (_req, res) => {
    res.json(getAllFetchCycles());
  });
  app2.get("/api/admin/blog", requireAdmin, async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 20;
      const status = req.query.status;
      const result = await storage.getBlogPosts(page, limit, status);
      res.json(result);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/blog", async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;
      const result = await storage.getBlogPosts(page, limit, "published");
      res.json(result);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/blog/:slug", async (req, res) => {
    try {
      const post = await storage.getBlogPostBySlug(req.params.slug);
      if (!post) return res.status(404).json({ message: "Blog post not found" });
      res.json(post);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  function normalizeBlogForSeo(payload, existing = {}) {
    const title = String(payload.title ?? existing.title ?? "").trim();
    const slugBase = String(payload.slug ?? existing.slug ?? title).trim().toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    const content = String(payload.content ?? existing.content ?? "");
    const plainText = content.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    const words = plainText ? plainText.split(/\s+/).length : 0;
    const status = String(payload.status ?? existing.status ?? "draft");
    const h1Count = (content.match(/<h1\b/gi) || []).length;
    const h2Count = (content.match(/<h2\b/gi) || []).length;
    const h3Count = (content.match(/<h3\b/gi) || []).length;
    if (status === "published") {
      if (words < 600) throw new Error(`Published articles require at least 600 words. Current: ${words}.`);
      if (h1Count > 0) throw new Error("Do not add H1 inside article content. The article title is the single page H1.");
      if (h2Count < 2) throw new Error("Published articles require at least two H2 section headings.");
      if (!String(payload.metaDescription ?? existing.metaDescription ?? "").trim()) throw new Error("Meta description is required before publishing.");
    }
    const metaTitle = String(payload.metaTitle ?? existing.metaTitle ?? title).trim().slice(0, 60);
    const excerpt = String(payload.excerpt ?? existing.excerpt ?? plainText.slice(0, 220)).trim();
    const metaDescription = String(payload.metaDescription ?? existing.metaDescription ?? excerpt.slice(0, 160)).trim().slice(0, 160);
    const canonicalUrl = String(payload.canonicalUrl ?? existing.canonicalUrl ?? `https://devglobaljobs.com/blog/${slugBase}`).trim();
    return {
      ...existing,
      ...payload,
      title,
      slug: slugBase,
      content,
      excerpt: excerpt || null,
      metaTitle: metaTitle || title,
      metaDescription: metaDescription || null,
      canonicalUrl,
      ogTitle: String(payload.ogTitle ?? existing.ogTitle ?? metaTitle ?? title).trim().slice(0, 95),
      ogDescription: String(payload.ogDescription ?? existing.ogDescription ?? metaDescription ?? excerpt).trim().slice(0, 200),
      schemaType: payload.schemaType || existing.schemaType || "BlogPosting",
      wordCount: words,
      readingTimeMinutes: Math.max(1, Math.ceil(words / 220)),
      seoHeadingSummary: { pageH1: 1, contentH1: h1Count, h2: h2Count, h3: h3Count }
    };
  }
  app2.post("/api/admin/blog", requireAdmin, async (req, res) => {
    try {
      const normalized = normalizeBlogForSeo(req.body);
      if (!normalized.title || !normalized.slug) return res.status(400).json({ message: "Title and slug are required" });
      const status = normalized.status || "draft";
      const post = await storage.createBlogPost({
        ...normalized,
        publishedAt: status === "published" ? new Date() : null,
        createdAt: new Date(),
        updatedAt: new Date()
      });
      if (status === "published") {
        queueUrlForIndexing(`${BASE_URL3}/blog/${post.slug}`);
        queueGoogleBlogUpdate(post.slug);
      }
      res.json({ success: true, post });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(400).json({ message });
    }
  });
  app2.put("/api/admin/blog/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const existing = await storage.getBlogPostById(id);
      if (!existing) return res.status(404).json({ message: "Blog post not found" });
      const normalized = normalizeBlogForSeo(req.body, existing);
      const wasPublished = existing.status === "published";
      const isPublishing = normalized.status === "published" && !wasPublished;
      const updated = await storage.updateBlogPost(id, {
        ...normalized,
        publishedAt: isPublishing ? new Date() : existing.publishedAt,
        updatedAt: new Date()
      });
      if (updated && (isPublishing || normalized.status === "published")) {
        queueUrlForIndexing(`${BASE_URL3}/blog/${updated.slug}`);
        queueGoogleBlogUpdate(updated.slug);
      }
      res.json({ success: true, post: updated });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(400).json({ message });
    }
  });
  app2.delete("/api/admin/blog/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getBlogPostById(id);
      if (post && post.status === "published") {
        queueGoogleBlogDelete(post.slug);
      }
      await storage.deleteBlogPost(id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/admin/fetch-jobs", requireAdmin, async (_req, res) => {
    try {
      fetchAllJobsSafe();
      res.json({ success: true, message: "Job fetch triggered" });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  function requireSeeker(req, res, next) {
    if (req.session && req.session.seekerAccountId) return next();
    return res.status(401).json({ message: "Please sign in to continue." });
  }
  let dgjVerificationTableReady = false;
  let dgjMailTransport = null;
  async function ensureSeekerVerificationTable() {
    if (dgjVerificationTableReady) return;
    await pool.query(`
      CREATE TABLE IF NOT EXISTS job_seeker_email_verifications (
        id BIGSERIAL PRIMARY KEY,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        country TEXT NOT NULL,
        code_hash TEXT NOT NULL,
        expires_at TIMESTAMPTZ NOT NULL,
        resend_after TIMESTAMPTZ NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_job_seeker_email_verifications_expires ON job_seeker_email_verifications(expires_at)`);
    dgjVerificationTableReady = true;
  }
  function normalizeSeekerEmail(value) {
    return String(value || "").trim().toLowerCase();
  }
  function validSeekerEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value) && value.length <= 254;
  }
  function validSeekerPassword(value) {
    const password = String(value || "");
    let classes = 0;
    if (/[a-z]/.test(password)) classes++;
    if (/[A-Z]/.test(password)) classes++;
    if (/\d/.test(password)) classes++;
    if (/[^A-Za-z0-9]/.test(password)) classes++;
    return password.length >= 10 && password.length <= 128 && classes >= 3;
  }
  function hashSeekerPasswordSecure(password) {
    const N = 16384, r = 8, p = 1;
    const salt = import_crypto2.default.randomBytes(16).toString("hex");
    const derived = import_crypto2.default.scryptSync(password, salt, 64, { N, r, p, maxmem: 64 * 1024 * 1024 });
    return `scrypt$${N}$${r}$${p}$${salt}$${derived.toString("hex")}`;
  }
  function verifySeekerPassword(password, stored) {
    try {
      const value = String(stored || "");
      if (value.startsWith("scrypt$")) {
        const parts = value.split("$");
        if (parts.length !== 6) return { ok: false, legacy: false };
        const N = Number(parts[1]), r = Number(parts[2]), p = Number(parts[3]), salt = parts[4];
        const expected = Buffer.from(parts[5], "hex");
        const actual = import_crypto2.default.scryptSync(password, salt, expected.length, { N, r, p, maxmem: 64 * 1024 * 1024 });
        return { ok: expected.length === actual.length && import_crypto2.default.timingSafeEqual(expected, actual), legacy: false };
      }
      if (/^[a-f0-9]{64}$/i.test(value)) {
        const legacy = import_crypto2.default.createHash("sha256").update(password + "dgj-seeker-salt-2026").digest("hex");
        const a = Buffer.from(legacy, "hex"), b = Buffer.from(value, "hex");
        return { ok: a.length === b.length && import_crypto2.default.timingSafeEqual(a, b), legacy: true };
      }
      return { ok: false, legacy: false };
    } catch (_err) {
      return { ok: false, legacy: false };
    }
  }
  function verificationCodeHash(email, code) {
    const secret = process.env.EMAIL_VERIFICATION_SECRET || process.env.SESSION_SECRET;
    if (!secret || String(secret).length < 32) throw new Error("A secure EMAIL_VERIFICATION_SECRET or SESSION_SECRET is required");
    return import_crypto2.default.createHmac("sha256", secret).update(email + "|" + code).digest("hex");
  }
  function safeEqualHex(a, b) {
    try {
      const aa = Buffer.from(String(a || ""), "hex");
      const bb = Buffer.from(String(b || ""), "hex");
      return aa.length > 0 && aa.length === bb.length && import_crypto2.default.timingSafeEqual(aa, bb);
    } catch (_err) { return false; }
  }
  let dgjEasyApplyTokenTableReady = false;
  async function ensureEasyApplyTokenTable() {
    if (dgjEasyApplyTokenTableReady) return;
    await pool.query(`CREATE TABLE IF NOT EXISTS dgj_easy_apply_tokens (
      id BIGSERIAL PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      account_id INTEGER NOT NULL,
      email TEXT NOT NULL,
      job_id INTEGER NOT NULL,
      expires_at TIMESTAMPTZ NOT NULL,
      used_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_dgj_easy_apply_tokens_lookup ON dgj_easy_apply_tokens(token_hash,job_id,expires_at) WHERE used_at IS NULL`);
    dgjEasyApplyTokenTableReady = true;
  }
  async function createEasyApplyAccessToken(accountId, email, jobId) {
    await ensureEasyApplyTokenTable();
    const rawToken = import_crypto2.default.randomBytes(32).toString("base64url");
    const tokenHash = import_crypto2.default.createHash("sha256").update(rawToken).digest("hex");
    await pool.query(`DELETE FROM dgj_easy_apply_tokens WHERE expires_at<NOW()-INTERVAL '1 day' OR used_at<NOW()-INTERVAL '1 day'`);
    await pool.query(`INSERT INTO dgj_easy_apply_tokens(token_hash,account_id,email,job_id,expires_at,created_at) VALUES($1,$2,$3,$4,NOW()+INTERVAL '10 minutes',NOW())`, [tokenHash,accountId,normalizeSeekerEmail(email),jobId]);
    return rawToken;
  }
  app2.post("/api/seekers/easy-apply-token", requireSeeker, rateLimit(30, 60 * 1e3), async (req, res) => {
    try {
      const jobId = Number(req.body?.jobId);
      if (!Number.isInteger(jobId) || jobId <= 0) return res.status(400).json({ message: "A valid job is required." });
      const account = await storage.getSeekerAccountById(req.session.seekerAccountId);
      if (!account || !validSeekerEmail(normalizeSeekerEmail(account.email))) return res.status(401).json({ message: "Please sign in to continue." });
      const job = await storage.getJobById(jobId);
      if (!job) return res.status(404).json({ message: "Job not found." });
      const token = await createEasyApplyAccessToken(account.id, account.email, jobId);
      return res.json({ token, email: normalizeSeekerEmail(account.email), expiresInSeconds: 600 });
    } catch (err) {
      console.error("[EasyApplyAuth] token error:", err && err.message ? err.message : err);
      return res.status(500).json({ message: "Easy Apply security token could not be created. Please try again." });
    }
  });
  function getVerificationMailer() {
    if (dgjMailTransport) return dgjMailTransport;
    const host = process.env.SMTP_HOST || "smtp.hostinger.com";
    const port = Number(process.env.SMTP_PORT || 465);
    const user = process.env.SMTP_USER || "info@devglobaljobs.com";
    const pass = process.env.SMTP_PASS;
    if (!pass) throw new Error("SMTP_PASS is not configured");
    const nodemailer = require("nodemailer");
    dgjMailTransport = nodemailer.createTransport({
      host,
      port,
      secure: String(process.env.SMTP_SECURE || (port === 465 ? "true" : "false")).toLowerCase() === "true",
      auth: { user, pass },
      connectionTimeout: 1e4,
      greetingTimeout: 1e4,
      socketTimeout: 15e3
    });
    return dgjMailTransport;
  }
  async function sendSeekerVerificationEmail(email, fullName, code) {
    const transporter = getVerificationMailer();
    const fromEmail = process.env.SMTP_FROM || process.env.SMTP_USER || "info@devglobaljobs.com";
    const safeName = dgjEscapeHtml(fullName || "there");
    const safeCode = dgjEscapeHtml(code);
    const html = `<!doctype html><html><body style="margin:0;background:#f3f6fb;font-family:Inter,Arial,sans-serif;color:#0f172a"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f6fb;padding:28px 12px"><tr><td align="center"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;background:#ffffff;border-radius:18px;overflow:hidden;border:1px solid #e2e8f0;box-shadow:0 14px 40px rgba(30,64,175,.10)"><tr><td bgcolor="#0f1e6e" style="background:#0f1e6e;background-image:linear-gradient(135deg,#0f1e6e,#2563eb);padding:30px;text-align:center"><img src="cid:dgj-logo" width="92" height="92" alt="Dev Global Jobs" style="display:block;margin:0 auto 12px;border-radius:14px;background:#fff;padding:4px"><div style="font-size:21px;font-weight:800;color:#fff">Dev Global Jobs</div><div style="font-size:12px;color:#dbeafe;margin-top:4px;letter-spacing:.4px">INTERNATIONAL CAREERS</div></td></tr><tr><td style="padding:30px 34px"><h1 style="font-size:21px;margin:0 0 10px;color:#0f172a">Verify your email address</h1><p style="font-size:14px;line-height:1.7;color:#475569;margin:0 0 18px">Hello ${safeName}, use the verification code below to complete your Dev Global Jobs account registration.</p><div style="text-align:center;margin:24px 0"><div style="display:inline-block;padding:15px 24px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;font-size:30px;line-height:1;font-weight:800;letter-spacing:8px;color:#1d4ed8;font-variant-numeric:tabular-nums">${safeCode}</div></div><p style="font-size:13px;line-height:1.7;color:#475569;margin:0 0 14px">This code expires in <strong>10 minutes</strong>. If you did not request this account, you can safely ignore this email.</p><div style="margin-top:22px;padding:14px 16px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0;font-size:12px;line-height:1.6;color:#64748b">For your security, Dev Global Jobs will never ask you to send this verification code by email, chat or phone.</div></td></tr><tr><td style="padding:18px 30px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;font-size:11px;line-height:1.6;color:#94a3b8">Dev Global Jobs · International Careers Platform<br><a href="https://devglobaljobs.com/privacy" style="color:#2563eb">Privacy Policy</a> · <a href="https://devglobaljobs.com/terms" style="color:#2563eb">Terms of Service</a></td></tr></table></td></tr></table></body></html>`;
    const text = `Dev Global Jobs\n\nHello ${fullName || "there"},\n\nYour verification code is: ${code}\n\nThis code expires in 10 minutes. If you did not request this account, ignore this email.\n\nhttps://devglobaljobs.com`;
    await transporter.sendMail({
      from: { name: process.env.MAIL_FROM_NAME || "Dev Global Jobs", address: fromEmail },
      to: email,
      subject: "Your Dev Global Jobs verification code",
      text,
      html,
      attachments: [{
        filename: "dev-global-jobs-logo.png",
        path: require("path").resolve(__dirname, "public", "email-logo.png"),
        cid: "dgj-logo",
        contentDisposition: "inline"
      }]
    });
    try {
      await ensureGrowthTables();
      await pool.query(`INSERT INTO dgj_mail_send_log(mail_type,recipient,audience,sent_at) VALUES('verification',$1,'job_seeker',NOW())`,[normalizeSeekerEmail(email)]);
    } catch (_mailLogError) {}
  }
  async function sendSeekerPasswordResetEmail(email, code) {
    const transporter = getVerificationMailer();
    const fromEmail = process.env.SMTP_FROM || process.env.SMTP_USER || "info@devglobaljobs.com";
    const safeCode = dgjEscapeHtml(code);
    const html = `<!doctype html><html><body style="margin:0;background:#f3f6fb;font-family:Inter,Arial,sans-serif;color:#0f172a"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f6fb;padding:28px 12px"><tr><td align="center"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;background:#ffffff;border-radius:18px;overflow:hidden;border:1px solid #e2e8f0;box-shadow:0 14px 40px rgba(30,64,175,.10)"><tr><td bgcolor="#0f1e6e" style="background:#0f1e6e;background-image:linear-gradient(135deg,#0f1e6e,#2563eb);padding:30px;text-align:center"><img src="cid:dgj-logo" width="92" height="92" alt="Dev Global Jobs" style="display:block;margin:0 auto 12px;border-radius:14px;background:#fff;padding:4px"><div style="font-size:21px;font-weight:800;color:#fff">Dev Global Jobs</div><div style="font-size:12px;color:#dbeafe;margin-top:4px;letter-spacing:.4px">INTERNATIONAL CAREERS</div></td></tr><tr><td style="padding:30px 34px"><h1 style="font-size:21px;margin:0 0 10px;color:#0f172a">Reset your password</h1><p style="font-size:14px;line-height:1.7;color:#475569;margin:0 0 18px">Use the secure code below to set a new password for your Dev Global Jobs account.</p><div style="text-align:center;margin:24px 0"><div style="display:inline-block;padding:15px 24px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;font-size:30px;line-height:1;font-weight:800;letter-spacing:8px;color:#1d4ed8;font-variant-numeric:tabular-nums">${safeCode}</div></div><p style="font-size:13px;line-height:1.7;color:#475569;margin:0 0 14px">This code expires in <strong>10 minutes</strong> and can be used only once. If you did not request a password reset, no action is required.</p><div style="margin-top:22px;padding:14px 16px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0;font-size:12px;line-height:1.6;color:#64748b">Never share this code. Dev Global Jobs will never ask for your password or verification code by email, chat or phone.</div></td></tr><tr><td style="padding:18px 30px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;font-size:11px;line-height:1.6;color:#94a3b8">Dev Global Jobs · International Careers Platform<br><a href="https://devglobaljobs.com/privacy" style="color:#2563eb">Privacy Policy</a> · <a href="https://devglobaljobs.com/terms" style="color:#2563eb">Terms of Service</a></td></tr></table></td></tr></table></body></html>`;
    const text = `Dev Global Jobs\n\nYour password reset code is: ${code}\n\nThis code expires in 10 minutes and can be used once. If you did not request this reset, ignore this email.\n\nhttps://devglobaljobs.com`;
    await transporter.sendMail({
      from: { name: process.env.MAIL_FROM_NAME || "Dev Global Jobs", address: fromEmail },
      to: email,
      subject: "Reset your Dev Global Jobs password",
      text,
      html,
      attachments: [{ filename: "dev-global-jobs-logo.png", path: require("path").resolve(__dirname, "public", "email-logo.png"), cid: "dgj-logo", contentDisposition: "inline" }]
    });
  }
  // ─── DGJ Growth CRM + weekly audience mailer ───────────────────────────────
  let dgjGrowthReady = false;
  let dgjNewsletterBusy = false;
  let dgjNewsletterAudienceTurn = 'job_seeker';
  async function ensureGrowthTables() {
    if (dgjGrowthReady) return;
    const ready = await pool.query(`SELECT
      to_regclass('public.dgj_marketing_contacts') IS NOT NULL AS contacts,
      to_regclass('public.dgj_employers') IS NOT NULL AS employers,
      to_regclass('public.dgj_employer_postings') IS NOT NULL AS postings,
      to_regclass('public.dgj_activity_events') IS NOT NULL AS events,
      to_regclass('public.dgj_mail_send_log') IS NOT NULL AS mail_log,
      to_regclass('public.dgj_email_campaigns') IS NOT NULL AS campaigns,
      to_regclass('public.dgj_email_queue') IS NOT NULL AS queue`);
    const r = ready.rows && ready.rows[0];
    if (!(r && r.contacts && r.employers && r.postings && r.events && r.mail_log && r.campaigns && r.queue)) {
      throw new Error("Growth CRM database migration is not installed completely");
    }
    dgjGrowthReady = true;
  }
  function dgjToken() { return require('crypto').randomBytes(24).toString('hex'); }
  async function dgjUpsertContact(dbClient, email, audience, name, country, source) {
    const e = normalizeSeekerEmail(email);
    if (!validSeekerEmail(e)) return;
    await dbClient.query(`INSERT INTO dgj_marketing_contacts(email,audience,name,country,source,active,unsubscribe_token,subscribed_at,unsubscribed_at,updated_at)
      VALUES($1,$2,$3,$4,$5,true,$6,NOW(),NULL,NOW()) ON CONFLICT(email,audience) DO UPDATE SET name=COALESCE(NULLIF(EXCLUDED.name,''),dgj_marketing_contacts.name),country=COALESCE(NULLIF(EXCLUDED.country,''),dgj_marketing_contacts.country),source=EXCLUDED.source,active=CASE WHEN dgj_marketing_contacts.unsubscribed_at IS NULL THEN true ELSE dgj_marketing_contacts.active END,updated_at=NOW()`, [e,audience,name||null,country||null,source||'site',dgjToken()]);
    // Keep the legacy subscriber table in sync so existing Admin newsletter views continue
    // to see newly verified accounts/employers. The new audience table remains authoritative
    // because it can represent the same email separately as job seeker and employer.
    await dbClient.query(`INSERT INTO newsletter_subscribers(email,name,type,active,subscribed_at) VALUES($1,$2,$3,true,NOW()) ON CONFLICT(email) DO UPDATE SET name=COALESCE(NULLIF(EXCLUDED.name,''),newsletter_subscribers.name),active=CASE WHEN newsletter_subscribers.active=false THEN false ELSE true END`,[e,name||null,audience==='employer'?'employer':'job_seeker']);
  }
  async function dgjEvent(dbClient, type, email, audience, accountId, jobId, metadata) {
    await dbClient.query(`INSERT INTO dgj_activity_events(event_type,actor_email,audience,account_id,job_id,metadata,occurred_at) VALUES($1,$2,$3,$4,$5,$6::jsonb,NOW())`, [type,email||null,audience||null,accountId||null,jobId||null,JSON.stringify(metadata||{})]);
  }
  async function dgjRecordEmployerPosting(email, company, country, accountId, job, allowanceType='free') {
    if (!validSeekerEmail(email)) return;
    await ensureGrowthTables();
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      let contactName = null;
      if (accountId) {
        const p = await client.query(`SELECT full_name FROM job_seeker_profiles WHERE account_id=$1 LIMIT 1`, [accountId]);
        contactName = p.rows[0]?.full_name || null;
      }
      await client.query(`INSERT INTO dgj_employers(email,company_name,contact_name,country,account_id,source,first_posted_at,last_posted_at,regular_post_count,featured_post_count,created_at,updated_at)
        VALUES($1,$2,$3,$4,$5,'job_post',NOW(),NOW(),0,0,NOW(),NOW()) ON CONFLICT(email) DO UPDATE SET company_name=COALESCE(EXCLUDED.company_name,dgj_employers.company_name),contact_name=COALESCE(EXCLUDED.contact_name,dgj_employers.contact_name),country=COALESCE(EXCLUDED.country,dgj_employers.country),account_id=COALESCE(EXCLUDED.account_id,dgj_employers.account_id),last_posted_at=NOW(),active=true,updated_at=NOW()`, [email,company||null,contactName,country||null,accountId||null]);
      await client.query(`INSERT INTO dgj_employer_postings(job_id,employer_email,company_name,country,account_id,listing_type,allowance_type,posted_at,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,COALESCE($8,NOW()),NOW()) ON CONFLICT(job_id) DO UPDATE SET employer_email=EXCLUDED.employer_email,company_name=COALESCE(EXCLUDED.company_name,dgj_employer_postings.company_name),country=COALESCE(EXCLUDED.country,dgj_employer_postings.country),account_id=COALESCE(EXCLUDED.account_id,dgj_employer_postings.account_id),listing_type=EXCLUDED.listing_type,allowance_type=EXCLUDED.allowance_type`,[job.id,email,company||null,country||null,accountId||null,job.featured?'featured':'regular',allowanceType==='admin'?'admin':'free',job.postedAt||null]);
      await client.query(`UPDATE dgj_employers e SET regular_post_count=(SELECT count(*)::int FROM dgj_employer_postings p WHERE p.employer_email=e.email AND p.listing_type='regular'),featured_post_count=(SELECT count(*)::int FROM dgj_employer_postings p WHERE p.employer_email=e.email AND p.listing_type='featured'),updated_at=NOW() WHERE e.email=$1`,[email]);
      await dgjUpsertContact(client,email,'employer',contactName,country,'job_post');
      await dgjEvent(client,job.featured?'employer_featured_post':'employer_regular_post',email,'employer',accountId,job.id,{company:company||'',country:country||'',allowanceType:allowanceType==='admin'?'admin':'free'});
      await client.query('COMMIT');
    } catch(e) { try{await client.query('ROLLBACK')}catch(_){}; console.error('[GrowthCRM] employer record:',e.message); }
    finally { client.release(); }
  }
  function dgjIsoWeek(d) {
    const x = new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()));
    const day = x.getUTCDay() || 7; x.setUTCDate(x.getUTCDate()+4-day);
    const yearStart = new Date(Date.UTC(x.getUTCFullYear(),0,1));
    return x.getUTCFullYear()+'-W'+String(Math.ceil((((x-yearStart)/86400000)+1)/7)).padStart(2,'0');
  }
  function dgjEmailShell(inner, preheader) {
    return `<!doctype html><html><body style="margin:0;background:#f3f6fb;font-family:Arial,Helvetica,sans-serif;color:#0f172a"><div style="display:none;max-height:0;overflow:hidden">${dgjEscapeHtml(preheader||'')}</div><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3f6fb;padding:26px 10px"><tr><td align="center"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:680px;background:#fff;border:1px solid #dbe4f0;border-radius:18px;overflow:hidden"><tr><td bgcolor="#0f1e6e" style="padding:25px 30px;background:#0f1e6e;background-image:linear-gradient(135deg,#0f1e6e,#2563eb);text-align:center"><img src="cid:dgj-logo" width="92" height="92" alt="Dev Global Jobs" style="background:#fff;border-radius:13px;padding:4px"><div style="font-size:22px;font-weight:800;color:#fff;margin-top:10px">Dev Global Jobs</div><div style="font-size:11px;color:#dbeafe;letter-spacing:1px;margin-top:4px">INTERNATIONAL CAREERS</div></td></tr><tr><td style="padding:30px">${inner}</td></tr><tr><td style="padding:18px 28px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;font-size:11px;line-height:1.7;color:#64748b">Dev Global Jobs · Careers across 190+ countries<br><a href="https://devglobaljobs.com/privacy" style="color:#2563eb">Privacy</a> · <a href="https://devglobaljobs.com/terms" style="color:#2563eb">Terms</a></td></tr></table></td></tr></table></body></html>`;
  }
  async function dgjWeeklyContent(audience, contact) {
    const safeName = dgjEscapeHtml(contact.name || (audience==='employer'?'Hiring Team':'Professional'));
    const unsub = `https://devglobaljobs.com/email/unsubscribe?token=${encodeURIComponent(contact.unsubscribe_token)}`;
    if (audience === 'employer') {
      const usage=await pool.query(`WITH ident AS (SELECT account_id FROM dgj_employers WHERE email=$1 LIMIT 1) SELECT count(*) FILTER (WHERE p.listing_type='regular')::int regular_used,count(*) FILTER (WHERE p.listing_type='featured')::int featured_used FROM dgj_employer_postings p WHERE p.allowance_type='free' AND p.posted_at>=date_trunc('month',NOW()) AND p.posted_at<date_trunc('month',NOW())+INTERVAL '1 month' AND (p.account_id=(SELECT account_id FROM ident) OR ((SELECT account_id FROM ident) IS NULL AND p.employer_email=$1))`,[String(contact.email||'').toLowerCase()]);
      const regularRemain=Math.max(0,5-Number(usage.rows[0]?.regular_used||0)),featuredRemain=Math.max(0,2-Number(usage.rows[0]?.featured_used||0));
      const inner = `<p style="font-size:14px;color:#475569;margin:0 0 8px">Hello ${safeName},</p><h1 style="font-size:24px;line-height:1.3;margin:0 0 12px">Your monthly free hiring allowance</h1><p style="font-size:14px;line-height:1.7;color:#475569">Dev Global Jobs includes up to <strong>5 Regular jobs</strong> and <strong>2 Featured jobs</strong> free each calendar month. Based on this employer email, the allowance currently available is shown below. Featured listings receive priority placement across relevant job and country pages.</p><table role="presentation" width="100%" style="margin:20px 0"><tr><td style="padding:16px;background:#eff6ff;border-radius:12px;text-align:center"><strong style="font-size:24px;color:#1d4ed8">${regularRemain}</strong><br><span style="font-size:12px;color:#475569">Regular remaining this month</span></td><td width="12"></td><td style="padding:16px;background:#fff7ed;border-radius:12px;text-align:center"><strong style="font-size:24px;color:#c2410c">${featuredRemain}</strong><br><span style="font-size:12px;color:#475569">Featured remaining this month</span></td></tr></table><p style="text-align:center;margin:24px 0"><a href="https://devglobaljobs.com/post-job" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;font-weight:700;padding:13px 22px;border-radius:10px">Post a Job</a></p><p style="font-size:12px;line-height:1.6;color:#64748b">Need additional or bulk placements? Contact <a href="mailto:info@devglobaljobs.com" style="color:#2563eb">info@devglobaljobs.com</a>.</p><p style="font-size:10.5px;color:#94a3b8;text-align:center;margin-top:24px"><a href="${unsub}" style="color:#64748b">Unsubscribe from employer updates</a></p>`;
      const subject=`Your hiring allowance: ${regularRemain} Regular + ${featuredRemain} Featured available`;
      return {subject,html:dgjEmailShell(inner,`${regularRemain} Regular + ${featuredRemain} Featured jobs currently available this month.`),text:`Dev Global Jobs\n\nHello ${contact.name||'Hiring Team'},\n\nYour current monthly free allowance has ${regularRemain} Regular and ${featuredRemain} Featured job posts remaining.\n\nPost now: https://devglobaljobs.com/post-job\n\nUnsubscribe: ${unsub}`};
    }
    const jr = await pool.query(`SELECT id,title,organization,location,country,category,featured FROM jobs WHERE posted_at>=NOW()-INTERVAL '7 days' AND (closing_date IS NULL OR closing_date>NOW()) AND (start_date IS NULL OR start_date<=NOW()) ORDER BY featured DESC,posted_at DESC NULLS LAST LIMIT 8`);
    const rows = jr.rows.map(j=>`<tr><td style="padding:12px 0;border-bottom:1px solid #eef2f7"><a href="https://devglobaljobs.com/jobs/detail/${j.id}" style="font-size:14px;font-weight:700;color:#1d4ed8;text-decoration:none">${dgjEscapeHtml(j.title)}</a><div style="font-size:12px;color:#475569;margin-top:4px">${dgjEscapeHtml(j.organization)}${j.location?' · '+dgjEscapeHtml(j.location):''}</div></td></tr>`).join('');
    const cats=[['International','/jobs/international'],['Remote','/jobs/remote'],['Technology','/jobs/technology'],['Healthcare','/jobs/healthcare'],['Engineering','/jobs/engineering'],['Education','/jobs/education'],['Business','/jobs/business'],['NGO','/jobs/ngo']].map(x=>`<a href="https://devglobaljobs.com${x[1]}" style="display:inline-block;margin:4px;padding:8px 10px;background:#eff6ff;border-radius:8px;color:#1d4ed8;text-decoration:none;font-size:12px;font-weight:700">${x[0]}</a>`).join('');
    const countries=[['USA','us'],['UK','uk'],['Canada','canada'],['Australia','australia'],['Germany','germany'],['Netherlands','netherlands'],['Singapore','singapore']].map(x=>`<a href="https://devglobaljobs.com/jobs/country/${x[1]}" style="display:inline-block;margin:4px;padding:7px 9px;border:1px solid #dbeafe;border-radius:8px;color:#334155;text-decoration:none;font-size:11px">${x[0]}</a>`).join('');
    const inner=`<p style="font-size:14px;color:#475569;margin:0 0 8px">Hello ${safeName},</p><h1 style="font-size:24px;line-height:1.3;margin:0 0 12px">Fresh global opportunities for your week</h1><p style="font-size:14px;line-height:1.7;color:#475569">Explore newly listed roles and return to Dev Global Jobs when an opportunity matches your skills, location or career goals.</p><h2 style="font-size:16px;margin:24px 0 10px">Selected new opportunities</h2><table role="presentation" width="100%">${rows||'<tr><td style="font-size:13px;color:#64748b">Browse the latest opportunities on Dev Global Jobs.</td></tr>'}</table><h2 style="font-size:15px;margin:24px 0 8px">Explore by career category</h2><div>${cats}</div><h2 style="font-size:15px;margin:20px 0 8px">Popular country searches</h2><div>${countries}</div><p style="text-align:center;margin:26px 0 8px"><a href="https://devglobaljobs.com/jobs/all" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;font-weight:700;padding:13px 22px;border-radius:10px">Explore All Jobs</a></p><p style="font-size:10.5px;color:#94a3b8;text-align:center;margin-top:22px">You are receiving the Global Jobs weekly digest. <a href="${unsub}" style="color:#64748b">Unsubscribe</a></p>`;
    return {subject:'Fresh international jobs for your week | Dev Global Jobs',html:dgjEmailShell(inner,'New international, remote and country-based opportunities.'),text:`Dev Global Jobs Weekly\n\nHello ${contact.name||'Professional'},\n\nFresh international opportunities are available. Explore: https://devglobaljobs.com/jobs/all\n\nUnsubscribe: ${unsub}`};
  }
  async function dgjCreateWeeklyCampaign(audience, force=false) {
    await ensureGrowthTables();
    const now = new Date();
    const weekday = Math.min(6,Math.max(0,Number(process.env.NEWSLETTER_WEEKDAY_UTC || 1))), hour = Math.min(23,Math.max(0,Number(process.env.NEWSLETTER_HOUR_UTC || 6)));
    // Catch-up scheduling: once the configured weekly send time has passed, create this ISO week's
    // campaign even if the app was restarting or unavailable at the exact scheduled hour/day.
    if (!force) {
      const daysSince = (now.getUTCDay()-weekday+7)%7;
      const scheduled = new Date(now);
      scheduled.setUTCDate(now.getUTCDate()-daysSince);
      scheduled.setUTCHours(hour,0,0,0);
      if (now < scheduled) return null;
    }
    const key = `weekly:${audience}:${dgjIsoWeek(now)}`;
    const existing = await pool.query(`SELECT id FROM dgj_email_campaigns WHERE campaign_key=$1 LIMIT 1`, [key]);
    if (existing.rows[0]?.id) return existing.rows[0].id;
    // Never stack a new weekly edition behind an unfinished older edition. If provider
    // capacity is too small, finish the existing audience backlog first and surface the
    // capacity warning in Admin instead of silently building duplicate weekly queues.
    const backlog = await pool.query(`SELECT c.id FROM dgj_email_campaigns c WHERE c.audience=$1 AND c.status<>'completed' AND EXISTS (SELECT 1 FROM dgj_email_queue q WHERE q.campaign_id=c.id AND q.status IN ('queued','retry','processing')) ORDER BY c.created_at ASC LIMIT 1`, [audience]);
    if (backlog.rows[0]?.id) return backlog.rows[0].id;
    const subject = audience==='employer'?'Your free monthly hiring allowance | Dev Global Jobs':'Fresh international jobs for your week | Dev Global Jobs';
    const ins=await pool.query(`INSERT INTO dgj_email_campaigns(campaign_key,audience,subject,status,scheduled_at,created_at) VALUES($1,$2,$3,'queued',NOW(),NOW()) ON CONFLICT(campaign_key) DO NOTHING RETURNING id`,[key,audience,subject]);
    let id=ins.rows[0]?.id;
    if(!id){const q=await pool.query(`SELECT id FROM dgj_email_campaigns WHERE campaign_key=$1`,[key]);return q.rows[0]?.id||null;}
    await pool.query(`INSERT INTO dgj_email_queue(campaign_id,contact_id,email,name,audience,status,next_attempt_at,created_at) SELECT $1,id,email,name,audience,'queued',NOW(),NOW() FROM dgj_marketing_contacts WHERE audience=$2 AND active=true AND unsubscribed_at IS NULL ON CONFLICT(campaign_id,contact_id) DO NOTHING`,[id,audience]);
    await pool.query(`UPDATE dgj_email_campaigns SET total_recipients=(SELECT count(*) FROM dgj_email_queue WHERE campaign_id=$1) WHERE id=$1`,[id]);
    return id;
  }
  async function dgjProcessNewsletterQueue() {
    if (dgjNewsletterBusy || String(process.env.NEWSLETTER_ENABLED||'true').toLowerCase()==='false') return;
    dgjNewsletterBusy=true;
    let queueClient;
    let advisoryLocked=false;
    try {
      await ensureGrowthTables();
      queueClient = await pool.connect();
      const lk = await queueClient.query(`SELECT pg_try_advisory_lock(hashtext('dgj-weekly-mailer-v1')) AS ok`);
      advisoryLocked = lk.rows[0]?.ok === true;
      if (!advisoryLocked) return;
      const smtpDailyLimit=Math.max(0,Number(process.env.SMTP_DAILY_LIMIT||1000));
      const reserve=Math.max(0,Number(process.env.TRANSACTIONAL_MAIL_RESERVE||100));
      const configuredNewsletter=Math.max(0,Number(process.env.NEWSLETTER_DAILY_LIMIT||900));
      const dailyLimit=Math.min(configuredNewsletter,Math.max(0,smtpDailyLimit-reserve));
      const usage=await queueClient.query(`SELECT
        count(*) FILTER (WHERE mail_type LIKE 'weekly_%')::int AS newsletter_sent,
        count(*) FILTER (WHERE mail_type NOT LIKE 'weekly_%')::int AS transactional_sent,
        count(*)::int AS total_sent
        FROM dgj_mail_send_log WHERE sent_at>=date_trunc('day',NOW())`);
      const newsletterSent=Number(usage.rows[0]?.newsletter_sent||0);
      const transactionalSent=Number(usage.rows[0]?.transactional_sent||0);
      const totalSent=Number(usage.rows[0]?.total_sent||0);
      const providerRemaining=Math.max(0,smtpDailyLimit-totalSent);
      const reserveRemaining=Math.max(0,reserve-transactionalSent);
      const newsletterRemaining=Math.max(0,configuredNewsletter-newsletterSent);
      let remaining=Math.min(newsletterRemaining,Math.max(0,providerRemaining-reserveRemaining)); if(remaining<=0)return;
      const batch=Math.min(Math.max(1,Number(process.env.NEWSLETTER_BATCH_SIZE||20)),remaining,50);
      const preferredAudience=dgjNewsletterAudienceTurn;
      dgjNewsletterAudienceTurn=preferredAudience==='job_seeker'?'employer':'job_seeker';
      // Claim rows atomically. This prevents duplicate sends if PM2 is running multiple workers.
      // The preferred audience alternates each processing cycle so a large seeker list cannot
      // starve employer reminders (or vice versa).
      const q=await queueClient.query(`WITH picked AS (
        SELECT q.id FROM dgj_email_queue q JOIN dgj_marketing_contacts c ON c.id=q.contact_id
        WHERE q.status IN ('queued','retry') AND q.next_attempt_at<=NOW() AND c.active=true AND c.unsubscribed_at IS NULL
        ORDER BY CASE WHEN q.audience=$2 THEN 0 ELSE 1 END,q.id FOR UPDATE OF q SKIP LOCKED LIMIT $1
      ), claimed AS (
        UPDATE dgj_email_queue q SET status='processing',attempts=q.attempts+1 FROM picked p WHERE q.id=p.id RETURNING q.*
      ) SELECT claimed.*,c.unsubscribe_token,c.country,c.active FROM claimed JOIN dgj_marketing_contacts c ON c.id=claimed.contact_id ORDER BY claimed.id`,[batch,preferredAudience]);
      const mailer=getVerificationMailer();
      const fromEmail=process.env.SMTP_FROM||process.env.SMTP_USER||'info@devglobaljobs.com';
      const maxAttempts=Math.max(1,Number(process.env.NEWSLETTER_MAX_ATTEMPTS||3));
      for(const item of q.rows){
        try{
          const content=await dgjWeeklyContent(item.audience,item);
          await mailer.sendMail({from:{name:process.env.NEWSLETTER_FROM_NAME||'Dev Global Jobs',address:fromEmail},to:item.email,subject:content.subject,text:content.text,html:content.html,attachments:[{filename:'dev-global-jobs-logo.png',path:require('path').resolve(__dirname,'public','email-logo.png'),cid:'dgj-logo',contentDisposition:'inline'}],headers:{'List-Unsubscribe':`<https://devglobaljobs.com/email/unsubscribe?token=${item.unsubscribe_token}>`,'List-Unsubscribe-Post':'List-Unsubscribe=One-Click'}});
          await queueClient.query(`INSERT INTO dgj_mail_send_log(mail_type,recipient,audience,related_id,sent_at) VALUES($1,$2,$3,$4,NOW())`,[item.audience==='employer'?'weekly_employer':'weekly_job_seeker',item.email,item.audience,item.campaign_id]);
          await queueClient.query(`UPDATE dgj_email_queue SET status='sent',sent_at=NOW(),last_error=NULL WHERE id=$1`,[item.id]);
          await queueClient.query(`UPDATE dgj_marketing_contacts SET last_sent_at=NOW(),updated_at=NOW() WHERE id=$1`,[item.contact_id]);
          await queueClient.query(`UPDATE dgj_email_campaigns SET sent_count=sent_count+1 WHERE id=$1`,[item.campaign_id]);
        }catch(e){
          const failed=Number(item.attempts||0)>=maxAttempts;
          const nextStatus=failed?'failed':'retry';
          await queueClient.query(`UPDATE dgj_email_queue SET status=$2,last_error=$3,next_attempt_at=NOW()+INTERVAL '6 hours' WHERE id=$1`,[item.id,nextStatus,String(e?.message||e).slice(0,500)]);
          if(failed) await queueClient.query(`UPDATE dgj_email_campaigns SET failed_count=failed_count+1 WHERE id=$1`,[item.campaign_id]);
        }
      }
      await queueClient.query(`UPDATE dgj_email_campaigns c SET status='completed',completed_at=NOW() WHERE status<>'completed' AND NOT EXISTS(SELECT 1 FROM dgj_email_queue q WHERE q.campaign_id=c.id AND q.status IN ('queued','retry','processing'))`);
    } catch(e) { console.error('[WeeklyMailer]',e?.message||e); }
    finally {
      if (queueClient) {
        if (advisoryLocked) { try { await queueClient.query(`SELECT pg_advisory_unlock(hashtext('dgj-weekly-mailer-v1'))`); } catch (_) {} }
        queueClient.release();
      }
      dgjNewsletterBusy=false;
    }
  }
  async function dgjGrowthOverview() {
    await ensureGrowthTables();
    const r=await pool.query(`SELECT
      (SELECT count(*) FROM job_seeker_accounts)::int seekers_total,
      (SELECT count(*) FROM job_seeker_accounts WHERE created_at>=CURRENT_DATE)::int seekers_today,
      (SELECT count(*) FROM dgj_employers)::int employers_total,
      (SELECT count(*) FROM dgj_employers WHERE created_at>=CURRENT_DATE)::int employers_today,
      (SELECT count(DISTINCT lower(trim(apply_email))) FROM jobs WHERE is_employer_posted=true AND apply_email IS NOT NULL AND trim(apply_email)<>'' AND posted_at>=CURRENT_DATE)::int employers_posted_today,
      (SELECT count(*) FROM jobs WHERE is_employer_posted=true AND posted_at>=CURRENT_DATE)::int employer_jobs_today,
      (SELECT count(*) FROM dgj_marketing_contacts WHERE audience='job_seeker' AND active=true AND unsubscribed_at IS NULL)::int subscriber_seekers,
      (SELECT count(*) FROM dgj_marketing_contacts WHERE audience='employer' AND active=true AND unsubscribed_at IS NULL)::int subscriber_employers,
      (SELECT count(*) FROM dgj_activity_events WHERE event_type IN ('seeker_login','google_login') AND occurred_at>=CURRENT_DATE)::int signins_today,
      (SELECT count(*) FROM jobs WHERE is_employer_posted=true AND featured=false AND posted_at>=CURRENT_DATE)::int regular_today,
      (SELECT count(*) FROM jobs WHERE is_employer_posted=true AND featured=true AND posted_at>=CURRENT_DATE)::int featured_today,
      (SELECT count(*) FROM jobs WHERE is_employer_posted=true AND featured=false AND posted_at>=date_trunc('month',NOW()))::int regular_month,
      (SELECT count(*) FROM jobs WHERE is_employer_posted=true AND featured=true AND posted_at>=date_trunc('month',NOW()))::int featured_month,
      (SELECT count(*) FROM dgj_email_queue WHERE status IN ('queued','retry','processing'))::int email_queued,
      (SELECT count(*) FROM dgj_email_queue WHERE sent_at>=CURRENT_DATE)::int email_sent_today,
      (SELECT count(*) FROM dgj_mail_send_log WHERE sent_at>=CURRENT_DATE)::int smtp_sent_today,
      (SELECT count(*) FROM dgj_mail_send_log WHERE sent_at>=CURRENT_DATE AND mail_type NOT LIKE 'weekly_%')::int transactional_sent_today`);
    const x=r.rows[0]; const active=Number(x.subscriber_seekers||0)+Number(x.subscriber_employers||0);
    const smtpDaily=Math.max(0,Number(process.env.SMTP_DAILY_LIMIT||1000));
    const reserve=Math.max(0,Number(process.env.TRANSACTIONAL_MAIL_RESERVE||100));
    const configured=Math.max(0,Number(process.env.NEWSLETTER_DAILY_LIMIT||900));
    const daily=Math.min(configured,Math.max(0,smtpDaily-reserve));
    return {...x,active_subscribers:active,smtp_daily_limit:smtpDaily,transactional_reserve:reserve,newsletter_daily_limit:daily,weekly_capacity:daily*7,required_daily_for_weekly:Math.ceil(active/7),capacity_ok:active<=daily*7};
  }
  async function dgjUnsubscribeByToken(token) {
    await ensureGrowthTables();
    if (!token) return false;
    const q=await pool.query(`UPDATE dgj_marketing_contacts SET active=false,unsubscribed_at=NOW(),updated_at=NOW() WHERE unsubscribe_token=$1 RETURNING id,email,audience`,[token]);
    const row=q.rows[0],id=row?.id;
    if(id) {
      await pool.query(`UPDATE dgj_email_queue SET status='suppressed',last_error='Unsubscribed' WHERE contact_id=$1 AND status IN ('queued','retry')`,[id]);
      await pool.query(`UPDATE newsletter_subscribers SET active=false WHERE lower(trim(email))=$1 AND type=$2`,[row.email,row.audience==='employer'?'employer':'job_seeker']);
    }
    return !!id;
  }
  app2.get('/email/unsubscribe', async (req,res)=>{try{await dgjUnsubscribeByToken(String(req.query.token||''));res.set('Content-Type','text/html; charset=utf-8').send(`<!doctype html><html><body style="font-family:Arial;background:#f3f6fb;margin:0;padding:40px"><div style="max-width:560px;margin:auto;background:white;padding:32px;border-radius:18px;border:1px solid #e2e8f0;text-align:center"><img src="/logo.png" width="62" alt="Dev Global Jobs"><h1 style="font-size:22px">Email preferences updated</h1><p style="color:#475569;line-height:1.7">This address will no longer receive the selected Dev Global Jobs weekly audience emails.</p><a href="/" style="display:inline-block;background:#2563eb;color:white;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:700">Return to Dev Global Jobs</a></div></body></html>`)}catch(e){res.status(500).send('Unable to update email preferences.')}});
  app2.post('/email/unsubscribe', async (req,res)=>{try{await dgjUnsubscribeByToken(String(req.query.token||req.body?.token||''));res.status(200).send('Unsubscribed')}catch(e){res.status(500).send('Unable to update email preferences.')}});
  app2.get('/api/admin/growth/overview',requireAdmin,async(_req,res)=>{try{res.json(await dgjGrowthOverview())}catch(e){res.status(500).json({message:e.message})}});
  app2.get('/api/admin/growth/job-seekers',requireAdmin,async(req,res)=>{try{await ensureGrowthTables();const page=Math.max(1,Number(req.query.page||1)),limit=Math.min(100,Math.max(10,Number(req.query.limit||50))),off=(page-1)*limit;const q=await pool.query(`SELECT a.id,a.email,a.created_at,a.last_login_at,p.full_name,p.country,p.city,p.job_title,mc.active AS subscribed,mc.last_sent_at FROM job_seeker_accounts a LEFT JOIN job_seeker_profiles p ON p.account_id=a.id LEFT JOIN dgj_marketing_contacts mc ON mc.email=lower(a.email) AND mc.audience='job_seeker' ORDER BY a.created_at DESC LIMIT $1 OFFSET $2`,[limit,off]);const c=await pool.query(`SELECT count(*)::int n FROM job_seeker_accounts`);res.json({items:q.rows,total:c.rows[0].n,page,limit})}catch(e){res.status(500).json({message:e.message})}});
  app2.get('/api/admin/growth/employers',requireAdmin,async(req,res)=>{try{await ensureGrowthTables();const page=Math.max(1,Number(req.query.page||1)),limit=Math.min(100,Math.max(10,Number(req.query.limit||50))),off=(page-1)*limit;const q=await pool.query(`SELECT e.*,mc.active AS subscribed,mc.last_sent_at,(SELECT count(*) FROM dgj_employer_postings p WHERE p.allowance_type='free' AND p.listing_type='regular' AND p.posted_at>=date_trunc('month',NOW()) AND (p.account_id=e.account_id OR (e.account_id IS NULL AND p.employer_email=e.email)))::int regular_this_month,(SELECT count(*) FROM dgj_employer_postings p WHERE p.allowance_type='free' AND p.listing_type='featured' AND p.posted_at>=date_trunc('month',NOW()) AND (p.account_id=e.account_id OR (e.account_id IS NULL AND p.employer_email=e.email)))::int featured_this_month,COALESCE((SELECT jsonb_agg(to_jsonb(x) ORDER BY x.posted_at DESC) FROM (SELECT p.job_id,p.listing_type,p.allowance_type,p.posted_at,j.title,j.organization FROM dgj_employer_postings p LEFT JOIN jobs j ON j.id=p.job_id WHERE p.employer_email=e.email ORDER BY p.posted_at DESC LIMIT 12) x),'[]'::jsonb) AS recent_postings FROM dgj_employers e LEFT JOIN dgj_marketing_contacts mc ON mc.email=e.email AND mc.audience='employer' ORDER BY e.last_posted_at DESC NULLS LAST,e.created_at DESC LIMIT $1 OFFSET $2`,[limit,off]);const c=await pool.query(`SELECT count(*)::int n FROM dgj_employers`);res.json({items:q.rows,total:c.rows[0].n,page,limit})}catch(e){res.status(500).json({message:e.message})}});
  app2.get('/api/admin/growth/subscribers',requireAdmin,async(req,res)=>{try{await ensureGrowthTables();const audience=['job_seeker','employer'].includes(String(req.query.audience))?String(req.query.audience):null;const q=await pool.query(`SELECT id,email,audience,name,country,source,active,subscribed_at,unsubscribed_at,last_sent_at FROM dgj_marketing_contacts WHERE ($1::text IS NULL OR audience=$1) ORDER BY subscribed_at DESC LIMIT 500`,[audience]);res.json(q.rows)}catch(e){res.status(500).json({message:e.message})}});
  app2.post('/api/admin/growth/subscribers',requireAdmin,async(req,res)=>{try{await ensureGrowthTables();const email=normalizeSeekerEmail(req.body?.email),audience=req.body?.audience==='employer'?'employer':'job_seeker';if(!validSeekerEmail(email))return res.status(400).json({message:'Valid email required'});await dgjUpsertContact(pool,email,audience,String(req.body?.name||'').trim().slice(0,100),String(req.body?.country||'').trim().slice(0,80),'admin');if(audience==='employer')await pool.query(`INSERT INTO dgj_employers(email,company_name,contact_name,country,source,created_at,updated_at) VALUES($1,$2,$3,$4,'admin',NOW(),NOW()) ON CONFLICT(email) DO UPDATE SET company_name=COALESCE(NULLIF(EXCLUDED.company_name,''),dgj_employers.company_name),contact_name=COALESCE(NULLIF(EXCLUDED.contact_name,''),dgj_employers.contact_name),country=COALESCE(NULLIF(EXCLUDED.country,''),dgj_employers.country),updated_at=NOW()`,[email,String(req.body?.company||'').trim().slice(0,160)||null,String(req.body?.name||'').trim().slice(0,100)||null,String(req.body?.country||'').trim().slice(0,80)||null]);res.json({success:true})}catch(e){res.status(500).json({message:e.message})}});
  app2.post('/api/admin/growth/subscribers/bulk',requireAdmin,async(req,res)=>{
    const entries=Array.isArray(req.body?.entries)?req.body.entries.slice(0,500):[];
    const audience=req.body?.audience==='employer'?'employer':'job_seeker';
    if(!entries.length)return res.status(400).json({message:'Provide at least one contact. Maximum 500 per import.'});
    await ensureGrowthTables();
    const client=await pool.connect();let added=0,invalid=0;
    try{
      await client.query('BEGIN');
      for(const raw of entries){
        const email=normalizeSeekerEmail(raw?.email),name=String(raw?.name||'').trim().slice(0,100),country=String(raw?.country||'').trim().slice(0,80),company=String(raw?.company||'').trim().slice(0,160);
        if(!validSeekerEmail(email)){invalid++;continue;}
        await dgjUpsertContact(client,email,audience,name,country,'admin_bulk');
        if(audience==='employer')await client.query(`INSERT INTO dgj_employers(email,company_name,contact_name,country,source,created_at,updated_at) VALUES($1,$2,$3,$4,'admin_bulk',NOW(),NOW()) ON CONFLICT(email) DO UPDATE SET company_name=COALESCE(NULLIF(EXCLUDED.company_name,''),dgj_employers.company_name),contact_name=COALESCE(NULLIF(EXCLUDED.contact_name,''),dgj_employers.contact_name),country=COALESCE(NULLIF(EXCLUDED.country,''),dgj_employers.country),updated_at=NOW()`,[email,company||null,name||null,country||null]);
        added++;
      }
      await dgjEvent(client,'admin_contact_import',null,audience,null,null,{added,invalid});
      await client.query('COMMIT');
      res.json({success:true,added,invalid,maximum:500});
    }catch(e){try{await client.query('ROLLBACK')}catch(_){};res.status(500).json({message:e.message})}finally{client.release()}
  });
  app2.get('/api/admin/growth/campaigns',requireAdmin,async(_req,res)=>{try{await ensureGrowthTables();const q=await pool.query(`SELECT id,campaign_key,audience,subject,status,total_recipients,sent_count,failed_count,created_at,completed_at FROM dgj_email_campaigns ORDER BY created_at DESC LIMIT 30`);res.json(q.rows)}catch(e){res.status(500).json({message:e.message})}});
  app2.post('/api/admin/growth/run-weekly',requireAdmin,async(req,res)=>{try{const a=req.body?.audience==='employer'?'employer':'job_seeker';const id=await dgjCreateWeeklyCampaign(a,true);await dgjProcessNewsletterQueue();res.json({success:true,campaignId:id})}catch(e){res.status(500).json({message:e.message})}});

  app2.post("/api/seekers/register", rateLimit(5, 10 * 60 * 1e3), async (req, res) => {
    try {
      await ensureSeekerVerificationTable();
      const email = normalizeSeekerEmail(req.body?.email);
      const fullName = String(req.body?.fullName || "").trim().replace(/[<>]/g, "").slice(0, 100);
      const country = String(req.body?.country || "").trim().replace(/[<>]/g, "").slice(0, 80);
      const password = String(req.body?.password || "");
      if (!validSeekerEmail(email) || fullName.length < 2 || country.length < 2) return res.status(400).json({ message: "Please provide a valid name, email address and country." });
      if (!validSeekerPassword(password)) return res.status(400).json({ message: "Password must be at least 10 characters and combine at least three of: uppercase, lowercase, numbers and symbols." });
      const existing = await storage.getSeekerAccountByEmail(email);
      if (existing) return res.status(409).json({ message: "An account with this email already exists. Please sign in instead." });
      const code = String(import_crypto2.default.randomInt(1e5, 1e6));
      const passwordHash = hashSeekerPasswordSecure(password);
      const codeHash = verificationCodeHash(email, code);
      await pool.query(`
        INSERT INTO job_seeker_email_verifications (email,password_hash,full_name,country,code_hash,expires_at,resend_after,attempts,updated_at)
        VALUES ($1,$2,$3,$4,$5,NOW()+INTERVAL '10 minutes',NOW()+INTERVAL '60 seconds',0,NOW())
        ON CONFLICT (email) DO UPDATE SET password_hash=EXCLUDED.password_hash,full_name=EXCLUDED.full_name,country=EXCLUDED.country,code_hash=EXCLUDED.code_hash,expires_at=EXCLUDED.expires_at,resend_after=EXCLUDED.resend_after,attempts=0,updated_at=NOW()
      `, [email, passwordHash, fullName, country, codeHash]);
      await sendSeekerVerificationEmail(email, fullName, code);
      if (req.session) {
        req.session.pendingVerificationEmail = email;
        await new Promise((resolve) => req.session.save((err) => { if (err) console.warn("[SeekerAuth] pending verification session save failed:", err && err.message ? err.message : err); resolve(); }));
      }
      return res.status(202).json({ success: true, verificationRequired: true, email });
    } catch (err) {
      console.error("[SeekerAuth] registration error:", err && err.message ? err.message : err);
      if (String(err?.message || "").includes("SMTP_PASS")) return res.status(503).json({ message: "Email verification is temporarily unavailable. Please try again shortly." });
      return res.status(500).json({ message: "Account registration could not be completed. Please try again." });
    }
  });
  app2.post("/api/seekers/resend-verification", rateLimit(3, 10 * 60 * 1e3), async (req, res) => {
    try {
      await ensureSeekerVerificationTable();
      const email = normalizeSeekerEmail(req.body?.email);
      if (!validSeekerEmail(email)) return res.status(400).json({ message: "Please enter a valid email address." });
      const result = await pool.query(`SELECT email, full_name, resend_after FROM job_seeker_email_verifications WHERE email=$1 LIMIT 1`, [email]);
      if (!result.rows[0]) return res.status(200).json({ success: true, message: "If a pending registration exists, a new code will be sent." });
      if (new Date(result.rows[0].resend_after).getTime() > Date.now()) return res.status(429).json({ message: "Please wait 60 seconds before requesting another code." });
      const code = String(import_crypto2.default.randomInt(1e5, 1e6));
      const codeHash = verificationCodeHash(email, code);
      await pool.query(`UPDATE job_seeker_email_verifications SET code_hash=$2,expires_at=NOW()+INTERVAL '10 minutes',resend_after=NOW()+INTERVAL '60 seconds',attempts=0,updated_at=NOW() WHERE email=$1`, [email, codeHash]);
      await sendSeekerVerificationEmail(email, result.rows[0].full_name, code);
      if (req.session) {
        req.session.pendingVerificationEmail = email;
        await new Promise((resolve) => req.session.save((err) => { if (err) console.warn("[SeekerAuth] resend pending-session save failed:", err && err.message ? err.message : err); resolve(); }));
      }
      return res.json({ success: true, message: "A new verification code has been sent." });
    } catch (err) {
      console.error("[SeekerAuth] resend error:", err && err.message ? err.message : err);
      return res.status(500).json({ message: "Verification code could not be resent. Please try again." });
    }
  });
  app2.post("/auth/verify-email", rateLimit(10, 10 * 60 * 1e3), async (req, res) => {
    const normalizeOtpServer = (value) => String(value || "")
      .replace(/[٠-٩]/g, (ch) => String("٠١٢٣٤٥٦٧٨٩".indexOf(ch)))
      .replace(/[۰-۹]/g, (ch) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(ch)))
      .replace(/[^0-9]/g, "")
      .slice(0, 6);
    const email = normalizeSeekerEmail(req.session?.pendingVerificationEmail || "");
    const code = normalizeOtpServer(req.body?.code);
    const requestedRedirect = String(req.body?.redirect || "/");
    const safeRedirect = requestedRedirect.startsWith("/") && !requestedRedirect.startsWith("//") ? requestedRedirect.slice(0, 2048) : "/";
    const back = (message, statusCode = 303) => {
      const q = new URLSearchParams();
      q.set("verify_error", String(message || "Verification could not be completed.").slice(0, 220));
      if (safeRedirect !== "/") q.set("redirect", safeRedirect);
      return res.redirect(statusCode, `/sign-in?${q.toString()}`);
    };
    if (!validSeekerEmail(email)) return back("Your verification session expired. Please create the account again or request a new code.");
    if (!/^\d{6}$/.test(code)) return back("Enter the latest 6-digit verification code.");
    let client;
    try {
      await ensureSeekerVerificationTable();
      client = await pool.connect();
      await client.query("BEGIN");
      const result = await client.query(`SELECT * FROM job_seeker_email_verifications WHERE email=$1 FOR UPDATE`, [email]);
      const pending = result.rows[0];
      if (!pending) {
        const recovered = await client.query(`SELECT id,email FROM job_seeker_accounts WHERE email=$1 LIMIT 1`, [email]);
        await client.query("ROLLBACK");
        if (!recovered.rows[0]) return back("Verification request not found. Please create your account again.");
        delete req.session.pendingVerificationEmail;
        await new Promise((resolve) => req.session.save(() => resolve()));
        return res.redirect(303, `/sign-in?verified=1${safeRedirect !== "/" ? `&redirect=${encodeURIComponent(safeRedirect)}` : ""}`);
      }
      if (pending.attempts >= 5) {
        await client.query("DELETE FROM job_seeker_email_verifications WHERE email=$1", [email]);
        await client.query("COMMIT");
        return back("Too many incorrect attempts. Please create your account again.");
      }
      if (new Date(pending.expires_at).getTime() < Date.now()) {
        await client.query("ROLLBACK");
        return back("This verification code has expired. Request a new code.");
      }
      const supplied = verificationCodeHash(email, code);
      if (!safeEqualHex(supplied, pending.code_hash)) {
        await client.query(`UPDATE job_seeker_email_verifications SET attempts=attempts+1,updated_at=NOW() WHERE email=$1`, [email]);
        await client.query("COMMIT");
        return back("Incorrect verification code. Please check the newest email and try again.");
      }
      const existing = await client.query(`SELECT id,email FROM job_seeker_accounts WHERE email=$1 LIMIT 1`, [email]);
      let account;
      if (existing.rows[0]) {
        account = existing.rows[0];
      } else {
        const accountResult = await client.query(`INSERT INTO job_seeker_accounts (email,password_hash,created_at,last_login_at) VALUES ($1,$2,NOW(),NOW()) RETURNING id,email`, [email, pending.password_hash]);
        account = accountResult.rows[0];
      }
      await client.query(`INSERT INTO job_seeker_profiles (account_id,full_name,country,updated_at) VALUES ($1,$2,$3,NOW()) ON CONFLICT (account_id) DO UPDATE SET full_name=COALESCE(NULLIF(job_seeker_profiles.full_name,''),EXCLUDED.full_name),country=COALESCE(NULLIF(job_seeker_profiles.country,''),EXCLUDED.country),updated_at=NOW()`, [account.id, pending.full_name, pending.country]);
      await client.query(`UPDATE job_seeker_accounts SET last_login_at=NOW() WHERE id=$1`, [account.id]);
      await client.query("COMMIT");
      try {
        await ensureGrowthTables();
        await dgjUpsertContact(pool,email,"job_seeker",pending.full_name,pending.country,"verified_signup");
        await dgjEvent(pool,"seeker_signup",email,"job_seeker",account.id,null,{method:"email_native"});
      } catch (growthErr) {
        console.warn("[SeekerAuth] native verified account CRM sync skipped:", growthErr && growthErr.message ? growthErr.message : growthErr);
      }
      req.session.seekerAccountId = account.id;
      delete req.session.pendingVerificationEmail;
      return req.session.save((sessionErr) => {
        pool.query(`DELETE FROM job_seeker_email_verifications WHERE email=$1`, [email]).catch((cleanupErr) => console.warn("[SeekerAuth] native verification cleanup deferred:", cleanupErr && cleanupErr.message ? cleanupErr.message : cleanupErr));
        if (sessionErr) {
          console.warn("[SeekerAuth] native verified session save failed:", sessionErr && sessionErr.message ? sessionErr.message : sessionErr);
          return res.redirect(303, `/sign-in?verified=1${safeRedirect !== "/" ? `&redirect=${encodeURIComponent(safeRedirect)}` : ""}`);
        }
        return res.redirect(303, safeRedirect === "/" ? "/profile" : safeRedirect);
      });
    } catch (err) {
      if (client) { try { await client.query("ROLLBACK"); } catch (_e) {} }
      console.error("[SeekerAuth] native verification error:", err && err.message ? err.message : err);
      return back("Email verification could not be completed. Please try again.");
    } finally {
      if (client) client.release();
    }
  });
  app2.post("/api/seekers/verify-email", rateLimit(10, 10 * 60 * 1e3), async (req, res) => {
    const email = normalizeSeekerEmail(req.body?.email);
    const code = String(req.body?.code || "").trim();
    if (!validSeekerEmail(email) || !/^\d{6}$/.test(code)) return res.status(400).json({ message: "Enter the valid 6-digit verification code." });
    let client;
    try {
      await ensureSeekerVerificationTable();
      client = await pool.connect();
      await client.query("BEGIN");
      const result = await client.query(`SELECT * FROM job_seeker_email_verifications WHERE email=$1 FOR UPDATE`, [email]);
      const pending = result.rows[0];
      if (!pending) {
        // Recovery path: if a previous correct verification created the account but
        // the browser/session response failed, do not trap the user in a dead-end.
        const recovered = await client.query(`SELECT id,email FROM job_seeker_accounts WHERE email=$1 LIMIT 1`, [email]);
        await client.query("ROLLBACK");
        if (!recovered.rows[0]) return res.status(400).json({ message: "Verification request not found. Please create your account again." });
        // The account is already verified, but without the pending verification row
        // there is no OTP secret left to validate. Never create an authenticated
        // session from an arbitrary six-digit value; ask for normal sign-in instead.
        return res.status(200).json({ success: true, account: recovered.rows[0], recovered: true, verified: true, sessionReady: false, signInRequired: true });
      }
      if (pending.attempts >= 5) { await client.query("DELETE FROM job_seeker_email_verifications WHERE email=$1", [email]); await client.query("COMMIT"); return res.status(429).json({ message: "Too many incorrect attempts. Please create your account again." }); }
      if (new Date(pending.expires_at).getTime() < Date.now()) { await client.query("ROLLBACK"); return res.status(400).json({ message: "This verification code has expired. Request a new code." }); }
      const supplied = verificationCodeHash(email, code);
      if (!safeEqualHex(supplied, pending.code_hash)) {
        await client.query(`UPDATE job_seeker_email_verifications SET attempts=attempts+1,updated_at=NOW() WHERE email=$1`, [email]);
        await client.query("COMMIT");
        return res.status(400).json({ message: "Incorrect verification code. Please check the email and try again." });
      }
      const existing = await client.query(`SELECT id,email FROM job_seeker_accounts WHERE email=$1 LIMIT 1`, [email]);
      let account;
      if (existing.rows[0]) {
        // Idempotent recovery: a previous verification may have created the account
        // before a session/network failure. A correct OTP should still complete cleanly.
        account = existing.rows[0];
      } else {
        const accountResult = await client.query(`INSERT INTO job_seeker_accounts (email,password_hash,created_at,last_login_at) VALUES ($1,$2,NOW(),NOW()) RETURNING id,email`, [email, pending.password_hash]);
        account = accountResult.rows[0];
      }
      await client.query(`INSERT INTO job_seeker_profiles (account_id,full_name,country,updated_at) VALUES ($1,$2,$3,NOW()) ON CONFLICT (account_id) DO UPDATE SET full_name=COALESCE(NULLIF(job_seeker_profiles.full_name,''),EXCLUDED.full_name),country=COALESCE(NULLIF(job_seeker_profiles.country,''),EXCLUDED.country),updated_at=NOW()`, [account.id, pending.full_name, pending.country]);
      await client.query(`UPDATE job_seeker_accounts SET last_login_at=NOW() WHERE id=$1`, [account.id]);
      // Keep the verified OTP row until the session is successfully persisted. This
      // makes the flow safely retryable if the session store/network fails after DB commit.
      await client.query("COMMIT");
      try {
        await ensureGrowthTables();
        await dgjUpsertContact(pool,email,"job_seeker",pending.full_name,pending.country,"verified_signup");
        await dgjEvent(pool,"seeker_signup",email,"job_seeker",account.id,null,{method:"email"});
      } catch (growthErr) {
        console.warn("[SeekerAuth] verified account CRM sync skipped:", growthErr && growthErr.message ? growthErr.message : growthErr);
      }
      req.session.seekerAccountId = account.id;
      delete req.session.pendingVerificationEmail;
      return req.session.save((sessionErr) => {
        // Correct OTP means the account is verified even if the session store has a
        // transient problem. Never report a verified account as an OTP failure.
        pool.query(`DELETE FROM job_seeker_email_verifications WHERE email=$1`, [email]).catch((cleanupErr) => console.warn("[SeekerAuth] verification cleanup deferred:", cleanupErr && cleanupErr.message ? cleanupErr.message : cleanupErr));
        if (sessionErr) {
          console.warn("[SeekerAuth] verified session save failed:", sessionErr && sessionErr.message ? sessionErr.message : sessionErr);
          return res.status(200).json({ success: true, account, verified: true, sessionReady: false, signInRequired: true });
        }
        return res.json({ success: true, account, verified: true, sessionReady: true });
      });
    } catch (err) {
      if (client) { try { await client.query("ROLLBACK"); } catch (_e) {} }
      console.error("[SeekerAuth] verification error:", err && err.message ? err.message : err);
      return res.status(500).json({ message: "Email verification could not be completed. Please try again." });
    } finally {
      if (client) client.release();
    }
  });
  app2.post("/api/seekers/password-reset/request", rateLimit(4, 10 * 60 * 1e3), async (req, res) => {
    try {
      const email = normalizeSeekerEmail(req.body?.email);
      if (!validSeekerEmail(email)) return res.status(400).json({ message: "Please enter a valid email address." });
      const account = await storage.getSeekerAccountByEmail(email);
      // Never disclose whether an account exists.
      if (!account) return res.status(202).json({ success: true, message: "If an account exists for this email, a reset code has been sent." });
      const existing = await pool.query(`SELECT resend_after FROM job_seeker_password_resets WHERE email=$1 LIMIT 1`, [email]);
      if (existing.rows[0] && new Date(existing.rows[0].resend_after).getTime() > Date.now()) return res.status(202).json({ success: true, message: "If an account exists for this email, a reset code has been sent." });
      const code = String(import_crypto2.default.randomInt(1e5, 1e6));
      const codeHash = verificationCodeHash(email, code);
      await pool.query(`INSERT INTO job_seeker_password_resets(email,code_hash,expires_at,resend_after,attempts,updated_at) VALUES($1,$2,NOW()+INTERVAL '10 minutes',NOW()+INTERVAL '60 seconds',0,NOW()) ON CONFLICT(email) DO UPDATE SET code_hash=EXCLUDED.code_hash,expires_at=EXCLUDED.expires_at,resend_after=EXCLUDED.resend_after,attempts=0,updated_at=NOW()`, [email, codeHash]);
      await sendSeekerPasswordResetEmail(email, code);
      return res.status(202).json({ success: true, message: "If an account exists for this email, a reset code has been sent." });
    } catch (err) {
      console.error("[SeekerAuth] password reset request error:", err && err.message ? err.message : err);
      return res.status(500).json({ message: "Password reset could not be started. Please try again." });
    }
  });
  app2.post("/api/seekers/password-reset/confirm", rateLimit(8, 10 * 60 * 1e3), async (req, res) => {
    const email = normalizeSeekerEmail(req.body?.email);
    const code = String(req.body?.code || "").trim();
    const password = String(req.body?.password || "");
    if (!validSeekerEmail(email) || !/^\d{6}$/.test(code)) return res.status(400).json({ message: "Enter the valid 6-digit reset code." });
    if (!validSeekerPassword(password)) return res.status(400).json({ message: "Password must be at least 10 characters and combine at least three of: uppercase, lowercase, numbers and symbols." });
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const result = await client.query(`SELECT * FROM job_seeker_password_resets WHERE email=$1 FOR UPDATE`, [email]);
      const pending = result.rows[0];
      if (!pending) { await client.query("ROLLBACK"); return res.status(400).json({ message: "Reset request not found. Request a new reset code." }); }
      if (pending.attempts >= 5) { await client.query(`DELETE FROM job_seeker_password_resets WHERE email=$1`, [email]); await client.query("COMMIT"); return res.status(429).json({ message: "Too many incorrect attempts. Request a new reset code." }); }
      if (new Date(pending.expires_at).getTime() < Date.now()) { await client.query("ROLLBACK"); return res.status(400).json({ message: "This reset code has expired. Request a new code." }); }
      const supplied = verificationCodeHash(email, code);
      if (!safeEqualHex(supplied, pending.code_hash)) { await client.query(`UPDATE job_seeker_password_resets SET attempts=attempts+1,updated_at=NOW() WHERE email=$1`, [email]); await client.query("COMMIT"); return res.status(400).json({ message: "Incorrect reset code. Please check the email and try again." }); }
      const account = await client.query(`SELECT id FROM job_seeker_accounts WHERE email=$1 LIMIT 1`, [email]);
      if (!account.rows[0]) { await client.query(`DELETE FROM job_seeker_password_resets WHERE email=$1`, [email]); await client.query("COMMIT"); return res.status(400).json({ message: "This reset request is no longer valid." }); }
      const passwordHash = hashSeekerPasswordSecure(password);
      await client.query(`UPDATE job_seeker_accounts SET password_hash=$2 WHERE id=$1`, [account.rows[0].id, passwordHash]);
      await client.query(`DELETE FROM job_seeker_password_resets WHERE email=$1`, [email]);
      await client.query("COMMIT");
      try { await ensureGrowthTables(); await dgjEvent(pool,"password_reset",email,"job_seeker",account.rows[0].id,null,{method:"email_code"}); } catch (_e) {}
      return res.json({ success: true });
    } catch (err) {
      try { await client.query("ROLLBACK"); } catch (_e) {}
      console.error("[SeekerAuth] password reset confirm error:", err && err.message ? err.message : err);
      return res.status(500).json({ message: "Password reset could not be completed. Please try again." });
    } finally { client.release(); }
  });

  app2.post("/api/seekers/login", rateLimit(10, 5 * 60 * 1e3), async (req, res) => {
    try {
      const email = normalizeSeekerEmail(req.body?.email);
      const password = String(req.body?.password || "");
      if (!validSeekerEmail(email) || !password || password.length > 128) return res.status(400).json({ message: "Email and password are required." });
      const account = await storage.getSeekerAccountByEmail(email);
      if (!account) return res.status(401).json({ message: "Invalid email or password." });
      const verification = verifySeekerPassword(password, account.passwordHash);
      if (!verification.ok) return res.status(401).json({ message: "Invalid email or password." });
      if (verification.legacy) {
        const upgraded = hashSeekerPasswordSecure(password);
        await pool.query(`UPDATE job_seeker_accounts SET password_hash=$2 WHERE id=$1`, [account.id, upgraded]);
      }
      await storage.updateSeekerLastLogin(account.id);
      try {
        await ensureGrowthTables();
        await dgjUpsertContact(pool,email,"job_seeker",null,null,"email_signin");
        await dgjEvent(pool,"seeker_login",email,"job_seeker",account.id,null,{method:"email"});
      } catch (growthErr) {
        console.warn("[SeekerAuth] sign-in CRM sync skipped:", growthErr && growthErr.message ? growthErr.message : growthErr);
      }
      req.session.seekerAccountId = account.id;
      return req.session.save((sessionErr) => {
        if (sessionErr) return res.status(500).json({ message: "Session error. Please try again." });
        return res.json({ success: true, account: { id: account.id, email: account.email } });
      });
    } catch (err) {
      console.error("[SeekerAuth] login error:", err && err.message ? err.message : err);
      return res.status(500).json({ message: "Sign-in could not be completed. Please try again." });
    }
  });

  app2.post("/api/seekers/google-auth", rateLimit(10, 6e4), async (req, res) => {
    try {
      const { credential } = req.body;
      if (!credential) return res.status(400).json({ message: "Google credential required." });
      const publicGoogleClientId = "76830429948-0afbgal53ch1o03ph8dan9pttp44ngsn.apps.googleusercontent.com";
      const configuredGoogleClientId = String(process.env.GOOGLE_CLIENT_ID || "").trim();
      const allowedGoogleAudiences = Array.from(new Set([publicGoogleClientId, configuredGoogleClientId].filter(Boolean)));
      const oauth2Client = new import_google_auth_library.OAuth2Client(publicGoogleClientId);
      const ticket = await oauth2Client.verifyIdToken({ idToken: credential, audience: allowedGoogleAudiences });
      const payload = ticket && ticket.getPayload ? ticket.getPayload() : null;
      if (!payload || !payload.email || payload.email_verified === false) return res.status(401).json({ message: "Google could not verify this email account. Please use another Google account or continue with email." });
      const email = payload.email.toLowerCase().trim();
      const fullName = payload.name || email;
      let account = await storage.getSeekerAccountByEmail(email);
      const isNewGoogleAccount = !account;
      if (!account) {
        const randomHash = import_crypto2.default.randomBytes(32).toString("hex");
        account = await storage.createSeekerAccount(email, "google-oauth-" + randomHash);
        await storage.upsertSeekerProfile(account.id, { fullName });
      }
      await storage.updateSeekerLastLogin(account.id);
      try {
        await ensureGrowthTables();
        await dgjUpsertContact(pool,email,"job_seeker",fullName,null,isNewGoogleAccount?"google_signup":"google_signin");
        await dgjEvent(pool,isNewGoogleAccount?"seeker_signup":"google_login",email,"job_seeker",account.id,null,{method:"google"});
      } catch (growthErr) {
        console.warn("[SeekerAuth] Google CRM sync skipped:", growthErr && growthErr.message ? growthErr.message : growthErr);
      }
      req.session.seekerAccountId = account.id;
      req.session.save((err) => {
        if (err) return res.status(500).json({ message: "Session error. Please try again." });
        res.json({ success: true, account: { id: account.id, email: account.email } });
      });
    } catch (err) {
      console.error('[SeekerAuth] Google authentication error:', err && err.message ? err.message : err);
      res.status(401).json({ message: "Google sign-in could not be completed. Please try again or continue with email." });
    }
  });


  app2.post("/api/seekers/apply-info", requireSeeker, async (req, res) => {
    try {
      const { jobId } = req.body;
      if (!jobId) return res.status(400).json({ message: "jobId required." });
      const job = await storage.getJobById(parseInt(jobId));
      if (!job) return res.status(404).json({ message: "Job not found." });
      const profile = await storage.getSeekerProfile(req.session.seekerAccountId);
      const account = await storage.getSeekerAccountById(req.session.seekerAccountId);
      res.json({
        job: { id: job.id, title: job.title, organization: job.organization, url: job.url, applyEmail: job.applyEmail },
        profile: profile || {},
        email: account ? account.email : ""
      });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });


  app2.get("/api/seekers/saved-jobs", requireSeeker, async (req, res) => {
    try {
      const jobs2 = await storage.getSavedJobs(req.session.seekerAccountId);
      res.json(jobs2);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.post("/api/seekers/saved-jobs", requireSeeker, async (req, res) => {
    try {
      const { jobId } = req.body;
      if (!jobId) return res.status(400).json({ message: "jobId required." });
      await storage.saveJob(req.session.seekerAccountId, parseInt(jobId));
      res.json({ success: true, saved: true });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.delete("/api/seekers/saved-jobs/:jobId", requireSeeker, async (req, res) => {
    try {
      const jobId = parseInt(req.params.jobId);
      if (isNaN(jobId)) return res.status(400).json({ message: "Invalid jobId." });
      await storage.unsaveJob(req.session.seekerAccountId, jobId);
      res.json({ success: true, saved: false });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/seekers/saved-jobs/:jobId/status", requireSeeker, async (req, res) => {
    try {
      const jobId = parseInt(req.params.jobId);
      if (isNaN(jobId)) return res.status(400).json({ message: "Invalid jobId." });
      const saved = await storage.isJobSaved(req.session.seekerAccountId, jobId);
      res.json({ saved });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  app2.post("/api/seekers/logout", (req, res) => {
    req.session.destroy(() => {
      res.clearCookie("connect.sid");
      res.json({ success: true });
    });
  });
  app2.get("/api/seekers/me", async (req, res) => {
    if (!req.session.seekerAccountId) return res.status(401).json({ message: "Not authenticated" });
    const account = await storage.getSeekerAccountById(req.session.seekerAccountId);
    if (!account) return res.status(401).json({ message: "Not authenticated" });
    res.json({ id: account.id, email: account.email, createdAt: account.createdAt });
  });
  app2.get("/api/seekers/profile", requireSeeker, async (req, res) => {
    try {
      const profile = await storage.getSeekerProfile(req.session.seekerAccountId);
      res.json(profile || { accountId: req.session.seekerAccountId });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.put("/api/seekers/profile", requireSeeker, async (req, res) => {
    try {
      const data = req.body;
      const allowedFields = ["fullName", "phone", "city", "country", "linkedin", "website", "jobTitle", "summary", "skills", "languages", "workExperience", "education", "certifications", "atsScore"];
      const filtered = {};
      for (const key of allowedFields) {
        if (key in data) {
          filtered[key] = typeof data[key] === "object" ? JSON.stringify(data[key]) : data[key];
        }
      }
      if (typeof data.atsScore === "number") filtered.atsScore = data.atsScore;
      const profile = await storage.upsertSeekerProfile(req.session.seekerAccountId, filtered);
      res.json(profile);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/seekers", requireAdmin, async (req, res) => {
    try {
      const page = parseInt(String(req.query.page || "1"));
      const q = String(req.query.q || "").trim();
      const country = String(req.query.country || "").trim();
      const atsMin = req.query.atsMin !== void 0 ? parseInt(String(req.query.atsMin)) : void 0;
      const atsMax = req.query.atsMax !== void 0 ? parseInt(String(req.query.atsMax)) : void 0;
      const hasSearch = q || country || atsMin !== void 0 || atsMax !== void 0;
      const result = await storage.getSeekerAccountsForAdmin(page, 20, hasSearch ? { q, country, atsMin, atsMax } : void 0);
      res.json(result);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/seekers/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const seeker = await storage.getSeekerByIdForAdmin(id);
      if (!seeker) return res.status(404).json({ message: "Not found" });
      res.json(seeker);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.delete("/api/admin/seekers/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteSeekerAccount(id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/admin/seekers/stats", requireAdmin, async (_req, res) => {
    try {
      const stats = await storage.getSeekerStats();
      res.json(stats);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });
  app2.get("/api/seekers/recommendations", async (req, res) => {
    try {
      if (!req.session.seekerAccountId) return res.json({ jobs: [], reason: "not_authenticated" });
      const profile = await storage.getSeekerProfile(req.session.seekerAccountId);
      if (!profile) return res.json({ jobs: [], reason: "no_profile" });
      let skills = [];
      try {
        skills = JSON.parse(profile.skills || "[]");
      } catch {
      }
      const jobTitle = (profile.jobTitle || "").trim();
      const country = (profile.country || "").trim().toLowerCase();
      const summary = (profile.summary || "").trim();
      const atsScore = profile.atsScore || 0;
      if (atsScore < 20 && skills.length === 0 && !jobTitle) {
        return res.json({ jobs: [], reason: "profile_incomplete" });
      }
      const stopWords = /* @__PURE__ */ new Set(["the", "a", "an", "and", "or", "of", "in", "at", "to", "for", "with", "on", "by", "from", "as", "is", "are", "was", "were", "be", "been", "has", "have", "had", "do", "does", "did", "will", "would", "could", "should"]);
      const titleWords = jobTitle.toLowerCase().split(/\s+/).filter((w) => w.length > 3 && !stopWords.has(w));
      const summaryWords = summary.toLowerCase().split(/\s+/).filter((w) => w.length > 5 && !stopWords.has(w)).slice(0, 10);
      const keywords = [.../* @__PURE__ */ new Set([
        ...skills.map((s) => s.toLowerCase()),
        ...titleWords,
        ...summaryWords
      ])].slice(0, 20);
      if (keywords.length === 0) return res.json({ jobs: [], reason: "no_keywords" });
      const likeConditions = keywords.slice(0, 10).map(
        (kw) => `(LOWER(title) LIKE '%${kw.replace(/'/g, "''")}%' OR LOWER(description) LIKE '%${kw.replace(/'/g, "''")}%')`
      ).join(" OR ");
      const candidates = await db.execute(
        import_drizzle_orm3.sql`SELECT id, title, organization, location, category, skill_category, url, source, posted_at, closing_date, job_type, salary, country, is_employer_posted, featured, apply_email, stripe_payment_id, description
               FROM jobs
               WHERE (${import_drizzle_orm3.sql.raw(likeConditions)})
               AND (closing_date IS NULL OR closing_date > NOW())
               ORDER BY posted_at DESC
               LIMIT 200`
      );
      const scored = candidates.rows.map((job) => {
        let score = 0;
        const titleLower = (job.title || "").toLowerCase();
        const descLower = (job.description || "").toLowerCase().slice(0, 500);
        const jobCountry = (job.country || "").toLowerCase();
        for (const skill of skills) {
          const sk = skill.toLowerCase();
          if (titleLower.includes(sk)) score += 8;
          else if (descLower.includes(sk)) score += 3;
        }
        for (const tw of titleWords) {
          if (titleLower.includes(tw)) score += 5;
        }
        if (country && jobCountry === country) score += 6;
        else if (country && !jobCountry) score += 1;
        const daysOld = (Date.now() - new Date(job.posted_at).getTime()) / (1e3 * 60 * 60 * 24);
        if (daysOld <= 1) score += 4;
        else if (daysOld <= 3) score += 2;
        else if (daysOld <= 7) score += 1;
        if (job.featured) score += 2;
        return { ...job, matchScore: score };
      });
      scored.sort((a, b) => b.matchScore - a.matchScore);
      const top = scored.slice(0, 15);
      const normalised = top.map((j) => ({
        id: j.id,
        title: j.title,
        organization: j.organization,
        location: j.location,
        category: j.category,
        skillCategory: j.skill_category,
        url: j.url,
        source: j.source,
        postedAt: j.posted_at,
        closingDate: j.closing_date,
        jobType: j.job_type,
        salary: j.salary,
        country: j.country,
        isEmployerPosted: j.is_employer_posted,
        featured: j.featured,
        applyEmail: j.apply_email,
        description: j.description,
        matchScore: j.matchScore
      }));
      res.json({ jobs: normalised, reason: "ok", totalCandidates: candidates.rows.length });
    } catch (err) {
      console.error("[recommendations]", err);
      res.status(500).json({ jobs: [], reason: "error", message: err.message });
    }
  });
  async function syncAutoFeaturedJobs() {
    let client;
    try {
      client = await pool.connect();
      await client.query("BEGIN");
      const countResult = await client.query(`
        SELECT COUNT(*)::int AS total
        FROM jobs
        WHERE COALESCE(is_employer_posted,false)=false
          AND (closing_date IS NULL OR closing_date > NOW())
          AND (start_date IS NULL OR start_date <= NOW())
      `);
      const eligible = Number(countResult.rows[0]?.total || 0);
      const target = Math.floor(eligible / 50);
      await client.query(`UPDATE jobs SET featured=false WHERE COALESCE(is_employer_posted,false)=false AND featured=true`);
      if (target > 0) {
        await client.query(`
          WITH ranked AS (
            SELECT id,
              (
                CASE WHEN apply_email IS NOT NULL AND BTRIM(apply_email) <> '' THEN 28 ELSE 0 END +
                CASE WHEN url ~* '^https?://' THEN 22 ELSE 0 END +
                CASE WHEN salary IS NOT NULL AND BTRIM(salary) <> '' THEN 18 ELSE 0 END +
                CASE WHEN closing_date IS NOT NULL THEN 12 ELSE 0 END +
                CASE WHEN description IS NOT NULL AND LENGTH(description) >= 1200 THEN 12 WHEN description IS NOT NULL AND LENGTH(description) >= 600 THEN 7 ELSE 0 END +
                CASE WHEN job_type IS NOT NULL AND BTRIM(job_type) <> '' THEN 5 ELSE 0 END +
                CASE WHEN country IS NOT NULL AND BTRIM(country) <> '' THEN 3 ELSE 0 END
              ) AS quality_score,
              posted_at
            FROM jobs
            WHERE COALESCE(is_employer_posted,false)=false
              AND (closing_date IS NULL OR closing_date > NOW())
              AND (start_date IS NULL OR start_date <= NOW())
            ORDER BY quality_score DESC, posted_at DESC NULLS LAST, id DESC
            LIMIT $1
          )
          UPDATE jobs j SET featured=true FROM ranked r WHERE j.id=r.id
        `, [target]);
      }
      await client.query("COMMIT");
      cache.delete("featured");
      for (const key of cache.keys()) if (String(key).startsWith("featured_employer")) cache.delete(key);
      console.log(`[AutoFeatured] selected ${target} of ${eligible} eligible jobs (2 per 100)`);
    } catch (err) {
      if (client) { try { await client.query("ROLLBACK"); } catch (_e) {} }
      console.error("[AutoFeatured] sync error:", err && err.message ? err.message : err);
    } finally {
      if (client) client.release();
    }
  }
  syncAutoFeaturedJobs();
  setInterval(syncAutoFeaturedJobs, 30 * 60 * 1e3);
  ensureGrowthTables().then(async()=>{
    await dgjCreateWeeklyCampaign("job_seeker",false);
    await dgjCreateWeeklyCampaign("employer",false);
    await dgjProcessNewsletterQueue();
  }).catch(e=>console.error("[GrowthCRM] startup:",e.message));
  setInterval(async()=>{
    try { await dgjCreateWeeklyCampaign("job_seeker",false); await dgjCreateWeeklyCampaign("employer",false); await dgjProcessNewsletterQueue(); }
    catch(e){ console.error("[GrowthCRM] scheduler:",e.message); }
  }, Math.max(60000,Number(process.env.NEWSLETTER_POLL_MS||60000)));
  startJobFetchScheduler();
  setTimeout(() => {
    pingSearchEngines().catch(() => {
    });
    submitAllPagesToIndexNow();
  }, 3e4);
  const runAutoCleanup = async () => {
    try {
      const removed = await storage.removeExpiredClosingDateJobs();
      if (removed > 0) {
        console.log(`[AutoCleanup] Removed ${removed} expired jobs`);
        cache.clear();
      }
    } catch (err) {
      console.error("[AutoCleanup] Error:", err);
    }
  };
  runAutoCleanup();
  setInterval(runAutoCleanup, 2 * 60 * 60 * 1e3);
  return httpServer2;
}

// server/static.ts
var import_express = __toESM(require("express"), 1);
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);

// server/seoMeta.ts
var DGJ_V27_BASE_URL = "https://devglobaljobs.com";
var DGJ_SOCIAL_SHARE_IMAGE = `${DGJ_V27_BASE_URL}/devglobaljobs-social-share.png`;
var DGJ_SOCIAL_SHARE_ALT = "Dev Global Jobs | International Careers";
var DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 = "DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27";
const dgjBrandFs = require("fs");
const dgjBrandPath = require("path");
function dgjLoadBrandContract() {
  const contractPath = process.env.DGJ_BRAND_CONTRACT || dgjBrandPath.join(process.cwd(), "brand-lock", "brand-contract.json");
  let parsed;
  try { parsed = JSON.parse(dgjBrandFs.readFileSync(contractPath, "utf8")); }
  catch (error) { throw new Error(`DGJ Brand Lock: cannot load ${contractPath}: ${error instanceof Error ? error.message : String(error)}`); }
  if (!parsed || parsed.lockId !== DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 || parsed.version !== "27.0.0") {
    throw new Error("DGJ Brand Lock: contract identity/version mismatch");
  }
  return parsed;
}
const DGJ_BRAND_CONTRACT = dgjLoadBrandContract();
function dgjTitleCaseSlug(slug) {
  return String(slug || "").replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
function dgjTrimTitle(value, max = 68) {
  const s = String(value || "").replace(/\s+/g, " ").trim();
  return s.length <= max ? s : s.slice(0, max - 1).replace(/\s+\S*$/, "") + "…";
}
function dgjStaticMeta(path) {
  return DGJ_BRAND_CONTRACT.staticRoutes[path] || DGJ_BRAND_CONTRACT.privateRoutes[path] || null;
}
function getPageMeta(urlPath) {
  const path = String(urlPath || "/").split("?")[0] || "/";
  if (path === "/jobs") {
    const m = DGJ_BRAND_CONTRACT.staticRoutes["/jobs/all"];
    return { ...m, canonical: `${DGJ_V27_BASE_URL}/jobs/all`, ogType: "website", robots: m.robots || DGJ_BRAND_CONTRACT.indexRobots };
  }
  const exact = dgjStaticMeta(path);
  if (exact) return { ...exact, canonical: path === "/" ? DGJ_V27_BASE_URL : `${DGJ_V27_BASE_URL}${path}`, ogType: path.startsWith("/blog/") ? "article" : "website", robots: exact.robots || DGJ_BRAND_CONTRACT.indexRobots };
  const country = path.match(/^\/jobs\/country\/([a-z0-9-]+)$/);
  if (country) {
    const slug = country[1]; const name = DGJ_BRAND_CONTRACT.countries[slug] || dgjTitleCaseSlug(slug);
    const p = DGJ_BRAND_CONTRACT.dynamicPatterns.country;
    return { title:p.title.replace("{Country}",name), description:p.description.replaceAll("{Country}",name), canonical:`${DGJ_V27_BASE_URL}${path}`, ogType:"website", pageType:p.pageType, robots:DGJ_BRAND_CONTRACT.indexRobots, label:`Jobs in ${name}` };
  }
  const city = path.match(/^\/jobs\/city\/([a-z0-9-]+)$/);
  if (city) {
    const slug=city[1]; const name=DGJ_BRAND_CONTRACT.cities?.[slug] || dgjTitleCaseSlug(slug); const p=DGJ_BRAND_CONTRACT.dynamicPatterns.city;
    return { title:p.title.replace("{City}",name), description:p.description.replaceAll("{City}",name), canonical:`${DGJ_V27_BASE_URL}${path}`, ogType:"website", pageType:p.pageType, robots:DGJ_BRAND_CONTRACT.indexRobots, label:`Jobs in ${name}` };
  }
  const job = path.match(/^\/jobs\/detail\/(\d+)$/);
  if (job) return { title:"Job Details | Dev Global Jobs", description:"Review the role, requirements and application information for this opportunity on Dev Global Jobs.", canonical:`${DGJ_V27_BASE_URL}${path}`, ogType:"article", pageType:"WebPage", robots:DGJ_BRAND_CONTRACT.indexRobots, label:"Job Details" };
  if (path.startsWith("/blog/")) {
    const slug=path.slice(6); const known=DGJ_BRAND_CONTRACT.blogArticles[slug];
    if (known) return { ...known, canonical:`${DGJ_V27_BASE_URL}${path}`, ogType:"article", pageType:"Article", robots:DGJ_BRAND_CONTRACT.indexRobots, label:dgjTitleCaseSlug(slug) };
    const label=dgjTitleCaseSlug(slug);
    return { title:dgjTrimTitle(`${label} | Dev Global Jobs`), description:`Read practical career guidance on ${label.toLowerCase()} from Dev Global Jobs, an international careers platform for global professionals.`, canonical:`${DGJ_V27_BASE_URL}${path}`, ogType:"article", pageType:"Article", robots:DGJ_BRAND_CONTRACT.indexRobots, label };
  }
  if (path === "/admin" || path.startsWith("/admin/") || path.startsWith("/api/")) return { title:"Private Area | Dev Global Jobs", description:"Private Dev Global Jobs platform area.", canonical:`${DGJ_V27_BASE_URL}${path}`, ogType:"website", pageType:"WebPage", robots:"noindex, nofollow", label:"Private Area" };
  return { title:"Page Not Found | Dev Global Jobs", description:"The requested page could not be found. Explore international careers and opportunities on Dev Global Jobs.", canonical:`${DGJ_V27_BASE_URL}${path}`, ogType:"website", pageType:"WebPage", robots:"noindex, nofollow", label:"Page Not Found" };
}
function dgjEscapeMeta(value) { return String(value || "").replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function dgjEscapeText(value) { return String(value || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function dgjPageLabel(path) {
  const m=dgjStaticMeta(path); if (m && m.label) return m.label;
  if (path.startsWith("/tools/")) return dgjTitleCaseSlug(path.slice(7));
  return dgjTitleCaseSlug(path.split("/").filter(Boolean).pop() || "Home");
}
function generateBreadcrumbSchema(urlPath) {
  const path=String(urlPath||"/").split("?")[0]||"/"; if(path==="/") return null;
  const items=[{"@type":"ListItem","position":1,"name":"Home","item":DGJ_V27_BASE_URL}];
  if (/^\/jobs\/(all|un|ngo|remote|international|technology|healthcare|business|education|engineering|creative|sales|gig|youth|sponsored)$/.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${DGJ_V27_BASE_URL}/jobs/all`});
    if(path!=="/jobs/all") items.push({"@type":"ListItem","position":3,"name":dgjPageLabel(path),"item":`${DGJ_V27_BASE_URL}${path}`});
  } else if (/^\/jobs\/(country|city)\//.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${DGJ_V27_BASE_URL}/jobs/all`});
    items.push({"@type":"ListItem","position":3,"name":getPageMeta(path).label || dgjPageLabel(path),"item":`${DGJ_V27_BASE_URL}${path}`});
  } else if (/^\/jobs\/detail\//.test(path)) {
    items.push({"@type":"ListItem","position":2,"name":"All Jobs","item":`${DGJ_V27_BASE_URL}/jobs/all`});
    items.push({"@type":"ListItem","position":3,"name":"Job Details","item":`${DGJ_V27_BASE_URL}${path}`});
  } else if (path.startsWith("/tools/")) {
    items.push({"@type":"ListItem","position":2,"name":"Career Tools","item":`${DGJ_V27_BASE_URL}/tools/country-salary-calculator`});
    items.push({"@type":"ListItem","position":3,"name":dgjPageLabel(path),"item":`${DGJ_V27_BASE_URL}${path}`});
  } else if (path.startsWith("/blog/")) {
    items.push({"@type":"ListItem","position":2,"name":"Career Insights","item":`${DGJ_V27_BASE_URL}/blog`});
    items.push({"@type":"ListItem","position":3,"name":getPageMeta(path).label || dgjPageLabel(path),"item":`${DGJ_V27_BASE_URL}${path}`});
  } else items.push({"@type":"ListItem","position":2,"name":dgjPageLabel(path),"item":`${DGJ_V27_BASE_URL}${path}`});
  return JSON.stringify({"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":items});
}
function generatePageSchema(urlPath, meta) {
  return JSON.stringify({"@context":"https://schema.org","@type":meta.pageType||"WebPage","@id":`${meta.canonical}#webpage`,"url":meta.canonical,"name":meta.title,"description":meta.description,"isPartOf":{"@id":`${DGJ_V27_BASE_URL}/#website`},"about":{"@type":"Thing","name":meta.label||"International Careers"},"publisher":{"@id":`${DGJ_V27_BASE_URL}/#organization`},"inLanguage":"en"});
}
function injectMetaTags(html, urlPath) {
  const meta=getPageMeta(urlPath), titleText=dgjEscapeText(meta.title), titleAttr=dgjEscapeMeta(meta.title), descAttr=dgjEscapeMeta(meta.description), canonicalAttr=dgjEscapeMeta(meta.canonical), robotsAttr=dgjEscapeMeta(meta.robots||DGJ_BRAND_CONTRACT.indexRobots);
  html=html.replace(/<title>[^<]*<\/title>/,`<title>${titleText}</title>`);
  html=html.replace(/<meta name="description" content="[^"]*"\s*\/?>/,`<meta name="description" content="${descAttr}" />`);
  html=html.replace(/<link rel="canonical" href="[^"]*"\s*\/?>/,`<link rel="canonical" href="${canonicalAttr}" />`);
  html=html.replace(/<meta property="og:type" content="[^"]*"\s*\/?>/,`<meta property="og:type" content="${dgjEscapeMeta(meta.ogType||"website")}" />`);
  html=html.replace(/<meta property="og:title" content="[^"]*"\s*\/?>/,`<meta property="og:title" content="${titleAttr}" />`);
  html=html.replace(/<meta property="og:description" content="[^"]*"\s*\/?>/,`<meta property="og:description" content="${descAttr}" />`);
  html=html.replace(/<meta property="og:url" content="[^"]*"\s*\/?>/,`<meta property="og:url" content="${canonicalAttr}" />`);
  html=html.replace(/<meta property="og:image" content="[^"]*"\s*\/?>/,`<meta property="og:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`);
  html=html.replace(/<meta property="og:image:width" content="[^"]*"\s*\/?>/,`<meta property="og:image:width" content="1200" />`);
  html=html.replace(/<meta property="og:image:height" content="[^"]*"\s*\/?>/,`<meta property="og:image:height" content="630" />`);
  html=html.replace(/<meta property="og:image:alt" content="[^"]*"\s*\/?>/,`<meta property="og:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`);
  html=html.replace(/<meta name="twitter:title" content="[^"]*"\s*\/?>/,`<meta name="twitter:title" content="${titleAttr}" />`);
  html=html.replace(/<meta name="twitter:description" content="[^"]*"\s*\/?>/,`<meta name="twitter:description" content="${descAttr}" />`);
  html=html.replace(/<meta name="twitter:image" content="[^"]*"\s*\/?>/,`<meta name="twitter:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`);
  html=html.replace(/<meta name="twitter:image:alt" content="[^"]*"\s*\/?>/,`<meta name="twitter:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`);
  html=html.replace(/<meta name="robots" content="[^"]*"\s*\/?>/,`<meta name="robots" content="${robotsAttr}" />`);
  html=html.replace(/<meta name="googlebot" content="[^"]*"\s*\/?>/,`<meta name="googlebot" content="${robotsAttr}" />`);
  html=html.replace(/<meta name="bingbot" content="[^"]*"\s*\/?>/,`<meta name="bingbot" content="${robotsAttr}" />`);
  html=html.replace(/\s*<link rel="alternate" hreflang="[^"]+" href="[^"]+"\s*\/?>/g,"");
  html=html.replace(/\s*<script id="dgj-v27-page-schema"[\s\S]*?<\/script>/g,"").replace(/\s*<script id="dgj-v27-breadcrumb-schema"[\s\S]*?<\/script>/g,"");
  const hreflang=`\n    <link rel="alternate" hreflang="en" href="${canonicalAttr}" />\n    <link rel="alternate" hreflang="x-default" href="${canonicalAttr}" />`;
  const breadcrumb=generateBreadcrumbSchema(urlPath); let injections=`${hreflang}\n    <!-- DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 -->\n    <script id="dgj-v27-page-schema" type="application/ld+json">${generatePageSchema(urlPath,meta)}</script>`;
  if(breadcrumb) injections+=`\n    <script id="dgj-v27-breadcrumb-schema" type="application/ld+json">${breadcrumb}</script>`;
  return html.replace("</head>",`${injections}\n</head>`);
}
var DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27 = "DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27";
function dgjJobIsoDate(value) { if (!value) return null; const d=new Date(value); return Number.isNaN(d.getTime()) ? null : d.toISOString().split("T")[0]; }
function dgjSafeJsonLd(value) { return JSON.stringify(value).replace(/</g,"\\u003c").replace(/>/g,"\\u003e").replace(/&/g,"\\u0026").replace(/\u2028/g,"\\u2028").replace(/\u2029/g,"\\u2029"); }
function dgjJobDescriptionHtml(raw) {
  if (!raw || !String(raw).trim()) return null;
  let s=String(raw).replace(/<script[^>]*>[\s\S]*?<\/script>/gi,"").replace(/<style[^>]*>[\s\S]*?<\/style>/gi,"").trim();
  if (/<(p|ul|li|br)\b/i.test(s)) return s;
  return s.split(/\n{2,}/).map((p)=>`<p>${dgjEscapeText(p.replace(/\n/g," "))}</p>`).join("");
}
const DGJ_JOB_COUNTRY_ALIASES={"US":"US","USA":"US","UNITED STATES":"US","UNITED STATES OF AMERICA":"US","GB":"GB","UK":"GB","UNITED KINGDOM":"GB","GREAT BRITAIN":"GB","CA":"CA","CANADA":"CA","AU":"AU","AUSTRALIA":"AU","NZ":"NZ","NEW ZEALAND":"NZ","DE":"DE","GERMANY":"DE","FR":"FR","FRANCE":"FR","NL":"NL","NETHERLANDS":"NL","CH":"CH","SWITZERLAND":"CH","IE":"IE","IRELAND":"IE","ES":"ES","SPAIN":"ES","IT":"IT","ITALY":"IT","PT":"PT","PORTUGAL":"PT","SE":"SE","SWEDEN":"SE","NO":"NO","NORWAY":"NO","DK":"DK","DENMARK":"DK","FI":"FI","FINLAND":"FI","AT":"AT","AUSTRIA":"AT","BE":"BE","BELGIUM":"BE","PL":"PL","POLAND":"PL","CZ":"CZ","CZECH REPUBLIC":"CZ","HU":"HU","HUNGARY":"HU","RO":"RO","ROMANIA":"RO","GR":"GR","GREECE":"GR","TR":"TR","TURKEY":"TR","UA":"UA","UKRAINE":"UA","AE":"AE","UAE":"AE","UNITED ARAB EMIRATES":"AE","QA":"QA","QATAR":"QA","SA":"SA","SAUDI ARABIA":"SA","KW":"KW","KUWAIT":"KW","BH":"BH","BAHRAIN":"BH","OM":"OM","OMAN":"OM","IN":"IN","INDIA":"IN","PK":"PK","PAKISTAN":"PK","BD":"BD","BANGLADESH":"BD","LK":"LK","SRI LANKA":"LK","NP":"NP","NEPAL":"NP","AF":"AF","AFGHANISTAN":"AF","SG":"SG","SINGAPORE":"SG","MY":"MY","MALAYSIA":"MY","ID":"ID","INDONESIA":"ID","PH":"PH","PHILIPPINES":"PH","TH":"TH","THAILAND":"TH","VN":"VN","VIETNAM":"VN","JP":"JP","JAPAN":"JP","KR":"KR","SOUTH KOREA":"KR","HK":"HK","HONG KONG":"HK","ZA":"ZA","SOUTH AFRICA":"ZA","NG":"NG","NIGERIA":"NG","KE":"KE","KENYA":"KE","GH":"GH","GHANA":"GH","ET":"ET","ETHIOPIA":"ET","UG":"UG","UGANDA":"UG","TZ":"TZ","TANZANIA":"TZ","EG":"EG","EGYPT":"EG","MA":"MA","MOROCCO":"MA","BR":"BR","BRAZIL":"BR","MX":"MX","MEXICO":"MX","AR":"AR","ARGENTINA":"AR","CO":"CO","COLOMBIA":"CO","CL":"CL","CHILE":"CL","PE":"PE","PERU":"PE","BG":"BG","BULGARIA":"BG","CN":"CN","CHINA":"CN","CY":"CY","CYPRUS":"CY","EE":"EE","ESTONIA":"EE","IL":"IL","ISRAEL":"IL","LT":"LT","LITHUANIA":"LT","LU":"LU","LUXEMBOURG":"LU","RS":"RS","SERBIA":"RS","SI":"SI","SLOVENIA":"SI","SK":"SK","SLOVAKIA":"SK"};
function dgjJobCountry(raw, location) {
  const invalid=new Set(["WORLDWIDE","GLOBAL","REMOTE","ANYWHERE","INTERNATIONAL"]);
  const r=String(raw||"").trim();
  if(r){const u=r.toUpperCase(); if(invalid.has(u))return null; if(DGJ_JOB_COUNTRY_ALIASES[u])return DGJ_JOB_COUNTRY_ALIASES[u]; if(/^[A-Z]{2}$/.test(u))return u; return r;}
  const loc=String(location||"").toUpperCase();
  const keys=Object.keys(DGJ_JOB_COUNTRY_ALIASES).filter((k)=>k.length>2).sort((a,b)=>b.length-a.length);
  for(const k of keys) if(loc.includes(k)) return DGJ_JOB_COUNTRY_ALIASES[k];
  return null;
}
function dgjJobCountryDisplayName(value) {
  const v=String(value||"").trim(); if(!v)return null;
  if(/^[A-Z]{2}$/i.test(v)){try{const n=new Intl.DisplayNames(["en"],{type:"region"}).of(v.toUpperCase()); if(n&&n!==v.toUpperCase())return n;}catch{} }
  return v;
}
function dgjJobPostalAddress(job,countryCode){
  const address={"@type":"PostalAddress","addressCountry":countryCode};
  const raw=String(job.location||"").trim(); if(!raw)return address;
  const parts=raw.split(",").map((x)=>x.trim()).filter(Boolean).filter((x)=>!/^(remote|worldwide|global|anywhere|virtual|telecommute)$/i.test(x));
  const clean=parts.filter((x)=>{const u=x.toUpperCase(); const mapped=DGJ_JOB_COUNTRY_ALIASES[u]||(/^[A-Z]{2}$/.test(u)?u:null); return !mapped || mapped!==countryCode;});
  if(clean[0])address.addressLocality=clean[0]; if(clean[1])address.addressRegion=clean[1]; return address;
}
function dgjJobHasApplyPath(job) { return !!(job && (job.url || job.applyEmail || job.isEmployerPosted)); }
function dgjJobApplicationContact(job) {
  if(!job)return null;
  const contact={"@type":"ContactPoint","contactType":"Application"};
  if(job.url){try{const u=new URL(String(job.url));if(/^https?:$/.test(u.protocol))contact.url=u.href;}catch{}}
  const email=String(job.applyEmail||"").trim();if(email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))contact.email=email;
  return contact.url||contact.email?contact:null;
}
function dgjEmployerSameAs(job) {
  if(!job || !job.isEmployerPosted || !job.url) return null;
  try {
    const u=new URL(String(job.url)); if(!/^https?:$/.test(u.protocol))return null;
    const host=String(u.hostname||"").toLowerCase().replace(/^www\./,""); if(!host || host==="devglobaljobs.com" || host.endsWith(".devglobaljobs.com"))return null;
    const blocked=["linkedin.com","indeed.com","indeed.co.uk","glassdoor.com","google.com","forms.gle","docs.google.com","greenhouse.io","lever.co","myworkdayjobs.com","ashbyhq.com","remoteok.com","remotive.com","jobicy.com","arbeitnow.com","themuse.com","himalayas.app","workingnomads.com","adzuna.com","usajobs.gov","reliefweb.int","weworkremotely.com","nofluffjobs.com"];
    if(blocked.some((d)=>host===d || host.endsWith("."+d)))return null;
    const stop=new Set(["the","and","company","co","corp","corporation","inc","llc","ltd","limited","group","holdings","services","solutions","international","global","careers","jobs"]);
    const tokens=String(job.organization||"").toLowerCase().replace(/[^a-z0-9]+/g," ").split(/\s+/).filter((x)=>x.length>=3&&!stop.has(x));
    const compactHost=host.replace(/[^a-z0-9]/g,""); if(tokens.length && !tokens.some((t)=>compactHost.includes(t.replace(/[^a-z0-9]/g,""))))return null;
    return u.origin;
  } catch { return null; }
}
function dgjJobEmploymentType(raw) { const t=String(raw||"").toLowerCase().trim(); if(!t)return null; if(/full[ -]?time|permanent/.test(t))return "FULL_TIME"; if(/part[ -]?time/.test(t))return "PART_TIME"; if(/contract|freelance|consult/.test(t))return "CONTRACTOR"; if(/temporary|temp|seasonal|casual/.test(t))return "TEMPORARY"; if(/intern|trainee|apprentice/.test(t))return "INTERN"; if(/volunteer|unpaid|pro.?bono/.test(t))return "VOLUNTEER"; if(/per.?diem/.test(t))return "PER_DIEM"; return "OTHER"; }
function dgjJobIsRemote(job) { if(String(job.category||"").toLowerCase()==="remote")return true; if(/remote/i.test(String(job.workplaceType||"")))return true; return /(^|\b)(remote|work from home|work from anywhere|anywhere|worldwide|virtual|telecommute)(\b|$)/i.test(String(job.location||"")); }
function dgjJobNumbers(s){return (String(s).toLowerCase().replace(/,/g,"").match(/\d+(?:\.\d+)?\s*k?/g)||[]).map((x)=>/k\s*$/i.test(x)?parseFloat(x)*1000:parseFloat(x)).filter((n)=>Number.isFinite(n)&&n>0);}
function dgjJobSalary(job,countryCode){
  if(!job.isEmployerPosted||!job.salary)return null;
  const s=String(job.salary); let currency=null,unit=null;
  if(/\bUSD\b|US\$/i.test(s))currency="USD"; else if(/\bEUR\b|€/i.test(s))currency="EUR"; else if(/\bGBP\b|£/i.test(s))currency="GBP"; else if(/\bCAD\b|CA\$/i.test(s))currency="CAD"; else if(/\bAUD\b|A\$/i.test(s))currency="AUD"; else if(/\bQAR\b/i.test(s))currency="QAR"; else if(/\bAED\b/i.test(s))currency="AED"; else if(/\bSAR\b/i.test(s))currency="SAR"; else if(/\bCHF\b/i.test(s))currency="CHF"; else if(/\bINR\b|₹/i.test(s))currency="INR"; else if(/\bPKR\b/i.test(s))currency="PKR"; else if(/\bSGD\b/i.test(s))currency="SGD";
  if(/per\s*hour|\/\s*(hr|hour)\b|hourly/i.test(s))unit="HOUR"; else if(/per\s*day|\/\s*day\b|daily/i.test(s))unit="DAY"; else if(/per\s*week|\/\s*(wk|week)\b|weekly/i.test(s))unit="WEEK"; else if(/per\s*month|\/\s*(mo|month)\b|monthly/i.test(s))unit="MONTH"; else if(/per\s*year|\/\s*(yr|year)\b|annual|annum|yearly/i.test(s))unit="YEAR";
  if(!currency||!unit)return null; const nums=dgjJobNumbers(s); if(!nums.length)return null; const value={"@type":"QuantitativeValue","unitText":unit}; if(nums.length>=2){value.minValue=Math.min(nums[0],nums[1]);value.maxValue=Math.max(nums[0],nums[1]);} else value.value=nums[0]; return {"@type":"MonetaryAmount","currency":currency,"value":value};
}
function buildGoogleJobPostingSchema(job, canonical) {
  if(!job||!job.id||!job.title||!job.organization)return null; if(!dgjJobHasApplyPath(job))return null;
  const description=dgjJobDescriptionHtml(job.description),datePosted=dgjJobIsoDate(job.postedAt); if(!description||!datePosted)return null;
  const validThrough=dgjJobIsoDate(job.closingDate); if(validThrough && new Date(validThrough+"T23:59:59Z").getTime()<Date.now())return null;
  const country=dgjJobCountry(job.country,job.location),isRemote=dgjJobIsRemote(job);
  const hiringOrganization={"@type":"Organization","name":String(job.organization).trim()}; const employerSameAs=dgjEmployerSameAs(job); if(employerSameAs)hiringOrganization.sameAs=employerSameAs;
  const schema={"@context":"https://schema.org","@type":"JobPosting","@id":`${canonical}#jobposting`,"title":String(job.title).trim(),"description":description,"datePosted":datePosted,"hiringOrganization":hiringOrganization,"identifier":{"@type":"PropertyValue","name":String(job.organization).trim(),"value":String(job.sourceId||job.id)},"url":canonical,"directApply":false};
  const employmentType=dgjJobEmploymentType(job.jobType); if(employmentType)schema.employmentType=employmentType; if(validThrough)schema.validThrough=validThrough;
  if(isRemote){if(!country)return null; schema.jobLocationType="TELECOMMUTE"; schema.applicantLocationRequirements={"@type":"Country","name":dgjJobCountryDisplayName(country)};}
  else {if(!country)return null; schema.jobLocation={"@type":"Place","address":dgjJobPostalAddress(job,country)};}
  const baseSalary=dgjJobSalary(job,country); if(baseSalary)schema.baseSalary=baseSalary; const applicationContact=dgjJobApplicationContact(job); if(applicationContact)schema.applicationContact=applicationContact; return schema;
}
function injectJobDetailMeta(html, job) {
  const BASE=DGJ_V27_BASE_URL, canonical=`${BASE}/jobs/detail/${job.id}`, title=`${job.title} at ${job.organization} | Dev Global Jobs`;
  const descRaw=job.description?String(job.description).replace(/<[^>]*>/g,"").replace(/\s+/g," ").trim():""; const description=descRaw.length>160?descRaw.substring(0,157).replace(/\s+\S*$/,"")+"...":descRaw||`Review ${job.title} at ${job.organization} on Dev Global Jobs.`; const safe=(s)=>dgjEscapeMeta(s);
  const validThrough=dgjJobIsoDate(job.closingDate), expired=!!(validThrough && new Date(validThrough+"T23:59:59Z").getTime()<Date.now()); const robots=expired?"noindex, nofollow":DGJ_BRAND_CONTRACT.indexRobots;
  html=html.replace(/<title>[^<]*<\/title>/,`<title>${dgjEscapeText(title)}</title>`).replace(/<meta name="description" content="[^"]*"\s*\/?>/,`<meta name="description" content="${safe(description)}" />`).replace(/<link rel="canonical" href="[^"]*"\s*\/?>/,`<link rel="canonical" href="${canonical}" />`).replace(/<meta property="og:title" content="[^"]*"\s*\/?>/,`<meta property="og:title" content="${safe(title)}" />`).replace(/<meta property="og:description" content="[^"]*"\s*\/?>/,`<meta property="og:description" content="${safe(description)}" />`).replace(/<meta property="og:url" content="[^"]*"\s*\/?>/,`<meta property="og:url" content="${canonical}" />`).replace(/<meta property="og:type" content="[^"]*"\s*\/?>/,`<meta property="og:type" content="article" />`).replace(/<meta property="og:image" content="[^"]*"\s*\/?>/,`<meta property="og:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`).replace(/<meta property="og:image:width" content="[^"]*"\s*\/?>/,`<meta property="og:image:width" content="1200" />`).replace(/<meta property="og:image:height" content="[^"]*"\s*\/?>/,`<meta property="og:image:height" content="630" />`).replace(/<meta property="og:image:alt" content="[^"]*"\s*\/?>/,`<meta property="og:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`).replace(/<meta name="twitter:title" content="[^"]*"\s*\/?>/,`<meta name="twitter:title" content="${safe(title)}" />`).replace(/<meta name="twitter:description" content="[^"]*"\s*\/?>/,`<meta name="twitter:description" content="${safe(description)}" />`).replace(/<meta name="twitter:image" content="[^"]*"\s*\/?>/,`<meta name="twitter:image" content="${DGJ_SOCIAL_SHARE_IMAGE}" />`).replace(/<meta name="twitter:image:alt" content="[^"]*"\s*\/?>/,`<meta name="twitter:image:alt" content="${DGJ_SOCIAL_SHARE_ALT}" />`).replace(/<meta name="robots" content="[^"]*"\s*\/?>/,`<meta name="robots" content="${robots}" />`).replace(/<meta name="googlebot" content="[^"]*"\s*\/?>/,`<meta name="googlebot" content="${robots}" />`);
  html=html.replace(/\s*<link rel="alternate" hreflang="[^"]+" href="[^"]+"\s*\/?>/g,"").replace(/\s*<script[^>]+id="(?:dgj-jobposting-v27|job-jsonld|dgj-job-graph|dgj-jobposting-schema)"[\s\S]*?<\/script>/g,"");
  const breadcrumb={"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":BASE},{"@type":"ListItem","position":2,"name":"All Jobs","item":`${BASE}/jobs/all`},{"@type":"ListItem","position":3,"name":job.title,"item":canonical}]}; const jobSchema=expired?null:buildGoogleJobPostingSchema(job,canonical);
  let extra=`\n    <link rel="alternate" hreflang="en" href="${canonical}" />\n    <link rel="alternate" hreflang="x-default" href="${canonical}" />\n    <!-- DGJ_SOURCE_OF_TRUTH_BRAND_LOCK_V27 | DGJ_GOOGLE_JOBS_SCHEMA_LOCK_V27 -->\n`;
  if(jobSchema)extra+=`    <script id="dgj-jobposting-v27" type="application/ld+json">${dgjSafeJsonLd(jobSchema)}</script>\n`; extra+=`    <script id="dgj-job-breadcrumb-v27" type="application/ld+json">${dgjSafeJsonLd(breadcrumb)}</script>\n`;
  return html.replace("</head>",`${extra}</head>`);
}


// server/static.ts
function injectDevelopersSsrContent(html) {
  const jsonLd = JSON.stringify({
    "@context":"https://schema.org",
    "@graph":[
      {"@type":"TechArticle","headline":"Dev Global Jobs Free Jobs API and RSS Feed","description":"Free developer access to international job listings through JSON API and RSS 2.0.","url":"https://devglobaljobs.com/developers","publisher":{"@type":"Organization","name":"Dev Global Jobs","url":"https://devglobaljobs.com"}},
      {"@type":"WebAPI","name":"Dev Global Jobs Free Jobs API","documentation":"https://devglobaljobs.com/developers","url":"https://devglobaljobs.com/api/v1/jobs","provider":{"@type":"Organization","name":"Dev Global Jobs"}}
    ]
  });
  const block = `<section id="dgj-developers-ssr" style="max-width:960px;margin:0 auto;padding:48px 20px;font-family:Inter,system-ui,sans-serif"><h1>Free Jobs API & RSS Feed</h1><p>Integrate international jobs from Dev Global Jobs into your website for free. The public JSON API requires no API key, supports category, country, search, Easy Apply and Featured filters, and returns Dev Global Jobs detail links for attribution and referral traffic.</p><h2>JSON API</h2><p><code>GET https://devglobaljobs.com/api/v1/jobs</code></p><h2>RSS 2.0</h2><p><code>https://devglobaljobs.com/jobs.rss</code></p><h2>Fair-use limits</h2><p>Up to 100 jobs per request and 120 requests per minute per IP. Please retain attribution and link each job back to its Dev Global Jobs detail URL.</p><script type="application/ld+json">${jsonLd.replace(/</g,"\\u003c")}</script></section>`;
  return html.replace('<div id="root"></div>', `<div id="root">${block}</div>`);
}
function serveStatic(app2) {
  const distPath = import_path2.default.resolve(__dirname, "public");
  if (!import_fs2.default.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(import_express.default.static(distPath, {
    index: false,
    setHeaders: (res, filePath) => {
      if (filePath.endsWith("sw.js")) {
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      } else if (filePath.includes(`${import_path2.default.sep}assets${import_path2.default.sep}`)) {
        res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
      } else {
        res.setHeader("Cache-Control", "public, max-age=3600");
      }
    }
  }));
  app2.use(async (_req, res) => {
    const indexPath = import_path2.default.resolve(distPath, "index.html");
    let html = import_fs2.default.readFileSync(indexPath, "utf-8");
    try {
      const urlPath = _req.originalUrl.split("?")[0];
      const detailMatch = urlPath.match(/^\/jobs\/detail\/(\d+)/);
      if (detailMatch) {
        const jobId = parseInt(detailMatch[1]);
        try {
          const job = await storage.getJobById(jobId);
          if (job) {
            html = injectJobDetailMeta(html, job);
          }
        } catch (e) {
        }
      } else {
        html = injectMetaTags(html, _req.originalUrl);
        if (urlPath === "/developers") html = injectDevelopersSsrContent(html);
      }
    } catch (e) {
    }
    res.status(200).set("Content-Type", "text/html").set("Cache-Control", "no-cache, no-store, must-revalidate").send(html);
  });
}

// server/index.ts
var import_http = require("http");
var app = (0, import_express2.default)();
app.set("trust proxy", 1);
var httpServer = (0, import_http.createServer)(app);
var PgSession = (0, import_connect_pg_simple.default)(import_express_session.default);
var sessionPool = new import_pg2.default.Pool({ connectionString: process.env.DATABASE_URL });
app.use(
  import_express2.default.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    }
  })
);
app.use(import_express2.default.urlencoded({ extended: false }));
app.use((0, import_express_session.default)({
  store: new PgSession({
    pool: sessionPool,
    tableName: "user_sessions",
    createTableIfMissing: true
  }),
  secret: process.env.SESSION_SECRET || "dgj-admin-secret-2024-fallback",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    sameSite: "lax",
    maxAge: 30 * 24 * 60 * 60 * 1e3
  }
}));
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  await registerRoutes(httpServer, app);
  app.use((err, _req, res, next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    console.error("Internal Server Error:", err);
    if (res.headersSent) {
      return next(err);
    }
    return res.status(status).json({ message });
  });
  if (true) {
    serveStatic(app);
  } else {
    const { setupVite } = await null;
    await setupVite(httpServer, app);
  }
  const port = parseInt(process.env.PORT || "8080", 10);
  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true
    },
    () => {
      log(`serving on port ${port}`);
    }
  );
})();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  log
});
