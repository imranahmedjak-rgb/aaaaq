#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
sha256sum -c PAYLOAD-SHA256SUMS.txt
node --check payload/dist/public/assets/dgj-v51-employer.js >/dev/null
grep -Fq "dgj-v63-employer-dashboard-layout" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "window.__DGJ_V63_EMPLOYER_NAV__" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq "window.addEventListener('pointerdown'" payload/dist/public/assets/dgj-v51-employer.js
grep -Fq '@media (max-width:767px)' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'activateEmployerTab(t,true)' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'switchPostToEmployerTab(t)' payload/dist/public/assets/dgj-v51-employer.js
grep -Fq 'dgj-v51-employer.js?v=63.0.0' payload/dist/public/index.html
! grep -Fq 'dgj-v51-recruitment.js?v=63' payload/dist/public/index.html
! grep -Fq 'dgj-v51-recruitment.css?v=63' payload/dist/public/index.html
echo 'PASS: V63 dashboard-layout and employer-navigation scope verified.'
