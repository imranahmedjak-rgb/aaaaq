Dev Global Jobs V63 — Employer Dashboard Layout + Click Fix

Purpose
-------
Fix ONLY the Employer Workspace dashboard layout and employer navigation interaction reported in the supplied screenshots.

What V63 does
-------------
1. Desktop (>=1024px): keeps the Employer Workspace sidebar fixed at 360px and gives the main dashboard the remaining viewport width. The sidebar remains available while the dashboard page scrolls.
2. Tablet (768–1023px): uses a 292px fixed sidebar and a correctly offset main dashboard.
3. Small screens (<768px): stops the sidebar from squeezing the dashboard into a narrow strip. Employer navigation becomes a compact horizontally scrollable bar and the dashboard uses the full width.
4. Navigation controls activate on pointer-down at window-capture level using the actual control coordinates, so same-document overlays cannot steal the intended employer navigation click.
5. Standard click and keyboard (Enter/Space) activation remain available as fallbacks.
6. The existing employer tab functions and routes remain in use. Backend/API architecture is unchanged.

Deployment safety
-----------------
- Payload changes exactly two live frontend files: employer JS + index cache reference.
- The deploy script accepts either the exact restored V60 baseline or the exact supplied V62 baseline, then creates a timestamped rollback backup before install.
- Recruitment/Easy Apply assets are hash-protected.
- No PM2 reload/restart is performed.
