#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$HERE/payload/dist/public"
BACKUP="/var/backups/devglobaljobs-v63-employer-dashboard-$(date +%Y%m%d-%H%M%S)"

# Known safe baselines: exact restored V60 OR exact supplied V62.
V60_IDX="0bbad414a3193318bab69b1b83e4db8679d11297d386af2a34afcfe54062cf9c"
V60_EMP="92bb0ad3f4c82ca993cb0c8c5e457c1ef71b40830b8cd9d2b24d7b791aefed70"
V62_IDX="57a29871212ca558702f3af42e9380891e893a6449a1ae8b6f4849f58ce8b385"
V62_EMP="c4afaf399214c8a1f4aedacf6d4b66e5e80526ffc6571613f36c9873de8883e0"
V63_IDX="5e9bd6e774b67a0c40d1c4cdad2de04a387b5060d074256372676023d18fd6ec"
V63_EMP="86c96d957d211d467ef4ed05b09eef252cde12b0e3b9165d4ef7e03deb80a455"
REC_JS="25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304"
REC_CSS="4fd6bc549aa36c3c674404d13c9e0ef0e65de46f23988daf759cce421b021042"

fail(){
  echo
  echo '============================================================'
  echo "SAFE STOP: $*"
  if [ -d "$BACKUP" ] && [ -f "$BACKUP/index.html" ]; then
    echo 'ROLLBACK: restoring the two pre-V63 frontend files...'
    cp -af "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -af "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    echo 'ROLLBACK COMPLETE.'
  fi
  echo 'NO BACKEND, DATABASE, RECRUITMENT, PAYMENT, SEO, PWA OR PM2 CHANGE WAS MADE.'
  echo '============================================================'
  exit 1
}

match_pair(){
  local idx="$1" emp="$2"
  { [ "$idx" = "$V60_IDX" ] && [ "$emp" = "$V60_EMP" ]; } || \
  { [ "$idx" = "$V62_IDX" ] && [ "$emp" = "$V62_EMP" ]; }
}

echo '============================================================'
echo 'DEV GLOBAL JOBS V63'
echo 'EMPLOYER DASHBOARD LAYOUT + CLICK FIX ONLY'
echo '============================================================'

echo '1/8 SAFE BASELINE + API HEALTH'
[ -f "$APP/dist/public/index.html" ] || fail 'live index missing'
[ -f "$APP/dist/public/assets/dgj-v51-employer.js" ] || fail 'live employer JS missing'
[ -f "$APP/dist/public/assets/dgj-v51-recruitment.js" ] || fail 'live recruitment JS missing'
[ -f "$APP/dist/public/assets/dgj-v51-recruitment.css" ] || fail 'live recruitment CSS missing'
LIVE_IDX="$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')"
LIVE_EMP="$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')"
LIVE_RECJS="$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')"
LIVE_RECCSS="$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')"
match_pair "$LIVE_IDX" "$LIVE_EMP" || fail "live employer frontend is not the exact safe V60/V62 baseline (index=$LIVE_IDX employer=$LIVE_EMP)"
[ "$LIVE_RECJS" = "$REC_JS" ] || fail 'recruitment JS differs; refusing unrelated overwrite'
[ "$LIVE_RECCSS" = "$REC_CSS" ] || fail 'recruitment CSS differs; refusing unrelated overwrite'
CODE="$(curl -sS -o /tmp/dgj-v63-before.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "API health is $CODE"
echo 'PASS: safe employer baseline + protected recruitment assets + backend health verified.'

echo '2/8 PACKAGE PREFLIGHT'
bash "$HERE/preflight-v63.sh" || fail 'V63 preflight failed'

echo '3/8 PRIVATE TWO-FILE BACKUP'
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
echo "Backup: $BACKUP"

echo '4/8 ATOMIC TWO-FILE INSTALL'
install -m 0644 "$PAYLOAD/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v63.tmp"
install -m 0644 "$PAYLOAD/index.html" "$APP/dist/public/index.html.v63.tmp"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v63.tmp" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/index.html.v63.tmp" "$APP/dist/public/index.html"
echo 'PASS: only employer JS + index cache reference installed.'

echo '5/8 EXACT BYTE VERIFICATION'
[ "$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')" = "$V63_IDX" ] || fail 'installed index hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')" = "$V63_EMP" ] || fail 'installed employer JS hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')" = "$REC_JS" ] || fail 'protected recruitment JS changed unexpectedly'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')" = "$REC_CSS" ] || fail 'protected recruitment CSS changed unexpectedly'
echo 'PASS: exact V63 bytes and protected recruitment assets verified.'

echo '6/8 ORIGIN CONTRACT — NO PM2 RELOAD'
IDX="$(curl -fsS --max-time 15 http://127.0.0.1:8080/)" || fail 'origin homepage fetch failed'
printf '%s' "$IDX" | grep -F 'dgj-v51-employer.js?v=63.0.0' >/dev/null || fail 'origin index does not expose V63 employer cache version'
JS="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v51-employer.js)" || fail 'origin employer JS fetch failed'
printf '%s' "$JS" | grep -F 'window.__DGJ_V63_EMPLOYER_NAV__' >/dev/null || fail 'origin employer JS does not expose V63 navigation marker'
printf '%s' "$JS" | grep -F 'dgj-v63-employer-dashboard-layout' >/dev/null || fail 'origin employer JS does not expose V63 dashboard layout marker'
echo 'PASS: origin serves V63 without backend restart.'

echo '7/8 FINAL API + HOME HEALTH'
CODE="$(curl -sS -o /tmp/dgj-v63-after.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "post-install API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "post-install homepage health is $HOME"
echo 'PASS: backend + homepage healthy.'

echo '8/8 FINAL SCOPE'
echo '============================================================'
echo 'SUCCESS: V63 EMPLOYER DASHBOARD LAYOUT + CLICK FIX IS LIVE'
echo '============================================================'
echo '✓ Employer Dashboard sidebar stays stable on desktop/tablet'
echo '✓ Employer Dashboard main column no longer slides underneath / away from sidebar'
echo '✓ Small screens use full-width dashboard with horizontal employer navigation'
echo '✓ Employer sidebar options activate immediately at capture level'
echo '✓ Click + keyboard fallbacks retained'
echo '✓ Post-a-Job form/design unchanged'
echo '✓ Recruitment/Easy Apply assets unchanged'
echo '✓ Admin/backend/database/payment/SEO/PWA unchanged'
echo '✓ No PM2 reload/restart performed'
echo "Rollback backup: $BACKUP"
echo '============================================================'
