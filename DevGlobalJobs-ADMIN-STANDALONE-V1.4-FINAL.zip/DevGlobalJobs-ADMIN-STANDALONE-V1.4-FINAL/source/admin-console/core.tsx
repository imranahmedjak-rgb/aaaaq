import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  LayoutDashboard, Briefcase, PlusCircle, Rss, Building2, Users, FileText as FileIcon,
  DollarSign, Ticket, Mail, Newspaper, LogOut, Search, Filter, RefreshCw, Trash2,
  Download, CheckCircle2, XCircle, Loader2, ChevronLeft, ChevronRight, ShieldCheck,
  AlertTriangle, ExternalLink, Menu, X,
} from "lucide-react";
import { COUNTRIES } from "@/lib/countries";

export type AnyRecord = Record<string, any>;
export async function requestJson<T = AnyRecord>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { credentials: "include", ...init });
  let data: AnyRecord = {};
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) {
    const error = new Error(data.message || data.error || `Request failed (${response.status})`);
    (error as Error & { status?: number }).status = response.status;
    throw error;
  }
  return data as T;
}
export function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

export const NAV = [
  { key: "overview", label: "Overview", icon: LayoutDashboard },
  { key: "jobs", label: "Jobs", icon: Briefcase },
  { key: "post-job", label: "Post Job", icon: PlusCircle },
  { key: "sources", label: "Sources & Fetcher", icon: Rss },
  { key: "employers", label: "Employers", icon: Building2 },
  { key: "seekers", label: "Job Seekers", icon: Users },
  { key: "recruitment", label: "Recruitment", icon: FileIcon },
  { key: "revenue", label: "Revenue", icon: DollarSign },
  { key: "commerce", label: "Plans, Boosts & Codes", icon: Ticket },
  { key: "subscribers", label: "Subscribers & Growth", icon: Mail },
  { key: "blog", label: "Blog", icon: Newspaper },
] as const;
export type SectionKey = typeof NAV[number]["key"];
export type CommerceTab = "requests" | "boosts" | "codes";

// Legacy/expected /admin/* URL aliases, so bookmarked or linked URLs open
// the correct standalone section instead of silently falling back to
// Overview. Mapped from: (a) the 12 routes previously registered in
// App.tsx pointing at the dead WorkspaceDashboard mode="admin" path, and
// (b) the URLs explicitly named as required. Every mapping below is to a
// section this console actually implements — nothing maps to a
// non-existent screen.
const LEGACY_ALIASES: Record<string, SectionKey> = {
  "": "overview",
  "dashboard": "overview",
  "jobs": "jobs",
  "sources": "sources",
  "employers": "employers",
  "seekers": "seekers",
  "applications": "recruitment",
  "review": "recruitment",       // legacy "review queue" concept — closest real equivalent is Recruitment/Applications
  "reviews": "recruitment",      // plural alias of the above — same mapping
  "support": "overview",         // no dedicated Support screen exists yet — Overview is the explicit, documented fallback
  "reports": "recruitment",      // legacy "reports" — closest real equivalent is Recruitment's CSV export
  "revenue": "revenue",
  "revenue-metrics": "revenue",
  "requests": "commerce",
  "premium": "commerce",
  "boosts": "commerce",
  "codes": "commerce",
  "newsletter": "subscribers",
  "growth": "subscribers",
  "blog": "blog",
  "settings": "overview",        // no dedicated Settings screen exists yet — Overview is the safe default
};
const COMMERCE_TAB_ALIASES: Record<string, CommerceTab> = { requests: "requests", premium: "requests", boosts: "boosts", codes: "codes" };

export function sectionFromPath(path: string): SectionKey {
  const seg = path.replace(/^\/admin\/?/, "").split("/")[0];
  if (seg in LEGACY_ALIASES) return LEGACY_ALIASES[seg];
  const found = NAV.find((n) => n.key === seg);
  return found ? found.key : "overview";
}
export function commerceTabFromPath(path: string): CommerceTab | null {
  const seg = path.replace(/^\/admin\/?/, "").split("/")[0];
  return COMMERCE_TAB_ALIASES[seg] || null;
}

// ---- shared primitives -----------------------------------------------------
export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-[var(--ac-radius)] border border-slate-200 bg-white shadow-[var(--ac-shadow)] ${className}`}>{children}</section>;
}
export function CardHeader({ title, action }: { title: string; action?: ReactNode }) {
  return <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4"><h2 className="text-sm font-bold text-slate-800">{title}</h2>{action}</div>;
}
export function KpiCard({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return (
    <Card className="p-4">
      <p className="text-[10px] font-bold uppercase tracking-[.14em] text-[var(--ac-cyan-700)]">{label}</p>
      <p className="ac-mono mt-2 text-2xl font-bold text-slate-900">{value}</p>
      {hint && <p className="mt-1 text-[11px] text-slate-400">{hint}</p>}
    </Card>
  );
}
export function Skeleton({ className }: { className: string }) { return <div className={`ac-skeleton ${className}`} />; }
export function EmptyState({ children }: { children: ReactNode }) { return <div className="p-10 text-center text-sm text-slate-500">{children}</div>; }
export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return <div className="flex items-center justify-between gap-3 rounded-xl bg-rose-50 p-4 text-xs font-semibold text-rose-700"><span className="flex items-center gap-2"><AlertTriangle size={14} />{message}</span><button type="button" onClick={onRetry} className="rounded-lg border border-rose-200 px-2.5 py-1">Retry</button></div>;
}
export function Pill({ tone, children }: { tone: "green" | "amber" | "rose" | "slate" | "cyan"; children: ReactNode }) {
  const map = { green: "bg-emerald-50 text-emerald-700", amber: "bg-amber-50 text-amber-700", rose: "bg-rose-50 text-rose-700", slate: "bg-slate-100 text-slate-600", cyan: "bg-cyan-50 text-cyan-700" };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold ${map[tone]}`}>{children}</span>;
}
export function Btn({ children, onClick, variant = "default", disabled, type = "button" }: { children: ReactNode; onClick?: () => void; variant?: "default" | "outline" | "danger" | "ghost"; disabled?: boolean; type?: "button" | "submit" }) {
  const styles = {
    default: "bg-[var(--ac-navy-700)] text-white",
    outline: "border border-slate-200 text-slate-700 hover:border-cyan-300",
    danger: "border border-rose-200 text-rose-700 hover:bg-rose-50",
    ghost: "text-slate-500 hover:text-slate-800",
  };
  return <button type={type} disabled={disabled} onClick={onClick} className={`inline-flex h-9 items-center gap-1.5 rounded-lg px-3 text-xs font-bold disabled:opacity-50 ${styles[variant]}`}>{children}</button>;
}
export function ConfirmDialog({ title, description, confirmLabel = "Confirm", danger, onConfirm, onCancel, busy }: { title: string; description: string; confirmLabel?: string; danger?: boolean; onConfirm: () => void; onCancel: () => void; busy?: boolean }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4" role="alertdialog" aria-modal="true">
      <div className="w-full max-w-sm rounded-2xl bg-white p-5">
        <p className="text-sm font-bold text-slate-800">{title}</p>
        <p className="mt-1 text-xs text-slate-500">{description}</p>
        <div className="mt-4 flex justify-end gap-2"><Btn variant="outline" onClick={onCancel} disabled={busy}>Cancel</Btn><Btn variant={danger ? "danger" : "default"} onClick={onConfirm} disabled={busy}>{busy ? "Working…" : confirmLabel}</Btn></div>
      </div>
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="block text-xs font-bold text-slate-700">{label}<div className="mt-1.5">{children}</div>{hint && <p className="mt-1 text-[11px] font-normal text-slate-400">{hint}</p>}</label>;
}
export const inputCls = "h-10 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none focus:border-cyan-500";

export function useAdminApi<T>(url: string, enabled = true) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const load = () => {
    if (!enabled) { setLoading(false); return; }
    setLoading(true); setError(null);
    requestJson<T>(url).then(setData).catch((e) => setError(errorMessage(e, "This data could not be loaded."))).finally(() => setLoading(false));
  };
  useEffect(load, [url, enabled]);
  return { data, error, loading, reload: load };
}

export function Pagination({ page, totalPages, onChange }: { page: number; totalPages: number; onChange: (p: number) => void }) {
  if (totalPages <= 1) return null;
  return <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3"><Btn variant="outline" disabled={page <= 1} onClick={() => onChange(page - 1)}><ChevronLeft size={13} />Prev</Btn><span className="ac-mono text-[11px] text-slate-500">Page {page} of {totalPages}</span><Btn variant="outline" disabled={page >= totalPages} onClick={() => onChange(page + 1)}>Next<ChevronRight size={13} /></Btn></div>;
}

// ---- Auth gate --------------------------------------------------------------
export function AdminLoginScreen({ onSuccess }: { onSuccess: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      await requestJson("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: username.trim(), password }) });
      onSuccess();
    } catch (reason) {
      setError(errorMessage(reason, "Invalid username or password."));
    } finally { setBusy(false); }
  }
  return (
    <div className="admin-console flex min-h-[100dvh] items-center justify-center bg-[var(--ac-navy-900)] px-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl border border-white/10 bg-[var(--ac-navy-800)] p-7 text-white">
        <ShieldCheck className="text-[var(--ac-cyan-300)]" size={26} />
        <h1 className="mt-4 text-lg font-bold">Admin Control Centre</h1>
        <p className="mt-1 text-xs text-slate-400">Restricted access. Operations sign-in.</p>
        {error && <div className="mt-4 rounded-lg bg-rose-500/10 p-3 text-xs font-semibold text-rose-300">{error}</div>}
        <div className="mt-5 space-y-3">
          <Field label="Username"><input value={username} onChange={(e) => setUsername(e.target.value)} className="h-10 w-full rounded-lg border border-white/10 bg-white/5 px-3 text-sm text-white outline-none focus:border-cyan-400" /></Field>
          <Field label="Password"><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="h-10 w-full rounded-lg border border-white/10 bg-white/5 px-3 text-sm text-white outline-none focus:border-cyan-400" /></Field>
        </div>
        <button type="submit" disabled={busy} className="mt-5 flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-[var(--ac-cyan-400)] text-xs font-bold text-[var(--ac-navy-900)] disabled:opacity-60">{busy && <Loader2 size={14} className="animate-spin" />}{busy ? "Signing in…" : "Sign in"}</button>
      </form>
    </div>
  );
}

// ---- Overview ----------------------------------------------------------------
export function OverviewSection() {
  const stats = useAdminApi<AnyRecord>("/api/admin/stats");
  const growth = useAdminApi<AnyRecord>("/api/admin/growth/overview");
  const v45 = useAdminApi<AnyRecord>("/api/v45/admin/summary");
  const v51 = useAdminApi<AnyRecord>("/api/v51/admin/summary");
  const loading = stats.loading || growth.loading || v45.loading || v51.loading;
  return (
    <div className="space-y-5">
      <h1 className="text-xl font-bold text-slate-900">Executive Overview</h1>
      {loading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[0, 1, 2, 3, 4, 5, 6, 7].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div>
      ) : stats.error ? <ErrorState message={stats.error} onRetry={stats.reload} /> : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <KpiCard label="Total jobs" value={stats.data?.total ?? "—"} hint={`${stats.data?.today ?? 0} in last 24h`} />
          <KpiCard label="Employer-posted" value={stats.data?.employer ?? "—"} hint={`${stats.data?.featured ?? 0} featured`} />
          <KpiCard label="Job seekers" value={growth.data?.seekers_total ?? "—"} hint={`+${growth.data?.seekers_today ?? 0} today`} />
          <KpiCard label="Employers" value={growth.data?.employers_total ?? "—"} hint={`+${growth.data?.employers_today ?? 0} today`} />
          <KpiCard label="Verified revenue (month)" value={v45.data?.revenue_verified_month != null ? `$${Number(v45.data.revenue_verified_month).toLocaleString()}` : "—"} hint="Actually reviewed payments" />
          <KpiCard label="Pending paid requests" value={v45.data?.pending_requests ?? "—"} hint={`${v45.data?.active_boosts ?? 0} active boosts`} />
          <KpiCard label="Applications" value={v51.data?.total_applications ?? "—"} hint={`${v51.data?.applications_today ?? 0} today`} />
          <KpiCard label="Sign-ins today" value={growth.data?.signins_today ?? "—"} hint={`${stats.data?.subscribers ?? 0} newsletter subscribers`} />
        </div>
      )}
      <Card>
        <CardHeader title="Newsletter capacity" />
        {growth.loading ? <div className="p-5"><Skeleton className="h-6 rounded" /></div> : growth.error ? <div className="p-5"><ErrorState message={growth.error} onRetry={growth.reload} /></div> : (
          <div className="grid gap-4 p-5 sm:grid-cols-3">
            <div><p className="text-[11px] text-slate-400">Active subscribers</p><p className="ac-mono text-lg font-bold">{growth.data?.active_subscribers ?? "—"}</p></div>
            <div><p className="text-[11px] text-slate-400">Weekly send capacity</p><p className="ac-mono text-lg font-bold">{growth.data?.weekly_capacity ?? "—"}</p></div>
            <div><p className="text-[11px] text-slate-400">Capacity status</p>{growth.data?.capacity_ok === false ? <Pill tone="rose">Over capacity</Pill> : <Pill tone="green">Healthy</Pill>}</div>
          </div>
        )}
      </Card>
    </div>
  );
}

// ---- Jobs Management ----------------------------------------------------------
function EditJobModal({ job, onClose, onSaved }: { job: AnyRecord; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    title: job.title || "", organization: job.organization || "", location: job.location || "",
    category: job.category || "", country: job.country || "", description: job.description || "",
    url: job.url || "", applyEmail: job.applyEmail || job.apply_email || "", jobType: job.jobType || job.job_type || "",
    salary: job.salary || "", startDate: (job.startDate || job.start_date || "").slice(0, 10), closingDate: (job.closingDate || job.closing_date || "").slice(0, 10),
    featured: Boolean(job.featured),
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const set = (k: keyof typeof form, v: any) => setForm((f) => ({ ...f, [k]: v }));
  async function save() {
    setBusy(true); setError("");
    try { await requestJson(`/api/admin/jobs/${job.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) }); onSaved(); onClose(); }
    catch (e) { setError(errorMessage(e, "Job could not be saved.")); }
    finally { setBusy(false); }
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5">
        <div className="flex items-center justify-between"><h3 className="text-sm font-bold">Edit job #{job.id}</h3><button onClick={onClose} aria-label="Close"><X size={16} /></button></div>
        {error && <p className="mt-3 rounded-lg bg-rose-50 p-2 text-xs text-rose-700">{error}</p>}
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Field label="Title"><input value={form.title} onChange={(e) => set("title", e.target.value)} className={inputCls} /></Field>
          <Field label="Organization"><input value={form.organization} onChange={(e) => set("organization", e.target.value)} className={inputCls} /></Field>
          <Field label="Location"><input value={form.location} onChange={(e) => set("location", e.target.value)} className={inputCls} /></Field>
          <Field label="Category"><select value={form.category} onChange={(e) => set("category", e.target.value)} className={inputCls}><option value="">Select category</option>{CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}</select></Field>
          <Field label="Country"><select value={form.country} onChange={(e) => set("country", e.target.value)} className={inputCls}><option value="">Select country</option>{COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}</select></Field>
          <Field label="Job type"><input value={form.jobType} onChange={(e) => set("jobType", e.target.value)} className={inputCls} /></Field>
          <Field label="Salary"><input value={form.salary} onChange={(e) => set("salary", e.target.value)} className={inputCls} /></Field>
          <Field label="Application email"><input value={form.applyEmail} onChange={(e) => set("applyEmail", e.target.value)} className={inputCls} /></Field>
          <Field label="Start date"><input type="date" value={form.startDate} onChange={(e) => set("startDate", e.target.value)} className={inputCls} /></Field>
          <Field label="Closing date"><input type="date" value={form.closingDate} onChange={(e) => set("closingDate", e.target.value)} className={inputCls} /></Field>
        </div>
        <div className="mt-3"><Field label="Application URL"><input value={form.url} onChange={(e) => set("url", e.target.value)} className={inputCls} /></Field></div>
        <div className="mt-3"><Field label="Description"><textarea value={form.description} onChange={(e) => set("description", e.target.value)} className="min-h-[140px] w-full rounded-lg border border-slate-200 p-3 text-sm outline-none" /></Field></div>
        <label className="mt-3 flex items-center gap-2 text-xs font-bold text-slate-700"><input type="checkbox" checked={form.featured} onChange={(e) => set("featured", e.target.checked)} />Featured</label>
        <div className="mt-5 flex justify-end gap-2"><Btn variant="outline" onClick={onClose}>Cancel</Btn><Btn onClick={save} disabled={busy}>{busy ? "Saving…" : "Save changes"}</Btn></div>
      </div>
    </div>
  );
}

export function JobsSection() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [source, setSource] = useState("");
  const [editing, setEditing] = useState<AnyRecord | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<AnyRecord | null>(null);
  const params = new URLSearchParams({ page: String(page), limit: "20", ...(search ? { search } : {}), ...(source ? { source } : {}) });
  const jobs = useAdminApi<{ jobs: AnyRecord[]; total: number }>(`/api/admin/jobs?${params.toString()}`);
  const sources = useAdminApi<{ source: string; count: number }[]>("/api/admin/sources");
  const totalPages = Math.max(1, Math.ceil((jobs.data?.total || 0) / 20));

  const [deleteError, setDeleteError] = useState("");
  const [deleteBusy, setDeleteBusy] = useState(false);
  async function deleteJob(job: AnyRecord) {
    setDeleteBusy(true); setDeleteError("");
    try { await requestJson(`/api/admin/jobs/${job.id}`, { method: "DELETE" }); setConfirmDelete(null); jobs.reload(); }
    catch (e) { setDeleteError(errorMessage(e, "This job could not be deleted.")); }
    finally { setDeleteBusy(false); }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Jobs Management</h1>
        <div className="flex flex-wrap gap-2">
          <div className="relative"><Search size={14} className="absolute left-3 top-3 text-slate-400" /><input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search title, organization, location" className="h-9 w-56 rounded-lg border border-slate-200 pl-9 pr-3 text-xs outline-none" /></div>
          <select value={source} onChange={(e) => { setSource(e.target.value); setPage(1); }} className="h-9 rounded-lg border border-slate-200 px-2 text-xs"><option value="">All sources</option>{(sources.data || []).map((s) => <option key={s.source} value={s.source}>{s.source} ({s.count})</option>)}</select>
        </div>
      </div>
      <Card>
        {jobs.loading ? <div className="p-5 space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-10 rounded" />)}</div>
          : jobs.error ? <div className="p-5"><ErrorState message={jobs.error} onRetry={jobs.reload} /></div>
          : (jobs.data?.jobs?.length ?? 0) === 0 ? <EmptyState>No jobs match this view.</EmptyState>
          : (
            <div className="overflow-x-auto"><table className="w-full min-w-[720px] text-left"><thead className="bg-slate-50"><tr className="text-[10px] font-bold uppercase text-slate-400"><th className="px-4 py-2.5">Title</th><th className="px-4 py-2.5">Organization</th><th className="px-4 py-2.5">Source</th><th className="px-4 py-2.5">Featured</th><th className="px-4 py-2.5"></th></tr></thead>
            <tbody className="divide-y divide-slate-100">{jobs.data!.jobs.map((job) => (
              <tr key={job.id}><td className="px-4 py-3 text-xs font-bold text-slate-800">{job.title}</td><td className="px-4 py-3 text-xs text-slate-500">{job.organization}</td><td className="px-4 py-3 text-xs text-slate-500">{job.source}</td><td className="px-4 py-3">{job.featured ? <Pill tone="amber">Featured</Pill> : <Pill tone="slate">Regular</Pill>}</td>
              <td className="px-4 py-3 text-right"><div className="flex justify-end gap-1.5"><Btn variant="outline" onClick={() => setEditing(job)}>Edit</Btn><Btn variant="danger" onClick={() => setConfirmDelete(job)}><Trash2 size={12} /></Btn></div></td></tr>
            ))}</tbody></table></div>
          )}
        <Pagination page={page} totalPages={totalPages} onChange={setPage} />
      </Card>
      {editing && <EditJobModal job={editing} onClose={() => setEditing(null)} onSaved={jobs.reload} />}
      {confirmDelete && (
        <ConfirmDialog title={`Delete "${confirmDelete.title}"?`} description={deleteError || "This permanently removes the job listing. This cannot be undone."} confirmLabel="Delete" danger busy={deleteBusy} onCancel={() => { setConfirmDelete(null); setDeleteError(""); }} onConfirm={() => deleteJob(confirmDelete)} />
      )}
    </div>
  );
}

// ---- Post Job ------------------------------------------------------------------
const CATEGORIES = ["un", "ngo", "remote", "international", "technology", "healthcare", "business", "education", "engineering", "creative", "sales", "gig", "youth"];

export function PostJobSection() {
  const [form, setForm] = useState({ title: "", organization: "", location: "", category: "international", description: "", url: "", jobType: "", salary: "", country: "", applyEmail: "", featured: false, source: "Admin" });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null);
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setResult(null);
    try { const r = await requestJson<{ job: AnyRecord }>("/api/admin/jobs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) }); setResult({ ok: true, message: `Published as job #${r.job.id}.` }); }
    catch (e2) { setResult({ ok: false, message: errorMessage(e2, "Job could not be created.") }); }
    finally { setBusy(false); }
  }
  const set = (k: keyof typeof form, v: any) => setForm((f) => ({ ...f, [k]: v }));
  return (
    <div className="max-w-2xl space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Post Job (Admin)</h1>
      <Card className="p-5">
        <form onSubmit={submit} className="space-y-3">
          {result && <div className={`rounded-lg p-3 text-xs font-semibold ${result.ok ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>{result.message}</div>}
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Title *"><input required value={form.title} onChange={(e) => set("title", e.target.value)} className={inputCls} /></Field>
            <Field label="Organization *"><input required value={form.organization} onChange={(e) => set("organization", e.target.value)} className={inputCls} /></Field>
            <Field label="Location"><input value={form.location} onChange={(e) => set("location", e.target.value)} className={inputCls} /></Field>
            <Field label="Category *"><select required value={form.category} onChange={(e) => set("category", e.target.value)} className={inputCls}><option value="">Select category</option>{CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}</select></Field>
            <Field label="Job type"><input value={form.jobType} onChange={(e) => set("jobType", e.target.value)} className={inputCls} /></Field>
            <Field label="Salary"><input value={form.salary} onChange={(e) => set("salary", e.target.value)} className={inputCls} /></Field>
            <Field label="Country *"><select required value={form.country} onChange={(e) => set("country", e.target.value)} className={inputCls}><option value="">Select country</option>{COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}</select></Field>
            <Field label="Apply email"><input value={form.applyEmail} onChange={(e) => set("applyEmail", e.target.value)} className={inputCls} /></Field>
          </div>
          <Field label="Application URL"><input value={form.url} onChange={(e) => set("url", e.target.value)} className={inputCls} /></Field>
          <Field label="Description"><textarea value={form.description} onChange={(e) => set("description", e.target.value)} className="min-h-[160px] w-full rounded-lg border border-slate-200 p-3 text-sm outline-none" /></Field>
          <label className="flex items-center gap-2 text-xs font-bold text-slate-700"><input type="checkbox" checked={form.featured} onChange={(e) => set("featured", e.target.checked)} />Featured</label>
          <Btn type="submit" disabled={busy}>{busy ? "Publishing…" : "Publish job"}</Btn>
        </form>
      </Card>
    </div>
  );
}
