import { useEffect, useState } from "react";
import { LogOut, Menu, X } from "lucide-react";
import { requestJson, errorMessage, type AnyRecord, NAV, sectionFromPath, commerceTabFromPath, AdminLoginScreen, OverviewSection, JobsSection, PostJobSection } from "./core";
import "@/styles/admin-console-tokens.css";
import { SourcesSection, EmployersSection, SeekersSection, RecruitmentSection } from "./sections-a";
import { RevenueSection, CommerceSection, SubscribersSection, BlogSection } from "./sections-b";

// Tiny self-contained router — no wouter, no dependency on any other chunk.
// Keeps this module's only external deps to react/react-dom/lucide-react,
// all of which esbuild inlines into the standalone bundle.
function usePathname(): [string, (path: string) => void] {
  const [path, setPath] = useState(() => window.location.pathname);
  useEffect(() => {
    const onPop = () => setPath(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  const navigate = (next: string) => {
    window.history.pushState({}, "", next);
    setPath(next);
  };
  return [path, navigate];
}

function AdminShell({ account, onLogout }: { account: AnyRecord; onLogout: () => void }) {
  const [location, setLocation] = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const section = sectionFromPath(location);

  function go(key: string) {
    setLocation(key === "overview" ? "/admin" : `/admin/${key}`);
    setMobileOpen(false);
  }

  const content = {
    overview: <OverviewSection />, jobs: <JobsSection />, "post-job": <PostJobSection />,
    sources: <SourcesSection />, employers: <EmployersSection />, seekers: <SeekersSection />,
    recruitment: <RecruitmentSection />, revenue: <RevenueSection />, commerce: <CommerceSection initialTab={commerceTabFromPath(location) || undefined} />,
    subscribers: <SubscribersSection />, blog: <BlogSection />,
  }[section];

  return (
    <div className="admin-console flex min-h-[100dvh] bg-[#f4f6f9]">
      {mobileOpen && <button aria-label="Close menu" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-40 bg-black/40 lg:hidden" />}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 shrink-0 bg-[var(--ac-navy-800)] text-slate-300 transition-transform lg:sticky lg:top-0 lg:h-[100dvh] lg:translate-x-0 ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex h-16 items-center justify-between border-b border-white/10 px-5">
          <div><p className="text-sm font-bold text-white">Admin Control Centre</p><p className="ac-mono text-[9px] uppercase tracking-widest text-[var(--ac-cyan-300)]">Dev Global Jobs</p></div>
          <button className="lg:hidden" onClick={() => setMobileOpen(false)} aria-label="Close"><X size={18} /></button>
        </div>
        <nav className="flex flex-col gap-0.5 p-3">
          {NAV.map((n) => { const Icon = n.icon; const active = section === n.key; return (
            <button key={n.key} onClick={() => go(n.key)} className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-left text-xs font-bold ${active ? "bg-[var(--ac-cyan-400)] text-[var(--ac-navy-900)]" : "text-slate-300 hover:bg-white/5"}`} aria-current={active ? "page" : undefined}>
              <Icon size={15} />{n.label}
            </button>
          ); })}
        </nav>
        <div className="absolute bottom-0 w-full border-t border-white/10 p-3">
          <p className="px-3 text-[11px] text-slate-500">Signed in as <b className="text-slate-300">{account.username}</b></p>
          <button onClick={onLogout} className="mt-2 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-bold text-slate-300 hover:bg-white/5"><LogOut size={14} />Sign out</button>
        </div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 items-center gap-3 border-b border-slate-200 bg-white px-4 lg:hidden">
          <button onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          <p className="text-sm font-bold text-slate-800">{NAV.find((n) => n.key === section)?.label}</p>
        </header>
        <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">{content}</main>
      </div>
    </div>
  );
}

// Stable, module-level component (not recreated per render) so React keeps
// this instance mounted across every /admin/* navigation — the same fix
// pattern already proven for Employer: one wildcard route, one component
// reference, no full-tree remount on tab switches.
export default function AdminConsole() {
  const [account, setAccount] = useState<AnyRecord | null>(null);
  const [checking, setChecking] = useState(true);

  function load() {
    setChecking(true);
    requestJson<AnyRecord>("/api/admin/me").then(setAccount).catch(() => setAccount(null)).finally(() => setChecking(false));
  }
  useEffect(load, []);

  async function logout() {
    try { await requestJson("/api/admin/logout", { method: "POST" }); } finally { setAccount(null); }
  }

  if (checking) return <div className="admin-console flex min-h-[100dvh] items-center justify-center bg-[var(--ac-navy-900)] text-sm text-slate-400">Verifying administrator access…</div>;
  if (!account) return <AdminLoginScreen onSuccess={load} />;
  return <AdminShell account={account} onLogout={logout} />;
}
