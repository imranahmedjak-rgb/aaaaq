#!/usr/bin/env bash
# Dev Global Jobs — Admin Standalone deployment hash verification.
# Run as: ./verify-protected-hashes.sh /path/to/production/webroot <preflight|postflight>
#
# PREFLIGHT (before copying any file from this package into production):
#   ./verify-protected-hashes.sh /var/www/devglobaljobs preflight
#   Also hard-asserts that the CURRENTLY LIVE dist/public/index.html is
#   still the exact, unmodified authoritative V70.6.1 baseline — i.e. that
#   nothing else has changed it since that baseline was recorded — BEFORE
#   this package is allowed to overwrite it. If the live file already
#   differs from that baseline, deployment must stop: overwriting it here
#   would silently discard whatever the live difference was.
# POSTFLIGHT (after copying files, before restarting/reloading anything):
#   ./verify-protected-hashes.sh /var/www/devglobaljobs postflight
#   Asserts the NEW final index.html (this package's patched version) is
#   now in place, plus the new Admin assets and all protected files.
#
# Every check below is a hard assertion. Any mismatch, missing file, or
# invalid stage argument causes a non-zero exit and the script prints
# exactly which check failed. Do not proceed with deployment (or consider
# it complete) unless both stages print "VERIFICATION PASSED".

set -euo pipefail
ROOT="${1:?Usage: $0 <webroot> <preflight|postflight>}"
STAGE="${2:?Usage: $0 <webroot> <preflight|postflight>}"

if [ "$STAGE" != "preflight" ] && [ "$STAGE" != "postflight" ]; then
  echo "INVALID STAGE ARGUMENT: '$STAGE' — must be exactly 'preflight' or 'postflight'."
  exit 1
fi

# Adjust these relative paths if your webroot layout differs from
# dist/public/... as referenced by index.html's script/link tags.
declare -A PROTECTED=(
  ["dist/index.cjs"]="2ca247c9c12e49922fba567a05cdc7cdd72799aab2d5fbb645b589986a958186"
  ["dist/dgj-v45-commercial.cjs"]="8cbd1c9084f0d70754e1bbec99c963b64b0255bbd4e0e25b97a8b67bdfdf8e81"
  ["dist/dgj-v46-employer.cjs"]="bc5c4f4088cc434aabe5acfba0c9b521228330775799c55c2e941a95f05b205e"
  ["dist/dgj-v51-recruitment.cjs"]="1308d7d8c44dc91e48866b7747e64ecc4eef27ecdee57ad72868faaae912deba"
  ["dist/public/assets/index-DGJ45auth-v43-youth.js"]="ff420f2b6b88f06f5a9f6c9e3bc2ae88b456bbca5bb6a76b3047992874a909df"
  ["dist/public/assets/dgj-claude-employer-v3.1.js"]="cad0720626baf48f36b65e328bf1bde551c35faf2d43cb558c037543ac8296e7"
  ["dist/public/assets/dgj-claude-employer-v2.css"]="cf32941f8fdf81394b2df8141f2e781ef470dda529627045467d288a4205cf95"
)

# The exact authoritative V70.6.1 baseline index.html — this is what must
# be live BEFORE this package overwrites it. Checked at preflight only.
BASELINE_INDEX_SHA="a557283d1df90760a6707b9c8b8fa6a4534d5be866ca26d7f73cfa90a3f28f3a"

# The new, patched index.html this package installs, plus its new Admin
# assets — checked at postflight only, hard-asserted against exact hashes.
declare -A NEW_ASSETS=(
  ["dist/public/index.html"]="f12dcec0962c5c343548b4789d420ead1c4a22bf282180ac60f547122efaad08"
  ["dist/public/assets/dgj-claude-admin-v1.js"]="3f8c96069c22db729ca53aad8e10b1434a80618e54447d864d032db12f5bc7c2"
  ["dist/public/assets/dgj-claude-admin-v1.css"]="0c23216ecccfd99fe40a6836f4de1c2288563b7bedf2233c0ed5f8a744c181a4"
)

fail=0
check() {
  local rel="$1" expected="$2" f="$ROOT/$1"
  if [ ! -f "$f" ]; then
    echo "MISSING [$STAGE]: $rel (expected sha256 $expected)"
    fail=1
    return
  fi
  local actual
  actual="$(sha256sum "$f" | awk '{print $1}')"
  if [ "$actual" != "$expected" ]; then
    echo "MISMATCH [$STAGE]: $rel"
    echo "  expected: $expected"
    echo "  actual:   $actual"
    fail=1
  else
    echo "OK [$STAGE]: $rel"
  fi
}

for rel in "${!PROTECTED[@]}"; do
  check "$rel" "${PROTECTED[$rel]}"
done

if [ "$STAGE" = "preflight" ]; then
  echo ""
  echo "Asserting the CURRENTLY LIVE index.html is still the authoritative baseline (must be true before this package may overwrite it):"
  check "dist/public/index.html" "$BASELINE_INDEX_SHA"
fi

if [ "$STAGE" = "postflight" ]; then
  echo ""
  echo "Asserting new/changed release assets (hard checks, not advisory):"
  for rel in "${!NEW_ASSETS[@]}"; do
    check "$rel" "${NEW_ASSETS[$rel]}"
  done
fi

if [ "$fail" -ne 0 ]; then
  echo ""
  echo "VERIFICATION FAILED at $STAGE — do not proceed."
  exit 1
fi
echo ""
echo "VERIFICATION PASSED at $STAGE."
