import { Link } from "wouter";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { JobCard, JobCardSkeleton } from "@/components/job-card";
import { Star, ArrowLeft, Briefcase } from "lucide-react";
import type { Job } from "@shared/schema";

export default function AllFeaturedJobs() {
  const { data: featuredEmployerJobs, isLoading } = useQuery<Job[]>({
    queryKey: ["/api/jobs/featured-employer"],
    refetchInterval: 30000,
  });
  useEffect(() => {
    document.title = "Sponsored Jobs | Employer-Promoted Opportunities | Dev Global Jobs";
    const description = "Explore sponsored jobs promoted directly by employers for greater visibility. Discover employer-promoted opportunities across industries, locations and career levels.";
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "description");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", description);
  }, []);
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-6"><Link href="/"><Button variant="outline" size="sm"><ArrowLeft className="h-4 w-4 mr-1.5" />Back to Home</Button></Link></div>
      <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-md shrink-0"><Star className="h-6 w-6 text-white" /></div>
          <div>
            <h1 className="text-2xl font-bold">All Featured Jobs</h1>
            <p className="text-muted-foreground mt-0.5 text-sm">Premium opportunities from top employers worldwide{featuredEmployerJobs && featuredEmployerJobs.length > 0 && <span className="ml-2 text-primary font-semibold">({featuredEmployerJobs.length} listings)</span>}</p>
          </div>
        </div>
        <Link href="/post-job"><Button><Star className="h-4 w-4 mr-1.5" />Post a Featured Job — $25</Button></Link>
      </div>
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">{Array.from({ length: 12 }).map((_, i) => <JobCardSkeleton key={i} />)}</div>
      ) : !featuredEmployerJobs || featuredEmployerJobs.length === 0 ? (
        <Card className="p-16 text-center"><div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-5"><Briefcase className="h-8 w-8 text-muted-foreground" /></div><h3 className="font-bold text-lg mb-2">No featured jobs yet</h3><Link href="/post-job"><Button>Post a Featured Job — $25</Button></Link></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featuredEmployerJobs.map((job) => (
            <div key={job.id} className="relative">
              <div className="absolute -top-2.5 -right-2.5 z-10"><Badge variant="default" className="bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] shadow-lg border-0"><Star className="h-3 w-3 mr-0.5" />Featured</Badge></div>
              <JobCard job={job} isFeatured />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}