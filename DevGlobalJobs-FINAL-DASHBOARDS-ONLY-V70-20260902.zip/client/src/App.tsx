import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import Home from "@/pages/home";
import JobListing from "@/pages/job-listing";
import JobDetail from "@/pages/job-detail";
import AllFeaturedJobs from "@/pages/all-featured-jobs";
import PostJob from "@/pages/post-job";
import PaymentSuccess from "@/pages/payment-success";
import Privacy from "@/pages/privacy";
import Terms from "@/pages/terms";
import About from "@/pages/about";
import Pricing from "@/pages/pricing";
import CountryJobs from "@/pages/country-jobs";
import Universities from "@/pages/universities";
import OnlineCourses from "@/pages/online-courses";
import FreeCertifications from "@/pages/free-certifications";
import Internships from "@/pages/internships";
import Scholarships from "@/pages/scholarships";
import VisaGuide from "@/pages/visa-guide";
import EligibilityChecker from "@/pages/eligibility-checker";
import Volunteers from "@/pages/volunteers";
import SalaryCalculator from "@/pages/tools/salary-calculator";
import NgoSalaryGuide from "@/pages/tools/ngo-salary-guide";
import CostOfLiving from "@/pages/tools/cost-of-living";
import ResumeChecker from "@/pages/tools/resume-checker";
import InterviewPrep from "@/pages/tools/interview-prep";
import CoverLetterGuide from "@/pages/tools/cover-letter";
import WorkPermitGuide from "@/pages/tools/work-permit-guide";
import RemoteWorkTax from "@/pages/tools/remote-work-tax";
import CountrySalaryCalculator from "@/pages/tools/country-salary-calculator";
import AtsKeywords from "@/pages/tools/ats-keywords";
import SalaryNegotiation from "@/pages/tools/salary-negotiation";
import CareerPath from "@/pages/tools/career-path";
import LinkedInOptimizer from "@/pages/tools/linkedin-optimizer";
import Blog from "@/pages/blog";
import BlogArticle from "@/pages/blog-article";
import NotFound from "@/pages/not-found";
import WorkspaceDashboard from "@/pages/workspace-dashboard";
import { useEffect } from "react";
import "./workspace-dashboard.css";

declare global {
  interface Window {
    gtag?: (...args: any[]) => void;
  }
}

function useScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" as ScrollBehavior });
  }, [location]);
}

function usePageTracking() {
  const [location] = useLocation();
  useEffect(() => {
    if (window.gtag) {
      window.gtag("config", "G-P15GRTQEJE", {
        page_path: location,
      });
    }
  }, [location]);
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/jobs/all">{() => <JobListing category="all" />}</Route>
      <Route path="/jobs/un">{() => <JobListing category="un" />}</Route>
      <Route path="/jobs/ngo">{() => <JobListing category="ngo" />}</Route>
      <Route path="/jobs/remote">{() => <JobListing category="remote" />}</Route>
      <Route path="/jobs/international">{() => <JobListing category="international" />}</Route>
      <Route path="/jobs/technology">{() => <JobListing category="technology" />}</Route>
      <Route path="/jobs/healthcare">{() => <JobListing category="healthcare" />}</Route>
      <Route path="/jobs/business">{() => <JobListing category="business" />}</Route>
      <Route path="/jobs/education">{() => <JobListing category="education" />}</Route>
      <Route path="/jobs/engineering">{() => <JobListing category="engineering" />}</Route>
      <Route path="/jobs/creative">{() => <JobListing category="creative" />}</Route>
      <Route path="/jobs/sales">{() => <JobListing category="sales" />}</Route>
      <Route path="/jobs/gig">{() => <JobListing category="gig" />}</Route>
      <Route path="/jobs/sponsored" component={AllFeaturedJobs} />
      <Route path="/jobs/youth">{() => <JobListing category="youth" />}</Route>
      <Route path="/universities" component={Universities} />
      <Route path="/online-courses" component={OnlineCourses} />
      <Route path="/free-certifications" component={FreeCertifications} />
      <Route path="/internships" component={Internships} />
      <Route path="/scholarships" component={Scholarships} />
      <Route path="/visa-guide" component={VisaGuide} />
      <Route path="/eligibility-checker" component={EligibilityChecker} />
      <Route path="/volunteers" component={Volunteers} />
      <Route path="/tools/salary-calculator" component={SalaryCalculator} />
      <Route path="/tools/ngo-salary-guide" component={NgoSalaryGuide} />
      <Route path="/tools/cost-of-living" component={CostOfLiving} />
      <Route path="/tools/resume-checker" component={ResumeChecker} />
      <Route path="/tools/interview-prep" component={InterviewPrep} />
      <Route path="/tools/cover-letter" component={CoverLetterGuide} />
      <Route path="/tools/work-permit-guide" component={WorkPermitGuide} />
      <Route path="/tools/remote-work-tax" component={RemoteWorkTax} />
      <Route path="/tools/country-salary-calculator" component={CountrySalaryCalculator} />
      <Route path="/tools/ats-keywords" component={AtsKeywords} />
      <Route path="/tools/salary-negotiation" component={SalaryNegotiation} />
      <Route path="/tools/career-path" component={CareerPath} />
      <Route path="/tools/linkedin-optimizer" component={LinkedInOptimizer} />
      <Route path="/jobs/country/uk">{() => <CountryJobs slug="uk" />}</Route>
      <Route path="/jobs/country/us">{() => <CountryJobs slug="us" />}</Route>
      <Route path="/jobs/country/canada">{() => <CountryJobs slug="canada" />}</Route>
      <Route path="/jobs/country/australia">{() => <CountryJobs slug="australia" />}</Route>
      <Route path="/jobs/country/germany">{() => <CountryJobs slug="germany" />}</Route>
      <Route path="/jobs/country/france">{() => <CountryJobs slug="france" />}</Route>
      <Route path="/jobs/country/india">{() => <CountryJobs slug="india" />}</Route>
      <Route path="/jobs/country/brazil">{() => <CountryJobs slug="brazil" />}</Route>
      <Route path="/jobs/country/south-africa">{() => <CountryJobs slug="south-africa" />}</Route>
      <Route path="/jobs/country/netherlands">{() => <CountryJobs slug="netherlands" />}</Route>
      <Route path="/jobs/country/poland">{() => <CountryJobs slug="poland" />}</Route>
      <Route path="/jobs/country/italy">{() => <CountryJobs slug="italy" />}</Route>
      <Route path="/jobs/country/belgium">{() => <CountryJobs slug="belgium" />}</Route>
      <Route path="/jobs/country/austria">{() => <CountryJobs slug="austria" />}</Route>
      <Route path="/jobs/country/switzerland">{() => <CountryJobs slug="switzerland" />}</Route>
      <Route path="/jobs/country/new-zealand">{() => <CountryJobs slug="new-zealand" />}</Route>
      <Route path="/jobs/country/singapore">{() => <CountryJobs slug="singapore" />}</Route>
      <Route path="/jobs/detail/:id" component={JobDetail} />
      <Route path="/post-job" component={PostJob} />
      <Route path="/employer" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/dashboard" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/jobs" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/applications" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/analytics" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/boosts" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/billing" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/plans" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/profile" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/settings" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/employer/support" component={() => <WorkspaceDashboard mode="employer" />} />
      <Route path="/admin" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/dashboard" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/jobs" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/employers" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/applications" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/review" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/requests" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/premium" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/revenue" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/reports" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/growth" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/admin/settings" component={() => <WorkspaceDashboard mode="admin" />} />
      <Route path="/payment-success" component={PaymentSuccess} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/terms" component={Terms} />
      <Route path="/about" component={About} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={BlogArticle} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  useScrollToTop();
  usePageTracking();
  const [location] = useLocation();
  const isWorkspace = /^\/(?:employer|admin)(?:\/|$)/.test(location);

  if (isWorkspace) {
    return <Router />;
  }
  return (
    <div className="flex flex-col min-h-screen overflow-x-hidden">
      <Header />
      <main className="flex-1">
        <Router />
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AppContent />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
