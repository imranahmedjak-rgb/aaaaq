import { build } from "esbuild";
import { execSync } from "child_process";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");

// Build client with Vite
console.log("building client...");
execSync("npx vite build", { stdio: "inherit", cwd: root });

// The release server contains production-only route modules that predate the
// editable source tree. Keep that runtime intact while the React frontend is
// rebuilt; replacing it with the small source server silently removes employer,
// recruitment, payment, and admin routes.
const existingRuntime = path.join(root, "dist", "index.cjs");
const preservedRuntime = fs.existsSync(existingRuntime)
  ? fs.readFileSync(existingRuntime)
  : null;
const hasReleaseRoutes = preservedRuntime?.toString("utf8").includes("dgj-v46-employer.cjs");

// Build the source server as a parity check and as a fallback for a fresh
// checkout. A known release runtime remains the serving runtime until the
// source tree exposes the same route surface.
console.log("building server...");
await build({
  entryPoints: [path.join(root, "server/index.ts")],
  bundle: true,
  platform: "node",
  format: "cjs",
  outfile: path.join(root, "dist/index.source.cjs"),
  packages: "external",
  // Tell esbuild NODE_ENV=production so vite dev-server branch is tree-shaken out
  define: {
    "process.env.NODE_ENV": '"production"',
  },
  sourcemap: false,
  minify: false,
});

if (hasReleaseRoutes && preservedRuntime) {
  fs.writeFileSync(existingRuntime, preservedRuntime);
  console.log("preserved production route runtime");
} else {
  fs.renameSync(path.join(root, "dist", "index.source.cjs"), existingRuntime);
}
if (fs.existsSync(path.join(root, "dist", "index.source.cjs"))) {
  fs.unlinkSync(path.join(root, "dist", "index.source.cjs"));
}

console.log("Build complete!");
