#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
P="$HERE/payload/dist/public"
[ -f "$P/index.html" ]
[ -f "$P/assets/dgj-v51-employer.js" ]
[ -f "$P/assets/dgj-v45-commercial.js" ]
node --check "$P/assets/dgj-v51-employer.js" >/dev/null
node --check "$P/assets/dgj-v45-commercial.js" >/dev/null
grep -F 'dgj-v51-employer.js?v=66.0.0' "$P/index.html" >/dev/null
grep -F 'dgj-v45-commercial.js?v=66.0.0' "$P/index.html" >/dev/null
grep -F 'window.__DGJ_V66_NATIVE_EMPLOYER_NAV__' "$P/assets/dgj-v51-employer.js" >/dev/null
grep -F 'public pages intentionally install no employer observer' "$P/assets/dgj-v51-employer.js" >/dev/null
! grep -F 'const mo=new MutationObserver(scheduleEmployerTick)' "$P/assets/dgj-v51-employer.js" >/dev/null
! grep -F 'setInterval(tick,2500)' "$P/assets/dgj-v51-employer.js" >/dev/null
! grep -F 'setInterval(check,300)' "$P/index.html" >/dev/null
grep -F 'bookmarkObserverTimer' "$P/index.html" >/dev/null
grep -F 'lastBoostSignature' "$P/assets/dgj-v45-commercial.js" >/dev/null
echo 'PASS: V66 main-thread stability preflight.'
