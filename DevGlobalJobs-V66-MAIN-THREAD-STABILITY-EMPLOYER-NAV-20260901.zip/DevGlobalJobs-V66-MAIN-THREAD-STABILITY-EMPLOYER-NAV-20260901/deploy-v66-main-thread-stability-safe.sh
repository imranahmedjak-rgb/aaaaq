#!/usr/bin/env bash
set -Eeuo pipefail
APP="/var/www/devglobaljobs"
HERE="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$HERE/payload/dist/public"
BACKUP="/var/backups/devglobaljobs-v66-main-thread-stability-$(date +%Y%m%d-%H%M%S)"

# Exact V64 production baseline currently expected.
V64_IDX="51a5a2592e8d7d3c85a35905c525d113b150f27940a0060abf1900b8295f88a5"
V64_EMP="e4d23e32dbb0ff6fcd406151379021751772110329cbc46f177da97921e71e32"
V64_COMM="a52126b670737e30dd6f929fb6f901d2e66bf99f899d65a22199ce3e0952a801"
V66_IDX="fb965e235f264ea2e968908490ef218c263c21a88a8e18250bf7bed82cddaa7c"
V66_EMP="ddd42715591de7cc6abb6f31826f60c9809b194c73ddc0422e50ab791bfb8798"
V66_COMM="0476e5a72a80392919906fb42a9a04cbebdd111cf0a563989b2efde1ee99a1d9"
REC_JS="25929f0fb7222d83b80661e3369f0ddf0839306772bba87aaca9cd15b67b0304"
REC_CSS="4fd6bc549aa36c3c674404d13c9e0ef0e65de46f23988daf759cce421b021042"
ADMIN_JS="8f463260c08757f95419ea461233315f18f0bbac590b2b287761e7b8e53cc0bf"

fail(){
  echo
  echo '============================================================'
  echo "SAFE STOP: $*"
  if [ -d "$BACKUP" ] && [ -f "$BACKUP/index.html" ]; then
    echo 'ROLLBACK: restoring exact pre-V66 frontend files...'
    cp -af "$BACKUP/index.html" "$APP/dist/public/index.html" || true
    cp -af "$BACKUP/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js" || true
    cp -af "$BACKUP/dgj-v45-commercial.js" "$APP/dist/public/assets/dgj-v45-commercial.js" || true
    echo 'ROLLBACK COMPLETE.'
  fi
  echo 'NO BACKEND, DATABASE, RECRUITMENT, ADMIN ENTERPRISE, PAYMENT BACKEND, SEO, GOOGLE JOBS, PWA OR PM2 CHANGE WAS MADE.'
  echo '============================================================'
  exit 1
}

echo '============================================================'
echo 'DEV GLOBAL JOBS V66'
echo 'MAIN-THREAD STABILITY + EMPLOYER NAVIGATION'
echo 'ZERO-DOWNTIME FRONTEND ATOMIC INSTALL'
echo '============================================================'

echo '1/9 EXACT V64 BASELINE + LIVE HEALTH'
for f in \
  "$APP/dist/public/index.html" \
  "$APP/dist/public/assets/dgj-v51-employer.js" \
  "$APP/dist/public/assets/dgj-v45-commercial.js" \
  "$APP/dist/public/assets/dgj-v51-recruitment.js" \
  "$APP/dist/public/assets/dgj-v51-recruitment.css" \
  "$APP/dist/public/assets/dgj-v57-admin-enterprise.js"; do
  [ -f "$f" ] || fail "missing protected/live file: $f"
done
LIVE_IDX="$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')"
LIVE_EMP="$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')"
LIVE_COMM="$(sha256sum "$APP/dist/public/assets/dgj-v45-commercial.js"|awk '{print $1}')"
[ "$LIVE_IDX" = "$V64_IDX" ] || fail "index is not exact V64 baseline: $LIVE_IDX"
[ "$LIVE_EMP" = "$V64_EMP" ] || fail "employer JS is not exact V64 baseline: $LIVE_EMP"
[ "$LIVE_COMM" = "$V64_COMM" ] || fail "commercial JS differs from protected baseline: $LIVE_COMM"
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')" = "$REC_JS" ] || fail 'recruitment JS differs; refusing unrelated overwrite'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')" = "$REC_CSS" ] || fail 'recruitment CSS differs; refusing unrelated overwrite'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v57-admin-enterprise.js"|awk '{print $1}')" = "$ADMIN_JS" ] || fail 'admin enterprise JS differs; refusing unrelated overwrite'
CODE="$(curl -sS -o /tmp/dgj-v66-before.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "homepage health is $HOME"
echo 'PASS: exact V64 baseline + protected assets + live health verified.'

echo '2/9 PACKAGE PREFLIGHT'
bash "$HERE/preflight-v66.sh" || fail 'V66 preflight failed'
(cd "$PAYLOAD" && sha256sum -c "$HERE/PAYLOAD-SHA256SUMS.txt") || fail 'V66 payload checksum failed'
echo 'PASS: V66 package verified.'

echo '3/9 PRIVATE THREE-FILE ROLLBACK BACKUP'
mkdir -p "$BACKUP"
cp -a "$APP/dist/public/index.html" "$BACKUP/index.html"
cp -a "$APP/dist/public/assets/dgj-v51-employer.js" "$BACKUP/dgj-v51-employer.js"
cp -a "$APP/dist/public/assets/dgj-v45-commercial.js" "$BACKUP/dgj-v45-commercial.js"
echo "Backup: $BACKUP"

echo '4/9 ATOMIC THREE-FILE INSTALL'
install -m 0644 "$PAYLOAD/assets/dgj-v51-employer.js" "$APP/dist/public/assets/dgj-v51-employer.js.v66.tmp"
install -m 0644 "$PAYLOAD/assets/dgj-v45-commercial.js" "$APP/dist/public/assets/dgj-v45-commercial.js.v66.tmp"
install -m 0644 "$PAYLOAD/index.html" "$APP/dist/public/index.html.v66.tmp"
mv -f "$APP/dist/public/assets/dgj-v51-employer.js.v66.tmp" "$APP/dist/public/assets/dgj-v51-employer.js"
mv -f "$APP/dist/public/assets/dgj-v45-commercial.js.v66.tmp" "$APP/dist/public/assets/dgj-v45-commercial.js"
mv -f "$APP/dist/public/index.html.v66.tmp" "$APP/dist/public/index.html"
echo 'PASS: V66 frontend files installed atomically; backend process untouched.'

echo '5/9 EXACT BYTE + PROTECTED-ASSET VERIFICATION'
[ "$(sha256sum "$APP/dist/public/index.html"|awk '{print $1}')" = "$V66_IDX" ] || fail 'installed index hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-employer.js"|awk '{print $1}')" = "$V66_EMP" ] || fail 'installed employer JS hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v45-commercial.js"|awk '{print $1}')" = "$V66_COMM" ] || fail 'installed commercial JS hash mismatch'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.js"|awk '{print $1}')" = "$REC_JS" ] || fail 'protected recruitment JS changed unexpectedly'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v51-recruitment.css"|awk '{print $1}')" = "$REC_CSS" ] || fail 'protected recruitment CSS changed unexpectedly'
[ "$(sha256sum "$APP/dist/public/assets/dgj-v57-admin-enterprise.js"|awk '{print $1}')" = "$ADMIN_JS" ] || fail 'protected admin enterprise JS changed unexpectedly'
echo 'PASS: exact V66 bytes + protected assets verified.'

echo '6/9 ORIGIN CONTRACT — NO PM2 RELOAD'
IDX="$(curl -fsS --max-time 15 http://127.0.0.1:8080/)" || fail 'origin homepage fetch failed'
printf '%s' "$IDX" | grep -F 'dgj-v51-employer.js?v=66.0.0' >/dev/null || fail 'origin index missing V66 employer cache reference'
printf '%s' "$IDX" | grep -F 'dgj-v45-commercial.js?v=66.0.0' >/dev/null || fail 'origin index missing V66 commercial cache reference'
EMP="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v51-employer.js)" || fail 'origin employer JS fetch failed'
printf '%s' "$EMP" | grep -F 'window.__DGJ_V66_NATIVE_EMPLOYER_NAV__' >/dev/null || fail 'origin employer JS missing V66 nav marker'
printf '%s' "$EMP" | grep -F 'public pages intentionally install no employer observer' >/dev/null || fail 'origin employer JS missing V66 stability marker'
if printf '%s' "$EMP" | grep -F 'setInterval(tick,2500)' >/dev/null; then fail 'old employer tick interval still present'; fi
if printf '%s' "$EMP" | grep -F 'new MutationObserver(scheduleEmployerTick)' >/dev/null; then fail 'old employer mutation observer still present'; fi
COMM="$(curl -fsS --max-time 15 http://127.0.0.1:8080/assets/dgj-v45-commercial.js)" || fail 'origin commercial JS fetch failed'
printf '%s' "$COMM" | grep -F 'lastBoostSignature' >/dev/null || fail 'origin commercial JS missing V66 scan limiter'
echo 'PASS: origin serves V66 immediately without backend restart.'

echo '7/9 FINAL API + HOME HEALTH'
CODE="$(curl -sS -o /tmp/dgj-v66-after.json -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/api/v51/config || true)"
[ "$CODE" = '200' ] || fail "post-install API health is $CODE"
HOME="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 http://127.0.0.1:8080/ || true)"
[ "$HOME" = '200' ] || fail "post-install homepage health is $HOME"
echo 'PASS: backend + homepage healthy.'

echo '8/9 PM2 NON-RESTART CONTRACT'
pm2 pid devglobaljobs >/tmp/dgj-v66-pid.txt 2>/dev/null || true
pm2 status | sed -n '1,20p'
echo 'PASS: deployment script issued no PM2 restart/reload command.'

echo '9/9 FINAL SCOPE'
echo '============================================================'
echo 'SUCCESS: V66 MAIN-THREAD STABILITY + EMPLOYER NAV IS LIVE'
echo '============================================================'
echo '✓ Removed document-wide Employer MutationObserver'
echo '✓ Removed recurring Employer tick polling'
echo '✓ Removed legacy 300ms same-URL auth reload loop'
echo '✓ Debounced saved-jobs/profile matching DOM work'
echo '✓ Debounced/rate-limited commercial Boost DOM/API scans'
echo '✓ Employer navigation uses native browser routes'
echo '✓ Employer/Post-a-Job API read timeouts retained'
echo '✓ Employer layout V64 rules retained'
echo '✓ Recruitment/Easy Apply protected and unchanged'
echo '✓ Admin enterprise asset protected and unchanged'
echo '✓ Backend/database/payment backend/SEO/Google Jobs/PWA unchanged'
echo '✓ Website remained served; no PM2 reload/restart performed'
echo "Rollback backup: $BACKUP"
echo '============================================================'
