DEV GLOBAL JOBS V66
MAIN-THREAD STABILITY + EMPLOYER NAVIGATION

Purpose
- Stop Chrome Page Unresponsive conditions caused by unbounded/global DOM observation and aggressive polling.
- Keep the Employer Dashboard and Post-a-Job workspace responsive.
- Preserve V65 native employer navigation and timeout protections.

Root causes addressed
1. Employer JS previously observed the entire document on every child mutation and ran a full tick; V64 did this synchronously. Removed from V66.
2. Employer JS polling loop removed. Employer work now boots only on employer/post-job/admin/legal routes that need it.
3. Legacy auth-route bridge polled every 300 ms and could assign the browser to the exact same URL. Removed.
4. Saved-jobs/matching DOM observer is debounced and excluded from Employer/Admin workspace routes.
5. Commercial boost scanning is debounced and repeat API scans are rate-limited by job-set signature.
6. Global description textarea scans are now route-gated and slower.
7. Noncritical profile/legal route polling reduced.

Production payload
- dist/public/index.html
- dist/public/assets/dgj-v51-employer.js
- dist/public/assets/dgj-v45-commercial.js

Not changed
- Backend server code
- Database/schema
- Recruitment/Easy Apply JS or CSS
- Admin enterprise asset
- Payments backend/business rules
- SEO schema/content
- Google Jobs implementation
- PWA/service worker
- PM2 process
